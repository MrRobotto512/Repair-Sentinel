## 2026-11-08 19:31
a ddns dynamic ip address updater client that works with no-ip.com services so Ip address updates can be sent to update a ddns. 

the app should have user configurable setting for the ddns service. there should be an auto-update toggle with user configurable interval setting. there should be a manual update button. there should be a "last sync time stamp". there should be a status window. settings should be remembers when the app closes and reopens. the configurable setting should be in a pane on the left side of the app and the status window should be on the right side

create a DASHBOARD PAGE that can view and change the settings and that has a status window.

