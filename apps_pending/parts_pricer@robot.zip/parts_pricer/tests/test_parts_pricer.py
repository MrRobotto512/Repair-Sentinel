#!/usr/bin/env python3
"""Unit tests for Parts Pricer — no network, no Tk, no dashboard.

    python3 tests/test_parts_pricer.py

Covers the parsers (against saved MobileSentrix markup), the search
matching, the pricing math, the SQLite store, the CSV import and the
dashboard renderers (with a fake ctx)."""

import io
import json
import os
import shutil
import sys
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)

import pp_pricing as pricing      # noqa: E402
import pp_search as search        # noqa: E402
import pp_sentrix as sx           # noqa: E402
import pp_store as store          # noqa: E402
import pp_worker as worker        # noqa: E402
import web                        # noqa: E402


def fx(name):
    with open(os.path.join(HERE, "fixtures", name), encoding="utf-8") as f:
        return f.read()


# --------------------------------------------------------------------------- #
class ParserTests(unittest.TestCase):
    def test_listing(self):
        items = sx.parse_listing(fx("listing_iphone13.html"))
        self.assertEqual([p["pid"] for p in items], ["240864", "250138", "134906", "146643"])
        lcd = items[0]
        self.assertEqual(lcd["name"], "LCD Assembly For iPhone 13 (Aftermarket / Incell)")
        self.assertEqual(lcd["path"], "lcd-assembly-for-iphone-13-aftermarket-incell")
        self.assertEqual(lcd["price"], 16.74)
        self.assertTrue(lcd["in_stock"])
        self.assertEqual(lcd["qty"], 218)
        self.assertEqual(lcd["quality"], "Aftermarket")
        self.assertTrue(lcd["all_colors"])
        oled = items[1]
        self.assertFalse(oled["in_stock"])
        self.assertEqual(oled["price"], 26.07)
        self.assertEqual(oled["quality"], "Aftermarket Plus")
        batt = items[2]
        self.assertEqual(batt["price"], 8.49, "special price wins over old price")
        self.assertEqual(batt["quality"], "Premium")
        self.assertEqual(batt["qty"], 1200)
        film = items[3]
        self.assertEqual(film["name"], 'Screen Protective Film Sheet For 6.1" iPhone 13 / 13 Pro (100 Pack)')
        self.assertFalse(film["in_stock"], "qty 0 means out of stock")
        self.assertEqual(film["quality"], "")

    def test_listing_empty(self):
        self.assertEqual(sx.parse_listing("<html><body>nothing</body></html>"), [])

    def test_product(self):
        info = sx.parse_product(fx("product_lcd13.html"))
        self.assertEqual(info["sku"], "107282226250")
        self.assertEqual(info["price"], 16.74)
        self.assertTrue(info["in_stock"])
        self.assertIn("iPhone 13", info["name"])

    def test_product_fallback(self):
        info = sx.parse_product('<span id="product-price-1"> $12.50 </span>')
        self.assertEqual(info["price"], 12.5)

    def test_model_index(self):
        models = sx.parse_model_index(fx("home_menu.html"))
        paths = [m["path"] for m in models]
        self.assertIn("replacement-parts/apple/iphone-parts/iphone-13", paths)
        self.assertIn("game-console-parts/sony/playstation-5-ps5", paths)
        self.assertNotIn("accessories/cables", paths)
        self.assertNotIn("customer/account/login", paths)
        self.assertNotIn("replacement-parts/apple", paths, "brand page is not a model")
        self.assertNotIn("replacement-parts/apple/iphone-parts", paths, "family page is not a model")
        self.assertEqual(paths.count("replacement-parts/apple/iphone-parts/iphone-13"), 1, "dedup")
        names = {m["path"]: m["name"] for m in models}
        self.assertTrue(names["replacement-parts/apple/iphone-parts/iphone-17-air"].startswith("iPhone Air"))
        self.assertNotIn("View all models", names.values())
        ip13 = next(m for m in models if m["path"].endswith("/iphone-13"))
        self.assertEqual((ip13["brand"], ip13["family"], ip13["depth"]), ("apple", "iphone-parts", 4))
        ps5 = next(m for m in models if m["path"].endswith("playstation-5-ps5"))
        self.assertEqual((ps5["brand"], ps5["family"]), ("sony", "sony"))

    def test_challenge_detection(self):
        self.assertTrue(sx.is_challenge("<html><head><title>Just a moment...</title>"))
        self.assertTrue(sx.is_challenge('<script src="https://challenges.cloudflare.com/x.js">'))
        self.assertFalse(sx.is_challenge(fx("listing_iphone13.html")))


# --------------------------------------------------------------------------- #
MODELS = None


def models():
    global MODELS
    if MODELS is None:
        MODELS = sx.parse_model_index(fx("home_menu.html"))
    return MODELS


class SearchTests(unittest.TestCase):
    def best(self, q):
        r = search.match_models(q, models())
        return r[0][0]["name"] if r else None

    def test_tokenize(self):
        self.assertEqual(search.tokenize("iPhone13 Pro-Max screen"), ["iphone", "13", "pro", "max", "screen"])
        self.assertEqual(search.tokenize("ip 13 promax"), ["iphone", "13", "pro", "max"])
        self.assertEqual(search.tokenize("s23+ battery"), ["s23", "plus", "battery"])
        self.assertEqual(search.tokenize('iPad Pro 12.9" 5th Gen'), ["ipad", "pro", "12.9", "5th", "gen"])
        self.assertEqual(search.tokenize("a2991 13promax"), ["a2991", "13", "pro", "max"])

    def test_model_specificity(self):
        self.assertEqual(self.best("iphone 13 pro max screen"), "iPhone 13 Pro Max")
        self.assertEqual(self.best("iphone 13 pro screen"), "iPhone 13 Pro")
        self.assertEqual(self.best("iphone 13 screen"), "iPhone 13")
        self.assertEqual(self.best("iphone 13 mini battery"), "iPhone 13 Mini")
        self.assertEqual(self.best("ip13 promax lcd"), "iPhone 13 Pro Max")

    def test_samsung_and_consoles(self):
        self.assertEqual(self.best("galaxy s23 ultra screen"), "Galaxy S23 Ultra")
        self.assertEqual(self.best("s23 ultra screen"), "Galaxy S23 Ultra")
        self.assertEqual(self.best("s23 battery"), "Galaxy S23")
        self.assertEqual(self.best("s23 fe screen"), "Galaxy S23 FE")
        self.assertEqual(self.best("a15 screen"), "Galaxy A15 5G (A156)")
        self.assertEqual(self.best("pixel 8 battery"), "Pixel 8")
        self.assertEqual(self.best("ps5 hdmi port"), "PlayStation 5")
        self.assertEqual(self.best("playstation 5 slim hdmi"), "PlayStation 5 Slim")
        self.assertEqual(self.best("switch oled screen"), "Switch OLED")

    def test_codes(self):
        self.assertEqual(self.best("a2991 screen"), 'MacBook Pro 16" A2991 (2023) M3 Pro / M3 Max')
        self.assertEqual(self.best("macbook pro 16 2023 keyboard"), 'MacBook Pro 16" A2991 (2023) M3 Pro / M3 Max')

    def test_no_match(self):
        self.assertEqual(search.match_models("toaster", models()), [])
        self.assertEqual(search.match_models("", models()), [])

    def test_part_filter_and_parts(self):
        r = search.match_models("iphone 13 screen", models())
        words = search.part_filter("iphone 13 screen", r[0][2])
        self.assertEqual(words, ["screen"])
        items = sx.parse_listing(fx("listing_iphone13.html"))
        hits = search.match_parts(words, items)
        names = [p["name"] for p, _ in hits]
        self.assertEqual(names[0], "LCD Assembly For iPhone 13 (Aftermarket / Incell)",
                         "in-stock assembly outranks the out-of-stock one and the film")
        self.assertIn("OLED Assembly For iPhone 13 (Aftermarket Plus: Hard)", names)
        self.assertNotIn("Replacement Battery With Adhesive For iPhone 13 (AmpSentrix)", names)
        self.assertEqual(names[-1], 'Screen Protective Film Sheet For 6.1" iPhone 13 / 13 Pro (100 Pack)')
        hits = search.match_parts(["battery"], items)
        self.assertEqual(len(hits), 1)
        self.assertEqual(search.match_parts(["hdmi"], items), [])
        self.assertEqual(len(search.match_parts([], items)), 4)

    def test_sheet_match(self):
        rows = [{"device": "iPhone 13", "repair": "Screen", "price": 99},
                {"device": "iPhone 13 Pro", "repair": "Screen", "price": 149},
                {"device": "iPhone 13", "repair": "Battery", "price": 69},
                {"device": "Galaxy S23 Ultra", "repair": "Charging port", "price": 89}]
        hit = search.match_sheet("iphone 13 screen", rows)
        self.assertEqual([r["price"] for r, _ in hit], [99])
        hit = search.match_sheet("iphone 13 pro lcd", rows)
        self.assertEqual([r["price"] for r, _ in hit], [149])
        hit = search.match_sheet("s23 ultra charge port", rows)
        self.assertEqual([r["price"] for r, _ in hit], [89])
        self.assertEqual(search.match_sheet("iphone 13 camera", rows), [])


# --------------------------------------------------------------------------- #
class PricingTests(unittest.TestCase):
    def test_defaults(self):
        bd = pricing.quote(16.74, {})
        # 16.74 + 60% (10.04) + 45 = 71.78 -> up to next $5 = 75
        self.assertEqual(bd["markup_amt"], 10.04)
        self.assertEqual(bd["subtotal"], 71.78)
        self.assertEqual(bd["price"], 75.0)
        self.assertEqual(bd["margin"], 58.26)

    def test_rounding(self):
        self.assertEqual(pricing.round_price(71.78, 0), 71.78)
        self.assertEqual(pricing.round_price(71.78, 5), 75.0)
        self.assertEqual(pricing.round_price(75.0, 5), 75.0)
        self.assertEqual(pricing.round_price(71.78, 10), 80.0)
        self.assertEqual(pricing.round_price(71.78, 9), 79.0)
        self.assertEqual(pricing.round_price(49.0, 9), 49.0)
        self.assertEqual(pricing.round_price(49.2, 9), 59.0)

    def test_settings_and_rates(self):
        s = pricing.clean_settings({"markup_pct": "80", "labor": "30", "round_to": "0",
                                    "min_price": "40", "labor_overrides": {"Back Glass": "70"}})
        self.assertEqual([(r["part"], r["labor"]) for r in s["labor_rates"]], [("back glass", 70.0)],
                         "v1.0 overrides migrate into part-only rates")
        bd = pricing.quote(5, s, "Back Glass Cover For iPhone 13", "iPhone 13")
        self.assertEqual((bd["labor"], bd["labor_name"]), (70.0, "Back Glass"))
        self.assertEqual(bd["price"], 79.0)            # 5 + 4 + 70 = 79, no rounding
        bd = pricing.quote(1, s, "SIM Tray")
        self.assertEqual(bd["price"], 40.0, "minimum price applies")
        s = pricing.clean_settings({"round_to": "7", "markup_pct": "abc"})
        self.assertEqual((s["round_to"], s["markup_pct"]), (5, 60.0), "bad values fall back")

    def test_rate_specificity(self):
        s = pricing.clean_settings({"labor": 45, "labor_rates": [
            {"id": "a", "name": "Screen", "part": "screen", "labor": 60},
            {"id": "b", "name": "iPad screen", "model": "ipad", "part": "screen", "labor": 100},
            {"id": "c", "name": "Fold anything", "model": "galaxy fold", "labor": 150},
            {"id": "d", "name": "PS5 HDMI", "model": "ps5", "part": "hdmi", "labor": 120},
        ]})
        lab, r = pricing.pick_labor("LCD Assembly For iPhone 13", s, "iPhone 13")
        self.assertEqual((lab, r["id"]), (60.0, "a"))
        lab, r = pricing.pick_labor("LCD Assembly For iPad Pro 12.9", s, 'iPad Pro 12.9" 5th Gen (2021)')
        self.assertEqual((lab, r["id"]), (100.0, "b"), "model+part beats part-only")
        lab, r = pricing.pick_labor("Battery For Galaxy Z Fold 5", s, "Galaxy Z Fold 5")
        self.assertEqual((lab, r["id"]), (150.0, "c"), "model-only rate")
        lab, r = pricing.pick_labor("HDMI Port Connector For PlayStation 5", s, "PlayStation 5")
        self.assertEqual((lab, r["id"]), (120.0, "d"), "ps5 shorthand matches PlayStation 5")
        lab, r = pricing.pick_labor("SIM Tray For iPhone 13", s, "iPhone 13")
        self.assertEqual((lab, r), (45.0, None), "default when nothing fits")
        bd = pricing.quote(10, s, "LCD Assembly For iPhone 13", "iPhone 13", labor="75", labor_name="Custom")
        self.assertEqual((bd["labor"], bd["labor_name"]), (75.0, "Custom"), "dropdown override wins")
        self.assertIsNone(pricing.clean_rate({"name": "x"}), "a rate needs a labor amount")
        self.assertIsNone(pricing.clean_rate({"labor": 5}), "a rate needs a name/model/part")


# --------------------------------------------------------------------------- #
class StoreTests(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp(prefix="pp_")

    def tearDown(self):
        shutil.rmtree(self.d, ignore_errors=True)

    def test_models_products_roundtrip(self):
        total, new = store.replace_model_index(self.d, models())
        self.assertGreater(total, 10)
        self.assertEqual(new, total)
        total2, new2 = store.replace_model_index(self.d, models())
        self.assertEqual(new2, 0)
        path = "replacement-parts/apple/iphone-parts/iphone-13"
        self.assertIsNone(store.get_model(self.d, path)["fetched_at"])
        items = sx.parse_listing(fx("listing_iphone13.html"))
        store.replace_products(self.d, path, items)
        m = store.get_model(self.d, path)
        self.assertIsNotNone(m["fetched_at"])
        self.assertEqual(m["product_count"], 4)
        self.assertEqual(len(store.products_for(self.d, path)), 4)
        self.assertEqual(store.get_product(self.d, "240864")["price"], 16.74)
        store.update_product_live(self.d, "240864", 17.5, False, "SKU1")
        p = store.get_product(self.d, "240864")
        self.assertEqual((p["price"], p["in_stock"], p["sku"]), (17.5, 0, "SKU1"))
        st = store.stats(self.d)
        self.assertEqual((st["cached"], st["products"]), (1, 4))
        self.assertEqual(len(store.stale_models(self.d, 0)), 1)
        self.assertEqual(len(store.stale_models(self.d, 1)), 0)
        store.forget_model(self.d, path)
        self.assertEqual(store.products_for(self.d, path), [])
        fams = store.families(self.d)
        self.assertIn(("apple", "iphone-parts", 5, 0), fams)

    def test_sheet_import(self):
        csv_text = "Device,Repair,Price,Note\niPhone 13,Screen,$99.00,aftermarket\niPhone 13,Battery,69,\nbad,,x\n"
        n, skipped, msg = store.import_sheet_csv(self.d, csv_text)
        self.assertEqual((n, skipped), (2, 1))
        rows = store.sheet_rows(self.d)
        self.assertEqual([(r["device"], r["repair"], r["price"]) for r in rows],
                         [("iPhone 13", "Battery", 69.0), ("iPhone 13", "Screen", 99.0)])
        # headerless + tabs + BOM + replace
        n, _s, _m = store.import_sheet_csv(self.d, "﻿Galaxy S23\tCharging port\t89\n", replace=True)
        self.assertEqual(n, 1)
        self.assertEqual(len(store.sheet_rows(self.d)), 1)
        # alternate header names
        n, _s, _m = store.import_sheet_csv(self.d, "Model;Service;Retail Price\nPixel 8;Screen;129\n")
        self.assertEqual(n, 1)
        self.assertIn("Pixel 8", store.sheet_csv(self.d))
        store.sheet_add(self.d, "PS5", "HDMI port", "149.5")
        self.assertEqual(len(store.sheet_rows(self.d)), 3)
        store.sheet_clear(self.d)
        self.assertEqual(store.sheet_rows(self.d), [])
        self.assertEqual(store.import_sheet_csv(self.d, "")[0], 0)

    def test_quotes(self):
        qid = store.add_quote(self.d, "iPhone 13", "LCD Assembly", "240864", 16.74, 75, {"x": 1})
        q = store.get_quote(self.d, qid)
        self.assertEqual((q["model"], q["price"]), ("iPhone 13", 75.0))
        self.assertIn("LCD Assembly", store.quotes_csv(self.d))
        self.assertEqual(store.stats(self.d)["quotes_today"], 1)
        store.delete_quote(self.d, qid)
        self.assertEqual(store.quotes(self.d), [])

    def test_kv(self):
        self.assertEqual(store.kv_get(self.d, "settings", {}), {})
        store.kv_set(self.d, "settings", {"labor": 45})
        self.assertEqual(store.kv_get(self.d, "settings"), {"labor": 45})


# --------------------------------------------------------------------------- #
class _Req:
    def __init__(self, method="GET", args=None, form=None, files=None):
        self.method = method
        self.args = args or {}
        self.form = _Form(form or {})
        self.files = files or {}


class _Form(dict):
    def getlist(self, k):
        v = self.get(k)
        return v if isinstance(v, list) else ([v] if v is not None else [])


class _Ctx:
    def __init__(self, app_dir, path="", req=None):
        self.app_dir = app_dir
        self.path = path
        self.request = req or _Req()
        self.name = "parts_pricer"
        self.meta = {}

    def url(self, sub=""):
        return "/x/parts_pricer/" + sub.lstrip("/")


class WebTests(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp(prefix="pp_")
        store.replace_model_index(self.d, models())
        store.replace_products(self.d, "replacement-parts/apple/iphone-parts/iphone-13",
                               sx.parse_listing(fx("listing_iphone13.html")))
        store.import_sheet_csv(self.d, "device,repair,price\niPhone 13,Battery,69\n")
        # never let the worker thread start / touch the network in tests
        worker.ensure_threads = lambda app_dir: None
        worker._push = lambda job, path=None: False
        worker.enqueue_model = lambda app_dir, path, name="": False
        worker.enqueue_index = lambda app_dir: False

    def tearDown(self):
        shutil.rmtree(self.d, ignore_errors=True)

    def test_search_page_renders(self):
        page = web.handle(_Ctx(self.d, "", _Req(args={"q": "iphone 13 screen"})))
        self.assertIsInstance(page, str)
        self.assertIn("LCD Assembly For iPhone 13", page)
        self.assertIn("$75.00", page, "16.74 -> 75 with default rules")
        self.assertIn("data-act='quote'", page)
        self.assertIn("open model page", page)
        self.assertNotIn("data-poll='1'", page)

    def test_sheet_first(self):
        frag, poll = web.render_results(self.d, _Ctx(self.d).url, "iphone 13 battery")
        self.assertIn("On your price sheet", frag)
        self.assertIn("$69.00", frag)
        self.assertIn("Replacement Battery With Adhesive", frag)
        self.assertLess(frag.index("On your price sheet"), frag.index("MobileSentrix"))
        self.assertFalse(poll)

    def test_uncached_model_polls(self):
        frag, poll = web.render_results(self.d, _Ctx(self.d).url, "iphone 13 pro max screen")
        self.assertTrue(poll)
        self.assertIn("data-poll", frag)
        self.assertIn("iPhone 13 Pro Max", frag)

    def test_ipad_query(self):
        r = search.match_models("ipad pro 12.9 5th gen screen", models())
        self.assertEqual(r[0][0]["name"], 'iPad Pro 12.9" 5th Gen (2021)')
        self.assertEqual(search.part_filter("ipad pro 12.9 5th gen screen", r[0][2]), ["screen"])

    def test_failed_fetch_is_not_retried_automatically(self):
        path = "replacement-parts/apple/iphone-parts/iphone-13-pro"
        store.set_model_status(self.d, path, "error", "Cloudflare browser check")
        calls = []
        worker.enqueue_model = lambda app_dir, p, name="": calls.append(p) or False
        frag, poll = web.render_results(self.d, _Ctx(self.d).url, "iphone 13 pro screen")
        self.assertIn("Try again", frag)
        self.assertIn("Cloudflare browser check", frag)
        self.assertFalse(poll)
        self.assertEqual(calls, [], "no automatic re-fetch after a failure")

    def test_no_model_falls_back_to_site_search(self):
        calls = []
        worker.enqueue_model = lambda app_dir, p, name="": calls.append(p) or False
        frag, poll = web.render_results(self.d, _Ctx(self.d).url, "x218 lcd")
        self.assertIn("site search", frag)
        self.assertTrue(poll)
        self.assertEqual(calls, ["search/x218-lcd"])
        row = store.get_model(self.d, "search/x218-lcd")
        self.assertEqual(row["brand"], "search")
        self.assertEqual(sx.search_query("search/x218-lcd"), "x218 lcd")
        self.assertIn("q=x218+lcd", sx.search_url("x218 lcd"))
        self.assertIn("&p=2", sx.search_url("x218 lcd", 2))
        # results arrive (names carry the real model) -> "looks like" chips
        store.replace_products(self.d, "search/x218-lcd", [
            {"pid": "9001", "name": 'LCD Assembly Without Frame For Samsung Galaxy Tab A9 Plus 11.0" (X210 / X215 / X218) (2023) (Refurbished) (Black)',
             "path": "lcd-tab-a9-plus", "price": 36.87, "in_stock": True, "qty": 5, "quality": "Refurbished"},
            {"pid": "9002", "name": "LCD Assembly Without Frame For Realme C11 (2020) / C12 / C15 (Refurbished)",
             "path": "lcd-realme", "price": 14.60, "in_stock": True, "qty": 5, "quality": ""},
        ])
        store.replace_model_index(self.d, models() + [
            {"path": "replacement-parts/samsung/tab-a-series/tab-a9-plus", "name": 'Tab A9 Plus 11.0" (2023)',
             "brand": "samsung", "family": "tab-a-series", "depth": 4}])
        frag, poll = web.render_results(self.d, _Ctx(self.d).url, "x218 lcd")
        self.assertFalse(poll)
        self.assertIn("Tab A9 Plus", frag)
        self.assertIn("looks like:", frag)
        self.assertIn("$36.87", frag)
        self.assertNotIn("search/x218-lcd", [m["path"] for m in store.stale_models(self.d, 0)],
                         "site searches are never refreshed overnight")
        self.assertEqual(store.stats(self.d)["cached"], 1, "pseudo-models don't count as cached models")
        # forcing the site search even when a model would match
        frag, poll = web.render_results(self.d, _Ctx(self.d).url, "site: iphone 13 screen")
        self.assertIn("site search", frag)
        frag, poll = web.render_results(self.d, _Ctx(self.d).url, "iphone 13 screen")
        self.assertIn("data-q='site: iphone 13 screen'", frag)

    def test_categories_default_to_screens(self):
        u = _Ctx(self.d).url
        frag, _ = web.render_results(self.d, u, "iphone 13")
        self.assertIn("LCD Assembly", frag)
        self.assertIn("OLED Assembly", frag)
        self.assertNotIn("Protective Film", frag, "accessories stay out of Screens")
        self.assertNotIn("Replacement Battery", frag)
        self.assertIn("data-cat='screen'", frag)
        self.assertIn("class='on' data-cat='screen'", frag)
        self.assertIn("data-cat='battery'", frag)
        frag, _ = web.render_results(self.d, u, "iphone 13", cat="battery")
        self.assertIn("Replacement Battery", frag)
        self.assertNotIn("LCD Assembly", frag)
        frag, _ = web.render_results(self.d, u, "iphone 13", cat="all")
        self.assertIn("Protective Film", frag)
        frag, _ = web.render_results(self.d, u, "iphone 13 screen")
        self.assertIn("LCD Assembly", frag)
        self.assertNotIn("Protective Film", frag, "a 'screen' query is narrowed to real screens")
        frag, _ = web.render_results(self.d, u, "iphone 13 battery")
        self.assertIn("Replacement Battery", frag)
        self.assertNotIn("LCD Assembly", frag)
        frag, _ = web.render_results(self.d, u, "iphone 13 film")
        self.assertIn("Protective Film", frag, "words with no category still work")
        frag, _ = web.render_results(self.d, u, "iphone 13 screen", cat="battery")
        self.assertIn("Replacement Battery", frag, "a tapped tab wins over the typed part")
        self.assertEqual(search.category_of("Screen Protective Film Sheet"), "other")
        self.assertEqual(search.detect_category(["back", "glass"]), "back")
        self.assertEqual(search.detect_category(["screen"]), "screen")

    def test_frag_and_api(self):
        r = web.handle(_Ctx(self.d, "frag", _Req(args={"q": "iphone 13 screen"})))
        self.assertIn("LCD Assembly", r.get_data(as_text=True))
        j = web.handle(_Ctx(self.d, "api/quote", _Req("POST", form={"pid": "240864", "q": "iphone 13 screen"})))
        self.assertEqual(j["price"], 75.0)
        self.assertEqual(store.stats(self.d)["quotes"], 1)
        j = web.handle(_Ctx(self.d, "api/quote", _Req("POST", form={"pid": "nope"})))
        self.assertIn("error", j)
        j = web.handle(_Ctx(self.d, "api/status", _Req()))
        self.assertIn("stats", j)

    def test_settings_roundtrip(self):
        r = web.handle(_Ctx(self.d, "settings", _Req("POST", args={"a": "save"}, form={
            "markup_pct": "100", "labor": "30", "round_to": "9", "min_price": "0",
            "tax_note": "+ tax"})))
        self.assertEqual(r.status_code, 302)
        s = store.kv_get(self.d, "settings")
        self.assertEqual((s["markup_pct"], s["labor"], s["round_to"]), (100.0, 30.0, 9))
        ok, err = web.settings_action(self.d, "add_rate", _Form({"name": "Screen", "part": "screen", "labor": "60"}))
        self.assertEqual(err, "")
        ok, err = web.settings_action(self.d, "add_rate", _Form({"name": "", "part": "", "labor": ""}))
        self.assertTrue(err)
        page = web.render_settings(self.d, _Ctx(self.d).url)
        self.assertIn("Screen", page)
        self.assertIn("$60.00", page)
        self.assertEqual(store.kv_get(self.d, "settings")["labor"], 30.0, "adding a rate keeps the rest")
        frag, _ = web.render_results(self.d, _Ctx(self.d).url, "iphone 13 lcd")
        self.assertIn("$99.00", frag)     # 16.74*2 + 60 = 93.48 -> ends in 9 = 99
        self.assertIn("select class='labor'", frag)
        self.assertIn("Default labor — $30.00", frag)
        self.assertIn("Custom…", frag)
        rid = store.kv_get(self.d, "settings")["labor_rates"][0]["id"]
        self.assertIn(f"value='{rid}' data-labor='60' data-name='Screen' selected", frag)
        # quoting with the dropdown's labor
        j = web.handle(_Ctx(self.d, "api/quote", _Req("POST", form={"pid": "240864", "labor": "45", "labor_name": "custom"})))
        self.assertEqual(j["price"], 79.0)    # 33.48 + 45 = 78.48 -> 79
        web.settings_action(self.d, "del_rate", _Form({"id": rid}))
        self.assertEqual(store.kv_get(self.d, "settings")["labor_rates"], [])
        ok, err = web.settings_action(self.d, "starter_rates", _Form({}))
        self.assertGreaterEqual(len(store.kv_get(self.d, "settings")["labor_rates"]), 7)

    def test_sheet_and_quotes_pages(self):
        page = web.render_sheet(self.d, _Ctx(self.d).url)
        self.assertIn("iPhone 13", page)
        store.add_quote(self.d, "iPhone 13", "LCD Assembly For iPhone 13 (Aftermarket / Incell)", "240864", 16.74, 75, {})
        page = web.render_quotes(self.d, _Ctx(self.d).url)
        self.assertIn("LCD Assembly", page)
        qid = store.quotes(self.d)[0]["id"]
        ok, err = web.quotes_action(self.d, "tosheet", {"id": qid})
        self.assertEqual(err, "")
        rows = store.sheet_rows(self.d)
        self.assertTrue(any(r["repair"] == "Screen" and r["price"] == 75 for r in rows))
        csv_r = web.handle(_Ctx(self.d, "sheet", _Req(args={"a": "export"})))
        self.assertIn("Screen", csv_r.get_data(as_text=True))

    def test_crawl_page(self):
        store.kv_set(self.d, "last_diag", {"at": time.time(),
                     "requests": {"status": 403, "bytes": 5000, "challenge": True, "model_links": 0, "title": "Just a moment..."},
                     "chromium": {"binary": "/usr/bin/chromium", "bytes": 1185000, "challenge": False, "model_links": 2988, "seconds": 9.2}})
        page = web.render_crawl(self.d, _Ctx(self.d).url)
        self.assertIn("cached models", page)
        self.assertIn("Cloudflare challenge", page)
        self.assertIn("2988 models found", page)
        self.assertIn("Connection test", page)
        self.assertIn("iPhone 13", page)
        ok, err = web.crawl_action(self.d, "auto", _Form({"auto": "0", "stale_days": "5",
                                                          "night_start": "1", "night_end": "5"}))
        self.assertEqual(store.kv_get(self.d, "crawl")["stale_days"], 5)
        self.assertFalse(store.kv_get(self.d, "crawl")["auto"])
        ok, err = web.crawl_action(self.d, "forget", _Form({"path": "replacement-parts/apple/iphone-parts/iphone-13"}))
        self.assertEqual(store.stats(self.d)["cached"], 0)


# --------------------------------------------------------------------------- #
class BrowserTests(unittest.TestCase):
    """Real headless Chromium over CDP against a local server (skipped when
    no Chromium / websockets is around)."""

    def test_raw_html_through_chromium(self):
        import pp_browser as b
        try:
            import websockets  # noqa: F401
        except ImportError:
            self.skipTest("websockets not installed")
        if not b.available():
            self.skipTest("no chromium binary (set PP_CHROMIUM)")
        import functools
        import http.server
        import socketserver
        import threading
        handler = functools.partial(http.server.SimpleHTTPRequestHandler,
                                    directory=os.path.join(HERE, "fixtures"))
        socketserver.TCPServer.allow_reuse_address = True
        srv = socketserver.TCPServer(("127.0.0.1", 0), handler)
        port = srv.server_address[1]
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            base = f"http://127.0.0.1:{port}/home_menu.html"
            html = b.get(base, base_url=base)
            self.assertGreaterEqual(len(sx.parse_model_index(html)), 10)
            html = b.get(f"http://127.0.0.1:{port}/listing_iphone13.html")
            self.assertEqual(len(sx.parse_listing(html)), 4)
            with self.assertRaises(b.BrowserError):
                b.get(f"http://127.0.0.1:{port}/missing.html")
        finally:
            b.close()
            srv.shutdown()
            srv.server_close()
            shutil.rmtree(os.path.join(APP, "data", "chromium-profile"), ignore_errors=True)


if __name__ == "__main__":
    unittest.main(verbosity=1)
