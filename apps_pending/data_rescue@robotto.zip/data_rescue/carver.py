#!/usr/bin/env python3
"""Data Rescue — self-contained streaming signature carver.

All-file recovery from failing / erased flash media (SD cards, USB sticks,
disk images). It reads the source strictly READ-ONLY and reconstructs files
by recognising their magic-number signatures — the same technique
RescuePRO / PhotoRec use — with no external dependencies (standard library
only), so it runs anywhere a BenchTool app runs.

Design notes
------------
* One active carve at a time, streamed. Memory stays bounded to roughly one
  read chunk regardless of how big the source or a recovered file is, so it
  is safe on a 1 GB Pi.
* Four end-detection strategies per signature:
    - "size"    : the header tells us the exact length (BMP, RIFF, SQLite).
    - "box"     : ISO-BMFF box walk (MP4 / MOV / M4A / HEIC).
    - "footer"  : scan forward for an end marker (JPG, PNG, GIF, PDF, RTF).
    - "zip"     : ZIP end-of-central-directory (also DOCX/XLSX/PPTX/JAR/APK).
    - "cap"     : no reliable end — carve until the next known header or a
                  size cap (MP3, FLAC, OGG, MKV, RAR, 7z, OLE2 docs, EXE...).
* The source is opened read-only. `open_source()` also transparently falls
  back to `sudo -n dd` when a raw block device isn't directly readable by the
  bench user (built-in tools rely on the same passwordless-sudo posture).

Run `python3 carver.py selftest` to exercise the engine against a synthetic
image built in memory.
"""

import os
import struct
import subprocess
import sys
import time

# ---------------------------------------------------------------------------
# Signature table
# ---------------------------------------------------------------------------
# Each signature:
#   ext      output file extension
#   cat      category bucket (images/video/audio/documents/archives/system)
#   headers  list of byte strings that mark the start of a file
#   mode     "size" | "box" | "footer" | "zip" | "cap"
#   hoff     header offset: how many bytes BEFORE the matched header the file
#            actually starts (MP4's 'ftyp' sits 4 bytes into the file)
#   footer   end marker (footer mode only)
#   maxsize  hard cap in bytes (runaway guard / cap-mode length)
#   minsize  discard anything smaller (false-positive filter)
#   verify   optional fn(head_bytes)->bool to reject bad header matches

KB = 1024
MB = 1024 * 1024
GB = 1024 * 1024 * 1024


def _riff_form(h, form):
    return len(h) >= 12 and h[0:4] == b"RIFF" and h[8:12] == form


def _riff_wave(h):
    return _riff_form(h, b"WAVE")


def _riff_avi(h):
    return _riff_form(h, b"AVI ")


def _riff_webp(h):
    return _riff_form(h, b"WEBP")


def _mp4_ok(h):
    # h starts 4 bytes before 'ftyp'; first 4 bytes are the box size.
    if len(h) < 8:
        return False
    size = struct.unpack(">I", h[0:4])[0]
    return 8 <= size <= 4 * MB


SIGS = [
    # ---- images --------------------------------------------------------
    dict(ext="jpg", cat="images", headers=[b"\xff\xd8\xff"],
         mode="footer", footer=b"\xff\xd9", maxsize=64 * MB, minsize=1 * KB),
    dict(ext="png", cat="images", headers=[b"\x89PNG\r\n\x1a\n"],
         mode="footer", footer=b"IEND\xaeB`\x82", maxsize=100 * MB, minsize=100),
    dict(ext="gif", cat="images", headers=[b"GIF87a", b"GIF89a"],
         mode="footer", footer=b"\x00\x3b", maxsize=32 * MB, minsize=64),
    dict(ext="bmp", cat="images", headers=[b"BM"],
         mode="size", maxsize=64 * MB, minsize=64),
    dict(ext="webp", cat="images", headers=[b"RIFF"], verify=_riff_webp,
         mode="size", maxsize=64 * MB, minsize=64),
    dict(ext="heic", cat="images", headers=[b"ftypheic", b"ftypheix",
                                            b"ftypmif1", b"ftypheis"],
         hoff=4, mode="box", maxsize=200 * MB, minsize=1 * KB),
    dict(ext="tif", cat="images", headers=[b"II*\x00", b"MM\x00*"],
         mode="cap", maxsize=100 * MB, minsize=1 * KB),
    dict(ext="cr2", cat="images", headers=[b"II*\x00\x10\x00\x00\x00CR"],
         mode="cap", maxsize=100 * MB, minsize=1 * KB),
    # ---- video ---------------------------------------------------------
    dict(ext="mp4", cat="video", headers=[b"ftypisom", b"ftypmp42",
                                          b"ftypMSNV", b"ftypdash",
                                          b"ftypavc1", b"ftypiso5"],
         hoff=4, verify=_mp4_ok, mode="box", maxsize=4 * GB, minsize=4 * KB),
    dict(ext="mov", cat="video", headers=[b"ftypqt  "],
         hoff=4, verify=_mp4_ok, mode="box", maxsize=4 * GB, minsize=4 * KB),
    dict(ext="m4a", cat="audio", headers=[b"ftypM4A "],
         hoff=4, verify=_mp4_ok, mode="box", maxsize=1 * GB, minsize=2 * KB),
    dict(ext="3gp", cat="video", headers=[b"ftyp3gp", b"ftyp3g2"],
         hoff=4, verify=_mp4_ok, mode="box", maxsize=1 * GB, minsize=2 * KB),
    dict(ext="avi", cat="video", headers=[b"RIFF"], verify=_riff_avi,
         mode="size", maxsize=4 * GB, minsize=4 * KB),
    dict(ext="mkv", cat="video", headers=[b"\x1a\x45\xdf\xa3"],
         mode="cap", maxsize=4 * GB, minsize=4 * KB),
    dict(ext="flv", cat="video", headers=[b"FLV\x01"],
         mode="cap", maxsize=2 * GB, minsize=2 * KB),
    # ---- audio ---------------------------------------------------------
    dict(ext="wav", cat="audio", headers=[b"RIFF"], verify=_riff_wave,
         mode="size", maxsize=1 * GB, minsize=256),
    dict(ext="mp3", cat="audio", headers=[b"ID3"],
         mode="cap", maxsize=64 * MB, minsize=2 * KB),
    dict(ext="flac", cat="audio", headers=[b"fLaC"],
         mode="cap", maxsize=256 * MB, minsize=2 * KB),
    dict(ext="ogg", cat="audio", headers=[b"OggS"],
         mode="cap", maxsize=256 * MB, minsize=1 * KB),
    # ---- documents -----------------------------------------------------
    dict(ext="pdf", cat="documents", headers=[b"%PDF-"],
         mode="footer", footer=b"%%EOF", maxsize=256 * MB, minsize=256),
    dict(ext="rtf", cat="documents", headers=[b"{\\rtf"],
         mode="footer", footer=b"}", maxsize=64 * MB, minsize=64),
    dict(ext="ole", cat="documents",
         headers=[b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"],
         mode="cap", maxsize=128 * MB, minsize=1 * KB),
    # ---- archives / zip-family (docx/xlsx/pptx detected post-carve) -----
    dict(ext="zip", cat="archives", headers=[b"PK\x03\x04"],
         mode="zip", maxsize=1 * GB, minsize=64),
    dict(ext="rar", cat="archives", headers=[b"Rar!\x1a\x07\x00",
                                            b"Rar!\x1a\x07\x01\x00"],
         mode="cap", maxsize=1 * GB, minsize=64),
    dict(ext="7z", cat="archives", headers=[b"7z\xbc\xaf\x27\x1c"],
         mode="cap", maxsize=1 * GB, minsize=64),
    dict(ext="gz", cat="archives", headers=[b"\x1f\x8b\x08"],
         mode="cap", maxsize=1 * GB, minsize=64),
    # ---- system / databases -------------------------------------------
    dict(ext="sqlite", cat="system", headers=[b"SQLite format 3\x00"],
         mode="size", maxsize=2 * GB, minsize=512),
    dict(ext="exe", cat="system", headers=[b"MZ"],
         mode="cap", maxsize=256 * MB, minsize=1 * KB),
]

CATEGORIES = ["images", "video", "audio", "documents", "archives", "system"]

# longest header we might need to peek to identify / verify a start
_MAXHDR = 32
CHUNK = 1 * MB


# ---------------------------------------------------------------------------
# Header matching
# ---------------------------------------------------------------------------
def _earliest_header(buf, start, sigs):
    """Return (rel_index, sig, header) of the earliest header in buf at or
    after `start`, or None. `rel_index` is where the *file* starts (already
    adjusted for hoff)."""
    best = None
    for sig in sigs:
        for h in sig["headers"]:
            idx = buf.find(h, start)
            if idx < 0:
                continue
            file_start = idx - sig.get("hoff", 0)
            if file_start < 0:
                continue
            verify = sig.get("verify")
            if verify is not None:
                head = bytes(buf[file_start:file_start + _MAXHDR])
                if len(head) >= 8 and not verify(head):
                    continue
            if best is None or file_start < best[0]:
                best = (file_start, sig, h)
    return best


# ---------------------------------------------------------------------------
# Length helpers for the "size" mode
# ---------------------------------------------------------------------------
def _size_len(sig, head):
    ext = sig["ext"]
    if ext == "bmp":
        if len(head) < 6:
            return None
        return struct.unpack("<I", head[2:6])[0]
    if ext in ("wav", "avi", "webp"):            # RIFF container
        if len(head) < 8:
            return None
        return struct.unpack("<I", head[4:8])[0] + 8
    if ext == "sqlite":
        if len(head) < 32:
            return None
        page_size = struct.unpack(">H", head[16:18])[0]
        if page_size == 1:
            page_size = 65536
        page_count = struct.unpack(">I", head[28:32])[0]
        if page_size <= 0 or page_count <= 0:
            return None
        return page_size * page_count
    return None


# ---------------------------------------------------------------------------
# The active-carve state machine
# ---------------------------------------------------------------------------
class _Active:
    """One file being carved. `feed()` consumes bytes from the front of the
    shared buffer, writing committed bytes to disk, and reports when done."""

    def __init__(self, sig, out_path, all_sigs, eof_getter):
        self.sig = sig
        self.mode = sig["mode"]
        self.maxsize = sig["maxsize"]
        self.out = open(out_path, "wb")
        self.out_path = out_path
        self.written = 0
        self.all_sigs = all_sigs
        # size / box bookkeeping
        self.total = None            # size mode: known total length
        self.box_remaining = 0       # box mode: bytes left in current box
        self.box_reading_header = True
        self.header_len = len(sig["headers"][0])

    # -- write helper -------------------------------------------------------
    def _emit(self, buf, n):
        if n <= 0:
            return
        self.out.write(bytes(buf[:n]))
        self.written += n
        del buf[:n]

    def feed(self, buf, eof):
        """Process buf in place. Returns:
            "more"  -> needs another chunk (buf trimmed as far as safe)
            "done"  -> file finished (out closed); leftover stays in buf
        """
        if self.mode == "size":
            return self._feed_size(buf, eof)
        if self.mode == "box":
            return self._feed_box(buf, eof)
        if self.mode == "footer":
            return self._feed_footer(buf, eof)
        if self.mode == "zip":
            return self._feed_zip(buf, eof)
        return self._feed_cap(buf, eof)

    def _finish(self):
        self.out.close()
        return "done"

    def _over_cap(self):
        return self.written >= self.maxsize

    # -- size ---------------------------------------------------------------
    def _feed_size(self, buf, eof):
        if self.total is None:
            need = 32
            if len(buf) < need and not eof:
                return "more"
            self.total = _size_len(self.sig, bytes(buf[:max(need, len(buf))]))
            if not self.total or self.total < self.sig["minsize"] \
                    or self.total > self.maxsize:
                # bogus length -> abandon as a 1-byte skip so search resumes
                self.total = None
                self.out.close()
                self.aborted = True
                return "abort"
        remaining = self.total - self.written
        if remaining <= 0:
            return self._finish()
        n = min(len(buf), remaining)
        self._emit(buf, n)
        if self.written >= self.total:
            return self._finish()
        return "more"

    # -- box walk (ISO-BMFF) ------------------------------------------------
    def _feed_box(self, buf, eof):
        while True:
            if self.box_reading_header:
                if len(buf) < 8 and not eof:
                    return "more"
                if len(buf) < 8:
                    return self._finish()
                size = struct.unpack(">I", bytes(buf[0:4]))[0]
                typ = bytes(buf[4:8])
                if not all(32 <= c < 127 for c in typ):
                    return self._finish()          # not a box -> file ended
                if size == 0:                       # extends to EOF
                    self.box_remaining = None
                    self.box_reading_header = False
                    continue
                if size == 1:                       # 64-bit largesize
                    if len(buf) < 16 and not eof:
                        return "more"
                    if len(buf) < 16:
                        return self._finish()
                    size = struct.unpack(">Q", bytes(buf[8:16]))[0]
                if size < 8:
                    return self._finish()
                self.box_remaining = size
                self.box_reading_header = False
            # inside a box
            if self.box_remaining is None:          # to EOF
                if len(buf):
                    self._emit(buf, len(buf))
                if self._over_cap():
                    return self._finish()
                return self._finish() if eof else "more"
            n = min(len(buf), self.box_remaining)
            self._emit(buf, n)
            self.box_remaining -= n
            if self._over_cap():
                return self._finish()
            if self.box_remaining > 0:
                return "more"
            self.box_reading_header = True          # next box

    # -- footer -------------------------------------------------------------
    def _feed_footer(self, buf, eof):
        foot = self.sig["footer"]
        idx = buf.find(foot)
        if idx >= 0:
            self._emit(buf, idx + len(foot))
            return self._finish()
        if self._over_cap():
            return self._finish()
        keep = len(foot) - 1
        if len(buf) > keep:
            self._emit(buf, len(buf) - keep)
        if eof:
            self._emit(buf, len(buf))
            return self._finish()
        return "more"

    # -- zip (end of central directory) -------------------------------------
    def _feed_zip(self, buf, eof):
        eocd = b"PK\x05\x06"
        idx = buf.find(eocd)
        if idx >= 0:
            if len(buf) < idx + 22 and not eof:
                return "more"
            if len(buf) >= idx + 22:
                clen = struct.unpack("<H", bytes(buf[idx + 20:idx + 22]))[0]
                end = idx + 22 + clen
                if len(buf) < end and not eof:
                    return "more"
                self._emit(buf, min(end, len(buf)))
                return self._finish()
        if self._over_cap():
            return self._finish()
        keep = len(eocd) - 1 + 22
        if len(buf) > keep:
            self._emit(buf, len(buf) - keep)
        if eof:
            self._emit(buf, len(buf))
            return self._finish()
        return "more"

    # -- cap (carve to next header or size cap) -----------------------------
    def _feed_cap(self, buf, eof):
        # look for the next file of any known type, past our own header
        nxt = _earliest_header(buf, max(1, self.header_len), self.all_sigs)
        if nxt is not None:
            cut = nxt[0]
            self._emit(buf, cut)
            return self._finish()               # leftover header stays in buf
        if self._over_cap():
            self._emit(buf, min(len(buf), self.maxsize - self.written))
            return self._finish()
        keep = _MAXHDR
        if len(buf) > keep:
            self._emit(buf, len(buf) - keep)
        if eof:
            self._emit(buf, len(buf))
            return self._finish()
        return "more"


# ---------------------------------------------------------------------------
# ZIP-family post-carve refinement
# ---------------------------------------------------------------------------
def _refine_zip(path):
    """Peek inside a carved .zip to see if it is really an Office file."""
    try:
        with open(path, "rb") as f:
            head = f.read(4096)
    except OSError:
        return "zip", "archives"
    if b"word/" in head:
        return "docx", "documents"
    if b"xl/" in head:
        return "xlsx", "documents"
    if b"ppt/" in head:
        return "pptx", "documents"
    if b"AndroidManifest.xml" in head:
        return "apk", "archives"
    if b"META-INF/MANIFEST.MF" in head:
        return "jar", "archives"
    if b"mimetypeapplication/epub" in head:
        return "epub", "documents"
    return "zip", "archives"


# ---------------------------------------------------------------------------
# Source opening (read-only, with a privileged fallback for raw devices)
# ---------------------------------------------------------------------------
def open_source(path):
    """Return (fileobj, total_size_or_None, closer).

    Tries a plain read-only open first. If that is denied on a block device,
    falls back to streaming it through `sudo -n dd` (the same passwordless
    posture the built-in bench helpers use). Raises RuntimeError with a
    human-readable message if neither works."""
    size = _source_size(path)
    try:
        f = open(path, "rb", buffering=0)
        # touch it to be sure we can actually read
        f.read(0)
        return f, size, f.close
    except PermissionError:
        pass
    except OSError as e:
        raise RuntimeError(f"Cannot open source: {e}")

    # privileged fallback
    try:
        proc = subprocess.Popen(
            ["sudo", "-n", "dd", f"if={path}", "bs=1M", "status=none"],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except FileNotFoundError:
        raise RuntimeError("Permission denied and 'sudo' is unavailable.")
    first = proc.stdout.read(1) if proc.stdout else b""
    if not first:
        err = proc.stderr.read().decode("utf-8", "replace") if proc.stderr else ""
        proc.kill()
        raise RuntimeError(
            "This drive needs elevated read access and passwordless sudo "
            "is not configured for it.\n"
            "Fix: run the built-in Data Recovery tool (it has the scoped "
            "helper), or point Data Rescue at a disk image instead.\n"
            + (err.strip() and f"[{err.strip()}]"))

    class _Piped:
        def __init__(self, p, lead):
            self.p = p
            self._lead = lead
        def read(self, n):
            if self._lead:
                lead, self._lead = self._lead, b""
                if n <= len(lead):
                    self._lead = lead[n:]
                    return lead[:n]
                more = self.p.stdout.read(n - len(lead)) or b""
                return lead + more
            return self.p.stdout.read(n) or b""

    def _close():
        try:
            proc.kill()
        except Exception:
            pass

    return _Piped(proc, first), size, _close


def _source_size(path):
    try:
        st = os.stat(path)
    except OSError:
        return None
    import stat as _stat
    if _stat.S_ISREG(st.st_mode) and st.st_size > 0:
        return st.st_size
    if _stat.S_ISBLK(st.st_mode):
        # /sys/class/block/<name>/size is in 512-byte sectors
        name = os.path.basename(os.path.realpath(path))
        for p in (f"/sys/class/block/{name}/size",):
            try:
                with open(p) as f:
                    return int(f.read().strip()) * 512
            except (OSError, ValueError):
                pass
        try:
            with open(path, "rb") as f:
                return f.seek(0, os.SEEK_END)
        except OSError:
            return None
    return None


# ---------------------------------------------------------------------------
# Main carve driver
# ---------------------------------------------------------------------------
def carve(source, out_dir, categories=None, progress=None, should_cancel=None,
          _preopened=None, total_size=None):
    """Carve `source` (path or file-like) into `out_dir`.

    categories    iterable of category names to recover; None = all.
    progress      optional fn(dict) called periodically.
    should_cancel optional fn()->bool; carving stops cleanly when true.

    Returns a summary dict.
    """
    cats = set(categories) if categories else set(CATEGORIES)
    active_sigs = [s for s in SIGS if s["cat"] in cats]

    closer = None
    if _preopened is not None:
        f = _preopened
    elif hasattr(source, "read"):
        f = source
    else:
        f, total_size, closer = open_source(source)

    os.makedirs(out_dir, exist_ok=True)
    counts = {c: 0 for c in CATEGORIES}
    sizes = {c: 0 for c in CATEGORIES}
    by_ext = {}
    seq = [0]

    buf = bytearray()
    abs_pos = 0                 # file offset of buf[0]
    read_total = 0
    active = None
    start_t = time.time()
    last_report = 0.0
    cancelled = False

    def new_out(sig):
        seq[0] += 1
        ext = sig["ext"]
        d = os.path.join(out_dir, sig["cat"], ext)
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, f"{ext}_{seq[0]:06d}.{ext}")

    def finalize(act):
        path = act.out_path
        try:
            written = act.written
        except Exception:
            written = 0
        if written < act.sig["minsize"]:
            try:
                os.remove(path)
            except OSError:
                pass
            return
        ext, cat = act.sig["ext"], act.sig["cat"]
        if ext == "zip":
            new_ext, cat = _refine_zip(path)
            if new_ext != "zip":
                newp = path[:-3] + new_ext
                try:
                    os.rename(path, newp)
                    path, ext = newp, new_ext
                except OSError:
                    pass
        counts[cat] = counts.get(cat, 0) + 1
        sizes[cat] = sizes.get(cat, 0) + written
        by_ext[ext] = by_ext.get(ext, 0) + 1

    def report(final=False):
        if progress is None:
            return
        progress(dict(read=read_total, total=total_size,
                      counts=dict(counts), sizes=dict(sizes),
                      by_ext=dict(by_ext), elapsed=time.time() - start_t,
                      final=final))

    try:
        while True:
            if should_cancel and should_cancel():
                cancelled = True
                break
            chunk = f.read(CHUNK)
            if chunk:
                buf += chunk
                read_total += len(chunk)
            eof = not chunk

            now = time.time()
            if now - last_report > 0.25:
                report()
                last_report = now

            # process everything we can from the current buffer
            while True:
                if active is None:
                    res = _earliest_header(buf, 0, active_sigs)
                    if res is None:
                        # nothing startable; drop all but a header-tail
                        keep = _MAXHDR - 1
                        if not eof and len(buf) > keep:
                            del buf[:len(buf) - keep]
                            abs_pos += 0  # positions not needed downstream
                        break
                    file_start, sig, _h = res
                    if file_start > 0:
                        del buf[:file_start]        # discard junk before it
                    active = _Active(sig, new_out(sig), SIGS, None)
                    continue
                st = active.feed(buf, eof)
                if st == "more":
                    break
                if st == "abort":
                    # bad size header: skip one byte and re-search
                    if buf:
                        del buf[:1]
                    active = None
                    continue
                # "done"
                finalize(active)
                active = None
                # loop again: more files may already be in buf
            if eof:
                break
    finally:
        if active is not None and active is not None:
            try:
                # flush whatever we have of a truncated final file
                if not active.out.closed:
                    active.out.close()
                finalize(active)
            except Exception:
                pass
        if closer:
            try:
                closer()
            except Exception:
                pass

    report(final=True)
    total_files = sum(counts.values())
    return dict(files=total_files, counts=counts, sizes=sizes, by_ext=by_ext,
                read=read_total, elapsed=time.time() - start_t,
                cancelled=cancelled, out_dir=out_dir)


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------
def _build_test_image():
    import io
    import zlib
    blobs = {}

    # JPEG
    blobs["jpg"] = b"\xff\xd8\xff\xe0" + b"\x00" * 5000 + b"\xff\xd9"
    # PNG (valid-ish: header + IHDR-ish junk + IEND)
    png = b"\x89PNG\r\n\x1a\n" + b"\x00" * 3000 + b"IEND\xaeB`\x82"
    blobs["png"] = png
    # GIF
    blobs["gif"] = b"GIF89a" + b"\x11" * 2000 + b"\x00\x3b"
    # PDF
    blobs["pdf"] = b"%PDF-1.4\n" + b"stuff " * 400 + b"\n%%EOF"
    # BMP (14-byte header; size field = whole-file size)
    body = b"\x00" * 4096
    bmp = b"BM" + struct.pack("<I", 14 + len(body)) + b"\x00" * 8 + body
    blobs["bmp"] = bmp
    # WAV (RIFF size)
    audio = b"\x01\x02" * 3000
    wav = b"RIFF" + struct.pack("<I", 4 + len(audio)) + b"WAVE" + audio
    blobs["wav"] = wav
    # SQLite (page_size * page_count)
    hdr = bytearray(b"SQLite format 3\x00")
    hdr += struct.pack(">H", 4096)          # page size @16
    hdr += b"\x00" * (28 - len(hdr))
    hdr += struct.pack(">I", 2)             # page count @28  -> 8192 bytes
    hdr += b"\x00" * (100 - len(hdr))
    sqlite = bytes(hdr) + b"\x00" * (4096 * 2 - 100)
    blobs["sqlite"] = sqlite
    # MP4 (two boxes: ftyp + mdat)
    ftyp = struct.pack(">I", 16) + b"ftyp" + b"isom" + b"\x00" * 4
    mdat_body = b"\x33" * 6000
    mdat = struct.pack(">I", 8 + len(mdat_body)) + b"mdat" + mdat_body
    blobs["mp4"] = ftyp + mdat
    # ZIP (real, so EOCD is correct)
    zbuf = io.BytesIO()
    import zipfile
    with zipfile.ZipFile(zbuf, "w") as z:
        z.writestr("hello.txt", "hello world " * 100)
    blobs["zip"] = zbuf.getvalue()
    # MP3 (ID3, cap mode -> ends at next header)
    blobs["mp3"] = b"ID3\x03\x00" + b"\x00" * 5 + b"\x44" * 8000

    junk = bytes((i * 7) & 0xFF for i in range(9000))
    order = ["jpg", "png", "gif", "pdf", "bmp", "wav", "sqlite", "mp4",
             "zip", "mp3"]
    img = bytearray()
    offsets = {}
    for name in order:
        img += junk[: (hash(name) % 2000) + 500]
        offsets[name] = len(img)
        img += blobs[name]
    img += junk
    return bytes(img), blobs, order


def selftest():
    import tempfile
    img, blobs, order = _build_test_image()
    tmp = tempfile.mkdtemp(prefix="carve_selftest_")
    src = os.path.join(tmp, "disk.img")
    with open(src, "wb") as f:
        f.write(img)
    out = os.path.join(tmp, "recovered")
    summary = carve(src, out)

    print(f"source: {len(img):,} bytes  ->  {summary['files']} files recovered")
    for c in CATEGORIES:
        if summary["counts"][c]:
            print(f"  {c:10s} {summary['counts'][c]}  "
                  f"({summary['sizes'][c]:,} bytes)")
    print("  by ext:", summary["by_ext"])

    # verify each planted type produced at least one file, and that the
    # carved bytes for the exactly-sized types match the originals.
    found = summary["by_ext"]
    expect_ext = {"jpg": "jpg", "png": "png", "gif": "gif", "pdf": "pdf",
                  "bmp": "bmp", "wav": "wav", "sqlite": "sqlite", "mp4": "mp4",
                  "zip": "zip", "mp3": "mp3"}
    problems = 0
    for name in order:
        want = expect_ext[name]
        # zip may be reclassified; accept zip or docx/xlsx
        alts = {want}
        if name == "zip":
            alts |= {"zip"}
        if not any(found.get(a, 0) for a in alts):
            print(f"  MISSING: {name}")
            problems += 1

    # byte-exact check for size/footer/box types we can compare
    def read_one(ext):
        for cat in CATEGORIES:
            d = os.path.join(out, cat, ext)
            if os.path.isdir(d):
                files = sorted(os.listdir(d))
                if files:
                    with open(os.path.join(d, files[0]), "rb") as f:
                        return f.read()
        return None

    for ext in ("jpg", "png", "gif", "bmp", "wav", "sqlite", "mp4", "pdf"):
        got = read_one(ext)
        if got is None:
            continue
        want = blobs[ext]
        if got != want:
            # footer types may include exact; report length delta
            print(f"  byte-mismatch {ext}: got {len(got)} want {len(want)}")
            problems += 1
        else:
            print(f"  exact {ext}: {len(got):,} bytes OK")

    print("SELFTEST:", "PASS" if problems == 0 else f"FAIL ({problems})")
    return 0 if problems == 0 else 1


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "selftest":
        sys.exit(selftest())
    if len(sys.argv) > 2 and sys.argv[1] == "carve":
        s = carve(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else "recovered",
                  progress=lambda d: None)
        print(s)
        sys.exit(0)
    print(__doc__)
    sys.exit(0)
