#!/usr/bin/env python3
"""Data Rescue — all-file recovery for the BenchTool touchscreen.

A RescuePRO-style wizard for the bench: point it at a failing/erased SD card,
USB stick or disk image, pick a destination, and it carves back every file it
can recognise — photos, video, audio, documents, archives, databases — writing
them onto your destination drive. The source is only ever read, never written.

Follows the BenchTool app contract (SDK README):
  * standalone Tk script, own root; launcher runs us as our own process
  * fullscreen / borderless / dark / cursor hidden ON THE BENCH, plain
    800x480 window in dev mode (no ui_theme around)
  * big EXIT (X) button top-right -> close() -> sys.exit(0)
  * all device I/O guarded; errors show on screen, never a bare traceback
  * exit code 0 on a clean close

The recovery engine lives in carver.py beside this file (pure stdlib).
"""

import json
import os
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import font
from queue import Queue, Empty

# our engine (same folder)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import carver  # noqa: E402

# Shared bench theme when present; graceful fallback on a dev machine.
try:
    import ui_theme as _ui
    ON_BENCH = True
except ImportError:
    _ui = None
    ON_BENCH = False

# Optional thumbnail preview.
try:
    from PIL import Image, ImageTk
    HAVE_PIL = True
except Exception:
    HAVE_PIL = False

# Palette (matches the built-in tools).
BG = "#000000"
FG = "#00ffcc"
DIM = "#888888"
WARN = "#ff6666"
OK = "#66ff99"
PANEL = "#111111"
PANEL2 = "#181818"
ACCENT = "#00ffcc"

CAT_ICON = {"images": "🖼", "video": "🎬", "audio": "🎵",
            "documents": "📄", "archives": "🗜", "system": "🗄"}
CAT_LABEL = {"images": "Photos & images", "video": "Video",
             "audio": "Audio", "documents": "Documents",
             "archives": "Archives", "system": "Databases & system"}


def human(n):
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


# ---------------------------------------------------------------------------
# Device / destination discovery
# ---------------------------------------------------------------------------
def _lsblk():
    try:
        out = subprocess.check_output(
            ["lsblk", "-J", "-b", "-o",
             "NAME,PATH,TYPE,RM,SIZE,MODEL,LABEL,MOUNTPOINT,TRAN,VENDOR,HOTPLUG"],
            stderr=subprocess.DEVNULL, timeout=8)
        return json.loads(out).get("blockdevices", [])
    except Exception:
        return []


def _mountpoints(node):
    mps = []
    if node.get("mountpoint"):
        mps.append(node["mountpoint"])
    for c in node.get("children", []) or []:
        mps += _mountpoints(c)
    return mps


def _is_system(node):
    for mp in _mountpoints(node):
        if mp in ("/", "/boot", "/boot/firmware") or (mp or "").startswith("/boot"):
            return True
    return False


def list_sources():
    """Return a list of source dicts: {kind, path, label, size, sub}."""
    sources = []
    seen_devs = set()
    for dev in _lsblk():
        if dev.get("type") != "disk":
            continue
        if _is_system(dev):
            continue                    # protect the Pi's own card
        removable = str(dev.get("rm")) in ("1", "True") or \
            str(dev.get("hotplug")) in ("1", "True") or \
            (dev.get("tran") in ("usb", "mmc", "sd"))
        # whole disk
        model = (dev.get("model") or dev.get("vendor") or "").strip()
        tran = (dev.get("tran") or "").strip()
        badge = "removable" if removable else (tran or "disk")
        path = dev.get("path") or f"/dev/{dev.get('name')}"
        if path not in seen_devs:
            seen_devs.add(path)
            sources.append(dict(
                kind="disk", path=path,
                label=f"{model or dev.get('name')}  ({human(dev.get('size'))})",
                size=int(dev.get("size") or 0),
                sub=f"whole {badge} disk · {path}",
                removable=removable))
        # partitions
        for part in dev.get("children", []) or []:
            if part.get("type") not in ("part", "rom"):
                continue
            ppath = part.get("path") or f"/dev/{part.get('name')}"
            if ppath in seen_devs:
                continue
            seen_devs.add(ppath)
            lbl = (part.get("label") or "").strip()
            sources.append(dict(
                kind="part", path=ppath,
                label=f"{lbl or part.get('name')}  ({human(part.get('size'))})",
                size=int(part.get("size") or 0),
                sub=f"partition · {ppath}",
                removable=removable))
    # image files
    for d in _scan_dirs():
        try:
            for name in sorted(os.listdir(d)):
                if name.lower().endswith((".img", ".dd", ".iso", ".raw", ".bin")):
                    p = os.path.join(d, name)
                    try:
                        sz = os.path.getsize(p)
                    except OSError:
                        continue
                    if sz < 4096:
                        continue
                    sources.append(dict(
                        kind="image", path=p,
                        label=f"{name}  ({human(sz)})",
                        size=sz, sub=f"image file · {d}", removable=True))
        except OSError:
            pass
    return sources


def _scan_dirs():
    dirs = ["/media", "/run/media", "/mnt",
            os.path.expanduser("~"), os.getcwd(),
            os.path.dirname(os.path.abspath(__file__))]
    out = []
    for d in dirs:
        if os.path.isdir(d):
            out.append(d)
            # one level down for /media/<user>, /run/media/<user>
            try:
                for sub in os.listdir(d):
                    p = os.path.join(d, sub)
                    if os.path.isdir(p):
                        out.append(p)
                        for sub2 in os.listdir(p):
                            p2 = os.path.join(p, sub2)
                            if os.path.isdir(p2):
                                out.append(p2)
            except OSError:
                pass
    # de-dup, keep order
    seen, res = set(), []
    for d in out:
        rp = os.path.realpath(d)
        if rp not in seen:
            seen.add(rp)
            res.append(d)
    return res


def _removable(dev):
    return (str(dev.get("rm")) in ("1", "True")
            or str(dev.get("hotplug")) in ("1", "True")
            or (dev.get("tran") in ("usb", "mmc", "sd")))


def _disk_paths(dev):
    """Every device path in a disk's subtree (the disk + its partitions)."""
    paths = []
    for node in [dev] + list(dev.get("children", []) or []):
        p = node.get("path") or (f"/dev/{node['name']}" if node.get("name")
                                 else None)
        if p:
            paths.append(p)
    return paths


def list_destinations(exclude_path=None):
    """Recovered files may only be written to a SEPARATE external USB drive —
    never the media being recovered, and never the Pi's own storage.

    Returns dicts of *mounted, writable* removable-drive partitions, with the
    source drive (and any partition on it) excluded entirely.
    """
    dests = []
    seen = set()
    excl_rp = os.path.realpath(exclude_path) if exclude_path else None
    tree = _lsblk()

    # Which whole disk does the source live on? Exclude that disk completely
    # so a different partition of the same card can't be picked.
    excl_disk = None
    for dev in tree:
        if dev.get("type") == "disk" and exclude_path in _disk_paths(dev):
            excl_disk = dev.get("name")
            break

    for dev in tree:
        if dev.get("type") != "disk":
            continue
        if _is_system(dev):            # never the Pi's own card / boot disk
            continue
        if not _removable(dev):        # external / hot-plug / USB only
            continue
        if excl_disk and dev.get("name") == excl_disk:
            continue                   # not the drive we're recovering from
        model = (dev.get("model") or dev.get("vendor") or "").strip()
        # a USB stick may be mounted whole (no partition table) or by partition
        for node in [dev] + list(dev.get("children", []) or []):
            mp = node.get("mountpoint")
            if not mp:
                continue
            rp = os.path.realpath(mp)
            if rp in seen or rp == excl_rp:
                continue
            if not (os.path.isdir(mp) and os.access(mp, os.W_OK)):
                continue
            seen.add(rp)
            free = None
            try:
                st = os.statvfs(mp)
                free = st.f_bavail * st.f_frsize
            except OSError:
                pass
            lbl = (node.get("label") or "").strip()
            name = lbl or model or os.path.basename(mp.rstrip("/")) or mp
            sub = f"external USB · {mp}"
            if free is not None:
                sub += f" · {human(free)} free"
            dests.append(dict(path=mp, label=name, sub=sub, free=free))
    return dests


# ---------------------------------------------------------------------------
# Scrollable list of big touch buttons
# ---------------------------------------------------------------------------
class TouchList(tk.Frame):
    def __init__(self, master, **kw):
        super().__init__(master, bg=BG, **kw)
        self.canvas = tk.Canvas(self, bg=BG, highlightthickness=0)
        self.inner = tk.Frame(self.canvas, bg=BG)
        self.win = self.canvas.create_window((0, 0), window=self.inner,
                                             anchor="nw")
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        railf = tk.Frame(self, bg=BG)
        railf.pack(side=tk.RIGHT, fill=tk.Y)
        big = font.Font(family="DejaVu Sans", size=22, weight="bold")
        tk.Button(railf, text="▲", font=big, bg=PANEL, fg=FG, width=3,
                  activebackground="#222", activeforeground=FG, bd=2,
                  command=lambda: self._scroll(-1)).pack(fill=tk.Y, expand=True)
        tk.Button(railf, text="▼", font=big, bg=PANEL, fg=FG, width=3,
                  activebackground="#222", activeforeground=FG, bd=2,
                  command=lambda: self._scroll(1)).pack(fill=tk.Y, expand=True)
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(
            scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>",
                         lambda e: self.canvas.itemconfig(self.win, width=e.width))
        # touch drag to scroll
        for w in (self.canvas, self.inner):
            w.bind("<ButtonPress-1>", self._press)
            w.bind("<B1-Motion>", self._drag)
        self.canvas.bind("<Button-4>", lambda e: self._scroll(-1))
        self.canvas.bind("<Button-5>", lambda e: self._scroll(1))
        self._y = 0

    def _scroll(self, direction):
        self.canvas.yview_scroll(direction * 2, "units")

    def _press(self, e):
        self._y = e.y_root

    def _drag(self, e):
        dy = self._y - e.y_root
        if abs(dy) > 2:
            self.canvas.yview_scroll(1 if dy > 0 else -1, "units")
            self._y = e.y_root

    def clear(self):
        for c in self.inner.winfo_children():
            c.destroy()

    def add(self, title, subtitle, command, icon=""):
        b = tk.Frame(self.inner, bg=PANEL, cursor="hand2")
        b.pack(fill=tk.X, padx=4, pady=5)
        for w in (b,):
            w.bind("<ButtonRelease-1>", lambda e, c=command: c())
        left = tk.Label(b, text=icon or "•", font=("DejaVu Sans", 26),
                        bg=PANEL, fg=FG, width=2)
        left.pack(side=tk.LEFT, padx=(10, 4), pady=10)
        txt = tk.Frame(b, bg=PANEL)
        txt.pack(side=tk.LEFT, fill=tk.X, expand=True, pady=6)
        tk.Label(txt, text=title, font=("DejaVu Sans", 17, "bold"),
                 bg=PANEL, fg=FG, anchor="w").pack(fill=tk.X)
        tk.Label(txt, text=subtitle, font=("DejaVu Sans", 12),
                 bg=PANEL, fg=DIM, anchor="w").pack(fill=tk.X)
        # make the whole row + children clickable
        for w in (left, txt) + tuple(txt.winfo_children()):
            w.bind("<ButtonRelease-1>", lambda e, c=command: c())
        return b

    def message(self, text):
        tk.Label(self.inner, text=text, font=("DejaVu Sans", 15),
                 bg=BG, fg=DIM, wraplength=680, justify="left").pack(
            padx=16, pady=24, anchor="w")


# ---------------------------------------------------------------------------
# The app
# ---------------------------------------------------------------------------
class App(tk.Tk):
    TITLE = "DATA RESCUE"

    def __init__(self):
        super().__init__()
        if ON_BENCH and hasattr(_ui, "apply_root"):
            try:
                _ui.apply_root(self)
            except Exception:
                self.geometry("800x480")
        else:
            self.geometry("800x480")
            self.title(self.TITLE + " (dev)")
        self.configure(bg=BG)

        self.f_title = font.Font(family="DejaVu Sans", size=24, weight="bold")
        self.f_h = font.Font(family="DejaVu Sans", size=18, weight="bold")
        self.f_body = font.Font(family="DejaVu Sans", size=15)
        self.f_exit = font.Font(family="DejaVu Sans", size=22, weight="bold")
        self.f_big = font.Font(family="DejaVu Sans", size=20, weight="bold")

        # wizard state
        self.source = None
        self.dest = None
        self.categories = set(carver.CATEGORIES)
        self._scan_thread = None
        self._queue = Queue()
        self._cancel = False
        self._summary = None

        self._build_chrome()
        self.container = tk.Frame(self, bg=BG)
        self.container.pack(fill=tk.BOTH, expand=True)
        self.after(80, self.screen_source)

    # ---- chrome ----------------------------------------------------------
    def _build_chrome(self):
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill=tk.X, padx=10, pady=(8, 2))
        self.header = tk.Label(bar, text=self.TITLE, font=self.f_title,
                               bg=BG, fg=FG)
        self.header.pack(side=tk.LEFT, padx=6)
        self.subhead = tk.Label(bar, text="", font=self.f_body, bg=BG, fg=DIM)
        self.subhead.pack(side=tk.LEFT, padx=10)
        tk.Button(bar, text="X", font=self.f_exit, bg="#3a1a1a", fg=WARN,
                  activebackground="#5a2a2a", activeforeground=WARN, bd=3,
                  relief="raised", width=3, command=self.close
                  ).pack(side=tk.RIGHT, padx=6)

    def _clear(self):
        for c in self.container.winfo_children():
            c.destroy()

    def _set_head(self, sub):
        self.subhead.config(text=sub)

    def _footer(self, parent, left=None, right=None):
        bar = tk.Frame(parent, bg=BG)
        bar.pack(side=tk.BOTTOM, fill=tk.X, pady=8)
        if left:
            tk.Button(bar, text=left[0], font=self.f_h, bg=PANEL, fg=FG,
                      activebackground="#222", activeforeground=FG, bd=3,
                      height=1, width=12, command=left[1]).pack(side=tk.LEFT,
                                                                 padx=8)
        if right:
            tk.Button(bar, text=right[0], font=self.f_h, bg="#0a3a2a", fg=OK,
                      activebackground="#0f5a3f", activeforeground=OK, bd=3,
                      height=1, width=14, command=right[1]).pack(side=tk.RIGHT,
                                                                  padx=8)
        return bar

    # ---- screen 1: source ------------------------------------------------
    def screen_source(self):
        self._clear()
        self._set_head("Step 1 of 4  ·  choose the media to recover")
        tk.Label(self.container,
                 text="Insert the SD card / USB stick, then pick it below.",
                 font=self.f_body, bg=BG, fg=DIM).pack(anchor="w", padx=14,
                                                       pady=(6, 2))
        lst = TouchList(self.container)
        lst.pack(fill=tk.BOTH, expand=True, padx=8)
        try:
            sources = list_sources()
        except Exception as e:
            sources = []
            print("list_sources failed:", e)
        if not sources:
            lst.message("No removable media or image files found.\n\n"
                        "• Plug an SD/USB reader into the bench and tap "
                        "REFRESH.\n• Or drop a .img/.dd disk image where the "
                        "app can see it (this folder, /media, /mnt).")
        for s in sources:
            icon = "💳" if s["kind"] in ("disk", "part") else "📁"
            if s.get("removable") and s["kind"] == "disk":
                icon = "💾"
            lst.add(s["label"], s["sub"],
                    lambda s=s: self._pick_source(s), icon=icon)
        self._footer(self.container,
                     left=("↻ REFRESH", self.screen_source))

    def _pick_source(self, s):
        self.source = s
        self.screen_types()

    # ---- screen 2: file types -------------------------------------------
    def screen_types(self):
        self._clear()
        self._set_head("Step 2 of 4  ·  what to recover")
        tk.Label(self.container,
                 text=f"Source: {self.source['label']}   —   read-only, "
                      "the card is never written to.",
                 font=self.f_body, bg=BG, fg=DIM).pack(anchor="w", padx=14,
                                                       pady=(6, 4))
        grid = tk.Frame(self.container, bg=BG)
        grid.pack(fill=tk.BOTH, expand=True, padx=10)
        self._cat_btns = {}
        cats = carver.CATEGORIES
        for i, cat in enumerate(cats):
            b = tk.Button(grid, font=self.f_h, bd=3, height=2, width=18,
                          anchor="w", justify="left",
                          command=lambda c=cat: self._toggle_cat(c))
            b.grid(row=i // 2, column=i % 2, sticky="nsew", padx=6, pady=6)
            self._cat_btns[cat] = b
        for r in range((len(cats) + 1) // 2):
            grid.rowconfigure(r, weight=1)
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)
        self._refresh_cat_btns()
        self._footer(self.container,
                     left=("‹ BACK", self.screen_source),
                     right=("NEXT ›", self._after_types))

    def _toggle_cat(self, cat):
        if cat in self.categories:
            if len(self.categories) > 1:
                self.categories.discard(cat)
        else:
            self.categories.add(cat)
        self._refresh_cat_btns()

    def _refresh_cat_btns(self):
        for cat, b in self._cat_btns.items():
            on = cat in self.categories
            try:
                b.winfo_exists()
            except tk.TclError:
                continue
            b.config(
                text=f" {CAT_ICON[cat]}  {CAT_LABEL[cat]}\n     {'ON' if on else 'off'}",
                bg=PANEL if not on else "#0a2a24",
                fg=DIM if not on else OK,
                activebackground="#0f3a30" if on else "#222",
                activeforeground=OK if on else FG)

    def _after_types(self):
        self.screen_dest()

    # ---- screen 3: destination ------------------------------------------
    def screen_dest(self):
        self._clear()
        self._set_head("Step 3 of 4  ·  save to an external USB drive")
        tk.Label(self.container,
                 text="Plug in a SECOND external USB drive with room to spare. "
                      "Recovery only writes to external USB — never the card "
                      "you're recovering, never the Pi.",
                 font=self.f_body, bg=BG, fg=DIM, wraplength=760,
                 justify="left").pack(anchor="w", padx=14, pady=(6, 2))
        lst = TouchList(self.container)
        lst.pack(fill=tk.BOTH, expand=True, padx=8)
        try:
            dests = list_destinations(exclude_path=self.source["path"])
        except Exception as e:
            dests = []
            print("list_destinations failed:", e)
        if not dests:
            lst.message("No external USB drive available for the recovered "
                        "files.\n\n• Plug in a SECOND USB drive (separate from "
                        "the one you're recovering) and tap REFRESH.\n• It "
                        "must be mounted and writable. The source card and the "
                        "Pi's own storage are never offered here.")
        for d in dests:
            lst.add(d["label"], d["sub"],
                    lambda d=d: self._pick_dest(d), icon="🔌")
        self._footer(self.container,
                     left=("‹ BACK", self.screen_types),
                     right=("↻ REFRESH", self.screen_dest))

    def _pick_dest(self, d):
        self.dest = d
        self.screen_confirm()

    # ---- screen 4: confirm ----------------------------------------------
    def screen_confirm(self):
        self._clear()
        self._set_head("Step 4 of 4  ·  ready to scan")
        card = tk.Frame(self.container, bg=PANEL2)
        card.pack(fill=tk.X, padx=16, pady=10)

        def row(k, v, color=FG):
            r = tk.Frame(card, bg=PANEL2)
            r.pack(fill=tk.X, padx=14, pady=4)
            tk.Label(r, text=k, font=self.f_body, bg=PANEL2, fg=DIM,
                     width=12, anchor="w").pack(side=tk.LEFT)
            tk.Label(r, text=v, font=self.f_h, bg=PANEL2, fg=color,
                     anchor="w", wraplength=560, justify="left").pack(
                side=tk.LEFT, fill=tk.X, expand=True)

        cats = ", ".join(CAT_LABEL[c].split(" ")[0].lower()
                         for c in carver.CATEGORIES if c in self.categories)
        row("SOURCE", self.source["label"])
        row("", self.source["sub"], DIM)
        row("RECOVER", cats)
        row("SAVE TO", f"{self.dest['label']}  ({self.dest['sub']})")
        tk.Label(self.container,
                 text="✓ The source is opened READ-ONLY. Nothing is written "
                      "back to the card.",
                 font=self.f_body, bg=BG, fg=OK).pack(anchor="w", padx=18,
                                                      pady=(4, 0))
        # destination free space vs source size sanity hint
        if self.dest.get("free") and self.source.get("size"):
            if self.dest["free"] < self.source["size"] * 0.5:
                tk.Label(self.container,
                         text="⚠ Destination free space is small relative to "
                              "the card — recovered data may not all fit.",
                         font=self.f_body, bg=BG, fg=WARN).pack(
                    anchor="w", padx=18, pady=(2, 0))
        self._footer(self.container,
                     left=("‹ BACK", self.screen_dest),
                     right=("▶ START SCAN", self.start_scan))

    # ---- screen 5: scanning ---------------------------------------------
    def start_scan(self):
        self._clear()
        self._set_head("Scanning…")
        self._cancel = False
        self._summary = None
        ts = time.strftime("%Y%m%d-%H%M%S")
        self.out_dir = os.path.join(self.dest["path"], f"RECOVERED_{ts}")

        top = tk.Frame(self.container, bg=BG)
        top.pack(fill=tk.X, padx=16, pady=(8, 2))
        self.prog_lbl = tk.Label(top, text="Starting…", font=self.f_h,
                                 bg=BG, fg=FG, anchor="w")
        self.prog_lbl.pack(fill=tk.X)
        self.rate_lbl = tk.Label(top, text="", font=self.f_body, bg=BG,
                                 fg=DIM, anchor="w")
        self.rate_lbl.pack(fill=tk.X)

        # progress bar
        self.bar_c = tk.Canvas(self.container, height=26, bg=PANEL,
                               highlightthickness=0)
        self.bar_c.pack(fill=tk.X, padx=16, pady=6)
        self.bar_rect = self.bar_c.create_rectangle(0, 0, 0, 26, fill=ACCENT,
                                                    width=0)

        # live per-category counts
        self.count_frame = tk.Frame(self.container, bg=BG)
        self.count_frame.pack(fill=tk.BOTH, expand=True, padx=16, pady=6)
        self.count_lbls = {}
        for i, cat in enumerate(carver.CATEGORIES):
            r = tk.Frame(self.count_frame, bg=BG)
            r.grid(row=i // 2, column=i % 2, sticky="w", padx=8, pady=4)
            self.count_lbls[cat] = tk.Label(
                r, text=f"{CAT_ICON[cat]}  {CAT_LABEL[cat]}: 0",
                font=self.f_h, bg=BG, fg=DIM, anchor="w")
            self.count_lbls[cat].pack(side=tk.LEFT)
        self.count_frame.columnconfigure(0, weight=1)
        self.count_frame.columnconfigure(1, weight=1)

        self._footer(self.container, left=("■ STOP", self._stop_scan))

        self._scan_thread = threading.Thread(target=self._scan_worker,
                                             daemon=True)
        self._scan_thread.start()
        self.after(120, self._poll_scan)

    def _scan_worker(self):
        try:
            summary = carver.carve(
                self.source["path"], self.out_dir,
                categories=self.categories,
                progress=lambda d: self._queue.put(("progress", d)),
                should_cancel=lambda: self._cancel,
                total_size=self.source.get("size") or None)
            self._queue.put(("done", summary))
        except Exception as e:
            self._queue.put(("error", str(e)))

    def _stop_scan(self):
        self._cancel = True
        self.prog_lbl.config(text="Stopping…", fg=WARN)

    def _poll_scan(self):
        try:
            while True:
                kind, payload = self._queue.get_nowait()
                if kind == "progress":
                    self._update_progress(payload)
                elif kind == "done":
                    self._summary = payload
                    self.screen_done(payload)
                    return
                elif kind == "error":
                    self.screen_error(payload)
                    return
        except Empty:
            pass
        self.after(150, self._poll_scan)

    def _update_progress(self, d):
        read = d.get("read", 0)
        total = d.get("total")
        elapsed = max(d.get("elapsed", 0.001), 0.001)
        rate = read / elapsed
        found = sum(d.get("counts", {}).values())
        if total:
            pct = min(100.0, read / total * 100)
            self.prog_lbl.config(
                text=f"{pct:4.1f}%   ·   {found} files recovered", fg=FG)
            w = self.bar_c.winfo_width() or 1
            self.bar_c.coords(self.bar_rect, 0, 0, int(w * pct / 100), 26)
            eta = (total - read) / rate if rate > 0 else 0
            self.rate_lbl.config(
                text=f"{human(read)} / {human(total)}   ·   "
                     f"{human(rate)}/s   ·   ETA {int(eta)//60}m{int(eta)%60:02d}s")
        else:
            self.prog_lbl.config(
                text=f"{human(read)} read   ·   {found} files recovered", fg=FG)
            self.rate_lbl.config(text=f"{human(rate)}/s")
        for cat, lbl in self.count_lbls.items():
            n = d.get("counts", {}).get(cat, 0)
            sz = d.get("sizes", {}).get(cat, 0)
            lbl.config(text=f"{CAT_ICON[cat]}  {CAT_LABEL[cat]}: {n}"
                            + (f"  ({human(sz)})" if n else ""),
                       fg=OK if n else DIM)

    # ---- screen 6: done --------------------------------------------------
    def screen_done(self, s):
        self._clear()
        done_kind = "STOPPED" if s.get("cancelled") else "COMPLETE"
        self._set_head(f"Recovery {done_kind.lower()}")
        total = s.get("files", 0)
        tk.Label(self.container,
                 text=f"{'■' if s.get('cancelled') else '✓'}  "
                      f"{total} files recovered  ·  {human(sum(s['sizes'].values()))}",
                 font=self.f_title, bg=BG,
                 fg=WARN if s.get("cancelled") else OK).pack(anchor="w",
                                                             padx=16, pady=(8, 2))
        tk.Label(self.container,
                 text=f"Saved to:  {self.out_dir}",
                 font=self.f_body, bg=BG, fg=DIM, wraplength=760,
                 justify="left").pack(anchor="w", padx=16)

        table = tk.Frame(self.container, bg=BG)
        table.pack(fill=tk.BOTH, expand=True, padx=16, pady=8)
        for cat in carver.CATEGORIES:
            n = s["counts"].get(cat, 0)
            if not n:
                continue
            r = tk.Frame(table, bg=PANEL)
            r.pack(fill=tk.X, pady=3)
            tk.Label(r, text=f"{CAT_ICON[cat]}  {CAT_LABEL[cat]}",
                     font=self.f_h, bg=PANEL, fg=FG, anchor="w",
                     width=22).pack(side=tk.LEFT, padx=10, pady=8)
            tk.Label(r, text=f"{n} files", font=self.f_h, bg=PANEL, fg=OK,
                     anchor="w", width=10).pack(side=tk.LEFT)
            tk.Label(r, text=human(s["sizes"].get(cat, 0)), font=self.f_body,
                     bg=PANEL, fg=DIM, anchor="e").pack(side=tk.RIGHT, padx=12)
        if total == 0:
            tk.Label(table,
                     text="No recoverable files were found. If the card was "
                          "recently formatted, a full sector image + deep "
                          "carve (built-in Data Recovery tool) may still find "
                          "data.",
                     font=self.f_body, bg=BG, fg=DIM, wraplength=740,
                     justify="left").pack(anchor="w", pady=20)

        has_images = s["counts"].get("images", 0) > 0
        self._footer(
            self.container,
            left=("↺ SCAN ANOTHER", self.screen_source),
            right=("🖼 VIEW PHOTOS", self._open_gallery) if
            (has_images and HAVE_PIL) else None)

    # ---- image gallery ---------------------------------------------------
    def _open_gallery(self):
        img_dir = os.path.join(self.out_dir, "images")
        paths = []
        for root, _dirs, files in os.walk(img_dir):
            for fn in files:
                if fn.lower().endswith((".jpg", ".png", ".gif", ".bmp",
                                        ".webp")):
                    paths.append(os.path.join(root, fn))
            if len(paths) >= 40:
                break
        self._clear()
        self._set_head(f"Recovered photos ({len(paths)} shown)")
        lst = TouchList(self.container)
        lst.pack(fill=tk.BOTH, expand=True, padx=8)
        grid = tk.Frame(lst.inner, bg=BG)
        grid.pack(fill=tk.BOTH, expand=True)
        self._thumbs = []
        col = cols = 4
        r = c = 0
        for p in paths[:40]:
            try:
                im = Image.open(p)
                im.thumbnail((150, 150))
                ph = ImageTk.PhotoImage(im)
                self._thumbs.append(ph)
                cell = tk.Label(grid, image=ph, bg=PANEL, bd=2, relief="ridge")
                cell.grid(row=r, column=c, padx=5, pady=5)
                c += 1
                if c >= cols:
                    c = 0
                    r += 1
            except Exception:
                continue
        if not self._thumbs:
            lst.message("Could not render thumbnails, but the image files are "
                        "saved on the destination drive.")
        self._footer(self.container,
                     left=("‹ BACK", lambda: self.screen_done(self._summary)))

    # ---- error screen ----------------------------------------------------
    def screen_error(self, msg):
        self._clear()
        self._set_head("Couldn't read the media")
        tk.Label(self.container, text="⚠  Recovery could not start",
                 font=self.f_title, bg=BG, fg=WARN).pack(anchor="w",
                                                         padx=16, pady=(10, 6))
        tk.Label(self.container, text=msg, font=self.f_body, bg=BG, fg=DIM,
                 wraplength=760, justify="left").pack(anchor="w", padx=16)
        self._footer(self.container,
                     left=("‹ BACK", self.screen_source))

    # ---- exit ------------------------------------------------------------
    def close(self):
        self._cancel = True
        try:
            self.destroy()
        except Exception:
            pass
        sys.exit(0)


if __name__ == "__main__":
    try:
        App().mainloop()
    except SystemExit:
        raise
    except Exception as e:
        # never die to a black screen without a trace in the log
        print("FATAL:", e)
        sys.exit(1)
