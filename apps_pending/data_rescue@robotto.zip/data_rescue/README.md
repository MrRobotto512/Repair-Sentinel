# Data Rescue — all-file recovery for BenchTool

A RescuePRO-style recovery wizard for the bench touchscreen. Point it at a
failing or accidentally-erased SD card, USB stick, or disk image; it carves
back every file it can recognise — photos, video, audio, documents,
archives, databases — and writes them to a destination drive. **The source
is only ever read, never written.**

This is a drop-in BenchTool "My Apps" package (no changes to the main repo).

## Install

Copy this whole folder into `~/benchtool-apps/` on the bench:

```bash
scp -r "Data Rescue" <user>@<bench-ip>:~/benchtool-apps/
```

Open **Utilities ▸ My Apps** on the bench — a **Data Rescue** tile appears
(Utilities re-scans every time it opens; no reboot). To remove it, delete
the folder.

## Using it

1. **Source** — insert the card/stick and pick it (or a `.img`/`.dd` image).
2. **What to recover** — toggle categories (all on by default).
3. **Destination** — a *second, external USB drive* with room to spare. The
   picker only offers external USB drives; the card being recovered and the
   Pi's own storage are never listed, so recovered data can't overwrite the
   source.
4. **Scan** — live progress and per-type counts; **STOP** is safe and the
   files found so far are kept.

Recovered files land in `RECOVERED_<timestamp>/<category>/<ext>/` on the
destination.

## How it works

`carver.py` is a pure standard-library streaming signature carver (no pip
dependencies). It recognises files by magic number and reconstructs them
using exact-length headers (BMP, RIFF/WAV/AVI, SQLite), ISO-BMFF box walking
(MP4/MOV/M4A/HEIC), end markers (JPG, PNG, GIF, PDF, ZIP and the Office
formats), or carve-to-next-header for headerless types (MP3, FLAC, OGG, MKV,
RAR, 7z, OLE documents, EXE). Memory use stays around one 1 MB read chunk, so
it is safe on a 1 GB Pi even imaging a large card.

Raw block devices are opened read-only; if the bench user can't read the
device directly it transparently falls back to `sudo -n dd` (the same
passwordless posture the built-in bench helpers use). If that isn't
available it tells you to use the built-in Data Recovery tool or point it at
an image file instead.

Optional: if Pillow is present (it is, in the bench venv) the results screen
offers a **VIEW PHOTOS** thumbnail gallery.

## Testing off-bench

```bash
python3 carver.py selftest      # engine self-test on a synthetic image
python3 main.py                 # runs in a plain 800x480 dev window
```
