#!/usr/bin/env python3
"""
qa_core — the device logic behind iOS Quick Activate. No UI in here, so the
bench screen (main.py) and the dashboard page (web.py) can't drift apart.

WHAT THIS DOES, and why it works
────────────────────────────────
Getting a freshly-restored iPhone to the home screen is two separate jobs:

  1. ACTIVATE — the device talks to Apple (albert.apple.com) and gets an
     activation record. Until then it sits on "Activation Required".

  2. SKIP SETUP — activation does NOT dismiss the Setup Assistant panes.
     Those are skipped by writing a CLOUD CONFIGURATION with a SkipSetup
     list — the same mechanism Apple Configurator's "Prepare" uses, sent to
     com.apple.mobile.MCInstall as a SetCloudConfiguration request.

  3. WI-FI PROFILE (optional) — a .mobileconfig installed before setup so
     the device can reach Apple on its own.

TWO LIBRARIES, ON PURPOSE (2026-08-22)
──────────────────────────────────────
Detection and status come from the libimobiledevice CLI (idevice_id /
ideviceinfo) — synchronous, already installed on every bench, and stable
for years. The ACTIONS use pymobiledevice3, which is the only thing that
implements SetCloudConfiguration.

That split exists because of a real failure: pymobiledevice3 went
ASYNC-ONLY (create_using_usbmux, get_value and friends are `async def`, and
the maintainers removed the sync path outright). The first build of this
app called them synchronously and every scan died with
"'coroutine' object is not iterable" — so no device ever appeared. Now the
device LIST cannot be taken down by that library at all, and every call
into it goes through _aw(), which awaits a coroutine or passes a plain
value straight through — so this works whether the installed version is
async or the older sync one.

If something still goes wrong, diagnostics() reports each probe separately
rather than collapsing to "no devices connected".
"""

import asyncio
import inspect
import json
import os
import plistlib
import shutil
import subprocess
import sys
import threading
import time

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(APP_DIR, "data")
SETTINGS = os.path.join(DATA_DIR, "settings.json")
WIFI_PROFILE = os.path.join(DATA_DIR, "wifi.mobileconfig")

# Apple's Setup Assistant skip keys, with the wording techs recognise.
# Unknown keys are ignored by the device, so sending the whole list is safe.
SKIP_KEYS = [
    ("Welcome", "Welcome (Get Started)"),
    ("Language", "Language"),
    ("Region", "Region"),
    ("WiFi", "Wi-Fi"),
    ("Restore", "Set Up as New or Restore"),
    ("DeviceToDeviceMigration", "Device to device migration"),
    ("Android", "Move from Android"),
    ("AppleID", "Apple ID"),
    ("TOS", "Terms and Conditions"),
    ("TermsOfAddress", "Terms of address"),
    ("Privacy", "Data and Privacy"),
    ("Diagnostics", "App / Device Analytics"),
    ("iCloudDiagnostics", "iCloud Analytics"),
    ("iCloudStorage", "iCloud Desktop and Documents"),
    ("Biometric", "Touch ID / Face ID"),
    ("Passcode", "Passcode Lock"),
    ("Payment", "Apple Pay"),
    ("Siri", "Siri"),
    ("Intelligence", "Apple Intelligence"),
    ("ScreenTime", "Screen Time"),
    ("Location", "Location Services"),
    ("SIMSetup", "Set Up Cellular"),
    ("iMessageAndFaceTime", "iMessage and FaceTime"),
    ("MessagingActivationUsingPhoneNumber", "Phone number feedback"),
    ("Keyboard", "Keyboards"),
    ("SpokenLanguage", "Spoken language"),
    ("DisplayTone", "True Tone Display"),
    ("Zoom", "Display Zoom"),
    ("Appearance", "Appearance"),
    ("Wallpaper", "Wallpaper"),
    ("HomeButtonSensitivity", "Home button feedback"),
    ("ActionButton", "Action Button"),
    ("CameraButton", "Camera Button"),
    ("Safety", "Safety features"),
    ("OnBoarding", "Onboarding"),
    ("NewFeatureHighlights", "New feature highlights"),
    ("SoftwareUpdate", "Software Update"),
    ("UpdateCompleted", "Update completed"),
    ("RestoreCompleted", "Restore completed"),
    ("AppStore", "App Store"),
    ("WatchMigration", "Apple Watch migration"),
    ("TapToSetup", "Tap to Setup"),
    ("ScreenSaver", "Screen saver"),
    ("TVHomeScreenSync", "Sync Apple TV home screen"),
    ("TVProviderSignIn", "Sign in to your TV provider"),
    ("TVRoom", "TV room"),
    ("Accessibility", "Accessibility"),
    ("EnableLockdownMode", "Lockdown Mode"),
    ("IntendedUser", "Intended user"),
]
SKIP_KEY_NAMES = [k for k, _ in SKIP_KEYS]

DEFAULTS = {
    "language": "en",
    "region": "US",
    "skip": SKIP_KEY_NAMES,
    "organization": "Bench Hero",
    "activate": True,
    "setup": True,
    "wifi": False,
}

# Enough marketing names that a tech recognises the row; anything missing
# falls back to the raw model code rather than pretending.
MODELS = {
    "iPhone12,1": "iPhone 11", "iPhone12,3": "iPhone 11 Pro",
    "iPhone12,5": "iPhone 11 Pro Max", "iPhone12,8": "iPhone SE (2nd gen)",
    "iPhone13,1": "iPhone 12 mini", "iPhone13,2": "iPhone 12",
    "iPhone13,3": "iPhone 12 Pro", "iPhone13,4": "iPhone 12 Pro Max",
    "iPhone14,4": "iPhone 13 mini", "iPhone14,5": "iPhone 13",
    "iPhone14,2": "iPhone 13 Pro", "iPhone14,3": "iPhone 13 Pro Max",
    "iPhone14,6": "iPhone SE (3rd gen)", "iPhone14,7": "iPhone 14",
    "iPhone14,8": "iPhone 14 Plus", "iPhone15,2": "iPhone 14 Pro",
    "iPhone15,3": "iPhone 14 Pro Max", "iPhone15,4": "iPhone 15",
    "iPhone15,5": "iPhone 15 Plus", "iPhone16,1": "iPhone 15 Pro",
    "iPhone16,2": "iPhone 15 Pro Max", "iPhone17,3": "iPhone 16",
    "iPhone17,4": "iPhone 16 Plus", "iPhone17,1": "iPhone 16 Pro",
    "iPhone17,2": "iPhone 16 Pro Max", "iPhone17,5": "iPhone 16e",
}

CLI_TIMEOUT = 20


# ── settings ────────────────────────────────────────────────────────────────

def load_settings():
    s = dict(DEFAULTS)
    try:
        with open(SETTINGS, encoding="utf-8") as f:
            saved = json.load(f)
        if isinstance(saved, dict):
            s.update({k: v for k, v in saved.items() if k in DEFAULTS})
    except Exception:
        pass
    s["skip"] = [k for k in s.get("skip") or [] if k in SKIP_KEY_NAMES]
    return s


def save_settings(s):
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        tmp = SETTINGS + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({k: s.get(k, DEFAULTS[k]) for k in DEFAULTS}, f, indent=1)
        os.replace(tmp, SETTINGS)
        return True, ""
    except OSError as e:
        return False, str(e)


def have_wifi_profile():
    return os.path.isfile(WIFI_PROFILE)


def save_wifi_profile(data):
    try:
        plistlib.loads(data)
    except Exception:
        return False, "that isn't a valid .mobileconfig (plist) file"
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(WIFI_PROFILE, "wb") as f:
            f.write(data)
        return True, "Wi-Fi profile saved"
    except OSError as e:
        return False, str(e)


# ── async bridge ────────────────────────────────────────────────────────────

async def _aw(value):
    """Await a coroutine, or pass a plain value through. Lets one code path
    drive both the async-only pymobiledevice3 and older sync builds."""
    if inspect.isawaitable(value):
        return await value
    return value


def _run(coro):
    """Run one async flow to completion on this thread's own loop. Each
    device runs in its own thread, so asyncio.run() is safe here."""
    return asyncio.run(coro)


# ── detection: libimobiledevice CLI (sync, stable, already installed) ────────

def _cli(args, timeout=CLI_TIMEOUT):
    try:
        p = subprocess.run(args, capture_output=True, text=True,
                           timeout=timeout)
        return p.returncode, (p.stdout or "").strip(), (p.stderr or "").strip()
    except FileNotFoundError:
        return 127, "", "%s is not installed" % args[0]
    except subprocess.TimeoutExpired:
        return 124, "", "%s timed out" % args[0]
    except Exception as e:  # noqa: BLE001
        return 1, "", str(e)


def _info_key(udid, key):
    rc, out, _err = _cli(["ideviceinfo", "-u", udid, "-k", key], timeout=10)
    return out if rc == 0 else ""


def list_devices():
    """([{udid, model, ios, serial, state, error}], error_message).

    Uses idevice_id/ideviceinfo — no pymobiledevice3 involved, so a library
    that changes its API can never make the device list come up empty."""
    if shutil.which("idevice_id"):
        rc, out, err = _cli(["idevice_id", "-l"], timeout=10)
        if rc != 0:
            return [], ("idevice_id failed: %s — is usbmuxd running?"
                        % (err or rc))
        udids = [u.strip() for u in out.splitlines() if u.strip()]
        rows = []
        for udid in udids:
            pt = _info_key(udid, "ProductType")
            rows.append({
                "udid": udid,
                "model": MODELS.get(pt, pt or "iOS device"),
                "ios": _info_key(udid, "ProductVersion"),
                "serial": _info_key(udid, "SerialNumber"),
                "state": _info_key(udid, "ActivationState") or "?",
                "error": "",
            })
        return rows, ""
    # No libimobiledevice CLI — fall back to pymobiledevice3's own listing.
    try:
        return _run(_list_via_pmd3()), ""
    except Exception as e:  # noqa: BLE001
        return [], ("no idevice_id, and pymobiledevice3 listing failed: %s"
                    % str(e)[:160])


async def _list_via_pmd3():
    from pymobiledevice3 import usbmux
    rows = []
    for d in await _aw(usbmux.list_devices()):
        udid = getattr(d, "serial", "") or ""
        row = {"udid": udid, "model": "iOS device", "ios": "", "serial": "",
               "state": "?", "error": ""}
        try:
            from pymobiledevice3.lockdown import create_using_usbmux
            ld = await _aw(create_using_usbmux(serial=udid, autopair=False))
            values = await _aw(getattr(ld, "all_values", None)) or {}
            if not values and hasattr(ld, "get_value"):
                values = await _aw(ld.get_value()) or {}
            pt = str(values.get("ProductType", "") or "")
            row["model"] = MODELS.get(pt, pt or "iOS device")
            row["ios"] = str(values.get("ProductVersion", "") or "")
            row["serial"] = str(values.get("SerialNumber", "") or "")
            row["state"] = str(values.get("ActivationState", "?") or "?")
        except Exception as e:  # noqa: BLE001
            row["error"] = str(e)[:120]
        rows.append(row)
    return rows


# ── diagnostics: say what actually happened, not "no devices" ───────────────

def diagnostics():
    """[(check, result)] — enough to tell library trouble from cable
    trouble without reading a log file."""
    out = [("Python", sys.version.split()[0])]

    for tool in ("idevice_id", "ideviceinfo", "usbmuxd"):
        out.append((tool, shutil.which(tool) or "NOT INSTALLED"))

    rc, o, e = _cli(["idevice_id", "-l"], timeout=10)
    out.append(("idevice_id -l",
                ("%d device(s): %s" % (len(o.splitlines()), o.replace("\n", ", "))
                 if rc == 0 and o else
                 ("no devices listed" if rc == 0 else "rc=%s %s" % (rc, e)))))

    try:
        import pymobiledevice3
        ver = getattr(pymobiledevice3, "__version__", "?")
        out.append(("pymobiledevice3", "installed, version %s" % ver))
        try:
            from pymobiledevice3 import usbmux
            is_async = inspect.iscoroutinefunction(usbmux.list_devices)
            out.append(("pymobiledevice3 API",
                        "async (usbmux.list_devices is a coroutine)"
                        if is_async else "sync"))
            devs = _run(_aw(usbmux.list_devices()))
            out.append(("usbmux.list_devices()", "%d device(s)" % len(devs)))
        except Exception as e:  # noqa: BLE001
            out.append(("usbmux.list_devices()", "FAILED: %s" % str(e)[:140]))
        for name, path in (("activation", "pymobiledevice3.services."
                            "mobile_activation"),
                           ("cloud config", "pymobiledevice3.services."
                            "mobile_config")):
            try:
                __import__(path)
                out.append(("%s service" % name, "importable"))
            except Exception as e:  # noqa: BLE001
                out.append(("%s service" % name, "FAILED: %s" % str(e)[:120]))
    except Exception as e:  # noqa: BLE001
        out.append(("pymobiledevice3", "NOT INSTALLED (%s)" % str(e)[:100]))

    rows, err = list_devices()
    out.append(("this app sees",
                err or ("%d device(s)" % len(rows)) if (err or rows)
                else "0 devices"))
    for r in rows:
        out.append(("  · " + (r["model"] or "device"),
                    "iOS %s · %s · %s" % (r["ios"] or "?",
                                          r["serial"] or r["udid"][:14],
                                          r["state"])))
    return out


# ── the work ────────────────────────────────────────────────────────────────

def cloud_config(settings):
    """The payload that skips the Setup Assistant panes. AllowPairing keeps
    the device talkable afterwards, which is the whole point for testing."""
    return {
        "AllowPairing": True,
        "CloudConfigurationUIComplete": True,
        "ConfigurationSource": 0,
        "PostSetupProfileWasInstalled": True,
        "SkipSetup": list(settings.get("skip") or []),
        "OrganizationName": str(settings.get("organization") or "Bench Hero"),
        "Language": str(settings.get("language") or "en"),
        "Locale": "%s_%s" % (settings.get("language") or "en",
                             settings.get("region") or "US"),
    }


async def _run_one_async(udid, settings, say):
    from pymobiledevice3.lockdown import create_using_usbmux
    lockdown = await _aw(create_using_usbmux(serial=udid, autopair=False))
    done = []
    try:
        if settings.get("wifi") and have_wifi_profile():
            say("installing Wi-Fi profile")
            from pymobiledevice3.services.mobile_config import \
                MobileConfigService
            with open(WIFI_PROFILE, "rb") as f:
                await _aw(MobileConfigService(lockdown).install_profile(f.read()))
            done.append("Wi-Fi profile")

        if settings.get("activate", True):
            say("activating with Apple")
            from pymobiledevice3.services.mobile_activation import \
                MobileActivationService
            svc = MobileActivationService(lockdown)
            state = getattr(svc, "state", None)
            if callable(state):
                state = state()
            state = await _aw(state)
            if str(state) == "Activated":
                done.append("already activated")
            else:
                # Never sit waiting for an Apple ID prompt on a bench with
                # no keyboard: a device that asks is iCloud-locked.
                await _aw(svc.activate(skip_apple_id_query=True))
                done.append("activated")

        if settings.get("setup", True):
            say("skipping setup screens")
            from pymobiledevice3.services.mobile_config import \
                MobileConfigService
            await _aw(MobileConfigService(lockdown).set_cloud_configuration(
                cloud_config(settings)))
            done.append("%d setup screens skipped"
                        % len(settings.get("skip") or []))
    finally:
        for closer in ("aclose", "close"):
            fn = getattr(lockdown, closer, None)
            if fn:
                try:
                    await _aw(fn())
                except Exception:
                    pass
                break
    return done


def run_one(udid, settings, log=None):
    """Activate and/or set up ONE device → (ok, summary)."""
    def say(msg):
        if log:
            try:
                log(udid, msg)
            except Exception:
                pass

    try:
        import pymobiledevice3  # noqa: F401
    except Exception as e:  # noqa: BLE001
        return False, ("pymobiledevice3 isn't installed (%s) — use "
                       "⬇ install deps on the app's card" % str(e)[:80])
    try:
        done = _run(_run_one_async(udid, settings, say))
    except Exception as e:  # noqa: BLE001
        msg = str(e)
        low = msg.lower()
        if "apple id" in low or "icloud" in low or "activation lock" in low:
            return False, ("Activation Lock — still signed into an iCloud "
                           "account")
        if "coroutine" in low or "await" in low:
            return False, ("pymobiledevice3 API mismatch: %s — check "
                           "🩺 Diagnostics" % msg[:90])
        return False, msg[:140]
    return True, ", ".join(done) or "nothing selected"


class BatchRun(object):
    """A batch across every connected device, on background threads so no
    UI ever blocks. Poll .snapshot() to draw progress."""

    def __init__(self, udids, settings):
        self.settings = settings
        self._lock = threading.Lock()
        self.results = {u: {"state": "queued", "msg": ""} for u in udids}
        self.started = time.time()
        self.finished = None
        self._threads = []
        for u in udids:
            t = threading.Thread(target=self._worker, args=(u,), daemon=True)
            self._threads.append(t)
            t.start()
        threading.Thread(target=self._reaper, daemon=True).start()

    def _set(self, udid, state, msg=""):
        with self._lock:
            self.results[udid] = {"state": state, "msg": msg}

    def _worker(self, udid):
        self._set(udid, "running", "starting")
        try:
            ok, msg = run_one(udid, self.settings,
                              log=lambda u, m: self._set(u, "running", m))
        except Exception as e:  # noqa: BLE001
            ok, msg = False, str(e)[:140]
        self._set(udid, "done" if ok else "failed", msg)

    def _reaper(self):
        for t in self._threads:
            t.join()
        self.finished = time.time()

    def snapshot(self):
        with self._lock:
            res = {u: dict(v) for u, v in self.results.items()}
        return {"results": res, "running": self.finished is None,
                "ok": sum(1 for v in res.values() if v["state"] == "done"),
                "failed": sum(1 for v in res.values()
                              if v["state"] == "failed"),
                "total": len(res)}
