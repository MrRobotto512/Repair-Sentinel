#!/usr/bin/env python3
"""
af_blob.py — turn workflows into the tiny line-script the ESP32 firmware stores.

We flash custom commands to the ESP32-S3 Automaton over its USB-CDC serial
console (no drive mounting). The device keeps the workflows in NVS as a compact
text script and plays them back from the button. This module is the one place
that defines that script grammar, so the Python side and the firmware companion
(`esp32s3_automaton/src/wf_store.h`) agree exactly.

Grammar (one line per element; opcode is the first token):
    #V1                         header / version marker
    #name:<text>                begins a workflow
    #note:<text>                optional one-line description
    #btn:<0-2>                  optional button assignment
    S <text>                    status line (shown on the device, no keys)
    K <combo>                   one chord            e.g.  K SHIFT+F10
    T <combo> <count> [gap_ms]  chord tapped N times e.g.  T CMD+TAB 3 500
    Y <text>                    type text (no Enter)
    L <text>                    type text + Enter    e.g.  L net user ...
    H <combo> <ms>              hold a chord for ms  e.g.  H CMD+R 25000
    W <ms>                      wait / delay

`<combo>` tokens match the firmware's parseCombo()/keyFromToken():
    mods : CMD CTRL ALT/OPT SHIFT VO(=CTRL+ALT)
    keys : F1..F12 TAB RET/ENTER ESC SPACE UP DOWN LEFT RIGHT BKSP
           DELETE HOME END PAGEUP PAGEDOWN  or a single character
"""

from __future__ import annotations

import af_model as wm
import af_bench as bench

SCRIPT_VERSION = 1

# canonical model key  ->  firmware combo token
_KEY_TOKEN = {
    "enter": "ENTER", "esc": "ESC", "tab": "TAB", "space": "SPACE",
    "bksp": "BKSP", "delete": "DELETE", "home": "HOME", "end": "END",
    "pageup": "PAGEUP", "pagedown": "PAGEDOWN",
    "up": "UP", "down": "DOWN", "left": "LEFT", "right": "RIGHT",
    **{f"f{i}": f"F{i}" for i in range(1, 13)},
}
_MOD_TOKEN = {"cmd": "CMD", "ctrl": "CTRL", "alt": "ALT", "shift": "SHIFT"}

# reverse maps for parsing a script back (tests / device read-back)
_TOKEN_KEY = {v: k for k, v in _KEY_TOKEN.items()}
_TOKEN_KEY.update({"RET": "enter", "RETURN": "enter", "SPC": "space",
                   "BACKSPACE": "bksp", "PGUP": "pageup", "PGDN": "pagedown"})
_TOKEN_MOD = {"CMD": "cmd", "GUI": "cmd", "WIN": "cmd", "CTRL": "ctrl",
              "CONTROL": "ctrl", "ALT": "alt", "OPT": "alt", "OPTION": "alt",
              "SHIFT": "shift"}


class BlobError(ValueError):
    """A workflow can't be represented in the device script (bad key, etc.)."""


# --------------------------------------------------------------------------- #
#  model -> combo token
# --------------------------------------------------------------------------- #
def combo_token(mods, key):
    """'SHIFT+F10' style token from a step's mods + key."""
    parts = [_MOD_TOKEN[m] for m in mods if m in _MOD_TOKEN]
    k = _KEY_TOKEN.get(key)
    if k is None:
        if len(key) == 1:
            k = key            # single character, firmware lowercases it
        else:
            raise BlobError(f"key {key!r} can't be sent to the ESP32 firmware")
    parts.append(k)
    return "+".join(parts)


# The dongle's display + HID keyboard are ASCII-only, so fold common typography
# to ASCII and replace anything else, rather than sending bytes it can't render
# or type.
_ASCII_FOLD = {
    ord("→"): "->", ord("←"): "<-", ord("—"): "-", ord("–"): "-",
    ord("’"): "'", ord("‘"): "'", ord("“"): '"', ord("”"): '"',
    ord("…"): "...", ord("·"): "-", ord("×"): "x",
}


def _san(text, table=None):
    """One line, ASCII only — the script goes to a line-delimited, ASCII
    device (TFT display + USB HID keyboard). `table` = the resolved
    placeholders ({BENCH}, {WIFI_SSID}, {WIFI_PASS}) for this script build."""
    t = bench.expand(text, table=table).translate(_ASCII_FOLD)
    t = t.replace("\r", " ").replace("\n", " ").replace("\t", " ")
    return t.encode("ascii", "replace").decode("ascii")


def step_to_line(step, table=None):
    op = step["op"]
    if op == "status":
        return "S " + _san(step["text"], table)
    if op == "type":
        return "Y " + _san(step["text"], table)
    if op == "line":
        return "L " + _san(step["text"], table)
    if op == "delay":
        return "W %d" % int(step["ms"])
    if op == "hold":
        return "H %s %d" % (combo_token(step.get("mods", []), step["key"]),
                            int(step["ms"]))
    if op == "taps":
        base = "T %s %d" % (combo_token(step.get("mods", []), step["key"]),
                            int(step.get("count", 1)))
        if step.get("gap"):
            base += " %d" % int(step["gap"])
        return base
    if op == "key":
        return "K " + combo_token(step.get("mods", []), step["key"])
    raise BlobError(f"unknown step op {op!r}")


# --------------------------------------------------------------------------- #
#  workflows -> script text
# --------------------------------------------------------------------------- #
def to_script(workflows, settings=None):
    """Serialise validated workflows to the device script (a str)."""
    wfs = [wm.validate_workflow(w) for w in workflows]
    if not wfs:
        raise BlobError("no workflows to flash")
    # placeholders resolve ONCE per build (nmcli/socket), and only if a step
    # actually uses one — plain Windows presets never pay for it
    table = None
    if any("{" in str(st.get("text", "")) for w in wfs for st in w["steps"]):
        table = bench.placeholders(settings)
    out = ["#V%d" % SCRIPT_VERSION]
    if settings:
        # a compact settings line the firmware may honour (optional)
        s = []
        for k in ("arm_countdown_ms", "key_down_ms", "step_settle_ms",
                  "tap_gap_ms"):
            if settings.get(k) is not None:
                s.append("%s=%d" % (k, int(settings[k])))
        if settings.get("autorun"):
            s.append("autorun=1")
        if s:
            out.append("#set:" + ",".join(s))
    for w in wfs:
        out.append("#name:" + _san(w["name"]))
        if w.get("note"):
            out.append("#note:" + _san(w["note"]))
        if w.get("button") not in (None, ""):
            out.append("#btn:%d" % int(w["button"]))
        for st in w["steps"]:
            out.append(step_to_line(st, table))
    return "\n".join(out) + "\n"


def script_stats(script):
    """(#workflows, #bytes) for a script string — for UI + NVS size checks."""
    n = sum(1 for ln in script.splitlines() if ln.startswith("#name:"))
    return n, len(script.encode("utf-8"))


# --------------------------------------------------------------------------- #
#  script text -> workflows  (round-trip / device read-back / tests)
# --------------------------------------------------------------------------- #
def _parse_combo(tok):
    mods, key = [], None
    for part in tok.split("+"):
        u = part.strip().upper()
        if not u:
            continue
        if u == "VO":
            for m in ("ctrl", "alt"):
                if m not in mods:
                    mods.append(m)
        elif u in _TOKEN_MOD:
            m = _TOKEN_MOD[u]
            if m not in mods:
                mods.append(m)
        elif u in _TOKEN_KEY:
            key = _TOKEN_KEY[u]
        elif len(part) == 1:
            key = part.lower()
        else:
            raise BlobError(f"unparseable combo token {part!r}")
    if key is None:
        raise BlobError(f"combo {tok!r} has no key")
    return mods, key


def from_script(text):
    """Parse a device script back into a list of workflow dicts."""
    workflows, cur = [], None

    def flush():
        if cur is not None:
            workflows.append(wm.validate_workflow(cur))

    for raw in text.splitlines():
        line = raw.rstrip("\n")
        if not line.strip():
            continue
        if line.startswith("#name:"):
            flush()
            cur = {"name": line[6:], "note": "", "steps": []}
            continue
        if line.startswith("#note:"):
            if cur is not None:
                cur["note"] = line[6:]
            continue
        if line.startswith("#btn:"):
            if cur is not None:
                cur["button"] = int(line[5:] or 0)
            continue
        if line.startswith("#"):        # #V1, #set:...
            continue
        if cur is None:
            continue
        op, _, rest = line.partition(" ")
        if op == "S":
            cur["steps"].append(wm.make_step("status", text=rest))
        elif op == "Y":
            cur["steps"].append(wm.make_step("type", text=rest))
        elif op == "L":
            cur["steps"].append(wm.make_step("line", text=rest))
        elif op == "W":
            cur["steps"].append(wm.make_step("delay", ms=int(rest or 0)))
        elif op == "K":
            m, k = _parse_combo(rest.strip())
            cur["steps"].append(wm.make_step("key", mods=m, key=k))
        elif op == "H":
            combo, _, ms = rest.rpartition(" ")
            m, k = _parse_combo(combo.strip())
            cur["steps"].append(wm.make_step("hold", mods=m, key=k,
                                             ms=int(ms or 0)))
        elif op == "T":
            bits = rest.split()
            combo = bits[0]
            count = int(bits[1]) if len(bits) > 1 else 1
            gap = int(bits[2]) if len(bits) > 2 else 0
            m, k = _parse_combo(combo)
            cur["steps"].append(wm.make_step("taps", mods=m, key=k,
                                             count=count, gap=gap))
        else:
            raise BlobError(f"unknown script opcode {op!r}")
    flush()
    return workflows
