#!/usr/bin/env python3
"""Tests for the Automaton Flasher (ESP32-S3 / serial edition).

Run:  python3 -m pytest keystroke_flasher/tests -q
Covers everything that doesn't need real hardware: the workflow language, the
device-script serializer, the shared library store, the serial upload protocol
(against a firmware-emulating fake transport), the Windows OOBE examples, and
the dashboard's action + render logic.
"""

import os
import sys

import pytest

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, APP)

import af_model as wm
import af_store as store
import af_blob as blob
import af_serial as ser
import af_examples as examples
import web


# --------------------------------------------------------------------------- #
#  workflow_model
# --------------------------------------------------------------------------- #
def test_norm_mods_and_vo():
    assert wm.norm_mods("shift+cmd") == ["cmd", "shift"]
    assert wm.norm_mods("vo") == ["ctrl", "alt"]


def test_make_step_variants():
    assert wm.make_step("key", mods="shift", key="f10") == {
        "op": "key", "mods": ["shift"], "key": "f10"}
    assert wm.make_step("tap", key="esc")["mods"] == []
    assert wm.make_step("line", text="start ms-cxh:localonly")["op"] == "line"
    with pytest.raises(wm.WorkflowError):
        wm.make_step("delay", ms=0)


def test_key_label_function_keys():
    assert wm.key_label(wm.make_step("key", mods="shift", key="f10")) == \
        "Shift-F10"


# --------------------------------------------------------------------------- #
#  af_blob — device script
# --------------------------------------------------------------------------- #
def test_combo_token():
    assert blob.combo_token(["shift"], "f10") == "SHIFT+F10"
    assert blob.combo_token([], "esc") == "ESC"
    assert blob.combo_token(["ctrl", "alt"], "right") == "CTRL+ALT+RIGHT"
    assert blob.combo_token([], "/") == "/"


def test_to_script_has_expected_lines():
    wf = {"name": "OOBE", "note": "n", "button": 0, "steps": [
        wm.make_step("status", text="cmd"),
        wm.make_step("key", mods="shift", key="f10"),
        wm.make_step("delay", ms=1500),
        wm.make_step("line", text="start ms-cxh:localonly"),
    ]}
    s = blob.to_script([wf])
    assert "#V1" in s
    assert "#name:OOBE" in s
    assert "#btn:0" in s
    assert "K SHIFT+F10" in s
    assert "W 1500" in s
    assert "L start ms-cxh:localonly" in s
    n, nbytes = blob.script_stats(s)
    assert n == 1 and nbytes == len(s.encode())


def test_script_roundtrip():
    wfs = examples.windows_oobe()
    s = blob.to_script(wfs)
    back = blob.from_script(s)
    assert [w["name"] for w in back] == [w["name"] for w in wfs]
    # step counts and the critical command survive the round-trip
    assert [len(w["steps"]) for w in back] == [len(w["steps"]) for w in wfs]
    joined = blob.to_script(back)
    assert "L start ms-cxh:localonly" in joined


def test_taps_with_gap_roundtrip():
    wf = {"name": "t", "steps": [
        wm.make_step("taps", mods="cmd", key="tab", count=3, gap=500)]}
    back = blob.from_script(blob.to_script([wf]))
    st = back[0]["steps"][0]
    assert st["op"] == "taps" and st["count"] == 3 and st["gap"] == 500


# --------------------------------------------------------------------------- #
#  af_examples
# --------------------------------------------------------------------------- #
def test_default_preset_is_oobe_focus_fix():
    # The first example is the bench's default selection AND the firmware's
    # built-in default (index 0) — it must be the focus-fix OOBE local account.
    first = examples.all_examples()[0]
    assert first["name"] == "OOBE: Local account (25H2)"
    ops = [(s["op"], s.get("mods"), s.get("key")) for s in first["steps"]]
    assert ("key", ["alt"], "tab") in ops        # the Alt+Tab focus nudge
    assert "start ms-cxh:localonly" in blob.to_script([first])


def _mac_batt_cmd():
    # the battery line specifically (the sysinfo line also calls ioreg)
    wf = examples.mac_battery()[0]
    return [s["text"] for s in wf["steps"]
            if s.get("op") == "line" and "BATT:" in s.get("text", "")][0]


def test_mac_battery_command_is_anchored_and_scoped():
    # Regression: on a real MacBook Air the loose /"Key"/ match grabbed the
    # inline "BatteryData" = {...} blob (sorts first, same key names, no
    # spaces) and the dongle showed Design 0 / Full 0 / Cycles 0. Guard the
    # two properties that prevent that: battery-only subtree, and matches
    # anchored to the scalar `"Key" = <digits>` at end-of-line.
    cmd = _mac_batt_cmd()
    assert "ioreg -rn AppleSmartBattery -w0" in cmd
    assert "-F'= '" not in cmd                  # the old blob-grabbing form
    for key in ("DesignCapacity", "AppleRawMaxCapacity", "CycleCount"):
        assert '"%s" = [0-9]+$' % key in cmd
    assert len(cmd) <= 480 and cmd.isascii()


def test_mac_setup_battery_uses_setup_assistant_shortcut():
    # At Setup Assistant there is no Spotlight, so this preset must open
    # Terminal with the built-in Ctrl+Opt+Cmd+T chord instead, and it must run
    # the SAME proven battery command as the logged-in preset.
    wf = examples.mac_battery_setup()[0]
    assert wf["name"] == "Battery Health (macOS Setup)"
    chord = [s for s in wf["steps"] if s.get("op") == "key"][0]
    assert sorted(chord["mods"]) == ["alt", "cmd", "ctrl"] and chord["key"] == "t"
    assert blob.combo_token(chord["mods"], chord["key"]) == "CMD+CTRL+ALT+t"
    # no Spotlight in this preset
    assert not any(s.get("key") == "space" for s in wf["steps"])
    assert not any(s.get("text") == "Terminal" for s in wf["steps"])
    # shares the exact battery command with the logged-in macOS preset
    assert _mac_batt_cmd() in [s.get("text") for s in wf["steps"]]
    # gives cold-launching Terminal time before typing
    delays = [s["ms"] for s in wf["steps"] if s.get("op") == "delay"]
    assert delays[0] >= 3000
    wm.validate_workflow(wf)
    assert "K CMD+CTRL+ALT+t" in blob.to_script([wf])
    # present in the seeded set, alongside (not replacing) the logged-in one
    names = [w["name"] for w in examples.all_examples()]
    assert "Battery Health (macOS)" in names
    assert "Battery Health (macOS Setup)" in names


def test_mac_dashboard_setup_runs_stick_without_sudo():
    # Phase 0 of the Mac-at-Setup-Assistant research: same Ctrl+Opt+Cmd+T
    # Terminal as the battery preset, then the MACDIAG stick's launcher in that
    # Terminal (bash, not `open`) with -NoSudo, because _mbsetupuser has no
    # password and benchmac.sh must never sit on a prompt.
    wf = examples.mac_dashboard_setup()[0]
    assert wf["name"] == "Mac Dashboard (macOS Setup)"
    chord = [s for s in wf["steps"] if s.get("op") == "key"][0]
    assert sorted(chord["mods"]) == ["alt", "cmd", "ctrl"] and chord["key"] == "t"
    lines = [s["text"] for s in wf["steps"] if s.get("op") == "line"]
    assert lines == [examples._DASHBOARD_MAC_SETUP]
    cmd = lines[0]
    assert cmd.startswith("bash /Volumes/MACDIAG/") and cmd.endswith("-NoSudo")
    assert "open " not in cmd and '"' not in cmd and " " not in cmd.split("/Volumes/")[1].split(" -")[0]
    assert cmd.isascii() and len(cmd) < 80
    delays = [s["ms"] for s in wf["steps"] if s.get("op") == "delay"]
    assert delays[0] >= 3000            # cold Terminal launch
    wm.validate_workflow(wf)
    assert "K CMD+CTRL+ALT+t" in blob.to_script([wf])
    names = [w["name"] for w in examples.all_examples()]
    assert "Mac Dashboard (macOS Setup)" in names
    assert "Battery Health (macOS Setup)" in names   # still there, not replaced


def _mac_sys_cmd():
    return examples._SYSINFO_MAC


def test_mac_sysinfo_command_shape_and_ordering():
    cmd = _mac_sys_cmd()
    assert len(cmd) <= 480 and cmd.isascii()
    # the four sources, and the pipe-delimited SYS: reply
    for must in ("IOPlatformSerialNumber", "machdep.cpu.brand_string",
                 "hw.memsize", "diskutil info disk0", "'SYS:%s|%s|%s|%s"):
        assert must in cmd, must
    # both macOS presets send the specs, and do so BEFORE the battery line so
    # the dongle already holds them when BATT: flips it to the readout screen
    for wf in examples.mac_battery() + examples.mac_battery_setup():
        lines = [s["text"] for s in wf["steps"] if s.get("op") == "line"]
        i_sys = next(i for i, t in enumerate(lines) if "SYS:" in t)
        i_bat = next(i for i, t in enumerate(lines) if "BATT:" in t)
        assert i_sys < i_bat, wf["name"]
        assert cmd in lines and _mac_batt_cmd() in lines
        wm.validate_workflow(wf)


@pytest.mark.skipif(
    not (__import__("shutil").which("bash") and __import__("shutil").which("awk")
         and __import__("shutil").which("sed")),
    reason="needs bash+awk+sed to run the preset end-to-end")
@pytest.mark.parametrize("cpu,mem,expect", [
    ("Apple M1", 8589934592, "SYS:C02XK1ABCDEF|Apple M1|8|251.0GB"),
    ("Apple M2 Pro", 17179869184, "SYS:C02XK1ABCDEF|Apple M2 Pro|16|251.0GB"),
    ("Intel(R) Core(TM) i5-8210Y CPU @ 1.60GHz", 8589934592,
     "SYS:C02XK1ABCDEF|i5-8210Y|8|251.0GB"),
    ("Intel(R) Xeon(R) W-3223 CPU @ 3.50GHz", 68719476736,
     "SYS:C02XK1ABCDEF|Xeon W-3223|64|251.0GB"),
])
def test_mac_sysinfo_command_end_to_end(tmp_path, cpu, mem, expect):
    # Run the LITERAL preset text against fake ioreg/sysctl/diskutil that
    # emit real-world output shapes; Intel brand strings must be cleaned to
    # the model so the line fits the dongle's 26-column display.
    import subprocess
    fakebin = tmp_path / "bin"; fakebin.mkdir()
    (fakebin / "ioreg").write_text(
        '#!/bin/sh\nprintf \'%s\\n\' \'+-o MacBookAir10,1  <class IOPlatformExpertDevice>\' '
        '\'    {\' \'      "IOPlatformUUID" = "5E2B-0000"\' '
        '\'      "IOPlatformSerialNumber" = "C02XK1ABCDEF"\' \'    }\'\n')
    (fakebin / "sysctl").write_text(
        '#!/bin/sh\ncase "$2" in machdep.cpu.brand_string) echo "%s";; '
        'hw.memsize) echo %d;; esac\n' % (cpu, mem))
    (fakebin / "diskutil").write_text(
        '#!/bin/sh\necho "   Device Identifier:         disk0"\n'
        'echo "   Disk Size:                 251.0 GB (251000193024 Bytes)"\n')
    for f in ("ioreg", "sysctl", "diskutil"):
        (fakebin / f).chmod(0o755)
    port = tmp_path / "cu.usbmodem1"; port.write_text("")
    cmd = _mac_sys_cmd().replace("/dev/cu.usbmodem*", str(tmp_path / "cu.usbmodem*"))
    env = dict(os.environ, PATH="%s:%s" % (fakebin, os.environ.get("PATH", "")))
    subprocess.run(["bash", "-c", cmd], env=env, check=True, timeout=20)
    assert port.read_text().strip() == expect


def test_windows_battery_treats_zero_cycles_as_unreported():
    # Regression: an MSI bench laptop reported CycleCount 0 (its pack doesn't
    # expose it via ACPI _BIX) and the dongle showed a misleading "Cycles: 0"
    # next to 66% health. The preset must blank the field on 0/empty so the
    # firmware hides the line (it draws Cycles only when the field is a number).
    wf = examples.windows_battery()[0]
    cmd = [s["text"] for s in wf["steps"]
           if s.get("op") == "line" and "powercfg" in s.get("text", "")][0]
    assert "if(!$k -or $k -eq 0){$k=''}" in cmd
    assert 'WriteLine("BATT:$d,$f,,$k")' in cmd     # 4th field carries cycles
    assert len(cmd) <= 480 and cmd.isascii()


@pytest.mark.skipif(
    not (__import__("shutil").which("bash") and __import__("shutil").which("awk")),
    reason="needs bash+awk to run the preset end-to-end")
def test_mac_battery_command_survives_batterydata_blob(tmp_path):
    # Run the LITERAL preset text against a fake ioreg that emits the trap,
    # with the dongle port redirected to a file. Must yield clean numbers.
    import subprocess
    sim = (
        '+-o AppleSmartBattery  <class AppleSmartBattery>\n'
        '    {\n'
        '      "BatteryInstalled" = Yes\n'
        '      "BatteryData" = {"DesignCapacity"=4382,"CycleCount"=34,'
        '"AppleRawMaxCapacity"=4165}\n'
        '      "DesignCapacity" = 4382\n'
        '      "AppleRawMaxCapacity" = 4165\n'
        '      "CycleCount" = 34\n'
        '    }\n')
    fakebin = tmp_path / "bin"; fakebin.mkdir()
    (fakebin / "ioreg").write_text("#!/bin/sh\ncat '%s'\n" % (tmp_path / "sim.txt"))
    (fakebin / "ioreg").chmod(0o755)
    (tmp_path / "sim.txt").write_text(sim)
    port = tmp_path / "cu.usbmodem1"; port.write_text("")
    cmd = _mac_batt_cmd().replace("/dev/cu.usbmodem*", str(tmp_path / "cu.usbmodem*"))
    env = dict(os.environ, PATH="%s:%s" % (fakebin, os.environ.get("PATH", "")))
    subprocess.run(["bash", "-c", cmd], env=env, check=True, timeout=20)
    assert port.read_text().strip() == "BATT:4382,4165,95,34"


def test_examples_validate_and_include_localonly():
    wfs = examples.all_examples()
    assert wfs and all("name" in w for w in wfs)
    for w in wfs:
        wm.validate_workflow(w)          # must not raise
    names = [w["name"] for w in wfs]
    assert any("Local account" in n for n in names)
    s = blob.to_script(wfs)
    assert "start ms-cxh:localonly" in s


# --------------------------------------------------------------------------- #
#  store — seeding + selection
# --------------------------------------------------------------------------- #
def test_seed_if_new(tmp_path):
    app = str(tmp_path)
    assert store.seed_if_new(app, examples.all_examples()) is True
    assert len(store.load_library(app)["workflows"]) == len(
        examples.all_examples())
    # second call is a no-op (never clobbers)
    assert store.seed_if_new(app, examples.all_examples()) is False


def test_selection_resolves(tmp_path):
    app = str(tmp_path)
    store.seed_if_new(app, examples.all_examples())
    name = examples.all_examples()[0]["name"]
    store.save_selection(app, [name])
    sel = store.selected_workflows(app)
    assert len(sel) == 1 and sel[0]["name"] == name


# --------------------------------------------------------------------------- #
#  af_serial — protocol against a firmware-emulating fake transport
# --------------------------------------------------------------------------- #
class FakeFirmware:
    """Emulates the ESP32 wf_store serial companion, enough to test the link."""

    def __init__(self, ident="AUTOMATON 1.0", quiet_ready=False):
        self.ident = ident
        self.quiet_ready = quiet_ready
        self._in = ""
        self._out = []          # queued reply lines (str, no newline)
        self._cap = None        # capture buffer when in WBEGIN..WEND
        self.stored = ""
        self.closed = False

    # transport interface -------------------------------------------------
    def write(self, data):
        self._in += data.decode("utf-8", "replace")
        while "\n" in self._in:
            line, self._in = self._in.split("\n", 1)
            self._line(line.rstrip("\r"))

    def readline(self):
        if self._out:
            return (self._out.pop(0) + "\n").encode()
        return b""

    def close(self):
        self.closed = True

    # firmware behaviour --------------------------------------------------
    def _line(self, line):
        u = line.strip().upper()
        if self._cap is not None and u != "WEND":
            self._cap.append(line)
            return
        if u == "IDENT":
            self._out.append(self.ident)
        elif u == "WBEGIN":
            self._cap = []
            if not self.quiet_ready:
                self._out.append("WREADY")
        elif u == "WEND":
            body = "\n".join(self._cap or [])
            self._cap = None
            self.stored = body
            n = sum(1 for ln in body.splitlines() if ln.startswith("#name:"))
            self._out.append("WOK %d %d" % (n, len(body.encode())))
        elif u == "WINFO":
            n = sum(1 for ln in self.stored.splitlines()
                    if ln.startswith("#name:"))
            self._out.append("WINFO %d %d" % (n, len(self.stored.encode())))
        elif u == "WCLEAR":
            self.stored = ""
            self._out.append("WOK 0 0")


def test_probe_identifies():
    # current firmware (>= v1.3) identifies as KEYSTROKE
    assert "KEYSTROKE" in ser.probe(FakeFirmware(ident="KEYSTROKE 1.3")).upper()
    # a board still on pre-rename firmware must ALSO be found (so it can be
    # updated from the bench), via the legacy AUTOMATON token
    assert "AUTOMATON" in ser.probe(FakeFirmware()).upper()
    assert ser.probe(FakeFirmware(ident="SOMETHING ELSE")) is None


def test_ident_tokens_new_first_and_legacy_kept():
    assert ser.IDENT_MATCHES[0] == "KEYSTROKE"
    assert "AUTOMATON" in ser.IDENT_MATCHES
    assert ser.IDENT_MATCH == "KEYSTROKE"          # old module attr still works
    assert ser._is_ident("=== KEYSTROKE v1.3 — BOOT ===")
    assert ser._is_ident("=== AUTOMATON v1.1 - BOOT ===")
    assert not ser._is_ident("USB JTAG/serial debug unit")


def test_find_device_injected():
    fws = {"/dev/ttyACM0": FakeFirmware()}
    dev = ser.find_device(open_fn=lambda p: fws[p], ports=["/dev/ttyACM0"])
    assert dev and dev["port"] == "/dev/ttyACM0"
    assert "label" in dev
    # nothing that identifies
    none = ser.find_device(open_fn=lambda p: FakeFirmware(ident="NOPE"),
                           ports=["/dev/ttyACM0"])
    assert none is None


def test_diagnose_reports_every_port():
    def opener(p):
        return FakeFirmware() if p == "/dev/ttyACM0" \
            else FakeFirmware(ident="Some other sketch")
    rows = ser.diagnose(open_fn=opener,
                        ports=["/dev/ttyACM0", "/dev/ttyUSB0"], timeout=1.0)
    assert len(rows) == 2
    m = {r["port"]: r for r in rows}
    assert m["/dev/ttyACM0"]["matched"] is True
    assert "AUTOMATON" in m["/dev/ttyACM0"]["ident"].upper()
    assert m["/dev/ttyUSB0"]["matched"] is False
    assert m["/dev/ttyUSB0"]["lines"]        # captured the non-matching reply


def test_probe_retries_and_reads_banner():
    # a device that only emits its boot banner (no direct IDENT reply path),
    # for both the current and the legacy banner wording
    def banner_only(text):
        class BannerOnly(FakeFirmware):
            def _line(self, line):
                if line.strip().upper() == "IDENT":
                    self._out.append(text)
        return BannerOnly()
    assert ser.probe(banner_only("=== KEYSTROKE v1.3 — BOOT ==="), timeout=1.5)
    assert ser.probe(banner_only("=== AUTOMATON v1.1 - BOOT ==="), timeout=1.5)


def test_upload_and_info_roundtrip():
    fw = FakeFirmware()
    al = ser.AutomatonLink(fw)
    script = blob.to_script(examples.windows_oobe())
    res = al.upload(script)
    assert res["ok"] and res["workflows"] == len(examples.windows_oobe())
    assert res["bytes"] == len(fw.stored.encode())
    # the device now reports the same
    info = al.info()
    assert info["workflows"] == res["workflows"]
    # and the stored text is our script verbatim -> parses back
    back = blob.from_script(fw.stored)
    assert [w["name"] for w in back] == \
        [w["name"] for w in examples.windows_oobe()]


def test_upload_survives_quiet_ready():
    fw = FakeFirmware(quiet_ready=True)          # firmware doesn't send WREADY
    res = ser.AutomatonLink(fw).upload(blob.to_script(examples.windows_oobe()))
    assert res["ok"]


def test_clear():
    fw = FakeFirmware()
    al = ser.AutomatonLink(fw)
    al.upload(blob.to_script(examples.windows_oobe()))
    assert al.clear()["workflows"] == 0
    assert fw.stored == ""


def test_upload_no_confirmation_raises():
    class Mute(FakeFirmware):
        def _line(self, line):
            pass  # never replies
    with pytest.raises(ser.SerialError):
        ser.AutomatonLink(Mute()).upload(
            blob.to_script(examples.windows_oobe()), timeout=0.4)


# --------------------------------------------------------------------------- #
#  web — actions + render (no Flask)
# --------------------------------------------------------------------------- #
def test_web_build_save_stage(tmp_path):
    app = str(tmp_path)
    web.apply_action(app, "add_step",
                     {"op": "key", "mods": ["shift"], "key": "f10"})
    web.apply_action(app, "add_step", {"op": "line",
                                       "text": "start ms-cxh:localonly"})
    ok, err = web.apply_action(app, "save_workflow", {"name": "OOBE"})
    assert not err and "Saved" in ok
    web.apply_action(app, "toggle_stage", {"name": "OOBE"})
    assert store.load_selection(app)["names"] == ["OOBE"]


def test_web_load_examples_action(tmp_path):
    app = str(tmp_path)
    ok, err = web.apply_action(app, "load_examples", {})
    assert not err and "example" in ok.lower()
    assert len(store.load_library(app)["workflows"]) >= 3


def test_web_render_has_windows_framing(tmp_path):
    app = str(tmp_path)
    store.seed_if_new(app, examples.all_examples())
    html = web.render_page(app, "/x/automaton_flasher/")
    assert "Windows OOBE" in html or "Windows" in html
    assert "OOBE: Local account (25H2)" in html
    assert "Add a step" in html


def test_web_bad_step_reports_error(tmp_path):
    app = str(tmp_path)
    ok, err = web.apply_action(app, "add_step",
                               {"op": "key", "key": "notakey"})
    assert err and not ok
