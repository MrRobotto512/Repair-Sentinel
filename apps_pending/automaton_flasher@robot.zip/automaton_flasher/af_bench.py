#!/usr/bin/env python3
"""
af_bench.py — where is THIS bench on the network, and where is the Mac
Diagnostics profile on disk?

Used by two things:
  * af_blob: a workflow may type "{BENCH}" and it is expanded at flash time to
    the bench's LAN address (ip:port of the Hero Dashboard), so a preset can
    make the target machine fetch something FROM the bench. The address is
    resolved when the script is built (flash / api preview), never stored.
  * web.py: the /x/keystroke_flasher/macdiag.tgz route packs the Mac
    Diagnostics stick profile (usb_profiles/mac-diag) into a tar.gz so a Mac
    at Setup Assistant — where Terminal is denied removable volumes — can
    curl it into /tmp and run the Dashboard from there.

  * {WIFI_SSID} / {WIFI_PASS}: the shop Wi-Fi, so a preset can make a Mac at
    Setup Assistant JOIN the network first (networksetup -setairportnetwork
    works as _mbsetupuser — Ryan verified). Source order: the flasher's own
    settings (wifi_ssid / wifi_pass, for a wired bench or a guest network) →
    env KF_WIFI_SSID / KF_WIFI_PASS → the network this bench is on
    (NetworkManager, same lookup the ESP32 Flasher's 📶 WI-FI push uses).

Overrides (env): KF_BENCH="ip:port" (whole address), KF_BENCH_PORT,
KF_MACDIAG_DIR (profile folder), KF_WIFI_SSID / KF_WIFI_PASS. Pure
functions, no Flask.
"""

from __future__ import annotations

import io
import os
import socket
import subprocess
import tarfile

DASHBOARD_PORT = 8377          # tech_notes_server / Hero Dashboard
BUNDLE_TOP = "mac-diag"        # folder name inside the tarball -> /tmp/mac-diag
BUNDLE_ROUTE = "macdiag.tgz"   # sub-path under /x/<app folder>/

# What NOT to ship to a Mac at the setup screen: the 2.5 MB smartctl (root-
# only, useless there), reports/logs from earlier runs, editor droppings.
_SKIP_DIRS = {"_bin", "__pycache__"}
_SKIP_DIR_SUFFIX = ("-Reports",)
_SKIP_FILES = {".DS_Store", ".gitkeep"}
_SKIP_FILE_SUFFIX = ("-last-run.log", ".pyc")


def lan_ip():
    """This machine's LAN IP (the UDP-connect trick: no packet is sent).
    Falls back to '<hostname>.local' — macOS resolves mDNS names natively."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("10.255.255.255", 1))
            ip = s.getsockname()[0]
        finally:
            s.close()
        if ip and not ip.startswith("127."):
            return ip
    except Exception:
        pass
    return socket.gethostname().split(".")[0] + ".local"


def bench_addr():
    """'ip:port' of the Hero Dashboard as a machine on the LAN would reach it."""
    a = os.environ.get("KF_BENCH", "").strip()
    if a:
        return a
    port = os.environ.get("KF_BENCH_PORT", "").strip() or str(DASHBOARD_PORT)
    return "%s:%s" % (lan_ip(), port)


def _run_quiet(cmd, timeout=8):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.stdout if r.returncode == 0 else ""
    except Exception:
        return ""


def _nm_wifi(active_only):
    """(ssid, psk, source) from NetworkManager, escalating with `sudo -n`
    (bench Pis have passwordless sudo; the psk is root-readable only)."""
    for pre in ([], ["sudo", "-n"]):
        args = ["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"]
        if active_only:
            args.append("--active")
        out = _run_quiet(pre + args)
        for ln in out.strip().splitlines():
            name, _, ctype = ln.partition(":")
            if "wireless" not in ctype:
                continue
            ssid = _run_quiet(pre + ["nmcli", "-g", "802-11-wireless.ssid",
                                     "connection", "show", name]).strip()
            psk = _run_quiet(pre + ["nmcli", "-s", "-g",
                                    "802-11-wireless-security.psk",
                                    "connection", "show", name]).strip()
            if ssid and psk:
                return ssid, psk, ("this bench's Wi-Fi (%s)" % name
                                   if active_only else
                                   "saved on this bench (%s)" % name)
    return "", "", ""


def wifi_creds(settings=None):
    """(ssid, password, source). Empty strings when nothing is known — the
    preset then types an empty join that macOS rejects harmlessly."""
    s = settings or {}
    ssid = str(s.get("wifi_ssid") or "").strip()
    if ssid:
        return ssid, str(s.get("wifi_pass") or ""), "flasher settings"
    ssid = os.environ.get("KF_WIFI_SSID", "").strip()
    if ssid:
        return ssid, os.environ.get("KF_WIFI_PASS", ""), "environment"
    for active in (True, False):
        ssid, psk, src = _nm_wifi(active)
        if ssid:
            return ssid, psk, src
    return "", "", "no Wi-Fi known — set it in the flasher settings"


def shell_dq(text):
    """Make text safe INSIDE a double-quoted bash string ("…")."""
    return (str(text).replace("\\", "\\\\").replace('"', '\\"')
            .replace("$", "\\$").replace("`", "\\`"))


def placeholders(settings=None):
    """Everything a typed command may reference, resolved right now."""
    ssid, psk, _src = wifi_creds(settings)
    return {"{BENCH}": bench_addr(),
            "{WIFI_SSID}": shell_dq(ssid),
            "{WIFI_PASS}": shell_dq(psk)}


def expand(text, settings=None, table=None):
    """Replace {BENCH} / {WIFI_SSID} / {WIFI_PASS} — only when present, so
    ordinary text costs nothing (no nmcli call, no socket)."""
    t = str(text)
    if "{" not in t:
        return t
    table = table if table is not None else placeholders(settings)
    for k, v in table.items():
        if k in t:
            t = t.replace(k, v)
    return t


def project_dir():
    """BenchTool checkout on this bench, or None.
    BENCH_TOOLS_DIR is set for user apps by the launcher (see app_sdk/README);
    inside the dashboard the built-in tools/ folder is importable instead."""
    t = os.environ.get("BENCH_TOOLS_DIR", "").strip()
    if t and os.path.isdir(t):
        return os.path.dirname(os.path.abspath(t))
    try:
        import usb_drive  # tools/ is on sys.path inside the Hero Dashboard
        return usb_drive.PROJECT_DIR
    except Exception:
        pass
    for cand in ("~/BenchTool-Project", "~/benchtool", "~/BenchTool"):
        p = os.path.expanduser(cand)
        if os.path.isdir(os.path.join(p, "usb_profiles")):
            return p
    return None


def macdiag_dir():
    """The usb_profiles/mac-diag folder, or None when this bench has no copy."""
    d = os.environ.get("KF_MACDIAG_DIR", "").strip()
    if d:
        return d if os.path.isdir(d) else None
    p = project_dir()
    if not p:
        return None
    d = os.path.join(p, "usb_profiles", "mac-diag")
    return d if os.path.isdir(d) else None


def _wanted(rel_dir_parts, name, is_dir):
    if is_dir:
        if name in _SKIP_DIRS or name.endswith(_SKIP_DIR_SUFFIX):
            return False
        return True
    if name in _SKIP_FILES or name.endswith(_SKIP_FILE_SUFFIX):
        return False
    return True


def bundle_bytes(profile_dir, gemini_key_path=None):
    """tar.gz of the profile as <BUNDLE_TOP>/…, minus _bin / reports / logs.
    Like the stick writer, drops the bench's gemini.key into Tools/ when one is
    given (the Mac has network by definition in this flow, so AI verdicts work).
    Returns (bytes, member_names)."""
    profile_dir = os.path.abspath(profile_dir)
    buf = io.BytesIO()
    names = []
    with tarfile.open(fileobj=buf, mode="w:gz") as tf:
        for root, dirs, files in os.walk(profile_dir):
            rel = os.path.relpath(root, profile_dir)
            rel_parts = [] if rel == "." else rel.split(os.sep)
            dirs[:] = sorted(d for d in dirs if _wanted(rel_parts, d, True))
            for f in sorted(files):
                if not _wanted(rel_parts, f, False):
                    continue
                full = os.path.join(root, f)
                arc = "/".join([BUNDLE_TOP] + rel_parts + [f])
                ti = tf.gettarinfo(full, arcname=arc)
                ti.uid = ti.gid = 0
                ti.uname = ti.gname = ""
                if f.endswith((".command", ".sh")) or "/_bin/" in arc:
                    ti.mode |= 0o111
                with open(full, "rb") as fh:
                    tf.addfile(ti, fh)
                names.append(arc)
        if gemini_key_path and os.path.isfile(gemini_key_path):
            key = open(gemini_key_path, "rb").read().strip() + b"\n"
            ti = tarfile.TarInfo(BUNDLE_TOP + "/Tools/gemini.key")
            ti.size = len(key)
            ti.mode = 0o600
            tf.addfile(ti, io.BytesIO(key))
            names.append(ti.name)
    return buf.getvalue(), names
