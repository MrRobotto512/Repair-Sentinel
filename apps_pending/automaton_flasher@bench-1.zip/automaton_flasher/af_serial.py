#!/usr/bin/env python3
"""
af_serial.py — talk to the ESP32-S3 Automaton over its USB-CDC serial console.

The dongle (a Freenove ESP32-S3 CYD / ESP32-S3-N16R8) uses the chip's NATIVE USB,
so on the Pi it shows up as /dev/ttyACM* and speaks USB-CDC directly — no UART
bridge, no drive to mount. We identify it by sending IDENT and matching the
firmware's "AUTOMATON" reply, then stream workflows to it (WBEGIN..WEND).

Detection is deliberately patient and self-explaining, because the bench has no
terminal: it enumerates ports (with VID/PID + description when pyserial's
list_ports is available), warms each port up, and retries IDENT over a few
seconds (a freshly-plugged S3 CDC can take ~1s to be ready). diagnose() returns
what every port said, so the touchscreen can show the technician the truth.

Upload protocol (bench → device), line-based at 115200 8N1:
    IDENT                       -> "AUTOMATON <ver>"
    WBEGIN                      -> "WREADY"            (device enters capture)
    <script line>               (repeated)
    WEND                        -> "WOK <count> <bytes>" | "WERR <reason>"
    WINFO                       -> "WINFO <count> <bytes>"
    WCLEAR                      -> "WOK 0 0"

The transport is injectable (write(bytes)/readline()->bytes/close(), optional
warmup()/reset_input()), so all of this is unit-tested without pyserial or
hardware. pyserial is only imported when actually opening a real port.
"""

from __future__ import annotations

import glob
import os
import time

IDENT_MATCH = "AUTOMATON"
BAUD = 115200

# USB VID/PIDs worth prioritising / labelling when we can read them.
ESPRESSIF_VID = 0x303A          # native ESP32-S3 USB (what this board uses)
BRIDGE_VIDS = {0x1A86: "CH34x", 0x10C4: "CP210x", 0x0403: "FTDI",
               0x303A: "Espressif"}


class SerialError(Exception):
    """A serial/transport problem worth showing the technician."""


# --------------------------------------------------------------------------- #
#  Transport
# --------------------------------------------------------------------------- #
class PySerialTransport:
    """Thin wrapper over pyserial with a line reader and a CDC-friendly open."""

    def __init__(self, port, baud=BAUD, timeout=1.0):
        try:
            import serial  # pyserial; present in the bench venv
        except ImportError as e:  # pragma: no cover
            raise SerialError("pyserial not available: %s" % e)
        try:
            # Do NOT let opening toggle DTR/RTS in a way that resets the board;
            # for native USB-CDC these lines are just readable state.
            self._s = serial.Serial()
            self._s.port = port
            self._s.baudrate = baud
            self._s.timeout = timeout
            try:
                self._s.dtr = True
                self._s.rts = False
            except Exception:
                pass
            self._s.open()
        except Exception as e:
            raise SerialError("couldn't open %s: %s" % (port, e))
        self.port = port

    def warmup(self):
        # A just-enumerated S3 CDC needs a beat before it reliably echoes.
        time.sleep(0.35)
        self.reset_input()

    def reset_input(self):
        try:
            self._s.reset_input_buffer()
        except Exception:
            pass

    def write(self, data):
        self._s.write(data)
        self._s.flush()

    def readline(self):
        return self._s.readline()

    def close(self):
        try:
            self._s.close()
        except Exception:
            pass


def open_serial(port, baud=BAUD, timeout=1.0):
    return PySerialTransport(port, baud, timeout)


# --------------------------------------------------------------------------- #
#  Port discovery
# --------------------------------------------------------------------------- #
def _pyserial_ports():
    """[(device, vid, pid, description)] via pyserial, or [] if unavailable."""
    try:
        from serial.tools import list_ports
    except Exception:
        return []
    out = []
    try:
        for p in list_ports.comports():
            out.append((p.device, getattr(p, "vid", None),
                        getattr(p, "pid", None),
                        (getattr(p, "description", "") or "").strip()))
    except Exception:
        return []
    return out


def list_candidate_ports(globs=None):
    """Serial ports that could be the dongle, best first.

    Native ESP32-S3 USB shows as /dev/ttyACM*; a few clones use a UART bridge
    (/dev/ttyUSB*). We also fold in pyserial's view (so we can prioritise the
    Espressif VID) and /dev/serial/by-id/* symlinks.
    """
    ordered = []
    seen_real = set()

    def add(dev):
        # de-dupe by the real device, so a /dev/serial/by-id/* symlink and its
        # /dev/ttyACM0 target don't get probed (and shown) as two ports.
        if not dev:
            return
        try:
            real = os.path.realpath(dev)
        except Exception:
            real = dev
        if real in seen_real or dev in ordered:
            return
        seen_real.add(real)
        ordered.append(dev)

    # 1) pyserial, Espressif first — but ONLY real USB serial devices. A Pi
    #    exposes many legacy /dev/ttyS* / ttyAMA* UARTs (vid=None); probing all
    #    of them is slow and pointless. Keep USB (has a VID) or ttyACM*/ttyUSB*.
    def _usbish(dev, vid):
        base = os.path.basename(dev)
        return vid is not None or base.startswith(("ttyACM", "ttyUSB"))

    ps = [p for p in _pyserial_ports() if _usbish(p[0], p[1])]
    for dev, vid, _pid, _desc in [p for p in ps if p[1] == ESPRESSIF_VID]:
        add(dev)
    for dev, _vid, _pid, _desc in ps:
        add(dev)

    # 2) raw globs (ACM before USB — native USB is the common case here)
    for pat in (globs or ["/dev/ttyACM*", "/dev/ttyUSB*"]):
        for dev in sorted(glob.glob(pat)):
            add(dev)

    # 3) by-id symlinks (stable names; harmless duplicates are de-duped by add)
    for dev in sorted(glob.glob("/dev/serial/by-id/*")):
        add(dev)

    return ordered


def _port_label(port):
    """A human tag like 'Espressif · USB JTAG/serial' for a device path."""
    for dev, vid, pid, desc in _pyserial_ports():
        if dev == port:
            vend = BRIDGE_VIDS.get(vid or -1)
            bits = []
            if vend:
                bits.append(vend)
            if desc:
                bits.append(desc)
            if vid and pid:
                bits.append("%04x:%04x" % (vid, pid))
            return " · ".join(bits) if bits else port
    return os.path.basename(port)


# --------------------------------------------------------------------------- #
#  Probe
# --------------------------------------------------------------------------- #
def _read_lines(transport, deadline, want_prefixes=None, collect=None):
    """Read decoded, stripped lines until a deadline (or a wanted prefix).
    Appends every line seen to `collect` if given (for diagnostics)."""
    lines = []
    while time.time() < deadline:
        raw = transport.readline()
        if not raw:
            time.sleep(0.005)      # fake transport returns instantly
            continue
        try:
            line = raw.decode("utf-8", "replace").strip()
        except Exception:
            continue
        if not line:
            continue
        lines.append(line)
        if collect is not None:
            collect.append(line)
        if want_prefixes and any(line.startswith(w) for w in want_prefixes):
            break
    return lines


def probe(transport, timeout=3.0, attempts=3, collect=None):
    """Identify an Automaton: send IDENT (a few times, patiently) and match the
    firmware's reply — or its boot banner, which also contains 'AUTOMATON'.
    Returns the matching line, or None. `collect` gathers everything seen."""
    if hasattr(transport, "warmup"):
        try:
            transport.warmup()
        except Exception:
            pass
    slice_s = max(timeout / max(attempts, 1), 0.5)
    for _ in range(max(attempts, 1)):
        try:
            transport.write(b"IDENT\n")
        except Exception as e:
            raise SerialError("write failed: %s" % e)
        for line in _read_lines(transport, time.time() + slice_s,
                                want_prefixes=None, collect=collect):
            if IDENT_MATCH in line.upper():
                return line
    return None


def find_device(open_fn=open_serial, ports=None, timeout=3.0):
    """Scan candidate ports for the dongle. Returns {"port","ident","label"} or
    None. `open_fn(port)` is injectable for tests."""
    for port in (ports if ports is not None else list_candidate_ports()):
        t = None
        try:
            t = open_fn(port)
            ident = probe(t, timeout=timeout)
            if ident:
                return {"port": port, "ident": ident,
                        "label": _safe_label(port)}
        except SerialError:
            continue
        except Exception:
            continue
        finally:
            if t is not None:
                t.close()
    return None


def _safe_label(port):
    try:
        return _port_label(port)
    except Exception:
        return os.path.basename(port)


def diagnose(open_fn=open_serial, ports=None, timeout=2.0):
    """Probe every candidate port and report what happened — for the on-screen
    diagnostic. Returns a list of dicts:
        {"port","label","opened","matched","ident","lines"[]}"""
    results = []
    cand = ports if ports is not None else list_candidate_ports()
    if not cand:
        return results
    for port in cand:
        row = {"port": port, "label": _safe_label(port), "opened": False,
               "matched": False, "ident": "", "lines": []}
        t = None
        try:
            t = open_fn(port)
            row["opened"] = True
            collect = []
            ident = probe(t, timeout=timeout, collect=collect)
            row["lines"] = collect[-6:]
            if ident:
                row["matched"] = True
                row["ident"] = ident
        except SerialError as e:
            row["lines"] = [str(e)]
        except Exception as e:
            row["lines"] = [str(e)]
        finally:
            if t is not None:
                t.close()
        results.append(row)
    return results


# --------------------------------------------------------------------------- #
#  The link (upload / info / clear)
# --------------------------------------------------------------------------- #
class AutomatonLink:
    """A conversation with one open transport. Caller owns closing it."""

    def __init__(self, transport):
        self.t = transport

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def close(self):
        self.t.close()

    def ident(self, timeout=3.0):
        return probe(self.t, timeout=timeout)

    def upload(self, script, timeout=6.0, progress=None):
        """Stream a device script (str) to NVS. Returns
        {"ok","workflows","bytes","message"} or raises SerialError."""
        if hasattr(self.t, "reset_input"):
            self.t.reset_input()
        lines = [ln for ln in script.splitlines()]
        try:
            self.t.write(b"WBEGIN\n")
            self._read_reply(["WREADY", "WERR"], timeout=2.0)
            total = len(lines)
            for i, ln in enumerate(lines):
                self.t.write(ln.encode("utf-8", "replace") + b"\n")
                if progress and total:
                    progress(i + 1, total)
            self.t.write(b"WEND\n")
        except SerialError:
            raise
        except Exception as e:
            raise SerialError("upload write failed: %s" % e)

        reply = self._read_reply(["WOK", "WERR"], timeout=timeout)
        if reply is None:
            raise SerialError("no confirmation from device — is it running "
                              "the ESP32 firmware esp32s3_automaton v1.2 (workflow-store "
                              "companion)? Re-flash it and try again.")
        if reply.startswith("WERR"):
            raise SerialError("device rejected the upload: " + reply[4:].strip())
        return _parse_wok(reply)

    def info(self, timeout=2.0):
        self.t.write(b"WINFO\n")
        reply = self._read_reply(["WINFO", "WERR"], timeout=timeout)
        if not reply or reply.startswith("WERR"):
            return {"workflows": 0, "bytes": 0}
        return _parse_wok(reply, tag="WINFO")

    def clear(self, timeout=3.0):
        self.t.write(b"WCLEAR\n")
        reply = self._read_reply(["WOK", "WERR"], timeout=timeout)
        if not reply:
            raise SerialError("no confirmation of clear")
        if reply.startswith("WERR"):
            raise SerialError(reply[4:].strip())
        return _parse_wok(reply)

    def _read_reply(self, prefixes, timeout):
        for line in _read_lines(self.t, time.time() + timeout,
                                want_prefixes=prefixes):
            for p in prefixes:
                if line.startswith(p):
                    return line
        return None


def _parse_wok(line, tag="WOK"):
    parts = line.split()
    n = _int(parts[1]) if len(parts) > 1 else 0
    b = _int(parts[2]) if len(parts) > 2 else 0
    return {"ok": line.startswith(tag) or line.startswith("WOK"),
            "workflows": n, "bytes": b, "message": line}


def _int(s):
    try:
        return int(s)
    except (ValueError, TypeError):
        return 0
