## 2026-11-08 15:25
a ddns dynamic ip address updater client that works with no-ip.com services so Ip address updates can be sent to update a ddns

