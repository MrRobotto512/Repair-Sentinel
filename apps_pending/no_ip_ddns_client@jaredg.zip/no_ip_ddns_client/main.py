import sys
import os
import json
import time
import threading
import urllib.request
import urllib.parse
import base64
import tkinter as tk

try:
    import ui_theme
except ImportError:
    ui_theme = None

try:
    import bench_keyboard
except ImportError:
    bench_keyboard = None

CONFIG_FILE = os.path.expanduser('~/.noip_ddns_config.json')

BG_NORMAL = '#0d0d0f'
BG_CARD = '#1b1b21'
BG_CODE = '#101014'
BG_CHIP = '#22222a'
BORDER_DIM = '#2a2a32'
FG_MAIN = '#e8e8f0'
FG_DIM = '#aab0bf'
FG_MUTED = '#7a7a8c'
ACCENT_OK = '#00c853'
ACCENT_ERR = '#ff5252'
ACCENT_WARN = '#ffab00'

class NoIPApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title('No-IP DDNS Client')
        self.root.configure(bg=BG_NORMAL)
        
        if ui_theme:
            try:
                ui_theme.apply_root(self.root)
            except Exception as e:
                print('ui_theme error:', e)
        else:
            self.root.geometry('800x480')
            
        self.auto_update_active = False
        self.timer_id = None
        self.last_ip = 'Unknown'
        self.is_updating = False
        
        self._build_ui()
        self._load_config()
        self._check_public_ip_async() # Initial IP check on startup
        
    def _build_ui(self):
        header = tk.Frame(self.root, bg=BG_CARD, height=45)
        header.pack(fill=tk.X, side=tk.TOP)
        header.pack_propagate(False)
        
        lbl_title = tk.Label(header, text='🌐 No-IP DDNS Updater', font=('DejaVu Sans', 16, 'bold'), fg=FG_MAIN, bg=BG_CARD)
        lbl_title.pack(side=tk.LEFT, padx=12, pady=6)
        
        btn_exit = tk.Button(header, text='X', font=('DejaVu Sans', 14, 'bold'), fg=FG_MAIN, bg='#d32f2f', activebackground='#b71c1c', activeforeground=FG_MAIN, bd=0, command=self.close, width=4)
        btn_exit.pack(side=tk.RIGHT, padx=8, pady=6)
        
        body = tk.Frame(self.root, bg=BG_NORMAL)
        body.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        
        left = tk.Frame(body, bg=BG_CARD, bd=1, relief=tk.SOLID)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 4))
        
        right = tk.Frame(body, bg=BG_CARD, bd=1, relief=tk.SOLID)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(4, 0))
        
        # Left Panel
        cfg_title = tk.Label(left, text='Account Credentials', font=('DejaVu Sans', 13, 'bold'), fg=FG_MAIN, bg=BG_CARD)
        cfg_title.pack(anchor='w', padx=8, pady=(8, 4))
        
        tk.Label(left, text='Username / Email:', font=('DejaVu Sans', 10), fg=FG_DIM, bg=BG_CARD).pack(anchor='w', padx=8)
        self.ent_user = tk.Entry(left, font=('DejaVu Sans', 12), bg=BG_CODE, fg=FG_MAIN, insertbackground=FG_MAIN, bd=1, relief=tk.SOLID)
        self.ent_user.pack(fill=tk.X, padx=8, pady=(2, 4))
        if bench_keyboard:
            bench_keyboard.attach(self.ent_user, title='No-IP Username')
            
        tk.Label(left, text='Password / Key:', font=('DejaVu Sans', 10), fg=FG_DIM, bg=BG_CARD).pack(anchor='w', padx=8)
        self.ent_pass = tk.Entry(left, font=('DejaVu Sans', 12), bg=BG_CODE, fg=FG_MAIN, show='*', insertbackground=FG_MAIN, bd=1, relief=tk.SOLID)
        self.ent_pass.pack(fill=tk.X, padx=8, pady=(2, 4))
        if bench_keyboard:
            bench_keyboard.attach(self.ent_pass, title='No-IP Password', secret=True)
            
        tk.Label(left, text='Hostname (e.g. host.ddns.net):', font=('DejaVu Sans', 10), fg=FG_DIM, bg=BG_CARD).pack(anchor='w', padx=8)
        self.ent_host = tk.Entry(left, font=('DejaVu Sans', 12), bg=BG_CODE, fg=FG_MAIN, insertbackground=FG_MAIN, bd=1, relief=tk.SOLID)
        self.ent_host.pack(fill=tk.X, padx=8, pady=(2, 6))
        if bench_keyboard:
            bench_keyboard.attach(self.ent_host, title='Hostname')
            
        tk.Label(left, text='Auto Update Interval:', font=('DejaVu Sans', 10), fg=FG_DIM, bg=BG_CARD).pack(anchor='w', padx=8)
        interval_frame = tk.Frame(left, bg=BG_CARD)
        interval_frame.pack(fill=tk.X, padx=8, pady=(2, 6))
        
        self.interval_var = tk.IntVar(value=15)
        for mins in (5, 15, 30, 60):
            r = tk.Radiobutton(interval_frame, text=f'{mins}m', value=mins, variable=self.interval_var, font=('DejaVu Sans', 10, 'bold'), fg=FG_MAIN, bg=BG_CARD, selectcolor=BG_CHIP, activebackground=BG_CARD, activeforeground=FG_MAIN)
            r.pack(side=tk.LEFT, expand=True)

        btn_frame = tk.Frame(left, bg=BG_CARD)
        btn_frame.pack(fill=tk.X, padx=8, pady=(4, 6))
        
        self.btn_update = tk.Button(btn_frame, text='⚡ Update Now', font=('DejaVu Sans', 12, 'bold'), fg=BG_NORMAL, bg=ACCENT_OK, activebackground='#009624', activeforeground=BG_NORMAL, bd=0, height=2, command=self.on_manual_update)
        self.btn_update.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 2))
        
        self.btn_auto = tk.Button(btn_frame, text='Auto: OFF', font=('DejaVu Sans', 12, 'bold'), fg=FG_MAIN, bg=BG_CHIP, activebackground=BORDER_DIM, activeforeground=FG_MAIN, bd=0, height=2, command=self.toggle_auto)
        self.btn_auto.pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(2, 0))
        
        self.btn_save = tk.Button(left, text='💾 Save Settings', font=('DejaVu Sans', 10), fg=FG_MAIN, bg=BG_CHIP, activebackground=BORDER_DIM, activeforeground=FG_MAIN, bd=0, command=self.save_config)
        self.btn_save.pack(fill=tk.X, padx=8, pady=(0, 8))

        # Right Panel
        st_title = tk.Label(right, text='Status & Connection', font=('DejaVu Sans', 13, 'bold'), fg=FG_MAIN, bg=BG_CARD)
        st_title.pack(anchor='w', padx=8, pady=(8, 4))
        
        ip_card = tk.Frame(right, bg=BG_CODE, bd=1, relief=tk.SOLID)
        ip_card.pack(fill=tk.X, padx=8, pady=4)
        
        tk.Label(ip_card, text='PUBLIC IP ADDRESS', font=('DejaVu Sans', 8, 'bold'), fg=FG_MUTED, bg=BG_CODE).pack(anchor='w', padx=8, pady=(4, 0))
        self.lbl_ip = tk.Label(ip_card, text='Checking...', font=('DejaVu Sans', 18, 'bold'), fg=ACCENT_OK, bg=BG_CODE)
        self.lbl_ip.pack(anchor='w', padx=8, pady=(0, 4))
        
        self.lbl_status = tk.Label(right, text='Status: Idle', font=('DejaVu Sans', 10, 'bold'), fg=FG_DIM, bg=BG_CARD, anchor='w')
        self.lbl_status.pack(fill=tk.X, padx=8, pady=(2, 1))
        
        self.lbl_last_sync = tk.Label(right, text='Last Sync: Never', font=('DejaVu Sans', 9), fg=FG_MUTED, bg=BG_CARD, anchor='w')
        self.lbl_last_sync.pack(fill=tk.X, padx=8, pady=(0, 4))
        
        tk.Label(right, text='Activity Log', font=('DejaVu Sans', 10, 'bold'), fg=FG_MAIN, bg=BG_CARD).pack(anchor='w', padx=8, pady=(4, 2))
        
        log_frame = tk.Frame(right, bg=BG_CODE)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))
        
        self.txt_log = tk.Text(log_frame, font=('DejaVu Sans Mono', 8), bg=BG_CODE, fg=FG_DIM, bd=0, highlightthickness=0, wrap=tk.WORD)
        self.txt_log.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)

    def log(self, msg):
        timestamp = time.strftime('%H:%M:%S')
        formatted = f'[{timestamp}] {msg}\n'
        self.txt_log.insert(tk.END, formatted)
        self.txt_log.see(tk.END)

    def _load_config(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    cfg = json.load(f)
                self.ent_user.delete(0, tk.END)
                self.ent_user.insert(0, cfg.get('user', ''))
                self.ent_pass.delete(0, tk.END)
                self.ent_pass.insert(0, cfg.get('pass', ''))
                self.ent_host.delete(0, tk.END)
                self.ent_host.insert(0, cfg.get('host', ''))
                self.interval_var.set(cfg.get('interval', 15))
                
                # Load auto-update state and apply directly
                self.auto_update_active = cfg.get('auto_update_active', False)
                if self.auto_update_active:
                    self.btn_auto.config(text='Auto: ON', bg=ACCENT_OK, fg=BG_NORMAL)
                    self.log('Auto-update was ENABLED. Scheduling first update. (App must remain open)')
                    self.lbl_status.config(text='Status: Auto-update scheduled', fg=ACCENT_WARN) # Added for immediate feedback
                    self.schedule_next_auto(0) # Schedule immediate first update
                else:
                    self.btn_auto.config(text='Auto: OFF', bg=BG_CHIP, fg=FG_MAIN)
                    self.log('Auto-update was DISABLED.')
                    self.lbl_status.config(text='Status: Idle', fg=FG_DIM) # Ensure idle status if disabled
                
                # Load last sync timestamp
                last_sync_text = cfg.get('last_sync_timestamp', 'Last Sync: Never')
                self.lbl_last_sync.config(text=last_sync_text)

                self.log('Loaded config file.')
            except Exception as e:
                self.log(f'Failed to load config: {e}')
        else:
            self.log('Ready. Enter credentials and hostname.')

    def save_config(self):
        cfg = {
            'user': self.ent_user.get().strip(),
            'pass': self.ent_pass.get().strip(),
            'host': self.ent_host.get().strip(),
            'interval': self.interval_var.get(),
            'auto_update_active': self.auto_update_active, # Save auto-update state
            'last_sync_timestamp': self.lbl_last_sync.cget('text') # Save last sync text
        }
        try:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(cfg, f, indent=2)
            self.log('Settings saved.')
        except Exception as e:
            self.log(f'Error saving settings: {e}')

    def _get_public_ip(self):
        services = [
            'https://api.ipify.org',
            'https://icanhazip.com',
            'https://ifconfig.me/ip',
            'https://checkip.amazonaws.com'
        ]
        for url in services:
            try:
                req = urllib.request.Request(url, headers={'User-Agent': 'BenchTool-DDNS/1.0'})
                with urllib.request.urlopen(req, timeout=4) as response:
                    ip = response.read().decode('utf-8').strip()
                    if ip:
                        return ip
            except Exception:
                continue
        return None

    def _check_public_ip_async(self):
        def worker():
            ip = self._get_public_ip()
            def update_ui():
                if ip:
                    self.last_ip = ip
                    self.lbl_ip.config(text=ip, fg=ACCENT_OK) # Set color on success
                else:
                    self.lbl_ip.config(text='Offline / Error', fg=ACCENT_ERR) # Set color on error
            self.root.after(0, update_ui)
        threading.Thread(target=worker, daemon=True).start()

    def on_manual_update(self):
        if self.is_updating:
            return
        self.save_config() # Save current settings before manual update
        self.do_update()

    def toggle_auto(self):
        self.auto_update_active = not self.auto_update_active
        if self.auto_update_active:
            self.btn_auto.config(text='Auto: ON', bg=ACCENT_OK, fg=BG_NORMAL)
            self.log('Auto-update ENABLED. (App must remain open)')
            self.schedule_next_auto(0) # Schedule immediate first update
        else:
            self.btn_auto.config(text='Auto: OFF', bg=BG_CHIP, fg=FG_MAIN)
            self.log('Auto-update DISABLED.')
            if self.timer_id:
                self.root.after_cancel(self.timer_id)
                self.timer_id = None
        self.save_config() # Save the new state immediately

    def schedule_next_auto(self, ms=None):
        if not self.auto_update_active:
            return
        if ms is None:
            ms = self.interval_var.get() * 60 * 1000
        if self.timer_id:
            self.root.after_cancel(self.timer_id)
        self.timer_id = self.root.after(ms, self.auto_update_tick)

    def auto_update_tick(self):
        if self.auto_update_active: # Double check in case it was toggled off during delay
            self.do_update()
            self.schedule_next_auto() # Schedule next update after current one finishes

    def do_update(self):
        user = self.ent_user.get().strip()
        pwd = self.ent_pass.get().strip()
        host = self.ent_host.get().strip()

        if not user or not pwd or not host:
            self.log('Error: Username, Password, and Hostname required.')
            self.lbl_status.config(text='Status: Missing Credentials', fg=ACCENT_ERR)
            return

        self.is_updating = True
        self.btn_update.config(state=tk.DISABLED, text='Updating...')
        self.lbl_status.config(text='Status: Updating...', fg=ACCENT_WARN)

        def worker():
            ip = self._get_public_ip()
            if not ip:
                self.finish_update(False, 'Failed to fetch public IP')
                return

            # Update public IP label immediately if successful
            self.root.after(0, lambda: self.lbl_ip.config(text=ip, fg=ACCENT_OK))

            url = f'https://dynupdate.no-ip.com/nic/update?hostname={urllib.parse.quote(host)}&myip={urllib.parse.quote(ip)}'
            ua = f'BenchTool-DDNS/1.0 {user}'
            
            req = urllib.request.Request(url)
            req.add_header('User-Agent', ua)
            
            auth_str = f'{user}:{pwd}'
            auth_b64 = base64.b64encode(auth_str.encode('utf-8')).decode('utf-8')
            req.add_header('Authorization', f'Basic {auth_b64}')

            try:
                with urllib.request.urlopen(req, timeout=10) as resp:
                    body = resp.read().decode('utf-8').strip()
                    self.handle_response(body, ip)
            except urllib.error.HTTPError as e:
                try:
                    body = e.read().decode('utf-8').strip()
                    self.handle_response(body if body else f'HTTP {e.code}', ip)
                except Exception:
                    self.finish_update(False, f'HTTP Error {e.code}')
            except Exception as e:
                self.finish_update(False, f'Network error: {str(e)}')

        threading.Thread(target=worker, daemon=True).start()

    def handle_response(self, resp_text, current_ip):
        parts = resp_text.split()
        code = parts[0] if parts else resp_text
        target_ip = parts[1] if len(parts) > 1 else current_ip

        if code == 'good':
            self.finish_update(True, f'Update SUCCESS: IP updated to {target_ip}')
        elif code == 'nochg':
            self.finish_update(True, f'IP unchanged ({target_ip}). Host is current.')
        elif code == 'nohost':
            self.finish_update(False, 'Error: Hostname does not exist on this account.')
        elif code == 'badauth':
            self.finish_update(False, 'Error: Invalid username or password.')
        elif code == 'badagent':
            self.finish_update(False, 'Error: User-Agent client suppressed/blocked.')
        elif code == '!donator':
            self.finish_update(False, 'Error: Requested feature unavailable for free tier.')
        elif code == 'abuse':
            self.finish_update(False, 'Error: Account blocked due to abuse.')
        elif code == '911':
            self.finish_update(False, 'Error: No-IP server status 911. Retrying in 30m.')
        else:
            self.finish_update(False, f'Response: {resp_text}')

    def finish_update(self, success, message):
        def update_ui():
            self.is_updating = False
            self.btn_update.config(state=tk.NORMAL, text='⚡ Update Now')
            self.log(message)
            now_str = time.strftime('%b %d %H:%M:%S')
            self.lbl_last_sync.config(text=f'Last Sync: {now_str}')
            if success:
                self.lbl_status.config(text='Status: Synchronized OK', fg=ACCENT_OK)
            else:
                self.lbl_status.config(text='Status: Update Failed', fg=ACCENT_ERR)
            self.save_config() # Save config after update, including last sync time

        self.root.after(0, update_ui)

    def close(self):
        # Save current state before exiting to ensure persistence
        self.save_config()

        if self.timer_id:
            try:
                self.root.after_cancel(self.timer_id)
            except Exception:
                pass
        self.root.destroy()
        sys.exit(0)

    def run(self):
        self.root.mainloop()

if __name__ == '__main__':
    app = NoIPApp()
    app.run()
