# iOS Quick Activate

Batch-activate freshly restored iPhones/iPads and skip the Setup Assistant,
so they land on the home screen ready for testing.

## What it does

Three independent operations, run over USB against every connected device:

1. **Activate** — the real handshake with Apple (albert.apple.com) that gets
   a device past "Activation Required".
2. **Skip setup screens** — writes a *cloud configuration* containing
   Apple's `SkipSetup` keys, the same mechanism Apple Configurator's
   "Prepare" uses. This is the part that actually gets you to the home
   screen; activation alone does not dismiss the setup panes.
3. **Install a Wi-Fi profile** (optional) — a `.mobileconfig` with a Wi-Fi
   payload, so the device joins the shop network by itself. Without a
   network there is no activation.

## Requirements

- `pymobiledevice3` (declared in `app.json`; the bench offers to install it
  on first launch)
- `usbmuxd` running (standard on BenchTool)
- The bench needs internet — activation talks to Apple

## How to use it

Settings live on the dashboard page (**🍏 iOS Activate** in the sidebar, or
`http://<bench-ip>:8377/x/ios_quick_activate/`): pick language and region,
tick the setup screens to skip, choose which operations to run, save.

Then either tap **▶ Execute on all devices** on that page, or hit **RUN ALL**
on the bench screen. Both drive the same code and show per-device results.

## Limits worth knowing

- **Devices must be freshly erased and sitting at the Hello screen.** A
  cloud configuration is only accepted before setup completes; a device
  that is already set up will refuse it, which is correct behaviour.
- **Activation Lock cannot be bypassed.** If a device is still signed into
  an iCloud account, Apple asks for that Apple ID and the run reports the
  device as failed. This app does not attempt to work around that.
- `AllowPairing` is set in the cloud configuration on purpose, so the
  device stays reachable for diagnostics after setup is skipped.
- Unknown skip keys are ignored by the device, so ticking everything is
  safe across iOS versions.
