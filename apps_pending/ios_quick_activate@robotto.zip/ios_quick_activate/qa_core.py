#!/usr/bin/env python3
"""
qa_core — the device logic behind iOS Quick Activate. No UI in here, so the
bench screen (main.py) and the dashboard page (web.py) can't drift apart.

WHAT THIS ACTUALLY DOES, and why it works
─────────────────────────────────────────
Getting a freshly-restored iPhone to the home screen is two separate jobs,
and they are often confused:

  1. ACTIVATE — the device talks to Apple (albert.apple.com) and gets an
     activation record. Until this happens it sits on "Activation Required"
     and nothing else can proceed. This is the real, official handshake.

  2. SKIP SETUP — activation does NOT dismiss the Setup Assistant panes
     (Hello, Language, Wi-Fi, Data & Privacy, Touch ID, Apple ID, Siri …).
     Those are skipped by writing a CLOUD CONFIGURATION to the device with
     a SkipSetup list — the same mechanism Apple Configurator's "Prepare"
     uses over USB, sent to the com.apple.mobile.MCInstall service as a
     SetCloudConfiguration request. The key names below are Apple's own.

  3. WI-FI PROFILE (optional) — a .mobileconfig with a Wi-Fi payload,
     installed before setup so the device can join the shop network on its
     own and reach Apple. Without network there is no activation.

All three run over USB through pymobiledevice3.

WHAT IT CANNOT DO
  • It cannot pass Activation Lock. If a device is still signed into
    someone's iCloud, Apple refuses and asks for that Apple ID — the run
    reports it and moves on. There is no way around that and this app does
    not try.
  • The device must be freshly erased and sitting at the Hello / Setup
    screen. A cloud configuration is only accepted before setup completes;
    on a device that is already set up it is rejected, which is correct.
"""

import json
import os
import plistlib
import threading
import time

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(APP_DIR, "data")
SETTINGS = os.path.join(DATA_DIR, "settings.json")
WIFI_PROFILE = os.path.join(DATA_DIR, "wifi.mobileconfig")

# Apple's Setup Assistant skip keys, with the wording techs recognise.
# Unknown keys are ignored by the device, so a newer iOS simply skips what
# it understands — safe to send the whole list.
SKIP_KEYS = [
    ("Welcome", "Welcome (Get Started)"),
    ("Language", "Language"),
    ("Region", "Region"),
    ("WiFi", "Wi-Fi"),
    ("Restore", "Set Up as New or Restore"),
    ("DeviceToDeviceMigration", "Device to device migration"),
    ("Android", "Move from Android"),
    ("AppleID", "Apple ID"),
    ("TOS", "Terms and Conditions"),
    ("TermsOfAddress", "Terms of address"),
    ("Privacy", "Data and Privacy"),
    ("Diagnostics", "App / Device Analytics"),
    ("iCloudDiagnostics", "iCloud Analytics"),
    ("iCloudStorage", "iCloud Desktop and Documents"),
    ("Biometric", "Touch ID / Face ID"),
    ("Passcode", "Passcode Lock"),
    ("Payment", "Apple Pay"),
    ("Siri", "Siri"),
    ("Intelligence", "Apple Intelligence"),
    ("ScreenTime", "Screen Time"),
    ("Location", "Location Services"),
    ("SIMSetup", "Set Up Cellular"),
    ("iMessageAndFaceTime", "iMessage and FaceTime"),
    ("MessagingActivationUsingPhoneNumber", "Phone number feedback"),
    ("Keyboard", "Keyboards"),
    ("SpokenLanguage", "Spoken language"),
    ("DisplayTone", "True Tone Display"),
    ("Zoom", "Display Zoom"),
    ("Appearance", "Appearance"),
    ("Wallpaper", "Wallpaper"),
    ("HomeButtonSensitivity", "Home button feedback"),
    ("ActionButton", "Action Button"),
    ("CameraButton", "Camera Button"),
    ("Safety", "Safety features"),
    ("OnBoarding", "Onboarding"),
    ("NewFeatureHighlights", "New feature highlights"),
    ("SoftwareUpdate", "Software Update"),
    ("UpdateCompleted", "Update completed"),
    ("RestoreCompleted", "Restore completed"),
    ("AppStore", "App Store"),
    ("WatchMigration", "Apple Watch migration"),
    ("TapToSetup", "Tap to Setup"),
    ("ScreenSaver", "Screen saver"),
    ("TVHomeScreenSync", "Sync Apple TV home screen"),
    ("TVProviderSignIn", "Sign in to your TV provider"),
    ("TVRoom", "TV room"),
    ("Accessibility", "Accessibility"),
    ("EnableLockdownMode", "Lockdown Mode"),
    ("IntendedUser", "Intended user"),
]
SKIP_KEY_NAMES = [k for k, _ in SKIP_KEYS]

DEFAULTS = {
    "language": "en",
    "region": "US",
    "skip": SKIP_KEY_NAMES,          # skip everything by default
    "organization": "Bench Hero",
    "activate": True,
    "setup": True,
    "wifi": False,
}


# ── settings ────────────────────────────────────────────────────────────────

def load_settings():
    s = dict(DEFAULTS)
    try:
        with open(SETTINGS, encoding="utf-8") as f:
            saved = json.load(f)
        if isinstance(saved, dict):
            s.update({k: v for k, v in saved.items() if k in DEFAULTS})
    except Exception:
        pass
    s["skip"] = [k for k in s.get("skip") or [] if k in SKIP_KEY_NAMES]
    return s


def save_settings(s):
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        tmp = SETTINGS + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({k: s.get(k, DEFAULTS[k]) for k in DEFAULTS}, f, indent=1)
        os.replace(tmp, SETTINGS)
        return True, ""
    except OSError as e:
        return False, str(e)


def have_wifi_profile():
    return os.path.isfile(WIFI_PROFILE)


def save_wifi_profile(data):
    """Store an uploaded .mobileconfig after checking it really is one."""
    try:
        plistlib.loads(data)
    except Exception:
        return False, "that isn't a valid .mobileconfig (plist) file"
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(WIFI_PROFILE, "wb") as f:
            f.write(data)
        return True, "Wi-Fi profile saved"
    except OSError as e:
        return False, str(e)


# ── talking to devices ──────────────────────────────────────────────────────

def _pmd3():
    """pymobiledevice3, imported late so a missing dependency is a message
    on screen instead of an import crash at launch."""
    from pymobiledevice3 import usbmux                       # noqa: F401
    from pymobiledevice3.lockdown import create_using_usbmux  # noqa: F401
    return usbmux, create_using_usbmux


def deps_ok():
    try:
        _pmd3()
        return True, ""
    except Exception as e:  # noqa: BLE001
        return False, str(e)


def list_devices():
    """Every iOS device on USB, with whatever identity we can read without
    pairing. Never raises — a bad device becomes a row with an error."""
    try:
        usbmux, create_using_usbmux = _pmd3()
    except Exception as e:  # noqa: BLE001
        return [], "pymobiledevice3 not available: %s" % e
    out = []
    try:
        muxed = usbmux.list_devices()
    except Exception as e:  # noqa: BLE001
        return [], "usbmuxd not reachable (%s) — is the daemon running?" % e
    for d in muxed:
        udid = getattr(d, "serial", None) or getattr(d, "udid", "")
        row = {"udid": udid, "model": "", "ios": "", "serial": "",
               "state": "?", "error": ""}
        try:
            ld = create_using_usbmux(serial=udid, autopair=False)
            row["model"] = _model_name(ld)
            row["ios"] = str(ld.all_values.get("ProductVersion", "") or "")
            row["serial"] = str(ld.all_values.get("SerialNumber", "") or "")
            row["state"] = activation_state(ld)
        except Exception as e:  # noqa: BLE001
            row["error"] = str(e)[:120]
        out.append(row)
    return out, ""


def _model_name(lockdown):
    """Marketing name when the bench can tell us, else the raw model code."""
    values = lockdown.all_values
    pt = str(values.get("ProductType", "") or "")
    for key in ("MarketingName", "DeviceClass"):
        v = values.get(key)
        if v:
            return "%s (%s)" % (v, pt) if key == "DeviceClass" and pt else str(v)
    return pt or "iOS device"


def activation_state(lockdown):
    try:
        from pymobiledevice3.services.mobile_activation import \
            MobileActivationService
        return str(MobileActivationService(lockdown).state or "?")
    except Exception:
        # ActivationState is also a plain lockdown value on most builds.
        try:
            return str(lockdown.all_values.get("ActivationState", "?"))
        except Exception:
            return "?"


def cloud_config(settings):
    """The payload that skips the Setup Assistant panes. AllowPairing keeps
    the device talkable afterwards, which is the whole point for testing."""
    return {
        "AllowPairing": True,
        "CloudConfigurationUIComplete": True,
        "ConfigurationSource": 0,
        "PostSetupProfileWasInstalled": True,
        "SkipSetup": list(settings.get("skip") or []),
        "OrganizationName": str(settings.get("organization") or "Bench Hero"),
        "Language": str(settings.get("language") or "en"),
        "Locale": "%s_%s" % (settings.get("language") or "en",
                             settings.get("region") or "US"),
    }


def run_one(udid, settings, log=None):
    """Activate and/or set up ONE device. Returns (ok, summary).
    Every step is independent so a failure says which half went wrong."""
    def say(msg):
        if log:
            try:
                log(udid, msg)
            except Exception:
                pass

    try:
        _usbmux, create_using_usbmux = _pmd3()
    except Exception as e:  # noqa: BLE001
        return False, "pymobiledevice3 missing: %s" % e
    try:
        lockdown = create_using_usbmux(serial=udid, autopair=False)
    except Exception as e:  # noqa: BLE001
        return False, "can't reach the device (%s)" % str(e)[:90]

    done = []

    if settings.get("wifi") and have_wifi_profile():
        say("installing Wi-Fi profile")
        try:
            from pymobiledevice3.services.mobile_config import \
                MobileConfigService
            with open(WIFI_PROFILE, "rb") as f:
                MobileConfigService(lockdown).install_profile(f.read())
            done.append("Wi-Fi profile")
        except Exception as e:  # noqa: BLE001
            return False, "Wi-Fi profile failed: %s" % str(e)[:110]

    if settings.get("activate", True):
        say("activating with Apple")
        try:
            from pymobiledevice3.services.mobile_activation import \
                MobileActivationService
            svc = MobileActivationService(lockdown)
            if str(svc.state) == "Activated":
                done.append("already activated")
            else:
                # skip_apple_id_query: never sit waiting for a prompt on a
                # bench with no keyboard. A device that WANTS an Apple ID is
                # iCloud-locked and belongs in the reject pile.
                svc.activate(skip_apple_id_query=True)
                done.append("activated")
        except Exception as e:  # noqa: BLE001
            msg = str(e)
            if "apple id" in msg.lower() or "icloud" in msg.lower():
                return False, ("Activation Lock — this device is still "
                               "signed into an iCloud account")
            return False, "activation failed: %s" % msg[:110]

    if settings.get("setup", True):
        say("skipping setup screens")
        try:
            from pymobiledevice3.services.mobile_config import \
                MobileConfigService
            MobileConfigService(lockdown).set_cloud_configuration(
                cloud_config(settings))
            done.append("%d setup screens skipped"
                        % len(settings.get("skip") or []))
        except Exception as e:  # noqa: BLE001
            return False, ("setup config rejected: %s — the device must be "
                           "freshly erased and still at the Hello screen"
                           % str(e)[:90])

    return True, ", ".join(done) or "nothing selected"


class BatchRun(object):
    """A batch across every connected device, on background threads so no
    UI ever blocks. Poll .snapshot() to draw progress."""

    def __init__(self, udids, settings):
        self.settings = settings
        self._lock = threading.Lock()
        self.results = {u: {"state": "queued", "msg": ""} for u in udids}
        self.started = time.time()
        self.finished = None
        self._threads = []
        for u in udids:
            t = threading.Thread(target=self._worker, args=(u,), daemon=True)
            self._threads.append(t)
            t.start()
        threading.Thread(target=self._reaper, daemon=True).start()

    def _set(self, udid, state, msg=""):
        with self._lock:
            self.results[udid] = {"state": state, "msg": msg}

    def _worker(self, udid):
        self._set(udid, "running", "starting")
        ok, msg = run_one(udid, self.settings,
                          log=lambda u, m: self._set(u, "running", m))
        self._set(udid, "done" if ok else "failed", msg)

    def _reaper(self):
        for t in self._threads:
            t.join()
        self.finished = time.time()

    def snapshot(self):
        with self._lock:
            res = {u: dict(v) for u, v in self.results.items()}
        return {"results": res, "running": self.finished is None,
                "ok": sum(1 for v in res.values() if v["state"] == "done"),
                "failed": sum(1 for v in res.values()
                              if v["state"] == "failed"),
                "total": len(res)}
