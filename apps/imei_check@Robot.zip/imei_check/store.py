#!/usr/bin/env python3
"""Config, cache and history for the IMEI Check app — all on-disk state.

Everything lives inside the app's own folder, so uninstalling the app
(deleting the folder) takes the shop's API key and lookup history with it.

Three files:
  config.json     API key + preferences. chmod 0600 — it holds money.
  cache.json      imei+service → result, so the same question is never
                  billed twice. TTL is per-service: a part number is a fact
                  about the hardware and never changes; an iCloud lock does,
                  so those expire in a day.
  history.jsonl   append-only log of every lookup, newest last, capped.

No Tk, no network — importable under pytest with nothing installed.
"""

import json
import os
import time

APP_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(APP_DIR, "config.json")
CACHE_PATH = os.path.join(APP_DIR, "cache.json")
HISTORY_PATH = os.path.join(APP_DIR, "history.jsonl")
SERVICES_PATH = os.path.join(APP_DIR, "services.json")

DAY = 86400
HISTORY_MAX = 500
CACHE_MAX = 1000

DEFAULTS = {
    "api_key": "",
    # A model number can't change; a lock state can. Two TTLs, not one.
    "cache_days_static": 365,
    "cache_days_volatile": 1,
    "cache_enabled": True,
    # Anything at or under this price runs without a confirm prompt. Above
    # it, the tech has to tap CHARGE — an unlock service is a $168 mistake.
    "confirm_over_usd": 0.25,
    "scanner_enabled": True,
    "recent_services": [],
}


# ── tiny json helpers ────────────────────────────────────────────────────

def _read_json(path, fallback):
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(fallback)) else fallback
    except (OSError, ValueError):
        return fallback


def _write_json(path, data, private=False):
    """Write via a temp file so a power cut mid-write can't leave a
    truncated config behind (the bench is a device people unplug)."""
    tmp = path + ".tmp"
    try:
        if private:
            # Created 0600 up front, not chmod'd afterwards — otherwise
            # there's a window where the file holding the API key sits at
            # whatever the umask allows.
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        else:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        os.replace(tmp, path)
        return True
    except OSError as e:
        print("store: cannot write %s: %s" % (path, e))
        try:
            os.unlink(tmp)
        except OSError:
            pass
        return False


# ── config ───────────────────────────────────────────────────────────────

def load_config():
    cfg = dict(DEFAULTS)
    cfg.update(_read_json(CONFIG_PATH, {}))
    for k, v in DEFAULTS.items():                 # coerce hand-edited junk
        got = cfg.get(k)
        # bool is checked before int because isinstance(True, int) is True
        # in Python — without this, `"cache_days_static": true` would sail
        # through and become a TTL of one day.
        if isinstance(v, bool):
            if not isinstance(got, bool):
                cfg[k] = v
        elif isinstance(v, (int, float)):
            # Accept either numeric type and convert. A hand-edited
            # `"confirm_over_usd": 0` is an int, and rejecting it would
            # restore the 0.25 default — turning "always ask me" back into
            # "bill quarters silently". Likewise `"cache_days_static":
            # 30.0` must mean 30 days, not fall back to a year.
            if isinstance(got, bool) or not isinstance(got, (int, float)):
                cfg[k] = v
            else:
                cfg[k] = type(v)(got)
        elif not isinstance(got, type(v)):
            cfg[k] = v
    return cfg


def save_config(cfg):
    return _write_json(CONFIG_PATH, cfg, private=True)


def set_api_key(key):
    cfg = load_config()
    cfg["api_key"] = (key or "").strip()
    return save_config(cfg)


def remember_service(service_id, keep=8):
    """Most-recently-used services float to the top of the picker — on a
    4" screen, scrolling past 130 tiles every time is the whole cost."""
    cfg = load_config()
    recent = [s for s in cfg.get("recent_services", []) if s != service_id]
    recent.insert(0, service_id)
    cfg["recent_services"] = recent[:keep]
    save_config(cfg)
    return cfg["recent_services"]


# ── service catalog ──────────────────────────────────────────────────────

def load_services():
    """[{kind, label, services:[{id,name,usd,volatile}]}] — empty on a
    corrupt catalog rather than an exception, so the app still opens and
    can show its own error."""
    data = _read_json(SERVICES_PATH, {})
    groups = data.get("groups", []) if isinstance(data, dict) else []
    return [g for g in groups if isinstance(g, dict) and g.get("services")]


def service_index():
    """{id: {..., 'group': label}} for O(1) lookup by service id."""
    idx = {}
    for g in load_services():
        for s in g["services"]:
            entry = dict(s)
            entry["group"] = g.get("label", "")
            entry["kind"] = g.get("kind", "")
            idx[s["id"]] = entry
    return idx


# ── cache ────────────────────────────────────────────────────────────────

def cache_key(identifier, service_id):
    return "%s|%s" % (str(identifier).upper(), service_id)


def ttl_for(service, cfg=None):
    """Seconds a result for this service stays good."""
    cfg = cfg or load_config()
    days = (cfg["cache_days_volatile"] if (service or {}).get("volatile")
            else cfg["cache_days_static"])
    return max(0, int(days)) * DAY


def cache_all():
    """The whole cache as one dict. The service picker draws ~130 tiles and
    each one wants to know if it's cached — read the file once and pass the
    snapshot in, rather than 130 disk reads per render on a Pi."""
    return _read_json(CACHE_PATH, {})


def cache_get(identifier, service_id, service=None, cfg=None, now=None,
              cache=None):
    """The cached entry, or None when absent/stale/disabled."""
    cfg = cfg or load_config()
    if not cfg.get("cache_enabled", True):
        return None
    ttl = ttl_for(service, cfg)
    if ttl <= 0:
        return None            # 0 days = never reuse, NOT "keep forever"
    if cache is None:
        cache = _read_json(CACHE_PATH, {})
    entry = cache.get(cache_key(identifier, service_id))
    if not isinstance(entry, dict):
        return None
    if (now or time.time()) - entry.get("ts", 0) > ttl:
        return None
    return entry


def cache_put(identifier, service_id, rows, cfg=None, service=None,
              now=None):
    cfg = cfg or load_config()
    if not cfg.get("cache_enabled", True):
        return False
    if service is not None and ttl_for(service, cfg) <= 0:
        return False           # don't store what can never be read back
    # Drop anything that isn't a well-formed entry rather than trusting the
    # file: a hand-edited or half-written cache.json used to make the
    # eviction sort raise AttributeError, and that exception would land in
    # the middle of storing a result the shop had already paid for.
    cache = {k: v for k, v in _read_json(CACHE_PATH, {}).items()
             if isinstance(v, dict)}
    cache[cache_key(identifier, service_id)] = {
        "ts": now or time.time(),
        "rows": [[str(a), str(b)] for a, b in rows],
    }
    if len(cache) > CACHE_MAX:                     # oldest out first
        def _age(kv):
            ts = kv[1].get("ts")
            # A hand-edited string timestamp would make the sort raise
            # TypeError, which lands mid-save of a result already paid for.
            return ts if isinstance(ts, (int, float)) else 0
        for k, _ in sorted(cache.items(),
                           key=_age)[:len(cache) - CACHE_MAX]:
            cache.pop(k, None)
    return _write_json(CACHE_PATH, cache)


def cache_clear():
    try:
        os.unlink(CACHE_PATH)
    except OSError:
        pass
    return True


def cache_stats():
    """(entries, bytes) for the settings screen."""
    cache = _read_json(CACHE_PATH, {})
    try:
        size = os.path.getsize(CACHE_PATH)
    except OSError:
        size = 0
    return len(cache), size


# ── history ──────────────────────────────────────────────────────────────

def history_add(identifier, service_id, service_name, rows, cached,
                usd=0.0, now=None):
    """Append one lookup. Failures are logged too (rows empty) — knowing a
    lookup was attempted and refused is worth as much as the answer."""
    rec = {
        "ts": now or time.time(),
        "identifier": identifier,
        "service": service_id,
        "service_name": service_name,
        "cached": bool(cached),
        # usd = what this actually cost (zero on a cache hit); list_usd =
        # what it would have cost, which is what the cache saved.
        "usd": 0.0 if cached else float(usd or 0.0),
        "list_usd": float(usd or 0.0),
        "rows": [[str(a), str(b)] for a, b in rows],
    }
    try:
        with open(HISTORY_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")
    except OSError as e:
        print("store: cannot append history: %s" % e)
        return None
    _trim_history()
    return rec


def _trim_history():
    try:
        with open(HISTORY_PATH, encoding="utf-8") as f:
            lines = f.readlines()
    except OSError:
        return
    if len(lines) <= HISTORY_MAX:
        return
    try:
        with open(HISTORY_PATH, "w", encoding="utf-8") as f:
            f.writelines(lines[-HISTORY_MAX:])
    except OSError:
        pass


def history_load(limit=200):
    """Newest first. A corrupt line is skipped, never fatal."""
    try:
        with open(HISTORY_PATH, encoding="utf-8") as f:
            lines = f.readlines()
    except OSError:
        return []
    out = []
    for line in reversed(lines):
        line = line.strip()
        if not line:
            continue
        try:
            rec = json.loads(line)
        except ValueError:
            continue
        if isinstance(rec, dict):
            out.append(rec)
        if len(out) >= limit:
            break
    return out


def history_count():
    """How many lookups are on file. The home screen shows this on every
    return, so it counts lines instead of parsing 500 JSON objects."""
    try:
        with open(HISTORY_PATH, encoding="utf-8") as f:
            return sum(1 for line in f if line.strip())
    except OSError:
        return 0


def history_clear():
    try:
        os.unlink(HISTORY_PATH)
    except OSError:
        pass
    return True


def spend_summary(days=30, now=None):
    """(lookups, usd_spent, saved_by_cache) over the window — the number a
    shop owner actually wants on the settings screen."""
    now = now or time.time()
    cutoff = now - days * DAY
    paid = saved = 0.0
    n = 0
    for rec in history_load(limit=HISTORY_MAX):
        if rec.get("ts", 0) < cutoff:
            break
        n += 1
        if rec.get("cached"):
            saved += float(rec.get("list_usd", rec.get("usd", 0)) or 0)
        else:
            paid += float(rec.get("usd", 0) or 0)
    return n, paid, saved
