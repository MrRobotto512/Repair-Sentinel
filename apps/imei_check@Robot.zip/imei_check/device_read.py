#!/usr/bin/env python3
"""Read the IMEI / serial straight off a device plugged into the bench,
and read a sickw API key off a USB stick.

Typing 15 digits on a touch keyboard is where mistakes get made, and a
mistyped IMEI is a billed lookup for someone else's phone. If the device
is already on the bench USB, ask the device.

  Android — adb. `getprop` first (instant, no root), then the
            `service call iphonesubinfo` transaction as a fallback for
            ROMs that hide the props.
  iOS     — libimobiledevice `ideviceinfo`, the same binaries the bench's
            iOS tools already use.

Every subprocess call is guarded and short-timeout: no device, no adb
binary, an unauthorized handset, a stuck usbmuxd — all return an empty
list, never an exception. The bench has no visible terminal.
"""

import glob
import os
import re
import subprocess

TIMEOUT = 8

# getprop keys that carry an IMEI across the vendor ROMs we see most.
_ANDROID_IMEI_PROPS = (
    "ril.gsm.imei",              # Qualcomm, most common
    "ril.imei",
    "persist.radio.imei",
    "gsm.imei",
    "ro.ril.oem.imei",
    "ro.gsm.imei",
    "persist.radio.imei1",
)


def _run(cmd, timeout=TIMEOUT):
    """(rc, stdout) — never raises. rc 127 = the binary isn't installed."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=timeout)
        return r.returncode, (r.stdout or "").strip()
    except FileNotFoundError:
        return 127, ""
    except (subprocess.TimeoutExpired, OSError, ValueError) as e:
        print("device_read: %s failed: %s" % (cmd[0] if cmd else "?", e))
        return 1, ""


def _plausible(value):
    """Filter out the placeholders ROMs return instead of admitting they
    don't know: all-zeros, 'unknown', 'null', dummy IMEIs."""
    v = re.sub(r"[^A-Za-z0-9]", "", str(value or ""))
    if not (11 <= len(v) <= 17):
        return ""
    low = v.lower()
    if low in ("unknown", "null", "none", "0"):
        return ""
    if v.isdigit() and len(set(v)) <= 1:          # 000000000000000
        return ""
    return v.upper()


# ── Android ──────────────────────────────────────────────────────────────

def _adb_devices():
    """Serials of handsets in 'device' state. 'unauthorized' is reported
    separately so the UI can tell the tech to tap Allow on the phone."""
    rc, out = _run(["adb", "devices"])
    if rc == 127:
        return [], "adb is not installed on this bench."
    ready, blocked = [], 0
    for line in out.splitlines()[1:]:
        parts = line.split()
        if len(parts) < 2:
            continue
        if parts[1] == "device":
            ready.append(parts[0])
        elif parts[1] in ("unauthorized", "offline"):
            blocked += 1
    note = ""
    if blocked and not ready:
        note = ("%d Android device(s) connected but not authorized — "
                "unlock the phone and tap ALLOW on the USB debugging "
                "prompt." % blocked)
    return ready, note


def _decode_service_call(raw):
    """`service call iphonesubinfo N` prints parcel hex with the string in
    UTF-16 across the right-hand columns. Pull the digits out of that."""
    chunks = re.findall(r"'([^']*)'", raw)
    text = "".join(chunks).replace(".", "").replace(" ", "")
    digits = re.sub(r"[^0-9]", "", text)
    return digits if 14 <= len(digits) <= 16 else ""


def read_android():
    """[{'kind','value','source','device'}] for every connected handset."""
    found = []
    serials, note = _adb_devices()
    for sn in serials:
        label = sn
        rc, model = _run(["adb", "-s", sn, "shell", "getprop",
                          "ro.product.model"])
        if rc == 0 and model:
            label = "%s (%s)" % (model.strip(), sn)

        for prop in _ANDROID_IMEI_PROPS:
            rc, val = _run(["adb", "-s", sn, "shell", "getprop", prop])
            v = _plausible(val) if rc == 0 else ""
            if v:
                found.append({"kind": "IMEI", "value": v,
                              "source": prop, "device": label})
                break
        else:
            # Props hidden (common on Android 10+): ask the telephony
            # service directly. Transaction 1 is getDeviceId on most ROMs.
            for txn in ("1", "3"):
                rc, out = _run(["adb", "-s", sn, "shell", "service", "call",
                                "iphonesubinfo", txn])
                v = _plausible(_decode_service_call(out)) if rc == 0 else ""
                if v:
                    found.append({"kind": "IMEI", "value": v,
                                  "source": "iphonesubinfo " + txn,
                                  "device": label})
                    break

        rc, ser = _run(["adb", "-s", sn, "shell", "getprop",
                        "ro.serialno"])
        v = _plausible(ser) if rc == 0 else _plausible(sn)
        if v:
            found.append({"kind": "Serial", "value": v,
                          "source": "ro.serialno", "device": label})
    return found, note


# ── iOS ──────────────────────────────────────────────────────────────────

def read_ios():
    """Same shape as read_android(), via libimobiledevice."""
    found = []
    rc, out = _run(["idevice_id", "-l"])
    if rc == 127:
        return [], "libimobiledevice is not installed on this bench."
    udids = [u.strip() for u in out.splitlines() if u.strip()]
    if not udids:
        return [], ""
    for udid in udids:
        rc, name = _run(["ideviceinfo", "-u", udid, "-k", "DeviceName"])
        label = name.strip() if rc == 0 and name.strip() else udid[:12]
        if rc != 0:
            found.append({"kind": "note", "value": "",
                          "source": "locked", "device": udid[:12]})
        for key, kind in (
                ("InternationalMobileEquipmentIdentity", "IMEI"),
                ("InternationalMobileEquipmentIdentity2", "IMEI2"),
                ("SerialNumber", "Serial"),
                ("MobileEquipmentIdentifier", "MEID")):
            rc, val = _run(["ideviceinfo", "-u", udid, "-k", key])
            v = _plausible(val) if rc == 0 else ""
            if v:
                found.append({"kind": kind, "value": v,
                              "source": key, "device": label})
    note = ""
    if udids and not [f for f in found if f["value"]]:
        note = ("iOS device seen but it won't answer — unlock it and tap "
                "TRUST on the 'Trust This Computer?' prompt.")
    return [f for f in found if f["value"]], note


def read_all():
    """(identifiers, notes) across both platforms. Never raises."""
    ids, notes = [], []
    for reader in (read_android, read_ios):
        try:
            found, note = reader()
        except Exception as e:                    # a reader must never kill the app
            print("device_read: %s crashed: %s" % (reader.__name__, e))
            found, note = [], "%s failed: %s" % (reader.__name__, e)
        ids.extend(found)
        if note:
            notes.append(note)

    seen, unique = set(), []
    for entry in ids:
        if entry["value"] not in seen:
            seen.add(entry["value"])
            unique.append(entry)
    return unique, notes


# ── API key from a USB stick ─────────────────────────────────────────────
# Mirrors tools/keyimport.py: the shop drops a text file on a stick rather
# than tapping 31 characters into a touch keyboard.

KEY_FILENAMES = ("sickw-key", "sickw-key.txt", "sickw.key",
                 "sickw-api-key", "sickw-api-key.txt")


def _mount_dirs():
    user = os.environ.get("USER") or os.environ.get("USERNAME") or "pi"
    pats = ["/media/%s/*" % user, "/media/*/*", "/media/*",
            "/run/media/%s/*" % user, "/run/media/*/*", "/mnt/*",
            "/Volumes/*"]                                  # /Volumes = dev Mac
    out = []
    for pat in pats:
        for d in glob.glob(pat):
            if os.path.isdir(d) and d not in out:
                out.append(d)
    return out


def _looks_like_key(text):
    """31 chars of key alphabet, per sickw's own length rule. Tolerates a
    'key=' prefix and Windows line endings, which is how these files
    actually arrive."""
    s = str(text or "").strip().strip('"\'')
    s = re.sub(r"(?i)^(sickw[\s_-]*)?(api[\s_-]*)?key\s*[:=]\s*", "", s)
    s = s.split("\n")[0].strip()
    return s if re.fullmatch(r"[A-Za-z0-9\-_]{31}", s) else ""


def find_key_on_usb():
    """(key, path) from the first stick holding a recognizable key file."""
    for root in _mount_dirs():
        for depth in (root, os.path.join(root, "*")):
            for name in KEY_FILENAMES:
                for path in glob.glob(os.path.join(depth, name)):
                    try:
                        if os.path.getsize(path) > 4096:
                            continue
                        with open(path, encoding="utf-8",
                                  errors="replace") as f:
                            key = _looks_like_key(f.read())
                    except OSError:
                        continue
                    if key:
                        return key, path
    return "", ""


if __name__ == "__main__":              # dev helper: python3 device_read.py
    found, notes = read_all()
    for f in found:
        print("%-7s %-20s  %s  [%s]" % (f["kind"], f["value"], f["device"],
                                        f["source"]))
    for n in notes:
        print("note:", n)
    k, p = find_key_on_usb()
    print("usb key:", ("%s at %s" % (k[:4] + "…", p)) if k else "none found")
