#!/usr/bin/env python3
"""IMEI Check — sickw.com IMEI/serial lookups on the BenchTool touchscreen.

Follows the BenchTool app contract (app_sdk/README.md):
  1. Standalone script, own Tk root, run as its own process.
  2. Fullscreen/borderless/dark/cursor hidden on the bench; a plain
     800x480 window on a dev laptop (no ui_theme module around).
  3. Big EXIT button top-right — the universal back on a touchscreen.
  4. Never crashes on a missing device or a dead network: every
     subprocess and HTTP call is guarded and reports on screen.
  5. Exit code 0 on a clean close.

The shop brings its own sickw API key (USB stick or on-screen keyboard);
nothing is shipped with one. Money is the reason this app is careful:
every lookup is billed, so results are cached by IMEI+service, anything
over the confirm threshold needs an explicit CHARGE tap, and the price is
on screen before the tap, not after.

Screens: HOME → SERVICES → RESULT, plus HISTORY and SETTINGS.
"""

import os
import sys
import threading
import time
import tkinter as tk
from tkinter import font as tkfont

os.environ.setdefault("DISPLAY", ":0")

APP_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP_DIR)

import device_read                                            # noqa: E402
import sickw_api                                              # noqa: E402
import store                                                  # noqa: E402

# On the bench, tools/ is on PYTHONPATH so the shared kit is importable and
# the app looks exactly like a built-in. On a laptop it isn't — degrade,
# never fail (SDK rule: the same script runs in both places).
try:
    import ui_theme as _ui
    ON_BENCH = True
except ImportError:
    _ui = None
    ON_BENCH = False
try:
    import bench_keyboard
except ImportError:
    bench_keyboard = None                       # dev PC has a real keyboard
try:
    # The shared barcode-wedge reader. It handles the three things that
    # make a scanner look dead: taking X keyboard focus (apply_root does
    # not), accepting every terminator a wedge can be configured to send,
    # and not rejecting a slow scanner as "human typing".
    import bench_scanner
except ImportError:
    bench_scanner = None            # older bench, or a dev PC without it

# Palette mirrors tools/bench_tokens.py so the app matches the built-ins
# even when ui_theme isn't importable.
BG = "#0d0d0f"
CARD = "#1b1b21"
CODE = "#101014"
CHIP = "#22222a"
BORDER = "#2a2a32"
FG = "#e8e8f0"
DIM = "#aab0bf"
MUTED = "#7a7a8c"
OK = "#69f0ae"
ERR = "#ff6e6e"
WARN = "#ffc94d"
INFO = "#7bd5ff"
ACCENT = "#5baee8"
FILL_OK = "#0d3318"
FILL_ERR = "#3a0d0d"
FILL_WARN = "#332200"
FILL_AI = "#0d1f33"
ACTIVE = "#2a2a34"

GROUP_COLOR = {"apple": INFO, "status": WARN, "generic": OK, "unlock": ERR}


# ── small widget helpers (self-contained: no ui_theme dependency) ────────

def button(parent, text, command, fg=FG, bg=CARD, font=None, height=2,
           **kw):
    """Finger-sized button: >=60px tall at the default height, raised so
    the edge is findable without a cursor."""
    return tk.Button(parent, text=text, command=command, font=font,
                     bg=bg, fg=fg, activebackground=ACTIVE,
                     activeforeground=fg, bd=2, relief="raised",
                     height=height, highlightthickness=0,
                     disabledforeground=MUTED, **kw)


class TouchList:
    """A drag-to-scroll list for a screen with no wheel and no cursor.

    Two things make this more than a canvas wrapper, and both are money:

    1. Tk does NOT bubble <Button-1> from a child widget to its parent —
       events travel the widget's own bindtags (widget → class → toplevel
       → all), not up the packing tree. So binding the drag handlers only
       on the canvas means a drag that starts on a row does nothing at
       all, and the 14px scrollbar becomes the only way to move a 96-item
       list on a 4" panel. Every widget placed in the list has to be
       registered individually.

    2. Rows fire on RELEASE, and only if the finger didn't travel. Binding
       a purchase to <Button-1> means it fires the instant the finger
       lands, before release, with no way to slide off and cancel — so
       trying to scroll the service list would buy whatever was under
       your fingertip.
    """

    TAP_SLOP = 12          # px of travel still forgiven as a tap

    def __init__(self, parent):
        wrap = tk.Frame(parent, bg=BG)
        wrap.pack(fill=tk.BOTH, expand=True)
        self.canvas = tk.Canvas(wrap, bg=BG, highlightthickness=0, bd=0)
        bar = tk.Scrollbar(wrap, orient="vertical",
                           command=self.canvas.yview, width=18, bg=CARD,
                           troughcolor=BG, bd=0, highlightthickness=0)
        self.frame = tk.Frame(self.canvas, bg=BG)
        win = self.canvas.create_window((0, 0), window=self.frame,
                                        anchor="nw")
        self.canvas.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)

        def _resize(_=None):
            self.canvas.configure(scrollregion=self.canvas.bbox("all"))
            self.canvas.itemconfig(win, width=self.canvas.winfo_width())
        self.frame.bind("<Configure>", _resize)
        self.canvas.bind("<Configure>", _resize)

        self._y = 0
        self._at = 0.0
        self._moved = False
        self._bound = set()
        self.register(self.canvas)
        self.register(self.frame)

    # ── drag ─────────────────────────────────────────────────────────────

    def _press(self, e):
        self._y = e.y_root
        self._at = self.canvas.canvasy(0)
        self._moved = False

    def _motion(self, e):
        dy = self._y - e.y_root
        if abs(dy) > self.TAP_SLOP:
            self._moved = True         # this gesture is a scroll, not a tap
        try:
            height = max(1, self.frame.winfo_height())
            self.canvas.yview_moveto(max(0.0, (self._at + dy) / height))
        except tk.TclError:
            pass

    def _wheel(self, direction):
        def _handler(_e):
            try:
                self.canvas.yview_scroll(direction, "units")
            except tk.TclError:
                pass
        return _handler

    # ── registration ─────────────────────────────────────────────────────

    def _release(self, on_tap):
        def _handler(e):
            if not self._moved:
                if on_tap is not None:
                    on_tap()
                return None
            # The gesture was a scroll. Returning "break" stops the event
            # before the *class* binding — which matters for tk.Button,
            # whose command is invoked by tk::ButtonUp, not by anything
            # this class binds. Without it, dragging to scroll the settings
            # page also fires whatever button the finger started on, and
            # because the content tracks the finger the pointer never
            # leaves the button for tk::ButtonLeave to cancel it. CLEAR
            # CACHE is one of those buttons.
            try:
                if e.widget.winfo_class() == "Button":
                    e.widget.configure(relief="raised")
                    if str(e.widget["state"]) == "active":
                        e.widget.configure(state="normal")
            except tk.TclError:
                pass
            return "break"
        return _handler

    def register(self, widget, on_tap=None):
        """Make `widget` part of the scrollable surface. With `on_tap`, it
        also becomes tappable — fired on release, suppressed after a drag.

        Bound per-widget, never bind_all: each screen builds a fresh list,
        and a global binding left pointing at a destroyed canvas raises
        TclError the next time anyone scrolls.
        """
        if str(widget) in self._bound:
            return widget          # double-binding would double the scroll
        self._bound.add(str(widget))
        widget.bind("<ButtonPress-1>", self._press, add="+")
        widget.bind("<B1-Motion>", self._motion, add="+")
        widget.bind("<Button-4>", self._wheel(-2), add="+")
        widget.bind("<Button-5>", self._wheel(2), add="+")
        # Bound even without an on_tap, so a drag can suppress a Button.
        widget.bind("<ButtonRelease-1>", self._release(on_tap), add="+")
        return widget

    def register_tree(self, widget=None, on_tap=None):
        """Register a whole subtree — a row is a frame of labels, and each
        of those labels swallows the press that lands on it."""
        widget = self.frame if widget is None else widget
        self.register(widget, on_tap)
        for child in widget.winfo_children():
            self.register_tree(child, on_tap)
        return widget


def usd(amount):
    """Prices run from $0.00 to $168, so a fixed 2 decimals would print
    several real services as '$0.02' when they differ ($0.022 vs $0.025).
    Show 3 decimals under a dime, 2 above."""
    try:
        a = float(amount or 0)
    except (TypeError, ValueError):
        return "—"
    if a <= 0:
        return "FREE"
    return money(a)


def money(amount):
    """Same, but for totals — a 30-day spend of zero is "$0.00", not
    "FREE"."""
    try:
        a = float(amount or 0)
    except (TypeError, ValueError):
        return "—"
    if 0 < a < 0.1:
        return ("$%.3f" % a).rstrip("0").rstrip(".")
    return "$%.2f" % a


class App(tk.Tk):
    TITLE = "IMEI CHECK"

    def __init__(self):
        super().__init__()
        if ON_BENCH and hasattr(_ui, "apply_root"):
            _ui.apply_root(self)
        else:
            self.geometry("800x480")
            self.title(self.TITLE + " (dev)")
        self.configure(bg=BG)

        self.f_title = tkfont.Font(family="DejaVu Sans", size=20,
                                   weight="bold")
        self.f_btn = tkfont.Font(family="DejaVu Sans", size=15, weight="bold")
        self.f_name = tkfont.Font(family="DejaVu Sans Mono", size=15,
                                  weight="bold")
        self.f_desc = tkfont.Font(family="DejaVu Sans", size=13)
        self.f_small = tkfont.Font(family="DejaVu Sans", size=11,
                                   weight="bold")
        self.f_big = tkfont.Font(family="DejaVu Sans Mono", size=26,
                                 weight="bold")
        self.f_mono_diag = tkfont.Font(family="DejaVu Sans Mono", size=12)

        self.cfg = store.load_config()
        self.services = store.load_services()
        self.svc_index = store.service_index()
        self.identifier = ""
        self.busy = False
        self._note = None
        self._cache_snapshot = None
        self._key_log = []

        self._build_chrome()
        self.show_home()
        self._start_scanner()

        if not ON_BENCH:
            # Dev convenience only. On the bench Escape would also cancel
            # bench_keyboard's modal, and there's no keyboard anyway.
            self.bind_all("<Escape>", lambda e: self.close())

    # ── barcode scanner ──────────────────────────────────────────────────

    def _start_scanner(self):
        """Wire up the USB wedge.

        All the hard parts live in bench_scanner (focus, terminators,
        no-suffix flush). The fallback exists because this app is
        published to the community store and can land on a bench whose
        BenchTool predates that module — degraded is better than dead.
        """
        self.scanner = None
        if not bench_scanner:
            self._scan_fallback()
            return
        self.scanner = bench_scanner.attach(
            self, self._scanned, min_len=11,
            # No keyboard on the bench, so anything "typed" IS the wedge
            # and a speed test could only reject real scans. On a dev
            # machine the check keeps our own typing out of the buffer.
            reject_slow_input=not ON_BENCH,
            on_key=self._log_key)

    def _log_key(self, keysym, char):
        """Last few keys, for the SCANNER TEST screen. The bench has no
        terminal; without this, "nothing happens" is unfalsifiable."""
        self._key_log.append(keysym if len(keysym) > 1 else (char or keysym))
        del self._key_log[:-40]

    def _scan_fallback(self):
        """Minimal wedge reader for a bench without bench_scanner.

        Same three lessons, inlined: take focus, accept any terminator,
        don't second-guess the speed.
        """
        buf = {"s": ""}

        def take_focus():
            try:
                self.focus_force()
            except tk.TclError:
                pass

        def on_key(event):
            if self.busy or not self.cfg.get("scanner_enabled", True):
                return
            self._log_key(event.keysym, event.char)
            if event.keysym in ("Return", "KP_Enter", "Tab", "Linefeed"):
                code, buf["s"] = buf["s"].strip(), ""
                if len(code) >= 11:
                    self.after(0, lambda: self._scanned(code))
                return
            if len(event.char) == 1 and event.char.isalnum():
                buf["s"] += event.char

        take_focus()
        self.bind("<FocusOut>", lambda e: take_focus(), add="+")
        self.bind_all("<Key>", on_key, add="+")
        self.after(1500, take_focus)

    # ── chrome ───────────────────────────────────────────────────────────

    def _build_chrome(self):
        bar = tk.Frame(self, bg=CODE)
        bar.pack(fill=tk.X)
        self.head = tk.Label(bar, text=self.TITLE, font=self.f_title,
                             bg=CODE, fg=ACCENT, anchor="w")
        self.head.pack(side=tk.LEFT, padx=12, pady=8)
        self.badge = tk.Label(bar, text="", font=self.f_small, bg=CODE,
                              fg=MUTED)
        self.badge.pack(side=tk.LEFT, padx=6)
        tk.Button(bar, text="✕", font=self.f_title, bg=FILL_ERR, fg=ERR,
                  activebackground="#5a1a1a", activeforeground=ERR, bd=2,
                  relief="raised", width=3, command=self.close
                  ).pack(side=tk.RIGHT, padx=8, pady=4)
        self.back_btn = tk.Button(bar, text="‹ BACK", font=self.f_small,
                                  bg=CARD, fg=DIM, activebackground=ACTIVE,
                                  activeforeground=FG, bd=2,
                                  relief="raised", command=self.show_home)
        self.back_btn.pack(side=tk.RIGHT, padx=4, pady=6)
        self.back_btn.pack_forget()

        self.body = tk.Frame(self, bg=BG)
        self.body.pack(fill=tk.BOTH, expand=True)

        self.status = tk.Label(self, text="", font=self.f_desc, bg=CODE,
                               fg=DIM, anchor="w", wraplength=780,
                               justify="left")
        self.status.pack(fill=tk.X, side=tk.BOTTOM)

    def set_status(self, msg, color=DIM):
        self.status.config(text="  " + str(msg), fg=color)
        self.update_idletasks()

    def note(self, msg, color=DIM):
        """A message that must survive the screen change about to happen.

        Every screen builder ends by setting its own status line, so a
        plain set_status() before navigating is overwritten before anyone
        reads it — and one of the messages that used to be lost this way
        was 'IMEI checksum FAILED', which the tech needs BEFORE paying.
        """
        self._note = (str(msg), color)
        self.set_status(msg, color)

    def _status_default(self, msg, color=DIM):
        """Screen builders call this instead of set_status: a note left by
        whatever navigated here wins, once."""
        if getattr(self, "_note", None):
            msg, color = self._note
            self._note = None
        self.set_status(msg, color)

    def set_badge(self, text, color=MUTED):
        self.badge.config(text=text, fg=color)

    def clear(self, title=None, back=None):
        for w in self.body.winfo_children():
            w.destroy()
        if title:
            self.head.config(text=title)
        if back:
            self.back_btn.config(command=back)
            self.back_btn.pack(side=tk.RIGHT, padx=4, pady=6)
        else:
            self.back_btn.pack_forget()
        return self.body

    # ── barcode scanner ──────────────────────────────────────────────────

    def _scan_paused(self, paused):
        """Hold the scanner off while a modal owns the screen."""
        if not self.scanner:
            return
        self.scanner.pause() if paused else self.scanner.resume()

    def _scanned(self, code):
        if not self.cfg.get("scanner_enabled", True) or self.busy:
            return
        kind, cleaned, msg = sickw_api.classify_identifier(code)
        if kind == "invalid":
            self.set_status("Scanned %r — %s" % (code[:24], msg), ERR)
            return
        self.identifier = cleaned
        self.note("Scanned %s — %s" % (cleaned, msg),
                  WARN if "FAILED" in msg else OK)
        self.show_services()

    # ── HOME ─────────────────────────────────────────────────────────────

    def show_home(self):
        body = self.clear(self.TITLE)
        self.head.config(fg=ACCENT)

        ok, why = sickw_api.validate_key(self.cfg.get("api_key", ""))
        self.set_badge("KEY SET" if ok else "NO KEY", OK if ok else ERR)

        card = tk.Frame(body, bg=CARD, highlightbackground=BORDER,
                        highlightthickness=1)
        card.pack(fill=tk.X, padx=12, pady=(12, 6))
        tk.Label(card, text="IMEI  /  SERIAL", font=self.f_small, bg=CARD,
                 fg=MUTED, anchor="w").pack(fill=tk.X, padx=12, pady=(8, 0))

        self.entry = tk.Entry(card, font=self.f_big, bg=CODE, fg=FG,
                              insertbackground=FG, bd=0,
                              highlightthickness=1,
                              highlightbackground=BORDER, justify="center")
        self.entry.pack(fill=tk.X, padx=12, pady=8, ipady=10)
        self.entry.insert(0, self.identifier)
        # Not bench_keyboard.attach(): its write-back uses delete/insert,
        # which fires no key event, so <KeyRelease> validation would be
        # dead code on the bench. And the modal has to hold `busy` — a
        # scan while it's open would destroy the entry it writes back to.
        self.entry.bind("<Button-1>", self._edit_identifier)
        self.entry.bind("<KeyRelease>", lambda e: self._echo_validity())

        hint = tk.Label(card, text="tap the field to type  ·  or scan the "
                        "barcode  ·  or pull it off the device",
                        font=self.f_small, bg=CARD, fg=MUTED)
        hint.pack(pady=(0, 8))

        row = tk.Frame(body, bg=BG)
        row.pack(fill=tk.X, padx=12, pady=4)
        row.columnconfigure((0, 1), weight=1, uniform="a")
        button(row, "📲  PULL FROM DEVICE", self.pull_from_device,
               fg=OK, bg=FILL_OK, font=self.f_btn).grid(
                   row=0, column=0, sticky="ew", padx=(0, 4))
        button(row, "🔎  CHOOSE SERVICE ›", self.go_services,
               fg=INFO, bg=FILL_AI, font=self.f_btn).grid(
                   row=0, column=1, sticky="ew", padx=(4, 0))

        row2 = tk.Frame(body, bg=BG)
        row2.pack(fill=tk.X, padx=12, pady=(4, 8))
        row2.columnconfigure((0, 1), weight=1, uniform="b")
        button(row2, "🕘  HISTORY (%d)" % store.history_count(),
               self.show_history,
               font=self.f_btn, height=1).grid(row=0, column=0, sticky="ew",
                                               padx=(0, 4))
        button(row2, "⚙  SETTINGS", self.show_settings, font=self.f_btn,
               height=1).grid(row=0, column=1, sticky="ew", padx=(4, 0))

        if not ok:
            self._status_default("No API key yet — Settings ▸ API KEY. "
                                 "Lookups bill your own sickw.com balance.",
                                 WARN)
        else:
            n, paid, saved = store.spend_summary(30)
            self._status_default(
                "Key %s  ·  last 30 days: %d lookups, %s spent, %s saved by "
                "cache." % (sickw_api.mask_key(self.cfg["api_key"]), n,
                            money(paid), money(saved)), DIM)

    def _edit_identifier(self, _event=None):
        """Tap the field → fullscreen touch keyboard, then validate what
        came back (the keyboard writes with insert(), so nothing else
        would notice the change)."""
        if not bench_keyboard:
            return                       # dev machine: type in it normally
        text = self._with_keyboard("IMEI / SERIAL", self.entry.get())
        if text is not None:
            self.entry.delete(0, "end")
            self.entry.insert(0, text)
            self._echo_validity()
        return "break"                   # swallow the click, no blink cursor

    def _with_keyboard(self, title, initial="", secret=False):
        """bench_keyboard.ask_text with `busy` held for its lifetime, so a
        barcode scan can't navigate away and destroy the widget the
        keyboard is about to write into."""
        self.busy = True
        self._scan_paused(True)
        try:
            return bench_keyboard.ask_text(self, title, initial=initial,
                                           mode="text", secret=secret,
                                           accent=ACCENT)
        except Exception as exc:
            print("keyboard failed: %s" % exc)
            return None
        finally:
            self.busy = False
            # resume() also re-takes focus, which the modal stole.
            self._scan_paused(False)

    def _echo_validity(self):
        kind, cleaned, msg = sickw_api.classify_identifier(self.entry.get())
        if kind == "invalid":
            self.set_status(msg, MUTED)
        else:
            self.set_status("%s · %s" % (cleaned, msg),
                            WARN if "FAILED" in msg else OK)

    def go_services(self):
        kind, cleaned, msg = sickw_api.classify_identifier(self.entry.get())
        if kind == "invalid":
            self.set_status(msg, ERR)
            return
        self.identifier = cleaned
        self.show_services()

    # ── pull from device ─────────────────────────────────────────────────

    def pull_from_device(self):
        if self.busy:
            return
        self.busy = True
        self.set_status("Looking for a connected device (adb, "
                        "libimobiledevice)…", INFO)
        threading.Thread(target=self._pull_worker, daemon=True).start()

    def _pull_worker(self):
        try:
            found, notes = device_read.read_all()
        except Exception as e:                    # readers are guarded, but
            found, notes = [], ["Device read failed: %s" % e]
        self.after(0, lambda: self._pull_done(found, notes))

    def _pull_done(self, found, notes):
        self.busy = False
        if not found:
            self.set_status(" ".join(notes) or
                            "No device answered. Plug in over USB, unlock "
                            "it, and allow debugging / trust this computer.",
                            WARN)
            return
        if len(found) == 1:
            self._use_pulled(found[0])
            return
        self._pick_identifier(found, notes)

    def _pick_identifier(self, found, notes):
        body = self.clear("PICK IDENTIFIER", back=self.show_home)
        if notes:
            tk.Label(body, text=" ".join(notes), font=self.f_small, bg=BG,
                     fg=WARN, wraplength=780, justify="left").pack(
                         fill=tk.X, padx=12, pady=(8, 0))
        lst = TouchList(body)
        for entry in found:
            b = tk.Frame(lst.frame, bg=CARD, highlightbackground=BORDER,
                         highlightthickness=1)
            b.pack(fill=tk.X, padx=12, pady=4)
            tk.Label(b, text="%s   %s" % (entry["kind"], entry["value"]),
                     font=self.f_name, bg=CARD, fg=FG, anchor="w").pack(
                         fill=tk.X, padx=12, pady=(8, 0))
            tk.Label(b, text="%s · %s" % (entry["device"], entry["source"]),
                     font=self.f_small, bg=CARD, fg=MUTED, anchor="w").pack(
                         fill=tk.X, padx=12, pady=(0, 8))
            lst.register_tree(b, on_tap=lambda x=entry: self._use_pulled(x))

    def _use_pulled(self, entry):
        kind, cleaned, msg = sickw_api.classify_identifier(entry["value"])
        if kind == "invalid":
            self.set_status("Device gave %r — %s" % (entry["value"], msg),
                            ERR)
            return
        self.identifier = cleaned
        self.note("Read %s off %s (%s) — %s"
                  % (cleaned, entry["device"], entry["source"], msg),
                  WARN if "FAILED" in msg else OK)
        self.show_services()

    # ── SERVICES ─────────────────────────────────────────────────────────

    def show_services(self):
        body = self.clear("SERVICE  ·  %s" % self.identifier,
                          back=self.show_home)
        self.head.config(fg=INFO)
        lst = TouchList(body)
        # One read for the whole list, not one per tile.
        self._cache_snapshot = store.cache_all()

        recent = [self.svc_index[s] for s in self.cfg.get("recent_services",
                                                          [])
                  if s in self.svc_index]
        if recent:
            self._group_header(lst, "RECENT", ACCENT)
            for svc in recent:
                self._service_tile(lst, svc)

        for group in self.services:
            self._group_header(lst, group.get("label", "OTHER"),
                               GROUP_COLOR.get(group.get("kind"), DIM))
            for svc in group["services"]:
                self._service_tile(lst, svc, kind=group.get("kind"))

        self._status_default(
            "%d services. Price shown is sickw's list price — your account "
            "price is what actually bills." % len(self.svc_index), MUTED)

    def _group_header(self, lst, label, color):
        h = tk.Frame(lst.frame, bg=BG)
        h.pack(fill=tk.X, padx=12, pady=(10, 2))
        tk.Label(h, text=label, font=self.f_small, bg=BG, fg=color,
                 anchor="w").pack(side=tk.LEFT)
        tk.Frame(h, bg=BORDER, height=1).pack(side=tk.LEFT, fill=tk.X,
                                              expand=True, padx=8, pady=6)
        lst.register_tree(h)

    def _service_tile(self, lst, svc, kind=None):
        cached = store.cache_get(self.identifier, svc["id"], svc, self.cfg,
                                 cache=self._cache_snapshot)
        color = GROUP_COLOR.get(kind or svc.get("kind"), DIM)
        tile = tk.Frame(lst.frame, bg=CARD, highlightbackground=BORDER,
                        highlightthickness=1)
        tile.pack(fill=tk.X, padx=12, pady=3)

        left = tk.Frame(tile, bg=CARD)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tk.Label(left, text=svc["name"], font=self.f_btn, bg=CARD, fg=FG,
                 anchor="w").pack(fill=tk.X, padx=12, pady=(8, 0))
        sub = "id %s" % svc["id"]
        if cached:
            age = (time.time() - cached.get("ts", 0)) / 3600.0
            sub += "  ·  cached %s ago — free" % (
                "%dh" % age if age >= 1 else "%dm" % max(1, age * 60))
        elif svc.get("volatile"):
            sub += "  ·  live status"
        tk.Label(left, text=sub, font=self.f_small, bg=CARD,
                 fg=OK if cached else MUTED, anchor="w").pack(
                     fill=tk.X, padx=12, pady=(0, 8))

        price = tk.Label(tile, text="CACHED" if cached else usd(svc["usd"]),
                         font=self.f_name, bg=CARD,
                         fg=OK if cached else color, width=8)
        price.pack(side=tk.RIGHT, padx=10)

        # Tap fires on release and only if the finger didn't travel — see
        # TouchList. Binding a purchase to <Button-1> would mean scrolling
        # the list buys whatever is under your fingertip.
        lst.register_tree(tile, on_tap=lambda s=svc: self.run_lookup(s))

    # ── the lookup ───────────────────────────────────────────────────────

    def run_lookup(self, svc):
        if self.busy:
            return
        cached = store.cache_get(self.identifier, svc["id"], svc, self.cfg)
        if cached:
            store.history_add(self.identifier, svc["id"], svc["name"],
                              cached["rows"], cached=True, usd=svc["usd"])
            # RECENT tracks what you actually use, so a service you keep
            # re-reading from cache has to count too.
            self.cfg["recent_services"] = store.remember_service(svc["id"])
            self.show_result(svc, cached["rows"], cached=True,
                             ts=cached.get("ts"))
            return

        ok, why = sickw_api.validate_key(self.cfg.get("api_key", ""))
        if not ok:
            self.note(why + "  Import or type it below.", ERR)
            self.show_settings()
            return

        if float(svc["usd"]) > float(self.cfg.get("confirm_over_usd", 0.25)):
            self._confirm_charge(svc)
        else:
            self._start_lookup(svc)

    def _confirm_charge(self, svc):
        """Above the threshold, spending is an explicit act. A misfired tap
        on an unlock service is $168."""
        body = self.clear("CONFIRM CHARGE", back=self.show_services)
        self.head.config(fg=WARN)
        card = tk.Frame(body, bg=CARD, highlightbackground=WARN,
                        highlightthickness=2)
        card.pack(fill=tk.X, padx=24, pady=24)
        tk.Label(card, text=svc["name"], font=self.f_title, bg=CARD,
                 fg=FG, wraplength=700).pack(padx=16, pady=(16, 4))
        tk.Label(card, text=self.identifier, font=self.f_name, bg=CARD,
                 fg=DIM).pack()
        tk.Label(card, text=usd(svc["usd"]), font=self.f_big, bg=CARD,
                 fg=WARN).pack(pady=8)
        tk.Label(card, text="bills your sickw.com balance · not refundable",
                 font=self.f_small, bg=CARD, fg=MUTED).pack(pady=(0, 12))

        row = tk.Frame(body, bg=BG)
        row.pack(fill=tk.X, padx=24)
        row.columnconfigure((0, 1), weight=1, uniform="c")
        button(row, "CANCEL", self.show_services, fg=DIM,
               font=self.f_btn).grid(row=0, column=0, sticky="ew",
                                     padx=(0, 6))
        button(row, "CHARGE  %s" % usd(svc["usd"]),
               lambda: self._start_lookup(svc), fg=WARN, bg=FILL_WARN,
               font=self.f_btn).grid(row=0, column=1, sticky="ew",
                                     padx=(6, 0))

    def _start_lookup(self, svc):
        self.busy = True
        body = self.clear("LOOKING UP…", back=None)
        self.head.config(fg=INFO)
        tk.Label(body, text=svc["name"], font=self.f_title, bg=BG,
                 fg=FG, wraplength=760).pack(pady=(80, 6))
        tk.Label(body, text=self.identifier, font=self.f_big, bg=BG,
                 fg=INFO).pack()
        self._dots = tk.Label(body, text="", font=self.f_title, bg=BG,
                              fg=MUTED)
        self._dots.pack(pady=16)
        self._anim = getattr(self, "_anim", 0) + 1
        self._animate(0, self._anim)
        self.set_status("Querying sickw.com — GSX and unlock services can "
                        "take up to a minute.", INFO)
        threading.Thread(target=self._lookup_worker, args=(svc,),
                         daemon=True).start()

    def _animate(self, n, stamp):
        # A pending after() from a finished lookup would otherwise resume
        # and drive a second loop over the new screen's dots.
        if not self.busy or stamp != getattr(self, "_anim", 0):
            return
        try:
            self._dots.config(text="·" * (n % 4 + 1))
        except tk.TclError:
            return
        self.after(400, lambda: self._animate(n + 1, stamp))

    def _lookup_worker(self, svc):
        try:
            res = sickw_api.lookup(self.cfg["api_key"], self.identifier,
                                   svc["id"])
            self.after(0, lambda: self._lookup_ok(svc, res))
        # Python unbinds the `as e` name when the except block ends, so the
        # message and codes must be copied out BEFORE the deferred lambda —
        # capturing `e` itself would be a NameError on every failed lookup,
        # i.e. a crash on exactly the path that must never crash.
        except sickw_api.SickwError as e:
            msg, codes = str(e), list(e.codes)
            self.after(0, lambda: self._lookup_fail(svc, msg, codes))
        except Exception as e:                    # rule 4: never a traceback
            msg = "Unexpected: %s" % e
            self.after(0, lambda: self._lookup_fail(svc, msg, []))

    def _lookup_ok(self, svc, res):
        self.busy = False
        # Show it FIRST. This answer has already been paid for, so a full
        # disk or a corrupt cache file must not be able to swallow it —
        # an exception in here runs inside an after() callback, where Tk
        # would quietly print it to a log nobody is watching.
        self.show_result(svc, res["rows"], cached=False)
        # Separate try blocks, ledger first: this lookup has been billed
        # either way, and a cache write that fails must not also take the
        # spend record down with it and under-report what the shop spent.
        try:
            store.history_add(self.identifier, svc["id"], svc["name"],
                              res["rows"], cached=False, usd=svc["usd"])
            self.cfg["recent_services"] = store.remember_service(svc["id"])
        except Exception as exc:
            print("could not record lookup in history: %s" % exc)
        try:
            store.cache_put(self.identifier, svc["id"], res["rows"],
                            self.cfg, service=svc)
        except Exception as exc:
            print("could not cache result: %s" % exc)
            self.set_status("Result shown but NOT cached: %s — it will cost "
                            "again next time." % exc, WARN)

    def _lookup_fail(self, svc, message, codes):
        self.busy = False
        # A refusal is not cached: it is usually unbilled and the answer
        # could be different in a minute.
        store.history_add(self.identifier, svc["id"], svc["name"], [],
                          cached=False, usd=0.0)
        body = self.clear("LOOKUP FAILED", back=self.show_services)
        self.head.config(fg=ERR)
        card = tk.Frame(body, bg=FILL_ERR, highlightbackground=ERR,
                        highlightthickness=2)
        card.pack(fill=tk.X, padx=20, pady=20)
        tk.Label(card, text="✕  %s" % svc["name"], font=self.f_title,
                 bg=FILL_ERR, fg=ERR, wraplength=720).pack(padx=16,
                                                           pady=(16, 4))
        tk.Label(card, text=message, font=self.f_desc, bg=FILL_ERR, fg=FG,
                 wraplength=720, justify="left").pack(padx=16, pady=(0, 8))
        if codes:
            tk.Label(card, text="sickw code: %s" % ", ".join(codes),
                     font=self.f_small, bg=FILL_ERR, fg=MUTED).pack(
                         pady=(0, 14))
        row = tk.Frame(body, bg=BG)
        row.pack(fill=tk.X, padx=20)
        row.columnconfigure((0, 1), weight=1, uniform="d")
        button(row, "‹ OTHER SERVICE", self.show_services,
               font=self.f_btn).grid(row=0, column=0, sticky="ew",
                                     padx=(0, 6))
        if "A01" in codes:
            button(row, "⚙ FIX API KEY", self.show_settings, fg=WARN,
                   bg=FILL_WARN, font=self.f_btn).grid(
                       row=0, column=1, sticky="ew", padx=(6, 0))
        else:
            # run_lookup, NOT _start_lookup: _start_lookup is the
            # post-confirmation entry point, so retrying through it would
            # re-bill a $168 unlock with no CHARGE screen.
            button(row, "↻ RETRY", lambda: self.run_lookup(
                self.svc_index.get(svc["id"], svc)), fg=INFO, bg=FILL_AI,
                font=self.f_btn).grid(row=0, column=1, sticky="ew",
                                      padx=(6, 0))
        self.set_status(message, ERR)

    # ── RESULT ───────────────────────────────────────────────────────────

    def show_result(self, svc, rows, cached=False, ts=None):
        body = self.clear("RESULT", back=self.show_services)
        self.head.config(fg=OK if not cached else ACCENT)
        self.set_badge("CACHED" if cached else "LIVE",
                       ACCENT if cached else OK)

        top = tk.Frame(body, bg=CODE)
        top.pack(fill=tk.X)
        tk.Label(top, text=self.identifier, font=self.f_name, bg=CODE,
                 fg=FG, anchor="w").pack(side=tk.LEFT, padx=12, pady=6)
        tk.Label(top, text=svc["name"], font=self.f_small, bg=CODE,
                 fg=MUTED, anchor="e").pack(side=tk.RIGHT, padx=12)

        lst = TouchList(body)
        for i, (label, value) in enumerate(rows):
            r = tk.Frame(lst.frame, bg=CARD if i % 2 else CODE)
            r.pack(fill=tk.X, padx=12, pady=1)
            if label:
                tk.Label(r, text=label, font=self.f_small,
                         bg=r["bg"], fg=MUTED, anchor="w", width=26,
                         wraplength=230, justify="left").pack(
                             side=tk.LEFT, padx=(10, 6), pady=6)
            tk.Label(r, text=value, font=self.f_desc, bg=r["bg"],
                     fg=self._value_color(value), anchor="w",
                     wraplength=500, justify="left").pack(
                         side=tk.LEFT, padx=6, pady=6)
        # A long GSX result has to be draggable too, not just tappable.
        lst.register_tree()

        # Branch on `cached` alone: a history record with no usable ts used
        # to fall through and announce a charge for a free re-open.
        if cached:
            age = (time.time() - ts) / 3600.0 if ts else None
            when = ("age unknown" if age is None else
                    "%.0f h ago" % age if age >= 1 else
                    "%.0f min ago" % (age * 60))
            self._status_default(
                "Cached result (%s) — no charge. Tap the service again "
                "after clearing the cache to re-query." % when, ACCENT)
        else:
            self._status_default(
                "Live result — %s billed to your sickw balance."
                % usd(svc["usd"]), OK)

    @staticmethod
    def _value_color(value):
        """Colour the answers a tech scans for: a lock is red, clean is
        green. Purely a reading aid over sickw's own words."""
        v = str(value).strip().lower()
        if v in ("on", "locked", "lost", "blacklisted", "blocked", "yes",
                 "true", "found") or ("blacklist" in v and "clean" not in v):
            return ERR
        if v in ("off", "clean", "unlocked", "no", "false", "not found",
                 "unlock", "sim free", "sim-free"):
            return OK
        return FG

    # ── HISTORY ──────────────────────────────────────────────────────────

    def show_history(self):
        body = self.clear("HISTORY", back=self.show_home)
        self.head.config(fg=ACCENT)
        records = store.history_load(limit=200)
        if not records:
            tk.Label(body, text="No lookups yet.", font=self.f_title, bg=BG,
                     fg=MUTED).pack(pady=100)
            self._status_default("History records every lookup, including "
                                 "the ones that failed.", MUTED)
            return

        lst = TouchList(body)
        for rec in records:
            row = tk.Frame(lst.frame, bg=CARD, highlightbackground=BORDER,
                           highlightthickness=1)
            row.pack(fill=tk.X, padx=12, pady=3)
            failed = not rec.get("rows")
            head = "%s   %s" % (rec.get("identifier", "?"),
                                "✕ failed" if failed else "")
            tk.Label(row, text=head, font=self.f_name, bg=CARD,
                     fg=ERR if failed else FG, anchor="w").pack(
                         fill=tk.X, padx=12, pady=(8, 0))
            when = time.strftime("%Y-%m-%d %H:%M",
                                 time.localtime(rec.get("ts", 0)))
            tag = "cached · free" if rec.get("cached") else usd(
                rec.get("usd", 0))
            tk.Label(row, text="%s  ·  %s  ·  %s"
                     % (when, rec.get("service_name", "?"), tag),
                     font=self.f_small, bg=CARD,
                     fg=ACCENT if rec.get("cached") else MUTED,
                     anchor="w").pack(fill=tk.X, padx=12, pady=(0, 8))
            lst.register_tree(row, on_tap=None if failed
                              else (lambda r=rec: self._open_history(r)))

        n, paid, saved = store.spend_summary(30)
        self._status_default(
            "Last 30 days: %d lookups · %s spent · %s saved by the cache. "
            "Tap any row to re-open it free."
            % (n, money(paid), money(saved)), DIM)

    def _open_history(self, rec):
        self.identifier = rec.get("identifier", "")
        svc = self.svc_index.get(rec.get("service"),
                                 {"id": rec.get("service"),
                                  "name": rec.get("service_name", "?"),
                                  "usd": rec.get("list_usd", 0)})
        self.show_result(svc, rec.get("rows", []), cached=True,
                         ts=rec.get("ts"))
        self.back_btn.config(command=self.show_history)

    # ── SETTINGS ─────────────────────────────────────────────────────────

    def show_settings(self):
        body = self.clear("SETTINGS", back=self.show_home)
        self.head.config(fg=WARN)
        lst = TouchList(body)
        inner = lst.frame

        key = self.cfg.get("api_key", "")
        ok, why = sickw_api.validate_key(key)
        card = tk.Frame(inner, bg=CARD, highlightbackground=OK if ok
                        else ERR, highlightthickness=2)
        card.pack(fill=tk.X, padx=12, pady=(10, 6))
        tk.Label(card, text="SICKW API KEY", font=self.f_small, bg=CARD,
                 fg=MUTED, anchor="w").pack(fill=tk.X, padx=12, pady=(8, 0))
        tk.Label(card, text=sickw_api.mask_key(key) or "— not set —",
                 font=self.f_name, bg=CARD, fg=OK if ok else ERR,
                 anchor="w").pack(fill=tk.X, padx=12)
        tk.Label(card, text=why, font=self.f_small, bg=CARD, fg=MUTED,
                 anchor="w", wraplength=740, justify="left").pack(
                     fill=tk.X, padx=12, pady=(2, 8))

        krow = tk.Frame(card, bg=CARD)
        krow.pack(fill=tk.X, padx=12, pady=(0, 10))
        krow.columnconfigure((0, 1, 2), weight=1, uniform="k")
        button(krow, "💾  IMPORT FROM USB", self.import_key_usb, fg=OK,
               bg=FILL_OK, font=self.f_small, height=2).grid(
                   row=0, column=0, sticky="ew", padx=(0, 4))
        button(krow, "⌨  TYPE KEY", self.type_key, font=self.f_small,
               height=2).grid(row=0, column=1, sticky="ew", padx=4)
        button(krow, "✓  TEST KEY", self.check_key, fg=INFO, bg=FILL_AI,
               font=self.f_small, height=2).grid(row=0, column=2,
                                                 sticky="ew", padx=(4, 0))

        tk.Label(inner, text="A sickw key is 31 characters. Save it in a "
                 "plain text file named  sickw-key  in the top folder of a "
                 "USB stick, plug the stick into the bench, then tap "
                 "IMPORT FROM USB. The key is stored only in this app's "
                 "folder (chmod 600) and goes with it if you delete it.",
                 font=self.f_small, bg=BG, fg=MUTED, wraplength=740,
                 justify="left", anchor="w").pack(fill=tk.X, padx=14,
                                                  pady=(0, 8))

        self._toggle(inner, "Cache results", "cache_enabled",
                     "Repeat lookups of the same IMEI + service come back "
                     "free instead of billing again.")
        self._stepper(inner, "Live-status cache", "cache_days_volatile",
                      (0, 1, 3, 7, 30), "days",
                      "iCloud / blacklist / carrier answers change — expire "
                      "them fast.")
        self._stepper(inner, "Hardware-info cache", "cache_days_static",
                      (7, 30, 90, 365, 3650), "days",
                      "Model, part number and manufacture data never "
                      "change — keep them a long time.")
        self._stepper(inner, "Ask before charging over", "confirm_over_usd",
                      (0.0, 0.05, 0.25, 1.0, 5.0), "usd",
                      "Anything dearer needs an explicit CHARGE tap.")
        self._toggle(inner, "Barcode scanner", "scanner_enabled",
                     "A USB scanner types the IMEI and presses Enter; the "
                     "app jumps straight to the service list.")

        srow = tk.Frame(inner, bg=BG)
        srow.pack(fill=tk.X, padx=12, pady=(4, 0))
        button(srow, "🔦  SCANNER TEST", self.show_scanner_test, fg=INFO,
               bg=FILL_AI, font=self.f_small, height=2).pack(fill=tk.X)

        n_cache, size = store.cache_stats()
        drow = tk.Frame(inner, bg=BG)
        drow.pack(fill=tk.X, padx=12, pady=(10, 20))
        drow.columnconfigure((0, 1), weight=1, uniform="e")
        button(drow, "🗑  CLEAR CACHE (%d)" % n_cache,
               self._clear_cache, fg=WARN, bg=FILL_WARN,
               font=self.f_small, height=2).grid(row=0, column=0,
                                                 sticky="ew", padx=(0, 4))
        button(drow, "🗑  CLEAR HISTORY", self._clear_history, fg=ERR,
               bg=FILL_ERR, font=self.f_small, height=2).grid(
                   row=0, column=1, sticky="ew", padx=(4, 0))

        # Every row is a frame of labels, each of which swallows the press
        # that lands on it — register the whole finished tree or the
        # settings page cannot be scrolled by dragging.
        lst.register_tree()
        self._status_default(
            "Cache holds %d results (%.1f KB). Nothing here leaves the "
            "bench." % (n_cache, size / 1024.0), MUTED)

    # ── scanner diagnostics ──────────────────────────────────────────────

    def show_scanner_test(self):
        """Live view of what the wedge is actually delivering.

        There is no terminal on the bench, so without this a scanner that
        does nothing is indistinguishable from a scanner that is unplugged,
        misconfigured, or delivering to a window that doesn't have focus.
        The three states are: no keys at all (focus or cable), keys but no
        scan (wrong suffix, or too short), scans fine.
        """
        body = self.clear("SCANNER TEST", back=self.show_settings)
        self.head.config(fg=INFO)

        tk.Label(body, text="Scan any barcode now.", font=self.f_title,
                 bg=BG, fg=FG).pack(pady=(14, 2))
        tk.Label(body, text="Nothing needs to be tapped first.",
                 font=self.f_small, bg=BG, fg=MUTED).pack()

        card = tk.Frame(body, bg=CARD, highlightbackground=BORDER,
                        highlightthickness=1)
        card.pack(fill=tk.BOTH, expand=True, padx=14, pady=12)
        self._diag = tk.Label(card, text="", font=self.f_mono_diag, bg=CARD,
                              fg=FG, justify="left", anchor="nw")
        self._diag.pack(fill=tk.BOTH, expand=True, padx=12, pady=10)

        self._verdict = tk.Label(body, text="", font=self.f_btn, bg=BG,
                                 fg=MUTED, wraplength=760, justify="left")
        self._verdict.pack(fill=tk.X, padx=14, pady=(0, 10))

        self._diag_tick()
        self._status_default("Leave this open and scan. It reports what the "
                             "app receives, not what the scanner sent.",
                             MUTED)

    def _diag_tick(self):
        if not self._diag.winfo_exists():
            return
        d = (self.scanner.diagnostics() if self.scanner else
             {"keys_seen": len(self._key_log), "scans_seen": "?",
              "last_key": (self._key_log or [""])[-1], "last_code": "",
              "last_rejected": "", "buffer": "", "paused": False,
              "has_focus": None, "mean_gap_ms": 0})
        lines = [
            "keyboard focus : %s" % {True: "YES", False: "NO — the app is "
                                     "not receiving keys", None: "unknown"}[
                                         d["has_focus"]],
            "keys received  : %d" % d["keys_seen"],
            "scans decoded  : %s" % d["scans_seen"],
            "last key       : %s" % (d["last_key"] or "—"),
            "last code      : %s" % (d["last_code"] or "—"),
            "buffer now     : %s" % (d["buffer"] or "—"),
            "speed          : %s ms/key" % d["mean_gap_ms"],
            "reader         : %s" % ("bench_scanner" if bench_scanner
                                     else "built-in fallback"),
            "",
            "recent keys    : %s" % (" ".join(self._key_log[-24:]) or "—"),
        ]
        self._diag.config(text="\n".join(lines))

        if d["last_rejected"]:
            self._verdict.config(
                text="Keys arrive, but the last one was ignored: %s"
                % d["last_rejected"], fg=WARN)
        elif d["scans_seen"] not in ("?", 0):
            self._verdict.config(text="✓ Scanner works.", fg=OK)
        elif d["keys_seen"]:
            self._verdict.config(
                text="Keys are arriving but no scan completed yet. If the "
                     "digits appear above and nothing happens, the scanner "
                     "is sending no end-of-scan key — either set its suffix "
                     "to Enter (CR), or just wait: a scan with no suffix is "
                     "accepted after a short pause.", fg=WARN)
        else:
            self._verdict.config(
                text="No keys received at all. The scanner is unplugged, "
                     "not in keyboard-wedge mode, or this window doesn't "
                     "have keyboard focus. Unplug and replug it, then scan "
                     "again with this screen open.", fg=ERR)
        self.after(400, self._diag_tick)

    def _toggle(self, parent, label, key, help_text):
        on = bool(self.cfg.get(key))
        card = tk.Frame(parent, bg=CARD, highlightbackground=BORDER,
                        highlightthickness=1)
        card.pack(fill=tk.X, padx=12, pady=3)
        txt = tk.Frame(card, bg=CARD)
        txt.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tk.Label(txt, text=label, font=self.f_btn, bg=CARD, fg=FG,
                 anchor="w").pack(fill=tk.X, padx=12, pady=(8, 0))
        tk.Label(txt, text=help_text, font=self.f_small, bg=CARD, fg=MUTED,
                 anchor="w", wraplength=560, justify="left").pack(
                     fill=tk.X, padx=12, pady=(0, 8))
        b = button(card, "ON" if on else "OFF",
                   lambda: self._set_cfg(key, not on),
                   fg=OK if on else MUTED, bg=FILL_OK if on else CHIP,
                   font=self.f_btn, width=6, height=2)
        b.pack(side=tk.RIGHT, padx=10, pady=8)

    def _stepper(self, parent, label, key, choices, unit, help_text):
        """Cycle through preset values — no number pad, no free text, one
        tap per change. Enumerable values should be buttons (SDK rule)."""
        cur = self.cfg.get(key)
        try:
            nxt = choices[(list(choices).index(cur) + 1) % len(choices)]
        except ValueError:
            nxt = choices[0]
        card = tk.Frame(parent, bg=CARD, highlightbackground=BORDER,
                        highlightthickness=1)
        card.pack(fill=tk.X, padx=12, pady=3)
        txt = tk.Frame(card, bg=CARD)
        txt.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tk.Label(txt, text=label, font=self.f_btn, bg=CARD, fg=FG,
                 anchor="w").pack(fill=tk.X, padx=12, pady=(8, 0))
        tk.Label(txt, text=help_text, font=self.f_small, bg=CARD, fg=MUTED,
                 anchor="w", wraplength=560, justify="left").pack(
                     fill=tk.X, padx=12, pady=(0, 8))
        shown = ("never" if cur == 0 and unit == "days"
                 else "always ask" if cur == 0.0 and unit == "usd"
                 else usd(cur) if unit == "usd" else "%g d" % cur)
        button(card, shown, lambda: self._set_cfg(key, nxt), fg=INFO,
               bg=FILL_AI, font=self.f_btn, width=9, height=2).pack(
                   side=tk.RIGHT, padx=10, pady=8)

    def _set_cfg(self, key, value):
        self.cfg[key] = value
        store.save_config(self.cfg)
        self.show_settings()

    def _clear_cache(self):
        store.cache_clear()
        self.note("Cache cleared — the next lookup of any IMEI will bill "
                  "again.", WARN)
        self.show_settings()

    def _clear_history(self):
        store.history_clear()
        self.note("History cleared.", WARN)
        self.show_settings()

    # ── key management ───────────────────────────────────────────────────

    def import_key_usb(self):
        if self.busy:
            return
        self.busy = True
        self.set_status("Scanning USB sticks for a sickw-key file…", INFO)
        # Threaded: globbing every mount point and reading files can block
        # for seconds on a stuck stick, and doing that on the Tk thread
        # freezes the whole screen with no explanation.
        threading.Thread(target=self._usb_worker, daemon=True).start()

    def _usb_worker(self):
        try:
            key, path = device_read.find_key_on_usb()
            err = ""
        except Exception as exc:
            key, path, err = "", "", str(exc)
        self.after(0, lambda: self._usb_done(key, path, err))

    def _usb_done(self, key, path, err):
        self.busy = False
        if err:
            self.set_status("USB scan failed: %s" % err, ERR)
            return
        if not key:
            self.set_status("No sickw-key file found. Put a plain text file "
                            "named  sickw-key  holding just the 31-character "
                            "key in the top folder of the stick.", WARN)
            return
        self.cfg["api_key"] = key
        store.save_config(self.cfg)
        self.note("Imported %s from %s" % (sickw_api.mask_key(key), path), OK)
        self.show_settings()

    def type_key(self):
        if bench_keyboard:
            key = self._with_keyboard("SICKW API KEY",
                                      self.cfg.get("api_key", ""),
                                      secret=True)
        else:
            key = self._dev_prompt("SICKW API KEY",
                                   self.cfg.get("api_key", ""))
        if key is None:
            return
        key = key.strip()
        ok, why = sickw_api.validate_key(key)
        self.cfg["api_key"] = key
        store.save_config(self.cfg)
        self.note(why, OK if ok else ERR)
        self.show_settings()

    def _dev_prompt(self, title, initial=""):
        """Dev-machine only stand-in for bench_keyboard — a real keyboard
        exists here. Never reached on the bench."""
        win = tk.Toplevel(self, bg=BG)
        win.title(title)
        win.transient(self)
        win.grab_set()
        tk.Label(win, text=title, font=self.f_title, bg=BG,
                 fg=ACCENT).pack(padx=20, pady=(16, 8))
        e = tk.Entry(win, font=self.f_name, bg=CODE, fg=FG, width=40,
                     insertbackground=FG)
        e.pack(padx=20, pady=8, ipady=6)
        e.insert(0, initial)
        e.focus_set()
        out = {"v": None}

        def done():
            out["v"] = e.get()
            win.destroy()
        tk.Button(win, text="OK", command=done, font=self.f_btn, bg=CARD,
                  fg=FG).pack(pady=12)
        e.bind("<Return>", lambda _e: done())
        self.busy = True                 # same reason as _with_keyboard
        try:
            self.wait_window(win)
        finally:
            self.busy = False
        return out["v"]

    def check_key(self):
        if self.busy:
            return
        self.busy = True
        self.set_status("Checking the key against sickw (balance query — "
                        "costs nothing)…", INFO)
        threading.Thread(target=self._check_worker, daemon=True).start()

    def _check_worker(self):
        try:
            ok, msg, bal = sickw_api.test_key(self.cfg.get("api_key", ""))
        except Exception as exc:
            ok, msg, bal = False, "Key check failed: %s" % exc, None
        self.after(0, lambda: self._check_done(ok, msg, bal))

    def _check_done(self, ok, msg, bal):
        self.busy = False
        if bal is not None:
            msg += "  Balance: %s" % money(bal)
        self.set_status(msg, OK if ok else ERR)
        self.set_badge("KEY OK" if ok else "KEY BAD", OK if ok else ERR)

    # ── exit ─────────────────────────────────────────────────────────────

    def close(self):
        try:
            store.save_config(self.cfg)
        except Exception:
            pass
        self.destroy()
        sys.exit(0)


if __name__ == "__main__":
    App().mainloop()
