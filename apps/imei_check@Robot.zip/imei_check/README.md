# IMEI Check — sickw.com lookups on the bench

A BenchTool user app (App SDK contract) that runs IMEI and serial-number
checks against [sickw.com](https://sickw.com) from the 4" touchscreen:
carrier, iCloud/FMI, blacklist, MDM, GSX warranty, Samsung/Pixel/Xiaomi
info, and the unlock services — 96 services in all.

**Bring your own API key.** Nothing ships with one, and every lookup bills
*your* sickw balance. The app is built around that fact: prices are on the
tile before you tap it, anything over a threshold needs an explicit
CHARGE tap, and results are cached so the same question is never billed
twice.

```
Utilities ▸ My Apps ▸ 🔎 IMEI Check
```

## Install

```bash
python3 app_sdk/validate_app.py app_sdk/imei_check     # PASS before you ship it
scp -r app_sdk/imei_check <user>@<bench-ip>:~/benchtool-apps/
```

Open Utilities on the bench — it rescans every time, no reboot. No
`requires`: the app is pure standard library, so it installs nothing into
`libs/` and can't drift from the bench stack.

## Your API key

A sickw key is exactly 31 characters. Two ways in, no keyboard needed:

**USB stick (recommended).** On a Mac or PC, save a plain text file named
`sickw-key` (or `sickw-key.txt`) containing only the key, put it in the
top folder of a stick, plug it into the bench, then
**Settings ▸ IMPORT FROM USB**. Same pattern as the bench's own API Key
Import tool. `key=` prefixes, quotes and Windows line endings are all
tolerated.

**Type it.** Settings ▸ TYPE KEY opens the bench's on-screen keyboard.

**TEST KEY** cannot spend anything: it queries `action=balance`, which
takes no IMEI and no service, so there is nothing for sickw to charge
for. A bad key still returns `A01`. If the bench can't reach sickw at all,
it says so rather than claiming the key is good.

The key is written to `config.json` **inside this app's folder**, chmod
600. Deleting the app folder takes the key, the cache and the history with
it; nothing is left in the user's home. It is masked (`ABCD•••…•••WXYZ`)
everywhere it appears on screen or in the log.

## Getting the IMEI in — three ways, none of them typing 15 digits

| | |
|---|---|
| **Barcode scanner** | Any USB HID scanner. Scan the label; the app detects the burst-then-Enter timing, validates, and jumps straight to the service list. |
| **Pull from device** | `adb getprop` (with an `iphonesubinfo` parcel fallback for ROMs that hide the props) and `ideviceinfo` for iOS. Multiple devices or multiple IMEIs → a picker. |
| **On-screen keyboard** | Tap the field for `bench_keyboard`'s fullscreen touch keyboard. |

Whatever the source, the value is stripped to alphanumerics (exactly what
sickw does server-side, so the cache key matches what was billed) and
Luhn-checked. **A failed checksum warns, it does not block** — refurb
boards and some MEIDs genuinely fail Luhn, and the tech decides whether to
spend the money, not the app.

## Not paying twice

Results are cached by `IMEI + service`, with two TTLs, because two kinds of
answer live in that catalog:

- **Hardware facts** — model, part number, capacity, manufacture data.
  These never change. Cached **365 days** by default.
- **Live status** — iCloud/FMI, blacklist, carrier lock, MDM, activation.
  These change, and a stale answer is worse than no answer. Cached **1
  day** by default.

Each service is tagged `volatile` in `services.json`. A cached tile reads
`CACHED` in place of the price and `cached 3h ago — free` under the name,
and costs nothing to open. Set either TTL to `0` in Settings to disable
that half. Failed lookups are **never** cached — a refusal is usually
unbilled and may succeed a minute later, so caching it would sell the
customer a permanent "no".

History keeps the last 500 lookups (including failures) and any of them
can be re-opened for free. Settings shows 30-day spend and what the cache
saved you.

## Files

| | |
|---|---|
| `main.py` | Tkinter UI — the only file that imports tkinter |
| `sickw_api.py` | API client: request, error codes, result flattening. No I/O beyond the one GET |
| `store.py` | config / cache / history, all inside this folder |
| `device_read.py` | adb + libimobiledevice readers, USB key import |
| `services.json` | the service catalog — id, name, price, volatile |
| `../../test_imei_check.py` | 82 tests, no network, no Tk |

`sickw_api`, `store` and `device_read` deliberately import no tkinter, so
the logic is testable in a headless container while `main.py` stays a
pure view.

## The API, for reference

One GET does everything:

```
https://sickw.com/api.php?format=beta&key=<31-char>&imei=<id>&service=<id>
```

`format=beta` is the richest JSON; services beta can't model yet return an
HTML blob instead, and `parse_result()` normalizes both into label/value
rows. Errors arrive as **HTTP 200** with `{"status":"error","result":"Error
A01: API KEY is Wrong!"}` and several codes can be concatenated into that
one string:

| | |
|---|---|
| `A01` | API key wrong |
| `E01` | IMEI wrong (checksum/length) |
| `E02` | IMEI or serial wrong for this service |
| `S01` | service ID wrong or not enabled on your account |

Balance is the same endpoint with `action=balance` and no imei —
undocumented but live, so it's treated as best-effort and never blocks a
lookup.

## Prices

`services.json` carries sickw's public list price so the tile can show a
number before you tap. **sickw changes prices and your account may have
its own rates** — treat the figure as an estimate. Your real balance is at
sickw.com. To refresh, re-read <https://sickw.com/?page=services>.

## Tests

```bash
python3 -m pytest test_imei_check.py -q      # from the repo root
```

All 82 run offline: every sickw call goes through an injected `opener`, so
the suite never spends a cent. They cover Luhn and identifier cleaning,
the error-code parser, beta/HTML result flattening, both cache TTLs, the
config coercion and chmod, USB key shapes, the adb parcel decoder, and the
SDK contract itself (manifest limits, `sys.exit(0)`, no `simpledialog`,
state confined to the app folder).

Several are AST or source assertions over `main.py` rather than live tests,
because tkinter can't be imported in a headless container. They pin the
things that would otherwise quietly regress into a charge: that purchases
are never bound to `<Button-1>`, that `_start_lookup` stays reachable only
through `run_lookup`'s confirm gate, that a status warning survives a
screen change, and that no `lambda` captures an `except ... as e` name
(Python unbinds it at the end of the block, so that would be a `NameError`
on the one path that must always render).

## Why taps fire on release

A tap bound to `<Button-1>` fires the instant a finger lands, with no way
to slide off and cancel — so on a 96-item list on a 4" panel, dragging to
scroll would buy whatever was under your fingertip. Rows fire on
`<ButtonRelease-1>` and only if the finger travelled less than 12px.

Two consequences worth knowing if you edit the UI: Tk does **not** bubble
button events from a child widget to its parent, so every label in every
row has to be registered with the scroller individually; and `tk.Button`
invokes its command from a *class* binding, so the release handler is
bound even where there's no tap action, purely to return `"break"` after a
drag. Otherwise dragging past CLEAR CACHE presses it.

## Notes and limits

- Unlock services (`🕒` on sickw) are **orders**, not instant lookups. The
  app submits and shows what sickw returns; the result may arrive in your
  sickw account later rather than on screen.
- The app never writes IMEIs to Repair-Sentinel or any shared pool — the
  Sentinel house rules forbid customer-identifying data, and IMEIs are
  named explicitly.
- Prices in the catalog were read on 2026-07-30.
