#!/usr/bin/env python3
"""sickw.com API client — pure logic, no Tk, no I/O beyond the HTTP call.

The whole public API of sickw.com is one GET:

    https://sickw.com/api.php?format=beta&key=<31-char-key>&imei=<id>&service=<id>

`format=beta` returns the richest JSON ("full JSON format ... still in
development", per sickw's own sample.php), so a service that beta can't
model yet comes back as an HTML blob in `result` instead of an object.
parse_result() handles both shapes and always hands the UI the same thing:
an ordered list of (label, value) pairs.

Balance lives at the same endpoint with `action=balance` and no imei.

Errors are NOT HTTP errors — the endpoint answers 200 with
{"status": "error", "result": "Error A01: API KEY is Wrong!"} and can
concatenate several codes into that one string.

No dependency beyond the standard library, so this runs on the bench venv,
on a dev laptop, and under pytest with nothing installed.
"""

import json
import re
import urllib.error
import urllib.parse
import urllib.request

API_URL = "https://sickw.com/api.php"
KEY_LEN = 31              # sickw's own sample.php rejects any other length
TIMEOUT = 60              # their sample uses 60s; GSX lookups are slow

# The documented error codes, mapped to something a tech can act on.
ERROR_CODES = {
    "A01": "API key is wrong. Check Settings ▸ API key.",
    "E01": "IMEI is wrong — failed the checksum or the wrong length.",
    "E02": "IMEI or serial is wrong for this service.",
    "S01": "Service ID is wrong or not enabled on your account.",
}
_ERR_RE = re.compile(r"Error\s+([A-Z]\d{2})\s*:\s*([^!]*!?)")

# Beta-format replies nest the real payload under one of these.
_PAYLOAD_KEYS = ("result", "object", "data")


class SickwError(Exception):
    """A refusal from sickw (bad key, bad IMEI, no balance) or a transport
    failure. `.codes` holds the parsed error codes when there were any."""

    def __init__(self, message, codes=None, raw=""):
        super().__init__(message)
        self.codes = codes or []
        self.raw = raw


# ── input hygiene ────────────────────────────────────────────────────────

def clean_identifier(value):
    """Strip everything a barcode scanner, a label or a fat finger adds.

    sickw does exactly this server-side (preg_replace non-alphanumerics),
    so doing it here means the cache key matches what actually got billed.
    """
    return re.sub(r"[^a-zA-Z0-9]+", "", str(value or "")).upper()


def luhn_ok(imei):
    """Luhn check digit — the standard IMEI checksum. Only meaningful for
    a 15-digit all-numeric IMEI; anything else is a serial and can't be
    checked this way."""
    if len(imei) != 15 or not imei.isdigit():
        return False
    total = 0
    for i, ch in enumerate(reversed(imei)):
        d = int(ch)
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def classify_identifier(value):
    """('imei'|'serial'|'invalid', cleaned, message).

    Deliberately permissive: a failed Luhn is reported as a warning, not a
    block. Refurb boards and some MEIDs genuinely fail it, and the tech —
    not the app — decides whether to spend money on the lookup.
    """
    v = clean_identifier(value)
    if not v:
        return "invalid", v, "Enter an IMEI or serial number."
    if len(v) < 11 or len(v) > 15:
        return "invalid", v, (
            "sickw accepts 11-15 characters; this is %d." % len(v))
    if v.isdigit() and len(v) == 15:
        if luhn_ok(v):
            return "imei", v, "Valid IMEI (checksum OK)."
        return "imei", v, "IMEI checksum FAILED — lookup may cost and fail."
    if v.isdigit() and len(v) == 14:
        return "imei", v, "14-digit IMEI/MEID — no checksum to verify."
    return "serial", v, "Treating as a serial number."


def validate_key(key):
    """(ok, message) for an API key, using sickw's own length rule."""
    k = (key or "").strip()
    if not k:
        return False, "No API key set."
    if len(k) != KEY_LEN:
        return False, "Key must be exactly %d characters — this one is %d." % (
            KEY_LEN, len(k))
    if not re.fullmatch(r"[A-Za-z0-9\-_]+", k):
        return False, "Key contains characters sickw never issues."
    return True, "Key looks well-formed."


def mask_key(key):
    """Never print a full key to a log or a screen in a shared shop."""
    k = (key or "").strip()
    if len(k) <= 8:
        return "•" * len(k)
    return "%s%s%s" % (k[:4], "•" * (len(k) - 8), k[-4:])


# ── response parsing ─────────────────────────────────────────────────────

def parse_errors(text):
    """Pull every 'Error XNN: message' out of a result string."""
    out = []
    for code, msg in _ERR_RE.findall(str(text or "")):
        out.append((code, ERROR_CODES.get(code, msg.strip().rstrip("!"))))
    return out


def _strip_html(fragment):
    """sickw's non-beta replies are an HTML table/br soup. Turn it into
    lines without dragging in a parser."""
    s = re.sub(r"(?i)<\s*br\s*/?\s*>", "\n", str(fragment or ""))
    s = re.sub(r"(?i)</\s*(tr|p|div|li|h\d)\s*>", "\n", s)
    s = re.sub(r"(?i)</\s*t[dh]\s*>", ": ", s)
    s = re.sub(r"<[^>]+>", "", s)
    s = (s.replace("&nbsp;", " ").replace("&amp;", "&")
          .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"'))
    return s


def _flatten(obj, rows, prefix=""):
    """Beta objects nest (GSX especially). Flatten to label/value rows so
    the UI never has to think about depth."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            label = str(k).replace("_", " ").strip()
            _flatten(v, rows, ("%s ▸ %s" % (prefix, label)).strip(" ▸")
                     if prefix else label)
    elif isinstance(obj, list):
        if all(not isinstance(x, (dict, list)) for x in obj):
            rows.append((prefix, ", ".join(str(x) for x in obj)))
        else:
            for i, v in enumerate(obj, 1):
                _flatten(v, rows, "%s [%d]" % (prefix, i))
    else:
        rows.append((prefix, "" if obj is None else str(obj)))


def parse_result(payload):
    """Normalize any sickw reply body into [(label, value), ...].

    Accepts the beta object form, the json/html string form, and the odd
    service that returns a bare string with no structure at all.
    """
    rows = []
    if isinstance(payload, (dict, list)):
        _flatten(payload, rows)
        return [(k, v) for k, v in rows if str(v).strip()]

    text = _strip_html(payload)
    for line in text.splitlines():
        line = line.strip(" \t|")
        if not line:
            continue
        if ":" in line:
            label, _, value = line.partition(":")
            label, value = label.strip(), value.strip()
            if label and value:
                rows.append((label, value))
                continue
        rows.append(("", line))
    return rows


# ── the call ─────────────────────────────────────────────────────────────

def _get(params, timeout=TIMEOUT, opener=None):
    """GET the endpoint and return the decoded body (dict when it is JSON,
    else the raw string). `opener` is the seam the tests inject through."""
    url = "%s?%s" % (API_URL, urllib.parse.urlencode(params))
    try:
        if opener is not None:
            body = opener(url, timeout)
        else:
            req = urllib.request.Request(
                url, headers={"User-Agent": "BenchTool-IMEI-Check/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read().decode("utf-8", "replace")
    # NET marks "we never got an answer", as opposed to an answer that
    # said no. A key check must not read a dead wifi link as a good key.
    except urllib.error.HTTPError as e:
        raise SickwError("sickw returned HTTP %s." % e.code,
                         codes=["NET"]) from e
    except urllib.error.URLError as e:
        raise SickwError("Cannot reach sickw.com: %s" % e.reason,
                         codes=["NET"]) from e
    except OSError as e:                       # DNS down, no route, TLS
        raise SickwError("Network error: %s" % e, codes=["NET"]) from e

    if isinstance(body, (dict, list)):
        return body
    try:
        return json.loads(body)
    except (ValueError, TypeError):
        return body


def lookup(key, identifier, service_id, timeout=TIMEOUT, opener=None):
    """Run one paid lookup.

    Returns {"rows": [(label, value)], "raw": <body>, "identifier": str,
             "service": int}. Raises SickwError on any refusal — the caller
    must NOT cache a raise, because a failed lookup is usually not billed
    and the answer could differ next time.
    """
    ident = clean_identifier(identifier)
    ok, why = validate_key(key)
    if not ok:
        raise SickwError(why)
    if not ident:
        raise SickwError("No IMEI or serial to look up.")

    body = _get({"format": "beta", "key": key, "imei": ident,
                 "service": service_id}, timeout=timeout, opener=opener)

    status, payload = "", body
    if isinstance(body, dict):
        status = str(body.get("status", "")).lower()
        for k in _PAYLOAD_KEYS:
            if k in body:
                payload = body[k]
                break

    # An error can arrive flagged by `status`, or only as text in the body
    # when there's no status field at all. But do NOT scan the body of an
    # explicit success: a GSX reply that happens to contain the words
    # "Error E01:" in a warranty note is a real, already-billed answer, and
    # raising here would both hide it and log the lookup as costing $0.
    errs = []
    if status != "success":
        errs = parse_errors(payload if isinstance(payload, str) else "")
    if status == "error" or errs:
        if errs:
            raise SickwError(" ".join(m for _, m in errs),
                             codes=[c for c, _ in errs], raw=str(payload))
        detail = (_strip_html(payload).strip()
                  if isinstance(payload, str) else "")
        raise SickwError(detail or "sickw rejected the request.",
                         raw=str(payload))

    rows = parse_result(payload)
    if not rows:
        raise SickwError("sickw returned an empty result for this service.",
                         raw=str(payload)[:500])
    return {"rows": rows, "raw": payload, "identifier": ident,
            "service": int(service_id) if str(service_id).isdigit()
            else service_id}


def balance(key, timeout=30, opener=None):
    """Account balance in USD, or None when sickw doesn't report one.

    Undocumented but live: api.php?action=balance validates the key and
    ignores imei/service. Treated as best-effort — a shop must never be
    blocked from a lookup because this shape changed.
    """
    ok, why = validate_key(key)
    if not ok:
        raise SickwError(why)
    body = _get({"format": "json", "key": key, "action": "balance"},
                timeout=timeout, opener=opener)

    payload = body
    if isinstance(body, dict):
        if str(body.get("status", "")).lower() == "error":
            errs = parse_errors(body.get("result", ""))
            raise SickwError(" ".join(m for _, m in errs) or
                             "Balance check refused.",
                             codes=[c for c, _ in errs])
        for k in ("balance", "credit", "result"):
            if k in body:
                payload = body[k]
                break
    if isinstance(payload, (int, float)):
        return float(payload)
    m = re.search(r"-?\d+(?:\.\d+)?", _strip_html(payload))
    return float(m.group(0)) if m else None


def test_key(key, timeout=30, opener=None):
    """(ok, message, balance) — liveness check that cannot spend anything.

    Deliberately built on `action=balance` rather than a lookup against
    the `demo` service: a lookup is a billable request by definition, and
    nothing guarantees `demo` stays free on every account. Balance takes
    no imei and no service, so there is nothing for sickw to charge for,
    and A01 still identifies a bad key.
    """
    ok, why = validate_key(key)
    if not ok:
        return False, why, None
    try:
        bal = balance(key, timeout=timeout, opener=opener)
    except SickwError as e:
        if "A01" in e.codes:
            return False, "sickw rejected this key (Error A01).", None
        if "NET" in e.codes:
            # Nothing was verified. Saying "key accepted" here would paint
            # the badge green because the shop's wifi is down.
            return False, "Could not reach sickw — key NOT verified (%s)." \
                % e, None
        # Otherwise the key got past authentication and it's the balance
        # endpoint being unhelpful — best-effort, don't blame the key.
        return True, "Key accepted; balance unavailable (%s)." % e, None
    if bal is None:
        return True, "Key accepted by sickw (balance not reported).", None
    return True, "Key accepted by sickw.", bal
