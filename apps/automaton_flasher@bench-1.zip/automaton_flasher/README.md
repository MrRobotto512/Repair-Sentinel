# Keystroke Flasher — BenchTool app

Build keyboard‑automation **workflows on the Hero Dashboard**, then **flash them
onto the ESP32‑S3 dongle over USB serial**. Primary job: **bypass the
Windows OOBE** to set up a local account (the dongle is a USB HID keyboard, so it
types on any PC at the setup screen).

```
┌────────────────────────┐      writes       ┌────────────────────────┐
│  Hero Dashboard (web.py) │  library.json →  │  Touchscreen (main.py)  │
│  step builder + library  │  selection.json  │  detect + FLASH         │
└────────────────────────┘   app's data/     └───────────┬────────────┘
                                                          │ USB-CDC serial
                                                          │ (no drive mount)
                                                          ▼
                                        ┌─────────────────────────────────┐
                                        │  esp32s3_automaton dongle         │
                                        │  stores workflows in NVS,          │
                                        │  plays them from the BOOT button   │
                                        └─────────────────────────────────┘
```

## Why serial (and not a drive)

The ESP32‑S3 already exposes a **USB‑CDC serial console** on the same USB‑C as
its HID keyboard. We flash by writing the workflows to that port — **no drive to
mount, no bootloader dance, no esptool** (uses `pyserial`, already on the bench).
The device stores them in **NVS**, so they survive reboots and play from the
button. Changing commands never rebuilds firmware.

## One‑time firmware companion

The stock `esp32s3_automaton` firmware bakes its workflows in at compile time.
To receive and store bench‑authored workflows it needs a small companion
(delivered with this app, under `esp32s3_automaton/`): it adds the `WBEGIN /
WEND / WINFO / WCLEAR` serial commands and an NVS‑backed workflow store. Build +
flash it **once** with PlatformIO (`pio run -t upload`). After that, all command
changes go over serial from the bench — no more rebuilds.

## Using it

1. On the **Hero Dashboard ▸ ⌨ Keystroke Flasher** page, the **Windows OOBE examples**
   are preloaded (including *OOBE: Local account (25H2)* — Shift+F10 →
   `start ms-cxh:localonly`). Edit them or build your own with the step builder,
   then **Stage to flash**.
2. On the bench, open **Utilities ▸ My Apps ▸ Keystroke Flasher**, plug the
   ESP32 dongle into a USB **data** port (it appears as `/dev/ttyACM*`), and tap
   **⚡ FLASH**.
3. Take the dongle to the target PC. At the OOBE screen, press its **BOOT button**
   to arm + run the selected workflow.

## The command model

Mirrors the firmware's own `mac_keys.h`: steps are chord / repeat‑tap / type /
run‑line / hold / wait / status; modifiers Cmd/Ctrl/Alt/Shift (plus a `VO`
VoiceOver chip for Mac use). Everything is a generic USB keyboard, so it works on
Windows and macOS alike — the OOBE examples just happen to be the shop's daily
driver.

## Install on the bench

```bash
python3 app_sdk/validate_app.py keystroke_flasher     # from the devkit
# then upload the zipped folder on Hero Dashboard ▸ 🧩 My Apps, or:
scp -r keystroke_flasher <user>@<bench-ip>:~/benchtool-apps/
```

## Safety

The dongle is a keyboard that types on its own — whatever window has focus on the
target receives the keystrokes. A BOOT‑button press **arms a countdown** so you
can cancel; auto‑run is **off** by default. Know what's focused before it fires.
