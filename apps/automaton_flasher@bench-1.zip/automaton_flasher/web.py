#!/usr/bin/env python3
"""
web.py — the Hero Dashboard face of Keystroke Flasher.

This is where the technician *types in or selects the commands* (exactly the
request): a touch-friendly step builder plus a saved-workflow library. What you
build here is written to the app's data/ folder; the touchscreen app (main.py)
reads the same folder and flashes the staged workflows to the dongle.

Contract (see tools/app_web.py): expose one `handle(ctx)`.
  ctx.path     — sub-path after /x/<folder>/
  ctx.request  — the Flask request (GET/POST form)
  ctx.app_dir  — our folder, so store.py reads/writes data/ here
  ctx.url(sub) — build links back into this app

Return conventions: a str is wrapped in the dashboard shell automatically; a
dict/list becomes JSON; anything else (a redirect) is handed to Flask as-is.

The rendering + state changes live in pure functions (render_page /
apply_action) so they can be unit-tested without a running dashboard.
"""

from __future__ import annotations

import html
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import af_store as store
import af_model as wm
import af_examples as examples

DEVICE_NAME = "ESP32-S3 dongle (USB serial)"

# --------------------------------------------------------------------------- #
#  Small helpers
# --------------------------------------------------------------------------- #
def _esc(s):
    return html.escape(str(s), quote=True)


def _getlist(form, key):
    if hasattr(form, "getlist"):
        return form.getlist(key)
    v = form.get(key)
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return list(v)
    return [p for p in str(v).replace(",", " ").split() if p]


# --------------------------------------------------------------------------- #
#  State changes (pure: take app_dir + action + a plain form dict)
# --------------------------------------------------------------------------- #
def apply_action(app_dir, action, form):
    """Mutate stored state for one POSTed action.
    Returns (ok_msg, err_msg) — at most one is non-empty."""
    try:
        if action == "add_step":
            step = _step_from_form(form)
            store.draft_add_step(app_dir, step)
            return (f"Added step: {wm.describe_step(step)}", "")

        if action == "del_step":
            store.draft_remove_step(app_dir, int(form.get("index", -1)))
            return ("Step removed.", "")

        if action == "move_step":
            store.draft_move_step(app_dir, int(form.get("index", -1)),
                                  int(form.get("delta", 0)))
            return ("Step moved.", "")

        if action == "set_meta":
            d = store.load_draft(app_dir)
            d["name"] = str(form.get("name", ""))[:wm.MAX_NAME]
            d["note"] = str(form.get("note", ""))[:wm.MAX_TEXT]
            d["button"] = str(form.get("button", "")).strip()
            store.save_draft(app_dir, d)
            return ("Workflow details saved.", "")

        if action == "clear_draft":
            store.clear_draft(app_dir)
            return ("Cleared the builder.", "")

        if action == "save_workflow":
            d = store.load_draft(app_dir)
            # allow the name/note to be set in the same submit
            if form.get("name"):
                d["name"] = str(form.get("name"))[:wm.MAX_NAME]
            if form.get("note") is not None:
                d["note"] = str(form.get("note"))[:wm.MAX_TEXT]
            if form.get("button") is not None:
                d["button"] = str(form.get("button")).strip()
            saved = store.upsert_workflow(app_dir, d)
            store.clear_draft(app_dir)
            return (f"Saved “{saved['name']}” ({len(saved['steps'])} steps).",
                    "")

        if action == "edit_workflow":
            wf = store.get_workflow(app_dir, form.get("name", ""))
            if not wf:
                return ("", "That workflow is gone.")
            store.save_draft(app_dir, {
                "name": wf.get("name", ""), "note": wf.get("note", ""),
                "button": ("" if wf.get("button") is None
                           else str(wf.get("button", ""))),
                "steps": list(wf.get("steps", [])),
            })
            return (f"Loaded “{wf['name']}” into the builder.", "")

        if action == "delete_workflow":
            store.delete_workflow(app_dir, form.get("name", ""))
            return ("Workflow deleted.", "")

        if action == "toggle_stage":
            name = form.get("name", "")
            sel = store.load_selection(app_dir)["names"]
            low = [n.lower() for n in sel]
            if name.lower() in low:
                sel = [n for n in sel if n.lower() != name.lower()]
                msg = f"Un-staged “{name}”."
            else:
                sel.append(name)
                msg = f"Staged “{name}” to flash."
            store.save_selection(app_dir, sel)
            return (msg, "")

        if action == "clear_stage":
            store.save_selection(app_dir, [])
            return ("Flash queue cleared.", "")

        if action == "load_examples":
            n = store.import_workflows(app_dir, examples.all_examples())
            return (f"Loaded {n} Windows OOBE example workflow(s).", "")

        if action == "save_settings":
            lib = store.load_library(app_dir)
            s = {}
            for k in ("arm_countdown_ms", "key_down_ms", "step_settle_ms",
                      "tap_gap_ms"):
                if form.get(k):
                    s[k] = int(form.get(k))
            s["autorun"] = str(form.get("autorun", "")).lower() in (
                "1", "on", "true", "yes")
            lib["settings"] = s
            store.save_library(app_dir, lib)
            return ("Settings saved.", "")

        return ("", f"Unknown action: {action}")
    except wm.WorkflowError as e:
        return ("", str(e))
    except (ValueError, KeyError) as e:
        return ("", f"Bad input: {e}")


def _step_from_form(form):
    """Turn the Add-Step form fields into a validated model step."""
    op = str(form.get("op", "")).strip().lower()
    mods = _getlist(form, "mods")
    if str(form.get("vo", "")).lower() in ("1", "on", "true"):
        mods = list(mods) + ["vo"]
    key = form.get("key", "")
    if op == "status":
        return wm.make_step("status", text=form.get("text", ""))
    if op in ("type", "line"):
        return wm.make_step(op, text=form.get("text", ""))
    if op == "delay":
        return wm.make_step("delay", ms=form.get("ms", 0))
    if op == "hold":
        return wm.make_step("hold", mods=mods, key=key, ms=form.get("ms", 0))
    if op == "taps":
        return wm.make_step("taps", mods=mods, key=key,
                            count=form.get("count", 1), gap=form.get("gap", 0))
    if op == "tap":
        return wm.make_step("tap", key=key)
    # default: a single chord
    return wm.make_step("key", mods=mods, key=key)


# --------------------------------------------------------------------------- #
#  Rendering
# --------------------------------------------------------------------------- #
PAGE_CSS = """
<style>
.atm{--acc:#40c4ff;--ok:#00c853;--warn:#ffab00;--err:#ff5252;
  --card:#1b1b21;--bg2:#101014;--line:#2a2a32;--dim:#aab0bf;--mut:#7a7a8c;}
.atm h1{font-size:20px;color:var(--acc);margin:0 0 2px;letter-spacing:.3px;
  text-shadow:0 0 12px rgba(64,196,255,.35)}
.atm .sub{color:var(--mut);font-size:13px;margin:0 0 12px}
.atm .meters{display:flex;gap:8px;margin:0 0 14px;flex-wrap:wrap}
.atm .meter{flex:1;min-width:88px;background:var(--card);border:1px solid var(--line);
  border-radius:10px;padding:8px 10px;position:relative;overflow:hidden}
.atm .meter b{display:block;font-size:22px;color:var(--acc);line-height:1.1}
.atm .meter small{color:var(--mut);font-size:11px;text-transform:uppercase;
  letter-spacing:.5px}
.atm .meter::after{content:"";position:absolute;left:0;bottom:0;height:3px;
  width:100%;background:linear-gradient(90deg,var(--acc),transparent)}
.atm .card{background:var(--card);border:1px solid var(--line);border-radius:12px;
  padding:14px;margin:12px 0}
.atm .card h2{font-size:13px;color:var(--dim);text-transform:uppercase;
  letter-spacing:.6px;margin:0 0 10px}
.atm label{display:block;color:var(--dim);font-size:12px;margin:12px 0 4px}
.atm input[type=text],.atm input[type=number],.atm textarea,.atm select{
  width:100%;background:var(--bg2);color:#e8e8f0;border:1px solid var(--line);
  border-radius:8px;padding:11px;font-size:15px}
.atm textarea{min-height:60px;font-family:ui-monospace,Menlo,monospace}
.atm .row{display:flex;gap:8px;flex-wrap:wrap}
.atm .row>div{flex:1;min-width:120px}
.atm .chips{display:flex;flex-wrap:wrap;gap:7px;margin-top:5px}
.atm .chips input{display:none}
.atm .chips label{display:inline-block;margin:0;background:#14141a;
  border:1px solid var(--line);border-radius:99px;padding:9px 14px;font-size:14px;
  color:#e8e8f0;cursor:pointer}
.atm .chips input:checked+label{background:#123a4d;border-color:var(--acc);
  color:var(--acc);box-shadow:0 0 8px rgba(64,196,255,.4)}
.atm .seg{display:flex;flex-wrap:wrap;gap:6px;margin-top:5px}
.atm .seg input{display:none}
.atm .seg label{flex:1;min-width:64px;text-align:center;margin:0;background:#14141a;
  border:1px solid var(--line);border-radius:8px;padding:11px 0;font-size:14px;
  color:#e8e8f0;cursor:pointer}
.atm .seg input:checked+label{background:#123a4d;border-color:var(--acc);
  color:var(--acc)}
.atm button,.atm .btn{width:100%;background:#123a4d;color:#eaf6ff;border:0;
  border-radius:10px;padding:14px;font-size:15px;font-weight:700;margin-top:14px;
  cursor:pointer;text-align:center;display:block}
.atm button.ghost,.atm .btn.ghost{background:#14141a;border:1px solid var(--line);
  color:var(--dim)}
.atm button.go{background:linear-gradient(90deg,#0d6b2f,#00c853);color:#04120a;
  box-shadow:0 0 16px rgba(0,200,83,.35)}
.atm button.danger{background:#3a0d0d;color:#ff8a8a}
.atm .mini{width:auto;display:inline-block;margin:0;padding:8px 12px;font-size:13px}
.atm .steps{list-style:none;margin:8px 0 0;padding:0}
.atm .steps li{display:flex;align-items:center;gap:8px;background:var(--bg2);
  border:1px solid var(--line);border-left:3px solid var(--acc);border-radius:8px;
  padding:9px 10px;margin:6px 0;font-family:ui-monospace,Menlo,monospace;
  font-size:13px;color:#dfe6ee}
.atm .steps li .n{color:var(--mut);min-width:20px}
.atm .steps li .d{flex:1}
.atm .steps li form{display:inline;margin:0;width:auto}
.atm .steps li .mini{background:#14141a;border:1px solid var(--line);color:var(--dim)}
.atm .wf{background:var(--bg2);border:1px solid var(--line);border-radius:10px;
  padding:11px;margin:8px 0}
.atm .wf.staged{border-color:var(--ok);box-shadow:0 0 10px rgba(0,200,83,.15)}
.atm .wf .t{font-size:15px;color:#eaf1f8;font-weight:600}
.atm .wf .m{color:var(--mut);font-size:12px;margin:2px 0 8px}
.atm .wf .acts{display:flex;gap:6px;flex-wrap:wrap}
.atm .flash{border-radius:8px;padding:10px 12px;margin:0 0 12px;font-size:14px}
.atm .flash.ok{background:#0d3318;color:#69f0ae;border:1px solid #135c2c}
.atm .flash.err{background:#3a0d0d;color:#ff9a9a;border:1px solid #5c1313}
.atm .hint{color:var(--mut);font-size:12px;margin-top:8px;line-height:1.5}
.atm details{background:#14141a;border:1px solid var(--line);border-radius:10px;
  padding:0 12px;margin:12px 0}
.atm details summary{cursor:pointer;padding:12px 0;color:var(--dim);font-size:13px;
  text-transform:uppercase;letter-spacing:.5px}
.atm .leds{display:inline-flex;gap:4px;vertical-align:middle;margin-left:8px}
.atm .leds i{width:9px;height:9px;border-radius:50%;background:#233;display:inline-block}
.atm .leds i.on{background:var(--ok);box-shadow:0 0 6px var(--ok)}
.atm code{background:#14141a;border:1px solid var(--line);border-radius:5px;
  padding:1px 5px;font-size:12px;color:#9fd0ff}
</style>
"""

_OPS_UI = [
    ("key", "Chord"), ("taps", "Repeat tap"), ("type", "Type text"),
    ("line", "Run line"), ("hold", "Hold"), ("delay", "Wait"),
    ("status", "Status"),
]


def _flash_banner(ok, err):
    if err:
        return f"<div class='flash err'>⚠ {_esc(err)}</div>"
    if ok:
        return f"<div class='flash ok'>✓ {_esc(ok)}</div>"
    return ""


def render_page(app_dir, url, ok="", err=""):
    """Full page body (wrapped in the dashboard shell by the host)."""
    lib = store.load_library(app_dir)
    wfs = lib["workflows"]
    settings = lib.get("settings", {})
    draft = store.load_draft(app_dir)
    staged = store.load_selection(app_dir)["names"]
    staged_low = [n.lower() for n in staged]

    P = [PAGE_CSS, "<div class='atm'>"]
    P.append("<h1>⌨ Keystroke Flasher — Command Builder</h1>")
    P.append(f"<p class='sub'>Build keyboard commands — mainly to bypass the "
             f"<b>Windows OOBE</b> for local-account setup — then stage what to "
             f"flash. Flashed over USB serial to the <b>{_esc(DEVICE_NAME)}</b>; "
             f"the dongle types them on any PC at the setup screen.</p>")

    # meter strip (TMOG-style)
    P.append("<div class='meters'>")
    P.append(_meter(len(wfs), "saved"))
    P.append(_meter(len(draft['steps']), "in builder"))
    P.append(_meter(len(staged), "staged"))
    P.append("</div>")

    P.append(_flash_banner(ok, err))

    # ---- builder ----
    P.append(_render_builder(url, draft))
    # ---- add-step form ----
    P.append(_render_add_step(url))
    # ---- library ----
    P.append(_render_library(url, wfs, staged_low))
    # ---- staged / flash instructions ----
    P.append(_render_staged(url, wfs, staged))
    # ---- settings ----
    P.append(_render_settings(url, settings))

    P.append("</div>")
    return "".join(P)


def _meter(n, label):
    return (f"<div class='meter'><b>{n}</b><small>{_esc(label)}</small></div>")


def _render_builder(url, draft):
    H = ["<div class='card'><h2>① Build a workflow</h2>"]
    H.append(f"<form method='post' action='{url}?a=set_meta'>")
    H.append("<div class='row'>")
    H.append(f"<div><label>Name</label><input type='text' name='name' "
             f"maxlength='{wm.MAX_NAME}' placeholder='e.g. Recovery: VO + AppChooser' "
             f"value='{_esc(draft.get('name',''))}'></div>")
    H.append(f"<div><label>Run on button (0–2, optional)</label>"
             f"<input type='number' name='button' min='0' max='2' "
             f"value='{_esc(draft.get('button',''))}'></div>")
    H.append("</div>")
    H.append(f"<label>Note</label><input type='text' name='note' "
             f"maxlength='{wm.MAX_TEXT}' placeholder='what it does' "
             f"value='{_esc(draft.get('note',''))}'>")
    H.append("<button class='ghost mini' type='submit'>Save details</button>")
    H.append("</form>")

    # step list
    steps = draft.get("steps", [])
    if steps:
        H.append("<ul class='steps'>")
        for i, st in enumerate(steps):
            H.append("<li>")
            H.append(f"<span class='n'>{i+1}</span>")
            H.append(f"<span class='d'>{_esc(wm.describe_step(st))}</span>")
            H.append(_iconform(url, "move_step", "↑",
                               {"index": i, "delta": -1}))
            H.append(_iconform(url, "move_step", "↓",
                               {"index": i, "delta": 1}))
            H.append(_iconform(url, "del_step", "✕", {"index": i},
                               danger=True))
            H.append("</li>")
        H.append("</ul>")
    else:
        H.append("<p class='hint'>No steps yet. Add the first one below — "
                 "each step is one keyboard action, played in order.</p>")

    # save / clear
    H.append("<div class='row'>")
    H.append(f"<div><form method='post' action='{url}?a=save_workflow'>"
             f"<input type='hidden' name='name' value='{_esc(draft.get('name',''))}'>"
             f"<button class='go' type='submit'>💾 Save to library</button></form></div>")
    H.append(f"<div><form method='post' action='{url}?a=clear_draft'>"
             f"<button class='ghost' type='submit'>Clear builder</button>"
             f"</form></div>")
    H.append("</div>")
    H.append("</div>")
    return "".join(H)


def _iconform(url, action, glyph, fields, danger=False):
    hid = "".join(f"<input type='hidden' name='{_esc(k)}' value='{_esc(v)}'>"
                  for k, v in fields.items())
    cls = "mini danger" if danger else "mini ghost"
    return (f"<form method='post' action='{url}?a={action}'>{hid}"
            f"<button class='{cls}' type='submit'>{glyph}</button></form>")


def _render_add_step(url):
    mod_chips = "".join(
        f"<input type='checkbox' id='m_{m}' name='mods' value='{m}'>"
        f"<label for='m_{m}'>{wm._MOD_GLYPH[m]}</label>"
        for m in wm.MODIFIERS)
    seg = "".join(
        f"<input type='radio' name='op' id='op_{op}' value='{op}'"
        f"{' checked' if op=='key' else ''}>"
        f"<label for='op_{op}'>{_esc(lbl)}</label>"
        for op, lbl in _OPS_UI)
    H = [f"<div class='card'><h2>② Add a step</h2>"
         f"<form method='post' action='{url}?a=add_step' id='addf'>"]
    H.append("<div class='seg'>" + seg + "</div>")

    # chord/keys fields
    H.append("<div data-when='key taps hold tap' class='fld'>")
    H.append("<label>Modifiers</label><div class='chips'>" + mod_chips +
             "<input type='checkbox' id='m_vo' name='vo' value='1'>"
             "<label for='m_vo'>VO</label></div>")
    H.append("<label>Key</label><input type='text' name='key' "
             "placeholder=\"a letter, or: enter tab esc f5 up down space\">")
    H.append("</div>")

    H.append("<div data-when='taps' class='fld row'>"
             "<div><label>Repeat count</label>"
             "<input type='number' name='count' min='1' max='64' value='3'></div>"
             "<div><label>Gap (ms)</label>"
             "<input type='number' name='gap' min='0' max='10000' value='500'></div>"
             "</div>")
    H.append("<div data-when='hold' class='fld'>"
             "<label>Hold for (ms)</label>"
             "<input type='number' name='ms' min='1' max='600000' value='25000'>"
             "</div>")
    H.append("<div data-when='type line' class='fld'>"
             "<label>Text</label>"
             "<textarea name='text' placeholder='text to type "
             "(Run line adds Return)'></textarea></div>")
    H.append("<div data-when='delay' class='fld'>"
             "<label>Wait (ms)</label>"
             "<input type='number' name='ms' min='1' max='600000' value='1000'>"
             "</div>")
    H.append("<div data-when='status' class='fld'>"
             "<label>On-screen status text</label>"
             "<input type='text' name='text' placeholder='shown on the dongle "
             "display / log'></div>")
    H.append("<button type='submit'>＋ Add step</button>")
    H.append("</form>")
    H.append("<p class='hint'>Tip: <code>VO</code> is the VoiceOver modifier "
             "(Ctrl+Opt). The device is blind — add <b>Wait</b> steps to let "
             "slow screens (Recovery, VoiceOver) catch up.</p>")
    H.append(_ADD_STEP_JS)
    H.append("</div>")
    return "".join(H)


_ADD_STEP_JS = """
<script>(function(){
 var f=document.getElementById('addf'); if(!f) return;
 function sync(){
   var op=(f.querySelector('input[name=op]:checked')||{}).value||'key';
   f.querySelectorAll('.fld').forEach(function(el){
     var w=(el.getAttribute('data-when')||'').split(' ');
     el.style.display = w.indexOf(op)>=0 ? '' : 'none';
   });
 }
 f.querySelectorAll('input[name=op]').forEach(function(r){
   r.addEventListener('change', sync); });
 sync();
})();</script>
"""


def _render_library(url, wfs, staged_low):
    H = ["<div class='card'><h2>③ Saved workflows</h2>"]
    H.append(f"<form method='post' action='{url}?a=load_examples'>"
             f"<button class='ghost mini' type='submit'>⭳ Load Windows OOBE "
             f"examples</button></form>")
    if not wfs:
        H.append("<p class='hint'>Nothing saved yet. Build one above and hit "
                 "<b>Save to library</b>, or load the OOBE examples.</p></div>")
        return "".join(H)
    for w in wfs:
        name = w.get("name", "")
        staged = name.lower() in staged_low
        staged_badge = ("" if not staged else
                        " &nbsp;<span style='color:#69f0ae;font-size:12px'>"
                        "● staged</span>")
        H.append(f"<div class='wf{' staged' if staged else ''}'>")
        H.append(f"<div class='t'>{_esc(name)}{staged_badge}</div>")
        note = w.get("note", "")
        H.append(f"<div class='m'>{len(w.get('steps',[]))} steps"
                 f"{' · ' + _esc(note) if note else ''}"
                 f"{' · button ' + _esc(w.get('button')) if w.get('button') not in (None,'') else ''}"
                 f"</div>")
        H.append("<div class='acts'>")
        H.append(_btnform(url, "toggle_stage", name,
                          "Un-stage" if staged else "Stage to flash",
                          cls="mini go" if not staged else "mini ghost"))
        H.append(_btnform(url, "edit_workflow", name, "Edit", cls="mini ghost"))
        H.append(_btnform(url, "delete_workflow", name, "Delete",
                          cls="mini danger"))
        H.append("</div></div>")
    H.append("</div>")
    return "".join(H)


def _btnform(url, action, name, label, cls="mini ghost"):
    return (f"<form method='post' action='{url}?a={action}'>"
            f"<input type='hidden' name='name' value='{_esc(name)}'>"
            f"<button class='{cls}' type='submit'>{_esc(label)}</button></form>")


def _render_staged(url, wfs, staged):
    H = ["<div class='card'><h2>④ Staged to flash "
         "<span class='leds'>"]
    for i in range(5):
        H.append(f"<i class='{'on' if i < min(len(staged),5) else ''}'></i>")
    H.append("</span></h2>")
    if not staged:
        H.append("<p class='hint'>Nothing staged. Tap <b>Stage to flash</b> on "
                 "a saved workflow, then go to the bench and open "
                 "<b>Keystroke Flasher</b> to write them to the dongle.</p>")
    else:
        H.append("<ol class='steps'>")
        for i, n in enumerate(staged):
            exists = any(w.get("name", "").lower() == n.lower() for w in wfs)
            tag = "" if exists else " <span style='color:#ff9a9a'>(missing)</span>"
            H.append(f"<li><span class='n'>{i+1}</span>"
                     f"<span class='d'>{_esc(n)}{tag}</span></li>")
        H.append("</ol>")
        H.append(f"<form method='post' action='{url}?a=clear_stage'>"
                 f"<button class='ghost' type='submit'>Clear flash queue</button>"
                 f"</form>")
        H.append("<p class='hint'>These are queued. On the bench, open "
                 "<b>Utilities ▸ My Apps ▸ Keystroke Flasher</b>, plug in the "
                 "dongle, and tap <b>FLASH</b>.</p>")
    H.append("</div>")
    return "".join(H)


def _render_settings(url, s):
    def val(k, d):
        v = s.get(k, d)
        return _esc(v)
    H = ["<details><summary>⚙ Timing &amp; safety settings</summary>",
         f"<form method='post' action='{url}?a=save_settings'>"]
    H.append("<div class='row'>"
             f"<div><label>Arm countdown (ms)</label>"
             f"<input type='number' name='arm_countdown_ms' min='0' max='60000' "
             f"value='{val('arm_countdown_ms',3000)}'></div>"
             f"<div><label>Key hold (ms)</label>"
             f"<input type='number' name='key_down_ms' min='1' max='2000' "
             f"value='{val('key_down_ms',40)}'></div></div>")
    H.append("<div class='row'>"
             f"<div><label>Step settle (ms)</label>"
             f"<input type='number' name='step_settle_ms' min='0' max='5000' "
             f"value='{val('step_settle_ms',140)}'></div>"
             f"<div><label>Tap gap (ms)</label>"
             f"<input type='number' name='tap_gap_ms' min='0' max='5000' "
             f"value='{val('tap_gap_ms',90)}'></div></div>")
    checked = "checked" if s.get("autorun") else ""
    H.append("<div class='chips' style='margin-top:12px'>"
             f"<input type='checkbox' id='autorun' name='autorun' value='1' {checked}>"
             "<label for='autorun'>⚠ Auto-run on plug-in (dangerous)</label></div>")
    H.append("<button class='ghost' type='submit'>Save settings</button>")
    H.append("</form>"
             "<p class='hint'>The dongle is a keyboard that types on its own. "
             "The arm countdown gives you time to cancel before keystrokes go "
             "out. Leave auto-run OFF unless you know exactly what's focused.</p>")
    H.append("</details>")
    return "".join(H)


# --------------------------------------------------------------------------- #
#  The dashboard entry point
# --------------------------------------------------------------------------- #
def handle(ctx):
    path = (ctx.path or "").strip("/")
    req = ctx.request

    # first-ever load seeds the Windows OOBE starter workflows
    try:
        store.seed_if_new(ctx.app_dir, examples.all_examples())
    except Exception:
        pass

    # machine endpoint: /x/<folder>/api  -> JSON of what's staged (skips PIN)
    if path.startswith("api"):
        staged = store.selected_workflows(ctx.app_dir)
        lib = store.load_library(ctx.app_dir)
        try:
            blob = wm.build_blob(staged, settings=lib.get("settings")) \
                if staged else None
        except wm.WorkflowError:
            blob = None
        return {
            "device": DEVICE_NAME,
            "staged": [w.get("name") for w in staged],
            "workflow_count": len(lib.get("workflows", [])),
            "blob": blob,
        }

    # POST -> apply, then redirect (Post/Redirect/Get) so refresh is safe
    if req.method == "POST":
        action = req.args.get("a", "")
        ok, err = apply_action(ctx.app_dir, action, req.form)
        try:
            from flask import redirect
            q = ("?ok=" + _q(ok)) if ok else (("?err=" + _q(err)) if err else "")
            return redirect(ctx.url(q))
        except Exception:
            return render_page(ctx.app_dir, ctx.url(), ok, err)

    ok = req.args.get("ok", "")
    err = req.args.get("err", "")
    return render_page(ctx.app_dir, ctx.url(), ok, err)


def _q(s):
    from urllib.parse import quote
    return quote(str(s)[:200])
