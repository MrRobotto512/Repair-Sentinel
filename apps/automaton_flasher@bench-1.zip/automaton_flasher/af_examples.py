#!/usr/bin/env python3
"""
af_examples.py — starter workflows for Keystroke Flasher.

The bench's main job for this tool is bypassing the Windows OOBE (Out-Of-Box
Experience) to set up a local account — so the app ships with ready-to-flash
OOBE workflows. They're seeded into the library on first run and can be
re-imported any time from the dashboard ("Load Windows OOBE examples").

The dongle is a USB HID keyboard, so these work on any PC at the OOBE screen.
Method note: `start ms-cxh:localonly` is the current (Win11 24H2/25H2) way to
reach local-account setup; the BypassNRO registry route is kept for older
builds. Edit or add your own on the dashboard.
"""

from __future__ import annotations

import af_model as wm


def _wf(name, note, steps, button=None):
    wf = {"name": name, "note": note, "steps": steps}
    if button is not None:
        wf["button"] = button
    return wf


def windows_oobe():
    """The Windows OOBE bypass starter set."""
    return [
        # ---- the primary one the shop asked for (with focus nudge) -------- #
        #  On recent builds the Shift+F10 cmd window opens WITHOUT keyboard
        #  focus (you'd normally have to click it). The dongle can't click, so
        #  we nudge focus with Alt+Tab before typing. If your build already
        #  focuses the cmd window, use the "no focus fix" variant instead.
        _wf("OOBE: Local account (25H2)",
            "Shift+F10, Alt+Tab to focus cmd, start ms-cxh:localonly",
            [
                wm.make_step("status", text="Shift+F10 - open Command Prompt"),
                wm.make_step("key", mods="shift", key="f10"),
                wm.make_step("delay", ms=2000),
                wm.make_step("status", text="Alt+Tab - focus the cmd window"),
                wm.make_step("key", mods="alt", key="tab"),
                wm.make_step("delay", ms=700),
                wm.make_step("status", text="Launch local-only setup"),
                wm.make_step("line", text="start ms-cxh:localonly"),
                wm.make_step("delay", ms=800),
                wm.make_step("status", text="Follow the local-account prompts"),
            ],
            button=0),

        # ---- same, for builds where cmd already takes focus -------------- #
        _wf("OOBE: Local account (no focus fix)",
            "Shift+F10 then type (no Alt+Tab)",
            [
                wm.make_step("status", text="Shift+F10 - open Command Prompt"),
                wm.make_step("key", mods="shift", key="f10"),
                wm.make_step("delay", ms=2000),
                wm.make_step("status", text="Launch local-only setup"),
                wm.make_step("line", text="start ms-cxh:localonly"),
                wm.make_step("delay", ms=800),
                wm.make_step("status", text="Follow the local-account prompts"),
            ]),

        # ---- reusable focus building block ------------------------------- #
        _wf("OOBE: Focus cmd window",
            "Alt+Tab - use if the cmd window won't accept typing",
            [
                wm.make_step("status", text="Alt+Tab to the cmd window"),
                wm.make_step("key", mods="alt", key="tab"),
            ]),

        # ---- a plain building block -------------------------------------- #
        _wf("OOBE: Open Command Prompt",
            "just Shift+F10 (some laptops: Shift+Fn+F10)",
            [
                wm.make_step("status", text="Opening Command Prompt"),
                wm.make_step("key", mods="shift", key="f10"),
            ],
            button=1),

        # ---- older builds: re-enable the 'no internet' path -------------- #
        _wf("OOBE: BypassNRO (older builds)",
            "reg BypassNRO=1 then reboot to OOBE",
            [
                wm.make_step("status", text="Shift+F10 - Command Prompt"),
                wm.make_step("key", mods="shift", key="f10"),
                wm.make_step("delay", ms=1500),
                wm.make_step("status", text="Enable BypassNRO"),
                wm.make_step("line", text=(
                    'reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\'
                    'CurrentVersion\\OOBE" /v BypassNRO /t REG_DWORD /d 1 /f')),
                wm.make_step("delay", ms=800),
                wm.make_step("status", text="Rebooting to OOBE"),
                wm.make_step("line", text="shutdown /r /t 0"),
            ],
            button=2),
    ]


# PowerShell the dongle types on the target laptop: compute battery health from
# the same capacity numbers powercfg reports (design vs full-charge), find THIS
# dongle's COM port by its Espressif VID, and write the result back to it so the
# firmware can show it on screen. Runs in Windows PowerShell 5.1 (System.IO.Ports
# is built in there). Assumes a US keyboard layout on the target.
_BATTERY_PS = (
    "$d=@(gcim -N root/wmi -Class BatteryStaticData)[0].DesignedCapacity;"
    "$c=@(gcim -N root/wmi -Class BatteryFullChargedCapacity)[0]"
    ".FullChargedCapacity;"
    "$p=[int](100*$c/$d);"
    "$n=(Get-PnpDevice -Class Ports -PresentOnly|"
    "?{$_.InstanceId -match 'VID_303A'}|select -First 1).FriendlyName;"
    "$m=[regex]::Match($n,'COM\\d+').Value;"
    "$s=New-Object IO.Ports.SerialPort $m,115200;$s.Open();"
    "$s.WriteLine(\"BATT:$d,$c,$p\");Start-Sleep -m 500;$s.Close()"
)


def windows_battery():
    """Read a laptop's battery health and show it on the dongle screen.

    The dongle is a blind keyboard, so it can't read the report itself — it
    types a command that computes the % on the PC and writes it back over the
    dongle's own USB-CDC COM port. Needs firmware with the BATT: screen.
    """
    return [
        _wf("Battery Health (Windows)",
            "PowerShell -> health % back to the dongle screen (US layout)",
            [
                wm.make_step("status", text="Win+R - Run"),
                wm.make_step("key", mods="cmd", key="r"),
                wm.make_step("delay", ms=900),
                wm.make_step("line", text="powershell"),
                wm.make_step("delay", ms=2200),
                wm.make_step("status", text="Reading battery..."),
                wm.make_step("line", text=_BATTERY_PS),
                wm.make_step("delay", ms=500),
                wm.make_step("status", text="Check dongle screen"),
            ]),
    ]


def all_examples():
    return windows_oobe() + windows_battery()
