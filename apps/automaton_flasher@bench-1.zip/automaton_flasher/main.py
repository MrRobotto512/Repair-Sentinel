#!/usr/bin/env python3
"""
main.py — Keystroke Flasher (BenchTool touchscreen app)

Flashes custom keyboard commands to the ESP32-S3 dongle over its
USB-CDC serial console — no drive to mount, no bootloader dance. The tech builds
and stages workflows on the Hero Dashboard (web.py); here they plug the dongle
into the bench's USB and tap FLASH.

Primary use: bypassing the Windows OOBE to set up a local account (the dongle is
a USB HID keyboard, so it drives any PC at the setup screen).

Follows the BenchTool app contract: standalone Tk root, fullscreen dark theme,
big EXIT button top-right, never crashes on missing hardware (all device I/O is
guarded and reported on screen), exit code 0 on clean close.
"""

import os
import sys
import threading
import queue
import tkinter as tk
from tkinter import font

APP_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP_DIR)

import af_store as store
import af_serial as link
import af_blob as blob
import af_examples as examples
import af_model as wm

try:
    import ui_theme as _ui
    ON_BENCH = True
except ImportError:
    _ui = None
    ON_BENCH = False

# design tokens (match the bench built-ins)
BG = "#0d0d0f"
CARD = "#1b1b21"
CODE = "#101014"
BORDER = "#2a2a32"
FG = "#e8e8f0"
DIM = "#aab0bf"
MUT = "#7a7a8c"
ACC = "#40c4ff"
OK = "#00c853"
WARN = "#ffab00"
ERR = "#ff5252"

# A single NVS string value tops out at ~4000 bytes; stay safely under.
MAX_SCRIPT_BYTES = 3900


class App(tk.Tk):
    TITLE = "KEYSTROKE FLASHER"

    def __init__(self):
        super().__init__()
        if ON_BENCH and hasattr(_ui, "apply_root"):
            _ui.apply_root(self)
        else:
            self.geometry("800x480")
            self.title(self.TITLE + " (dev)")
        self.configure(bg=BG)

        self.f_title = font.Font(family="DejaVu Sans", size=24, weight="bold")
        self.f_h = font.Font(family="DejaVu Sans", size=15, weight="bold")
        self.f_body = font.Font(family="DejaVu Sans", size=14)
        self.f_small = font.Font(family="DejaVu Sans", size=12)
        self.f_exit = font.Font(family="DejaVu Sans", size=22, weight="bold")
        self.f_flash = font.Font(family="DejaVu Sans", size=22, weight="bold")

        # seed the Windows OOBE starter workflows on first run
        try:
            store.seed_if_new(APP_DIR, examples.all_examples())
        except Exception as e:
            print("seed failed:", e)

        self.device = None          # {"port","ident"} when found
        self.staged = []
        self.q = queue.Queue()
        self.busy = False

        self._build_header()
        self._build_body()
        self.after(150, self.rescan)
        self.after(120, self._pump)

    # ---- chrome -----------------------------------------------------------
    def _build_header(self):
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill=tk.X, padx=12, pady=(10, 4))
        tk.Label(bar, text="⌨ " + self.TITLE, font=self.f_title,
                 bg=BG, fg=ACC).pack(side=tk.LEFT)
        tk.Button(bar, text="X", font=self.f_exit, bg="#3a1a1a", fg=ERR,
                  activebackground="#5a2a2a", activeforeground=ERR, bd=2,
                  relief="raised", width=3, command=self.close
                  ).pack(side=tk.RIGHT)

    def _build_body(self):
        body = tk.Frame(self, bg=BG)
        body.pack(fill=tk.BOTH, expand=True, padx=12, pady=6)
        body.grid_columnconfigure(0, weight=1, uniform="c")
        body.grid_columnconfigure(1, weight=1, uniform="c")
        body.grid_rowconfigure(0, weight=1)

        # left: device panel
        left = tk.Frame(body, bg=CARD, highlightbackground=BORDER,
                        highlightthickness=1)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        tk.Label(left, text="ESP32 DONGLE (USB)", font=self.f_h, bg=CARD,
                 fg=DIM).pack(anchor="w", padx=12, pady=(10, 2))
        self.dev_dot = tk.Label(left, text="●  scanning…", font=self.f_body,
                                bg=CARD, fg=MUT, justify="left",
                                wraplength=360, anchor="w")
        self.dev_dot.pack(anchor="w", fill=tk.X, padx=12, pady=2)
        self.dev_msg = tk.Label(left, text="", font=self.f_small, bg=CARD,
                                fg=MUT, justify="left", wraplength=360,
                                anchor="w")
        self.dev_msg.pack(anchor="w", fill=tk.X, padx=12, pady=(2, 8))

        btns = tk.Frame(left, bg=CARD)
        btns.pack(fill=tk.X, padx=12, pady=4)
        self.btn_rescan = tk.Button(btns, text="⟳ Rescan", font=self.f_body,
                                    bg=CODE, fg=FG, activebackground="#20202a",
                                    activeforeground=FG, bd=0,
                                    command=self.rescan)
        self.btn_rescan.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 3))
        self.btn_ports = tk.Button(btns, text="🔎 Ports", font=self.f_body,
                                   bg=CODE, fg=DIM, activebackground="#20202a",
                                   activeforeground=FG, bd=0,
                                   command=self.show_ports)
        self.btn_ports.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(3, 0))

        # right: staged workflows
        right = tk.Frame(body, bg=CARD, highlightbackground=BORDER,
                         highlightthickness=1)
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        tk.Label(right, text="STAGED TO FLASH", font=self.f_h, bg=CARD, fg=DIM
                 ).pack(anchor="w", padx=12, pady=(10, 2))
        self.staged_box = tk.Frame(right, bg=CARD)
        self.staged_box.pack(fill=tk.BOTH, expand=True, padx=12, pady=4)

        # bottom: status + FLASH
        bottom = tk.Frame(self, bg=BG)
        bottom.pack(fill=tk.X, padx=12, pady=(4, 10))
        self.status = tk.Label(bottom, text="", font=self.f_small, bg=BG,
                               fg=DIM, anchor="w", justify="left",
                               wraplength=760)
        self.status.pack(fill=tk.X, pady=(0, 6))
        self.btn_flash = tk.Button(bottom, text="⚡ FLASH", font=self.f_flash,
                                   bg="#0d3318", fg=OK,
                                   activebackground="#12401f",
                                   activeforeground=OK, bd=0, height=2,
                                   state=tk.DISABLED, command=self.flash)
        self.btn_flash.pack(fill=tk.X)

    # ---- staged list ------------------------------------------------------
    def refresh_staged(self):
        for w in self.staged_box.winfo_children():
            w.destroy()
        try:
            self.staged = store.selected_workflows(APP_DIR)
        except Exception as e:
            self.staged = []
            print("staged load failed:", e)
        if not self.staged:
            tk.Label(self.staged_box,
                     text="Nothing staged.\n\nOn the Hero Dashboard ▸ "
                          "Keystroke Flasher page, build workflows (OOBE "
                          "examples are preloaded) and tap “Stage to flash”.",
                     font=self.f_small, bg=CARD, fg=MUT, justify="left",
                     wraplength=360, anchor="nw").pack(anchor="w", fill=tk.X)
            return
        for i, w in enumerate(self.staged):
            row = tk.Frame(self.staged_box, bg=CODE, highlightbackground=BORDER,
                           highlightthickness=1)
            row.pack(fill=tk.X, pady=3)
            tk.Label(row, text=f"{i+1}", font=self.f_h, bg=CODE, fg=ACC,
                     width=2).pack(side=tk.LEFT, padx=(8, 4), pady=6)
            sub = f"{len(w.get('steps', []))} steps"
            if w.get("note"):
                sub += " · " + w["note"]
            cell = tk.Frame(row, bg=CODE)
            cell.pack(side=tk.LEFT, fill=tk.X, expand=True)
            tk.Label(cell, text=w.get("name", "?"), font=self.f_body, bg=CODE,
                     fg=FG, anchor="w").pack(anchor="w")
            tk.Label(cell, text=sub, font=self.f_small, bg=CODE, fg=MUT,
                     anchor="w", wraplength=280, justify="left"
                     ).pack(anchor="w")
        self.update_status()

    # ---- detection --------------------------------------------------------
    def rescan(self):
        if self.busy:
            return
        self.set_dev("●  scanning USB…", MUT)
        self.refresh_staged()
        threading.Thread(target=self._scan_worker, daemon=True).start()

    def _scan_worker(self):
        try:
            dev = link.find_device()
        except Exception as e:
            dev = None
            print("scan error:", e)
        self.q.put(("device", dev))

    def _apply_device(self, dev):
        self.device = dev
        if dev:
            self.set_dev("● CONNECTED", OK)
            self.dev_msg.config(
                text=f"{dev['ident']}\n{dev.get('label', dev['port'])}\n"
                     f"{dev['port']}")
        else:
            self.set_dev("● not found", MUT)
            self.dev_msg.config(
                text="No dongle found. Plug the ESP32 into the Pi's USB "
                     "(native USB-C port) — it shows as /dev/ttyACM*. The board "
                     "must be running the ESP32 firmware (esp32s3_automaton "
                     "v1.1). Tap 🔎 Ports to see what's detected.")
        can = bool(dev) and bool(self.staged)
        self.btn_flash.config(state=tk.NORMAL if can else tk.DISABLED,
                              fg=OK if can else MUT,
                              bg="#0d3318" if can else "#161a16")
        self.update_status()

    # ---- ports diagnostic -------------------------------------------------
    def show_ports(self):
        if self.busy:
            return
        self.set_dev("●  probing ports…", MUT)
        self.dev_msg.config(text="")
        threading.Thread(target=self._diag_worker, daemon=True).start()

    def _diag_worker(self):
        try:
            rows = link.diagnose()
        except Exception as e:
            rows = None
            print("diagnose error:", e)
        self.q.put(("ports", rows))

    def _apply_ports(self, rows):
        if not rows:
            self.set_dev("● no serial ports", WARN)
            self.dev_msg.config(
                text="No serial ports on the Pi. Check the USB cable is a DATA "
                     "cable, the dongle is plugged into the Pi (not the target "
                     "PC), and it's powered (screen on).")
            return
        hit = any(r["matched"] for r in rows)
        self.set_dev(f"● {len(rows)} port(s) found", OK if hit else WARN)
        lines = []
        esp_wrong_fw = False
        for r in rows:
            tag = "✓ " if r["matched"] else "✗ "
            name = os.path.basename(r["port"])
            label = r.get("label", "")
            lines.append(f"{tag}{name}  {label}")
            if r["matched"]:
                lines.append(f"    {r['ident']}")
            elif r["lines"]:
                lines.append(f"    reply: {r['lines'][-1][:40]}")
            else:
                lines.append("    (no reply to IDENT)")
            # An Espressif device that won't answer = an ESP32 that isn't
            # running our firmware (or is in the bootloader / JTAG mode).
            low = (label + " " + " ".join(r.get("lines", []))).lower()
            if (not r["matched"]) and ("espressif" in low or "303a" in low
                                       or "jtag" in low):
                esp_wrong_fw = True
        if esp_wrong_fw:
            lines.append("")
            lines.append("→ ESP32 found but not answering: it's in JTAG/")
            lines.append("  bootloader mode or running other firmware.")
            lines.append("  Flash esp32s3_automaton v1.1, then replug.")
        self.dev_msg.config(text="\n".join(lines))

    def update_status(self):
        n = len(self.staged)
        if n == 0:
            self.set_status("Stage workflows on the dashboard first.")
        elif not self.device:
            self.set_status(f"{n} workflow(s) staged — waiting for the dongle.")
        else:
            try:
                script = blob.to_script(self.staged,
                                        store.load_library(APP_DIR).get("settings"))
                _, nb = blob.script_stats(script)
                self.set_status(f"{n} workflow(s) staged ({nb} B). Tap FLASH "
                                f"to write them to the dongle.")
            except Exception as e:
                self.set_status(f"⚠ {e}", ERR)

    # ---- flash ------------------------------------------------------------
    def flash(self):
        if self.busy or not self.device or not self.staged:
            return
        try:
            script = blob.to_script(
                self.staged, store.load_library(APP_DIR).get("settings"))
        except (blob.BlobError, wm.WorkflowError) as e:
            return self.set_status(f"⚠ can't build script: {e}", ERR)
        n, nb = blob.script_stats(script)
        if nb > MAX_SCRIPT_BYTES:
            return self.set_status(
                f"⚠ too large for the dongle ({nb} B > {MAX_SCRIPT_BYTES}). "
                f"Stage fewer/shorter workflows.", ERR)
        self.busy = True
        self.btn_flash.config(state=tk.DISABLED, fg=MUT)
        self.set_status(f"Flashing {n} workflow(s)…", ACC)
        threading.Thread(target=self._flash_worker,
                         args=(self.device["port"], script), daemon=True).start()

    def _flash_worker(self, port, script):
        t = None
        try:
            t = link.open_serial(port, timeout=1.0)
            al = link.AutomatonLink(t)
            res = al.upload(script,
                            progress=lambda i, tot: self.q.put(
                                ("prog", (i, tot))))
            self.q.put(("done", f"Flashed {res['workflows']} workflow(s) "
                                f"({res['bytes']} B) to the dongle. It reloaded "
                                f"and is ready — trigger with its BOOT button."))
        except link.SerialError as e:
            self.q.put(("err", str(e)))
        except Exception as e:
            self.q.put(("err", f"unexpected: {e}"))
        finally:
            if t is not None:
                t.close()
        self.busy = False
        self.q.put(("rescan", None))

    # ---- event pump -------------------------------------------------------
    def _pump(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "device":
                    self._apply_device(payload)
                elif kind == "ports":
                    self._apply_ports(payload)
                elif kind == "prog":
                    i, tot = payload
                    self.set_status(f"Flashing… line {i}/{tot}", ACC)
                elif kind == "err":
                    self.set_status("⚠ " + str(payload), ERR)
                elif kind == "done":
                    self.set_status("✓ " + str(payload), OK)
                elif kind == "rescan":
                    self.after(500, self.rescan)
        except queue.Empty:
            pass
        self.after(120, self._pump)

    # ---- helpers ----------------------------------------------------------
    def set_dev(self, text, color):
        self.dev_dot.config(text=text, fg=color)
        self.update_idletasks()

    def set_status(self, msg, color=DIM):
        self.status.config(text=msg, fg=color)
        self.update_idletasks()

    def close(self):
        self.destroy()
        sys.exit(0)


if __name__ == "__main__":
    App().mainloop()
