#!/usr/bin/env python3
"""
workflow_model.py — the shared "language" of an Automaton workflow.

This is the ONE place that defines what a keyboard workflow is. Both sides of
the app import it:

  * web.py   (the Hero Dashboard step-builder) builds workflows and saves them.
  * main.py  (the touchscreen flasher) reads them and writes them to the dongle.
  * flasher.py serialises the selected workflows into the JSON blob that our
               CircuitPython runtime (runtime/code.py) reads back on the device.

It is a faithful mirror of the firmware's own model in
`esp32s3_automaton/src/mac_keys.h`: the same step opcodes (KEY / TAPS / TYPE /
LINE / HOLD / DELAY / STATUS), the same modifier set (Cmd/Ctrl/Alt/Shift, plus
the VoiceOver "VO" = Ctrl+Alt shortcut), and the same named keys. Keeping the
vocabularies identical means a workflow authored here plays back the same way
whether it ends up on the ESP32-S3 clone or a re-flashed Twocanoes ItsyBitsy.

Pure standard library — safe to import on the bench, in the dashboard process,
and in a plain pytest run on a dev box.
"""

from __future__ import annotations

import json
import re
import time

SCHEMA_VERSION = 1

# --------------------------------------------------------------------------- #
#  Modifiers.  Names the tech types/selects  ->  canonical token.
#  "vo" is the VoiceOver modifier (Ctrl+Option); it expands to ctrl+alt so the
#  runtime never needs a special case.
# --------------------------------------------------------------------------- #
MODIFIERS = ("cmd", "ctrl", "alt", "shift")

MOD_ALIASES = {
    "cmd": "cmd", "command": "cmd", "meta": "cmd", "gui": "cmd", "win": "cmd", "⌘": "cmd",
    "ctrl": "ctrl", "control": "ctrl", "⌃": "ctrl",
    "alt": "alt", "opt": "alt", "option": "alt", "⌥": "alt",
    "shift": "shift", "shft": "shift", "⇧": "shift",
    "vo": "vo", "voiceover": "vo",
}

# --------------------------------------------------------------------------- #
#  Named (non-printable) keys.  Printable keys (letters, digits, most symbols)
#  are stored as their own single character, exactly like the firmware treats
#  'r', '5', '/'.
# --------------------------------------------------------------------------- #
NAMED_KEYS = {
    "enter", "return", "esc", "escape", "tab", "space", "bksp", "backspace",
    "delete", "del", "home", "end", "pageup", "pagedown", "up", "down",
    "left", "right",
    "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11", "f12",
}
KEY_ALIASES = {
    "return": "enter", "escape": "esc", "backspace": "bksp",
    "del": "delete", "pgup": "pageup", "pgdn": "pagedown",
}

# Step opcodes.  Mirror StepType in mac_keys.h.
OPS = ("status", "key", "tap", "taps", "type", "line", "hold", "delay")

# Sensible default timings (ms), mirroring config.h.  Overridable per blob.
DEFAULT_SETTINGS = {
    "arm_countdown_ms": 3000,   # safety countdown before keys fire
    "key_down_ms": 40,          # how long each key is held
    "step_settle_ms": 140,      # pause after a KEY/TAPS step
    "tap_gap_ms": 90,           # gap between repeated taps
    "autorun": False,           # fire without a button press (DANGEROUS — off)
}

MAX_WORKFLOWS = 24
MAX_STEPS = 200
MAX_TEXT = 480          # a typed string / command line
MAX_NAME = 40


class WorkflowError(ValueError):
    """Raised when a workflow or step is malformed. Message is human-readable
    and safe to show a technician on the bench or the dashboard."""


# --------------------------------------------------------------------------- #
#  Normalisation helpers
# --------------------------------------------------------------------------- #
def norm_mods(mods):
    """Return a de-duplicated, canonical, ordered modifier list.

    Accepts a list of names or a '+'-joined string ("cmd+shift"). Expands the
    VoiceOver 'vo' token to ctrl+alt.
    """
    if mods is None:
        return []
    if isinstance(mods, str):
        parts = re.split(r"[+\s,]+", mods.strip())
    else:
        parts = list(mods)
    out = []
    for p in parts:
        if not str(p).strip():
            continue
        token = MOD_ALIASES.get(str(p).strip().lower())
        if token is None:
            raise WorkflowError(f"unknown modifier: {p!r}")
        if token == "vo":
            for m in ("ctrl", "alt"):
                if m not in out:
                    out.append(m)
        elif token not in out:
            out.append(token)
    # canonical order
    return [m for m in MODIFIERS if m in out]


def norm_key(key):
    """Return a canonical key token: a named key from NAMED_KEYS, or a single
    printable character."""
    if key is None or key == "":
        raise WorkflowError("a key is required")
    k = str(key)
    low = k.strip().lower()
    low = KEY_ALIASES.get(low, low)
    if low in NAMED_KEYS:
        return low
    # printable single character (store letters lower-case; the runtime adds
    # Shift itself if the workflow asked for it)
    if len(k) == 1 and k.isprintable() and not k.isspace():
        return k.lower() if k.isalpha() else k
    if low == "space":
        return "space"
    raise WorkflowError(
        f"unknown key: {key!r} (use a single character or a named key like "
        f"'enter', 'tab', 'f5', 'up')")


# --------------------------------------------------------------------------- #
#  Step construction / validation
# --------------------------------------------------------------------------- #
def make_step(op, *, mods=None, key=None, count=1, ms=0, gap=0, text=""):
    """Build one validated step dict. Raises WorkflowError on bad input."""
    op = str(op).strip().lower()
    if op not in OPS:
        raise WorkflowError(f"unknown step type: {op!r}")

    if op == "status":
        text = str(text)[:MAX_TEXT]
        if not text.strip():
            raise WorkflowError("a status step needs some text")
        return {"op": "status", "text": text}

    if op in ("type", "line"):
        text = str(text)[:MAX_TEXT]
        if text == "":
            raise WorkflowError(f"a {op} step needs text to type")
        return {"op": op, "text": text}

    if op == "delay":
        ms = _pos_int(ms, "delay ms", lo=1, hi=600000)
        return {"op": "delay", "ms": ms}

    if op == "hold":
        return {
            "op": "hold",
            "mods": norm_mods(mods),
            "key": norm_key(key),
            "ms": _pos_int(ms, "hold ms", lo=1, hi=600000),
        }

    if op == "tap":  # a bare key, no modifiers (S_TAP)
        return {"op": "key", "mods": [], "key": norm_key(key)}

    if op == "key":
        return {"op": "key", "mods": norm_mods(mods), "key": norm_key(key)}

    if op == "taps":
        step = {
            "op": "taps",
            "mods": norm_mods(mods),
            "key": norm_key(key),
            "count": _pos_int(count, "tap count", lo=1, hi=64),
        }
        gap = _pos_int(gap, "tap gap", lo=0, hi=10000, allow_zero=True)
        if gap:
            step["gap"] = gap
        return step

    raise WorkflowError(f"unhandled step type: {op!r}")  # pragma: no cover


def _pos_int(v, label, lo=0, hi=10 ** 9, allow_zero=False):
    try:
        n = int(v)
    except (TypeError, ValueError):
        raise WorkflowError(f"{label} must be a whole number, got {v!r}")
    if n == 0 and allow_zero:
        return 0
    if n < lo or n > hi:
        raise WorkflowError(f"{label} must be between {lo} and {hi}, got {n}")
    return n


def validate_step(step):
    """Re-validate a step dict (e.g. loaded from disk). Returns a clean copy."""
    if not isinstance(step, dict) or "op" not in step:
        raise WorkflowError("a step must be an object with an 'op'")
    op = step["op"]
    if op == "status":
        return make_step("status", text=step.get("text", ""))
    if op in ("type", "line"):
        return make_step(op, text=step.get("text", ""))
    if op == "delay":
        return make_step("delay", ms=step.get("ms", 0))
    if op == "hold":
        return make_step("hold", mods=step.get("mods"), key=step.get("key"),
                         ms=step.get("ms", 0))
    if op == "key":
        return make_step("key", mods=step.get("mods"), key=step.get("key"))
    if op == "taps":
        return make_step("taps", mods=step.get("mods"), key=step.get("key"),
                         count=step.get("count", 1), gap=step.get("gap", 0))
    raise WorkflowError(f"unknown step type: {op!r}")


def validate_workflow(wf):
    """Return a clean, validated copy of a workflow dict."""
    if not isinstance(wf, dict):
        raise WorkflowError("a workflow must be an object")
    name = str(wf.get("name", "")).strip()[:MAX_NAME]
    if not name:
        raise WorkflowError("every workflow needs a name")
    note = str(wf.get("note", "")).strip()[:MAX_TEXT]
    steps = wf.get("steps") or []
    if not isinstance(steps, list) or not steps:
        raise WorkflowError(f"workflow {name!r} has no steps")
    if len(steps) > MAX_STEPS:
        raise WorkflowError(f"workflow {name!r} has too many steps "
                            f"(max {MAX_STEPS})")
    clean_steps = [validate_step(s) for s in steps]
    out = {"name": name, "note": note, "steps": clean_steps}
    btn = wf.get("button", None)
    if btn is not None and btn != "":
        out["button"] = _pos_int(btn, "button", lo=0, hi=4)
    return out


# --------------------------------------------------------------------------- #
#  The flash blob (what gets written to the device as /workflows.json)
# --------------------------------------------------------------------------- #
def build_blob(workflows, settings=None, device="BenchTool Automaton"):
    """Assemble + validate the JSON blob the runtime reads on the device."""
    wfs = [validate_workflow(w) for w in workflows]
    if not wfs:
        raise WorkflowError("select at least one workflow to flash")
    if len(wfs) > MAX_WORKFLOWS:
        raise WorkflowError(f"too many workflows (max {MAX_WORKFLOWS})")
    names = [w["name"].lower() for w in wfs]
    dupes = {n for n in names if names.count(n) > 1}
    if dupes:
        raise WorkflowError("workflow names must be unique; duplicated: "
                            + ", ".join(sorted(dupes)))
    s = dict(DEFAULT_SETTINGS)
    if settings:
        for k in DEFAULT_SETTINGS:
            if k in settings and settings[k] is not None:
                if k == "autorun":
                    s[k] = bool(settings[k])
                else:
                    s[k] = _pos_int(settings[k], k, lo=0, hi=600000,
                                    allow_zero=True)
    return {
        "schema": SCHEMA_VERSION,
        "device": str(device)[:40],
        "generated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "settings": s,
        "workflows": wfs,
    }


def dumps_blob(blob):
    """Compact but human-diffable JSON for the device."""
    return json.dumps(blob, ensure_ascii=True, indent=1, sort_keys=False)


def loads_blob(text):
    """Parse + validate a blob read back from disk / the device."""
    try:
        data = json.loads(text)
    except json.JSONDecodeError as e:
        raise WorkflowError(f"not valid JSON: {e}")
    return build_blob(data.get("workflows", []), data.get("settings"),
                      data.get("device", "BenchTool Automaton"))


# --------------------------------------------------------------------------- #
#  Human-readable rendering (used by both the dashboard and the touchscreen)
# --------------------------------------------------------------------------- #
_KEY_GLYPH = {
    "enter": "Enter", "esc": "Esc", "tab": "Tab", "space": "Space",
    "bksp": "Backspace", "delete": "Delete", "up": "Up", "down": "Down",
    "left": "Left", "right": "Right", "home": "Home", "end": "End",
    "pageup": "PageUp", "pagedown": "PageDown",
}
_MOD_GLYPH = {"cmd": "Cmd", "ctrl": "Ctrl", "alt": "Opt", "shift": "Shift"}


def key_label(step):
    """A '⌘F5' / 'Cmd-Tab ×3' style label for a step's chord."""
    mods = step.get("mods", [])
    # collapse ctrl+alt back to 'VO' for readability
    if set(mods) == {"ctrl", "alt"}:
        prefix = "VO"
        rest = []
    else:
        prefix = ""
        rest = [_MOD_GLYPH[m] for m in mods]
    key = step.get("key", "")
    if key in _KEY_GLYPH:
        kl = _KEY_GLYPH[key]
    elif len(key) == 1:
        kl = key.upper()
    elif re.fullmatch(r"f\d{1,2}", key):        # f5 -> F5
        kl = key.upper()
    else:
        kl = key
    chord = "-".join([p for p in ([prefix] if prefix else []) + rest + [kl] if p])
    return chord


def describe_step(step):
    """One-line human description of a step, for lists and confirmations."""
    op = step["op"]
    if op == "status":
        return f"● status: “{step['text']}”"
    if op == "delay":
        return f"⏱ wait {step['ms']} ms"
    if op == "type":
        return f"⌨ type “{_clip(step['text'])}”"
    if op == "line":
        return f"↵ run “{_clip(step['text'])}”"
    if op == "hold":
        return f"⭳ hold {key_label(step)} for {step['ms']} ms"
    if op == "taps":
        g = f" (gap {step['gap']}ms)" if step.get("gap") else ""
        return f"⇥ {key_label(step)} ×{step['count']}{g}"
    if op == "key":
        return f"⌘ {key_label(step)}"
    return op


def _clip(s, n=40):
    s = str(s)
    return s if len(s) <= n else s[: n - 1] + "…"
