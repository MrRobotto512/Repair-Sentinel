#!/usr/bin/env python3
"""
store.py — the little shared library both faces of the app read and write.

The Hero Dashboard (web.py, inside the dashboard process) and the touchscreen
flasher (main.py, its own process) are two programs that never talk directly.
They rendezvous through two JSON files in the app's own data/ folder:

  library.json    — every saved workflow the tech has built, plus settings
  selection.json  — which workflow names are queued to flash next, + a marker
                    the touchscreen shows ("3 workflows staged from the dash")

Writes are atomic (temp + os.replace) so a dashboard save can never leave the
touchscreen reading half a file. Pure standard library; unit-tested.
"""

from __future__ import annotations

import json
import os
import time

import af_model as wm

LIBRARY_FILE = "library.json"
SELECTION_FILE = "selection.json"
DRAFT_FILE = "draft.json"

EMPTY_DRAFT = {"name": "", "note": "", "button": "", "steps": []}


def _data_dir(app_dir):
    d = os.path.join(app_dir, "data")
    os.makedirs(d, exist_ok=True)
    return d


def _load(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return default


def _atomic_write(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


# --------------------------------------------------------------------------- #
#  Library
# --------------------------------------------------------------------------- #
def load_library(app_dir):
    """Return {'workflows': [...], 'settings': {...}} — always well-formed."""
    raw = _load(os.path.join(_data_dir(app_dir), LIBRARY_FILE),
                {"workflows": [], "settings": {}})
    if not isinstance(raw, dict):
        raw = {"workflows": [], "settings": {}}
    raw.setdefault("workflows", [])
    raw.setdefault("settings", {})
    return raw


def save_library(app_dir, library):
    _atomic_write(os.path.join(_data_dir(app_dir), LIBRARY_FILE), library)


def library_exists(app_dir):
    return os.path.isfile(os.path.join(_data_dir(app_dir), LIBRARY_FILE))


def seed_if_new(app_dir, workflows):
    """First-run only: if no library file exists yet, create it from these
    starter workflows. Returns True if it seeded. Never clobbers an existing
    library (so a tech who deleted them all stays in control)."""
    if library_exists(app_dir):
        return False
    lib = {"workflows": [], "settings": {}}
    for w in workflows:
        try:
            lib["workflows"].append(wm.validate_workflow(w))
        except wm.WorkflowError:
            continue
    lib["workflows"].sort(key=lambda w: str(w.get("name", "")).lower())
    save_library(app_dir, lib)
    return True


def import_workflows(app_dir, workflows):
    """Add/replace a batch of workflows (used by the dashboard 'load examples').
    Returns the count imported."""
    n = 0
    for w in workflows:
        try:
            upsert_workflow(app_dir, w)
            n += 1
        except wm.WorkflowError:
            continue
    return n


def upsert_workflow(app_dir, wf):
    """Add or replace a workflow by (case-insensitive) name. Validates first.
    Returns the saved, cleaned workflow."""
    clean = wm.validate_workflow(wf)
    lib = load_library(app_dir)
    key = clean["name"].lower()
    lib["workflows"] = [w for w in lib["workflows"]
                        if str(w.get("name", "")).lower() != key]
    lib["workflows"].append(clean)
    lib["workflows"].sort(key=lambda w: str(w.get("name", "")).lower())
    save_library(app_dir, lib)
    return clean


def delete_workflow(app_dir, name):
    lib = load_library(app_dir)
    key = str(name).lower()
    before = len(lib["workflows"])
    lib["workflows"] = [w for w in lib["workflows"]
                        if str(w.get("name", "")).lower() != key]
    save_library(app_dir, lib)
    # drop it from any pending selection too
    sel = load_selection(app_dir)
    if name in sel["names"]:
        sel["names"] = [n for n in sel["names"] if n.lower() != key]
        save_selection(app_dir, sel["names"])
    return before != len(lib["workflows"])


def get_workflow(app_dir, name):
    key = str(name).lower()
    for w in load_library(app_dir)["workflows"]:
        if str(w.get("name", "")).lower() == key:
            return w
    return None


# --------------------------------------------------------------------------- #
#  Flash selection (what the touchscreen will write next)
# --------------------------------------------------------------------------- #
def load_selection(app_dir):
    raw = _load(os.path.join(_data_dir(app_dir), SELECTION_FILE),
                {"names": [], "updated": ""})
    if not isinstance(raw, dict):
        raw = {"names": [], "updated": ""}
    raw.setdefault("names", [])
    raw.setdefault("updated", "")
    return raw


def save_selection(app_dir, names):
    _atomic_write(os.path.join(_data_dir(app_dir), SELECTION_FILE),
                  {"names": list(names),
                   "updated": time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                            time.gmtime())})


def selected_workflows(app_dir):
    """Resolve the queued names to full workflow dicts, in selection order.
    Silently drops names that no longer exist in the library."""
    lib = {str(w.get("name", "")).lower(): w
           for w in load_library(app_dir)["workflows"]}
    out = []
    for n in load_selection(app_dir)["names"]:
        w = lib.get(str(n).lower())
        if w:
            out.append(w)
    return out


# --------------------------------------------------------------------------- #
#  Draft (the workflow being built step-by-step on the dashboard)
# --------------------------------------------------------------------------- #
def load_draft(app_dir):
    raw = _load(os.path.join(_data_dir(app_dir), DRAFT_FILE), None)
    if not isinstance(raw, dict):
        return dict(EMPTY_DRAFT, steps=[])
    d = dict(EMPTY_DRAFT)
    d.update({k: raw.get(k, d[k]) for k in EMPTY_DRAFT})
    if not isinstance(d["steps"], list):
        d["steps"] = []
    return d


def save_draft(app_dir, draft):
    _atomic_write(os.path.join(_data_dir(app_dir), DRAFT_FILE), draft)


def clear_draft(app_dir):
    save_draft(app_dir, dict(EMPTY_DRAFT, steps=[]))


def draft_add_step(app_dir, step):
    """Append a validated step to the draft. `step` is already a model step."""
    d = load_draft(app_dir)
    d["steps"].append(step)
    save_draft(app_dir, d)
    return d


def draft_remove_step(app_dir, index):
    d = load_draft(app_dir)
    if 0 <= index < len(d["steps"]):
        d["steps"].pop(index)
    save_draft(app_dir, d)
    return d


def draft_move_step(app_dir, index, delta):
    d = load_draft(app_dir)
    j = index + delta
    if 0 <= index < len(d["steps"]) and 0 <= j < len(d["steps"]):
        d["steps"][index], d["steps"][j] = d["steps"][j], d["steps"][index]
    save_draft(app_dir, d)
    return d
