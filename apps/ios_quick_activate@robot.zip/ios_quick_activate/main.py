#!/usr/bin/env python3
"""
iOS Quick Activate — bench screen.

Plug in a hub full of freshly-restored iPhones, tap RUN, and every one of
them activates with Apple and gets a cloud configuration that skips the
Setup Assistant panes — so they land on the home screen ready for testing
instead of a tech thumbing through fifteen screens per device.

The settings (language, region, which screens to skip, Wi-Fi profile) live
on the Hero Dashboard page for this app, where a full checkbox grid is
practical. This screen is the one-tap trigger and the live result board.

Contract: standalone Tk process, fullscreen, EXIT top-right, exit 0.
"""

import os
import sys
import threading

os.environ.setdefault("DISPLAY", ":0")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import tkinter as tk
from tkinter import font

import qa_core

try:
    import ui_theme as _ui                    # provided by the bench
except ImportError:
    _ui = None                                # dev machine

BG = "#0d0d0f"
CARD = "#1b1b21"
EDGE = "#2a2a32"
INK = "#e8e8f0"
DIM = "#aab0bf"
MUTED = "#7a7a8c"
ACCENT = "#5baee8"
OK_FILL, OK_INK = "#0d3318", "#69f0ae"
WARN_FILL, WARN_INK = "#332200", "#ffc94d"
ERR_FILL, ERR_INK = "#3a0d0d", "#ff6e6e"


class QuickActivate(tk.Tk):
    TITLE = "🍏 iOS QUICK ACTIVATE"

    def __init__(self):
        super().__init__()
        if _ui is not None and hasattr(_ui, "apply_root"):
            _ui.apply_root(self)
        else:
            self.geometry("800x480")
            self.title(self.TITLE + " (dev)")
        self.configure(bg=BG)

        w = self.winfo_screenwidth() or 800
        self.narrow = w < 640
        self.wrap = max(260, w - 40)
        sz = (15, 12, 13) if self.narrow else (18, 14, 15)
        self.f_h = font.Font(family="DejaVu Sans", size=sz[0], weight="bold")
        self.f_b = font.Font(family="DejaVu Sans", size=sz[1])
        self.f_btn = font.Font(family="DejaVu Sans", size=sz[2], weight="bold")

        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", padx=10, pady=6)
        tk.Label(bar, text=self.TITLE, font=self.f_h, bg=BG,
                 fg=ACCENT).pack(side="left", padx=4)
        tk.Button(bar, text="X", font=self.f_h, bg="#3a1a1a", fg=ERR_INK,
                  activebackground="#5a2a2a", activeforeground=ERR_INK,
                  bd=3, relief="raised", width=3,
                  command=self.close).pack(side="right", padx=4)

        self.status = tk.Label(self, text="", font=self.f_b, bg=BG, fg=DIM,
                               anchor="w", wraplength=self.wrap,
                               justify="left")
        self.status.pack(fill="x", padx=12)

        self.list_frame = tk.Frame(self, bg=BG)
        self.list_frame.pack(fill="both", expand=True, padx=10, pady=6)

        actions = tk.Frame(self, bg=BG)
        actions.pack(fill="x", padx=10, pady=(0, 10))
        for col, (label, cmd, fill, ink) in enumerate((
                ("↻  RESCAN", self.rescan, "#22222a", INK),
                ("🩺  DIAG", self.diagnostics, "#0d1f33", "#7bd5ff"),
                ("▶  RUN ALL", self.run_all, OK_FILL, OK_INK))):
            b = tk.Button(actions, text=label, font=self.f_btn, bg=fill,
                          fg=ink, activebackground="#252533",
                          activeforeground=ink, bd=0, relief="flat",
                          height=2, command=cmd)
            b.grid(row=0, column=col, sticky="nsew", padx=5)
            actions.columnconfigure(col, weight=1)

        self.batch = None
        self.rows = {}
        self.after(200, self.rescan)

    # ---- helpers --------------------------------------------------------
    def say(self, msg, color=DIM):
        self.status.config(text=msg, fg=color)
        self.update_idletasks()

    def clear(self):
        for w in self.list_frame.winfo_children():
            w.destroy()
        self.rows = {}

    def note(self, text, color=MUTED):
        tk.Label(self.list_frame, text=text, font=self.f_b, bg=BG, fg=color,
                 anchor="w", wraplength=self.wrap,
                 justify="left").pack(fill="x", padx=4, pady=6)

    # ---- device list ----------------------------------------------------
    def rescan(self):
        try:
            self._rescan()
        except Exception as e:                     # never spam the log with
            import traceback                       # a Tk callback traceback
            self.clear()
            self.say("scan failed", ERR_INK)
            self.note("The scan itself failed:\n\n%s\n\nTap 🩺 DIAG for "
                      "what each probe reports." % traceback.format_exc(limit=4),
                      ERR_INK)

    def _rescan(self):
        if self.batch is not None and self.batch.snapshot()["running"]:
            return
        self.clear()
        # Devices are found with the libimobiledevice CLI, so a missing
        # pymobiledevice3 only blocks the ACTIONS — still show the list.
        self.deps_ok, deps_err = qa_core.deps_ok()
        if not self.deps_ok:
            self.note("⚠ pymobiledevice3 isn't installed, so RUN ALL can't "
                      "activate anything yet (%s).\n\nHero Dashboard ▸ My "
                      "Apps ▸ ⬇ install deps fixes it. Devices below are "
                      "still detected." % deps_err[:90], WARN_INK)
        devices, err = qa_core.list_devices()
        if err:
            self.say(err, ERR_INK)
            self.note(err, ERR_INK)
            return
        self.devices = devices
        if not devices:
            self.say("no iOS devices connected")
            self.note("Plug in the freshly-restored devices (a powered USB "
                      "hub is fine) and tap RESCAN.\n\nThey should be "
                      "sitting at the Hello / Setup screen — a device that "
                      "has already finished setup will refuse the setup "
                      "configuration.")
            return
        s = qa_core.load_settings()
        self.say("%d device%s · will %s" % (
            len(devices), "" if len(devices) == 1 else "s",
            " + ".join(x for x in (
                "activate" if s.get("activate") else "",
                "skip %d setup screens" % len(s.get("skip") or [])
                if s.get("setup") else "",
                "install Wi-Fi profile"
                if s.get("wifi") and qa_core.have_wifi_profile() else "")
                if x) or "do nothing — check the dashboard settings"))
        for d in devices:
            self._row(d)

    def _row(self, d):
        f = tk.Frame(self.list_frame, bg=CARD, highlightthickness=1,
                     highlightbackground=EDGE)
        f.pack(fill="x", pady=3)
        left = tk.Frame(f, bg=CARD)
        left.pack(side="left", fill="both", expand=True, padx=10, pady=7)
        title = d["model"] or "iOS device"
        if d["ios"]:
            title += "  ·  iOS %s" % d["ios"]
        tk.Label(left, text=title, font=self.f_b, bg=CARD, fg=INK,
                 anchor="w").pack(fill="x")
        sub = d["serial"] or d["udid"][:16]
        if d.get("setup_done") is True:
            sub += "  ·  past setup"
        if d["error"]:
            sub += "  ·  " + d["error"]
        tk.Label(left, text=sub, font=self.f_b, bg=CARD, fg=MUTED,
                 anchor="w", wraplength=self.wrap - 180,
                 justify="left").pack(fill="x")
        state = tk.Label(f, text=self._badge(d["state"]), font=self.f_b,
                         bg=CARD, fg=self._badge_ink(d["state"]))
        state.pack(side="right", padx=10)
        self.rows[d["udid"]] = state

    def _badge(self, state):
        s = (state or "").lower()
        if "unactivated" in s or "unknown" in s:
            return "needs activation"
        if "activated" in s:
            return "✓ activated"
        return state or "?"

    def _badge_ink(self, state):
        s = (state or "").lower()
        if "unactivated" in s:
            return WARN_INK
        if "activated" in s:
            return OK_INK
        return MUTED

    # ---- the run --------------------------------------------------------
    def run_all(self):
        try:
            self._run_all()
        except Exception as e:                     # noqa: BLE001
            self.say("couldn't start: %s" % str(e)[:90], ERR_INK)

    def _run_all(self):
        if self.batch is not None and self.batch.snapshot()["running"]:
            return
        devices = getattr(self, "devices", [])
        if not devices:
            self.say("nothing connected — tap RESCAN", WARN_INK)
            return
        if not getattr(self, "deps_ok", True):
            self.say("pymobiledevice3 missing — install deps from the "
                     "dashboard first", ERR_INK)
            return
        s = qa_core.load_settings()
        if not (s.get("activate") or s.get("setup") or s.get("wifi")):
            self.say("no operations selected — set them on the dashboard "
                     "page for this app", WARN_INK)
            return
        self.batch = qa_core.BatchRun([d["udid"] for d in devices], s)
        self.say("running on %d device%s…"
                 % (len(devices), "" if len(devices) == 1 else "s"), ACCENT)
        self._tick()

    def _tick(self):
        if self.batch is None:
            return
        snap = self.batch.snapshot()
        for udid, r in snap["results"].items():
            lbl = self.rows.get(udid)
            if lbl is None:
                continue
            text = {"queued": "waiting", "running": r["msg"] or "working…",
                    "done": "✓ " + (r["msg"] or "done"),
                    "failed": "✗ " + (r["msg"] or "failed")}[r["state"]]
            ink = {"queued": MUTED, "running": ACCENT,
                   "done": OK_INK, "failed": ERR_INK}[r["state"]]
            try:
                lbl.config(text=text[:60], fg=ink)
            except tk.TclError:
                pass
        if snap["running"]:
            self.after(500, self._tick)
        else:
            self.say("finished — %d ok, %d failed"
                     % (snap["ok"], snap["failed"]),
                     OK_INK if not snap["failed"] else WARN_INK)

    def diagnostics(self):
        """What each probe actually reports. The first build of this app
        showed 'no devices connected' when the real problem was an API
        change inside pymobiledevice3 — this screen exists so that can
        never be a guessing game again."""
        self.clear()
        self.say("diagnostics")
        try:
            rows = qa_core.diagnostics()
        except Exception as e:                     # noqa: BLE001
            rows = [("diagnostics failed", str(e))]
        for check, result in rows:
            line = tk.Frame(self.list_frame, bg=BG)
            line.pack(fill="x", pady=1)
            tk.Label(line, text=check, font=self.f_b, bg=BG, fg=MUTED,
                     width=22, anchor="w").pack(side="left")
            bad = any(w in str(result) for w in
                      ("NOT INSTALLED", "FAILED", "rc=", "no devices"))
            tk.Label(line, text=str(result), font=self.f_b, bg=BG,
                     fg=(ERR_INK if bad else INK), anchor="w",
                     wraplength=self.wrap - 200,
                     justify="left").pack(side="left", fill="x", expand=True)

    def close(self):
        self.destroy()
        sys.exit(0)


if __name__ == "__main__":
    app = QuickActivate()
    try:
        import benchversion as _bv
        _bv.stamp(app, __file__)
    except Exception:
        pass
    app.mainloop()
