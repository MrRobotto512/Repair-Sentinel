# iOS Quick Activate

Batch-activate freshly restored iPhones/iPads and skip the Setup Assistant,
so they land on the home screen ready for testing.

## What it does

Three independent operations, run over USB against every connected device:

1. **Activate** — the real handshake with Apple (albert.apple.com) that gets
   a device past "Activation Required".
2. **Skip setup screens** — writes a *cloud configuration* containing
   Apple's `SkipSetup` keys, the same mechanism Apple Configurator's
   "Prepare" uses. This is the part that actually gets you to the home
   screen; activation alone does not dismiss the setup panes.
3. **Install a Wi-Fi profile** (optional) — a `.mobileconfig` with a Wi-Fi
   payload, so the device joins the shop network by itself. Without a
   network there is no activation.

## Requirements

- `pymobiledevice3` (declared in `app.json`; the bench offers to install it
  on first launch)
- `usbmuxd` running (standard on BenchTool)
- The bench needs internet — activation talks to Apple

## How to use it

Settings live on the dashboard page (**🍏 iOS Activate** in the sidebar, or
`http://<bench-ip>:8377/x/ios_quick_activate/`): pick language and region,
tick the setup screens to skip, choose which operations to run, save.

Then either tap **▶ Execute on all devices** on that page, or hit **RUN ALL**
on the bench screen. Both drive the same code and show per-device results.

## Limits worth knowing

- **A device at the Hello screen is the reliable case.** The skip-setup
  configuration is aimed at a device that has not finished setup yet — that
  is when it takes effect on the panes you are trying to avoid. Devices that
  are already past setup often still accept the write (it is then stored and
  applies at the next erase), and the app always tries; when one is refused,
  the result says so in plain words rather than relaying MCInstall's error.
  Rows show **past setup** so you can tell which is which at a glance.
- **Activation Lock cannot be bypassed.** If a device is still signed into
  an iCloud account, Apple asks for that Apple ID and the run reports the
  device as failed. This app does not attempt to work around that.
- `AllowPairing` is set in the cloud configuration on purpose, so the
  device stays reachable for diagnostics after setup is skipped.
- Unknown skip keys are ignored by the device, so ticking everything is
  safe across iOS versions.
- **Language and Country/Region are not skip keys.** Apple's skip list has
  no entry for them; Setup Assistant omits those two panes when the values
  are already set. So the app sets them rather than skipping them, by two
  routes at once — written over lockdown before the configuration is pushed
  (`Language`, `Locale`), and carried inside the configuration itself in
  both the CamelCase and the enrollment-profile spellings. The per-device
  result line says which route the device accepted, e.g.
  `en/US preset (language+locale)` versus `en/US in config only`.

## Troubleshooting

Tap **🩺 DIAG** on the bench screen. It reports each probe separately —
whether `idevice_id` and `ideviceinfo` exist, what `idevice_id -l` returns,
whether pymobiledevice3 is installed, **whether its API is async or sync**,
and what this app ends up seeing. That is usually enough to tell a cable or
usbmuxd problem from a library problem without reading a log.

Known history: pymobiledevice3 became async-only (`create_using_usbmux`,
`get_value` and friends are `async def`). An early build of this app called
them synchronously and every scan died with *"'coroutine' object is not
iterable"*, showing no devices. Device detection now runs on the
libimobiledevice CLI instead, and every call into pymobiledevice3 goes
through an await-or-passthrough bridge, so both API shapes work.
