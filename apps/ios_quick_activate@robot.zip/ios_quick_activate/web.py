#!/usr/bin/env python3
"""
iOS Quick Activate — Hero Dashboard page.

The bench screen is the one-tap trigger; this is where the settings live,
because a 40-checkbox skip list and a table of ten devices want a monitor
and a mouse, not a 4-inch panel.

Layout mirrors the workflow: language/region, the Setup Assistant screens
to skip, which operations to run, then Execute. The device table polls
itself so you can watch a hub full of phones go green.

Served at http://<bench-ip>:8377/x/<this-app-folder>/ — see the BenchTool
App SDK, "Dashboard pages".
"""

import html
import json

import qa_core

_batch = {"run": None}          # the one in-flight batch, if any

LANGS = [("en", "English"), ("es", "Español"), ("fr", "Français"),
         ("de", "Deutsch"), ("it", "Italiano"), ("pt", "Português"),
         ("nl", "Nederlands"), ("pl", "Polski"), ("hu", "Magyar"),
         ("ja", "日本語"), ("ko", "한국어"), ("zh", "中文")]
REGIONS = [("US", "United States"), ("CA", "Canada"), ("GB", "United Kingdom"),
           ("IE", "Ireland"), ("AU", "Australia"), ("NZ", "New Zealand"),
           ("DE", "Germany"), ("FR", "France"), ("ES", "Spain"),
           ("IT", "Italy"), ("NL", "Netherlands"), ("HU", "Hungary"),
           ("MX", "Mexico"), ("JP", "Japan")]


def _e(s):
    return html.escape(str(s), quote=True)


# ── the page ────────────────────────────────────────────────────────────────

def _select(name, options, chosen):
    opts = "".join(
        "<option value='%s'%s>%s</option>"
        % (_e(v), " selected" if v == chosen else "", _e(label))
        for v, label in options)
    return ("<select name='%s' style='background:#101014;color:#e8e8f0;"
            "border:1px solid #2a2a32;border-radius:8px;padding:8px;"
            "font-size:15px;min-width:170px'>%s</select>" % (name, opts))


def _checkbox(key, label, on):
    return ("<label style='display:block;padding:3px 0;font-size:14px;"
            "color:#e8e8f0'><input type='checkbox' name='skip' value='%s'%s "
            "style='margin-right:8px'>%s</label>"
            % (_e(key), " checked" if on else "", _e(label)))


def _page(ctx, msg="", err=""):
    s = qa_core.load_settings()
    chosen = set(s.get("skip") or [])
    cols = [[], [], []]
    for i, (key, label) in enumerate(qa_core.SKIP_KEYS):
        cols[i % 3].append(_checkbox(key, label, key in chosen))
    grid = "".join(
        "<div style='flex:1;min-width:210px'>%s</div>" % "".join(c)
        for c in cols)

    banner = ""
    if msg:
        banner += ("<div style='background:#0d3318;color:#69f0ae;padding:10px;"
                   "border-radius:8px;margin:8px 0'>%s</div>" % _e(msg))
    if err:
        banner += ("<div style='background:#3a0d0d;color:#ff6e6e;padding:10px;"
                   "border-radius:8px;margin:8px 0'>%s</div>" % _e(err))

    ok, deperr = qa_core.deps_ok()
    if not ok:
        banner += ("<div style='background:#3a0d0d;color:#ff6e6e;padding:10px;"
                   "border-radius:8px;margin:8px 0'>pymobiledevice3 isn't "
                   "installed yet (%s). Use ⬇ install deps on this app's card "
                   "on the My Apps page.</div>" % _e(deperr))

    wifi_state = ("a Wi-Fi profile is stored" if qa_core.have_wifi_profile()
                  else "no Wi-Fi profile uploaded yet")

    card = ("background:#1b1b21;border:1px solid #2a2a32;border-radius:10px;"
            "padding:14px;margin:12px 0")
    btn = ("background:#0d3318;color:#69f0ae;border:1px solid #2a2a32;"
           "border-radius:8px;padding:10px 18px;font-size:15px;cursor:pointer")

    return """
<h2>🍏 iOS Quick Activate</h2>
<div style='color:#aab0bf'>Freshly-restored devices activate with Apple and
skip the Setup Assistant, so they arrive at the home screen ready to test.
Leave them plugged in at the Hello screen.</div>
%(banner)s

<div id='devices' style='%(card)s'>
  <b>Connected devices</b>
  <div id='devbody' style='color:#7a7a8c;margin-top:8px'>loading…</div>
  <div style='margin-top:10px'>
    <button onclick='runAll()' style='%(btn)s'>▶ Execute on all devices</button>
    <span id='runstate' style='color:#aab0bf;margin-left:10px'></span>
  </div>
</div>

<form method='post' action='%(save)s'>
  <div style='%(card)s'>
    <b>Language &amp; region</b>
    <div style='color:#7a7a8c;font-size:13px;margin:4px 0 0'>
      These two panes have no skip key — Apple skips them by having the
      value already set. So this is applied twice: written to the device
      over lockdown before the config is pushed, and carried inside the
      config itself. The per-device result says which one the device took.
    </div>
    <div style='margin-top:8px'>%(lang)s &nbsp; %(region)s</div>
  </div>

  <div style='%(card)s'>
    <b>Skip these setup screens</b>
    <div style='color:#7a7a8c;font-size:13px;margin:4px 0 10px'>
      Apple's own Setup Assistant skip keys. Anything a given iOS build
      doesn't recognise is simply ignored, so it is safe to tick everything.
      <a href='#' onclick='allOn(true);return false' style='color:#7bd5ff'>Select all</a> ·
      <a href='#' onclick='allOn(false);return false' style='color:#7bd5ff'>none</a>
    </div>
    <div style='display:flex;gap:18px;flex-wrap:wrap'>%(grid)s</div>
  </div>

  <div style='%(card)s'>
    <b>Operations</b>
    <div style='margin-top:8px'>
      <label style='display:block;padding:3px 0'>
        <input type='checkbox' name='activate'%(act)s style='margin-right:8px'>
        Activate with Apple</label>
      <label style='display:block;padding:3px 0'>
        <input type='checkbox' name='setup'%(setup)s style='margin-right:8px'>
        Skip setup screens</label>
      <label style='display:block;padding:3px 0'>
        <input type='checkbox' name='wifi'%(wifi)s style='margin-right:8px'>
        Install Wi-Fi profile <span style='color:#7a7a8c'>(%(wifistate)s)</span></label>
    </div>
    <button type='submit' style='%(btn)s;margin-top:10px'>Save settings</button>
  </div>
</form>

<div style='%(card)s'>
  <b>Wi-Fi profile</b>
  <div style='color:#7a7a8c;font-size:13px;margin:4px 0 8px'>
    A .mobileconfig with a Wi-Fi payload, installed before setup so the
    device joins the shop network on its own — without a network there is
    no activation. Make one in Apple Configurator or any profile editor.
  </div>
  <form method='post' action='%(upload)s' enctype='multipart/form-data'>
    <input type='file' name='profile' accept='.mobileconfig' required>
    <button type='submit' style='%(btn)s'>Upload</button>
  </form>
</div>

<script>
function allOn(v){document.querySelectorAll("input[name=skip]").forEach(function(c){c.checked=v;});}
function runAll(){
  document.getElementById('runstate').textContent='starting…';
  fetch('%(run)s',{method:'POST'}).then(r=>r.json()).then(j=>{
     document.getElementById('runstate').textContent=j.error||('running on '+j.started+' device(s)');
     poll();});
}
function badge(t,c){return "<span style='color:"+c+"'>"+t+"</span>";}
function poll(){
  fetch('%(status)s').then(r=>r.json()).then(function(j){
    var rows=(j.devices||[]).map(function(d){
      var r=(j.run&&j.run.results&&j.run.results[d.udid])||null;
      var st=d.state||'?', c='#aab0bf', txt=st;
      if(r){ if(r.state=='done'){c='#69f0ae';txt='✓ '+r.msg;}
             else if(r.state=='failed'){c='#ff6e6e';txt='✗ '+r.msg;}
             else if(r.state=='running'){c='#7bd5ff';txt=r.msg||'working…';}
             else {c='#7a7a8c';txt='waiting';} }
      else if(/unactivated/i.test(st)){c='#ffc94d';txt='needs activation';}
      else if(/activated/i.test(st)){c='#69f0ae';txt='✓ activated';}
      return "<tr><td style='padding:6px 10px 6px 0'>"+d.model+"</td>"+
             "<td style='padding:6px 10px 6px 0;color:#7a7a8c'>"+(d.ios||'')+"</td>"+
             "<td style='padding:6px 10px 6px 0;color:#7a7a8c'>"+(d.serial||d.udid.slice(0,14))+"</td>"+
             "<td style='padding:6px 0'>"+badge(txt,c)+"</td></tr>";}).join('');
    document.getElementById('devbody').innerHTML = rows
      ? "<table style='width:100%%;border-collapse:collapse'>"+rows+"</table>"
      : (j.error || "Nothing connected. Plug the devices in at the Hello screen.");
    if(j.run){ document.getElementById('runstate').textContent =
        j.run.running ? ('running… '+j.run.ok+'/'+j.run.total+' done')
                      : ('finished — '+j.run.ok+' ok, '+j.run.failed+' failed'); }
    if(!j.run || j.run.running) setTimeout(poll, 1500);
  }).catch(function(){setTimeout(poll,4000);});
}
poll();
</script>
""" % {"banner": banner, "card": card, "btn": btn, "grid": grid,
       "lang": _select("language", LANGS, s.get("language")),
       "region": _select("region", REGIONS, s.get("region")),
       "act": " checked" if s.get("activate") else "",
       "setup": " checked" if s.get("setup") else "",
       "wifi": " checked" if s.get("wifi") else "",
       "wifistate": wifi_state,
       "save": ctx.url("save"), "upload": ctx.url("upload"),
       "run": ctx.url("run"), "status": ctx.url("status")}


# ── the one entry point the dashboard calls ─────────────────────────────────

def handle(ctx):
    path = ctx.path
    req = ctx.request

    if path == "status":
        devices, err = qa_core.list_devices()
        run = _batch["run"].snapshot() if _batch["run"] else None
        return {"devices": devices, "error": err, "run": run}

    if path == "run" and req.method == "POST":
        if _batch["run"] and _batch["run"].snapshot()["running"]:
            return {"error": "a run is already in progress", "started": 0}
        devices, err = qa_core.list_devices()
        if err:
            return {"error": err, "started": 0}
        if not devices:
            return {"error": "no devices connected", "started": 0}
        s = qa_core.load_settings()
        if not (s.get("activate") or s.get("setup") or s.get("wifi")):
            return {"error": "no operations selected — save settings first",
                    "started": 0}
        _batch["run"] = qa_core.BatchRun([d["udid"] for d in devices], s)
        return {"started": len(devices), "error": ""}

    if path == "save" and req.method == "POST":
        s = qa_core.load_settings()
        s["language"] = req.form.get("language") or "en"
        s["region"] = req.form.get("region") or "US"
        s["skip"] = [k for k in req.form.getlist("skip")
                     if k in qa_core.SKIP_KEY_NAMES]
        s["activate"] = bool(req.form.get("activate"))
        s["setup"] = bool(req.form.get("setup"))
        s["wifi"] = bool(req.form.get("wifi"))
        ok, err = qa_core.save_settings(s)
        return _page(ctx, msg="Settings saved." if ok else "",
                     err="" if ok else "Couldn't save: %s" % err)

    if path == "upload" and req.method == "POST":
        f = req.files.get("profile")
        if f is None or not f.filename:
            return _page(ctx, err="pick a .mobileconfig file first")
        ok, msg = qa_core.save_wifi_profile(f.read(2 * 1024 * 1024))
        return _page(ctx, msg=msg if ok else "", err="" if ok else msg)

    return _page(ctx)
