import json
import html
import urllib.request
import urllib.error
from datetime import datetime, timezone

API="http://127.0.0.1:8379"

TASKS=[
    ("system_info","System Info"),
    ("device_manager","Device Manager"),
    ("crash_review","Crash Review"),
    ("sfc","SFC"),
    ("dism_scan","DISM Scan"),
    ("dism_restore","DISM Repair"),
    ("chkdsk_scan","CHKDSK"),
    ("defender_quick","Defender Quick"),
    ("defender_full","Defender Full"),
    ("adware_review","Adware Review"),
    ("adware_cleanup","Adware Cleanup"),
    ("browser_search_reset","Browser Search Reset"),
    ("browser_notifications_reset","Browser Notifications Reset"),
]

def esc(v):
    return html.escape(str(v or ""))

def api(path,payload=None,timeout=5):
    data=None if payload is None else json.dumps(payload).encode("utf-8")
    req=urllib.request.Request(
        API+path,data=data,
        headers={"Content-Type":"application/json"},
        method="POST" if payload is not None else "GET")
    try:
        with urllib.request.urlopen(req,timeout=timeout) as r:
            raw=r.read().decode("utf-8","replace")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        raw=e.read().decode("utf-8","replace")
        try:
            obj=json.loads(raw)
            raise RuntimeError(obj.get("detail") or obj.get("error") or raw)
        except json.JSONDecodeError:
            raise RuntimeError("Fleet HTTP %s: %s"%(e.code,raw or e.reason))
    except Exception as e:
        raise RuntimeError(str(e))

def age_seconds(stamp):
    if not stamp:return 999999
    try:
        dt=datetime.fromisoformat(str(stamp).replace("Z","+00:00"))
        if dt.tzinfo is None:dt=dt.replace(tzinfo=timezone.utc)
        return max(0,(datetime.now(timezone.utc)-dt).total_seconds())
    except Exception:return 999999

def device_name(d):
    return d.get("pc_name") or d.get("hostname") or "Unnamed PC"

def task_label(task):
    labels=dict(TASKS)
    return labels.get(str(task),str(task or "").replace("_"," ").title())

def friendly_status(status):
    s=str(status or "").replace("_"," ").strip().title()
    return s or "Unknown"

def friendly_time(stamp):
    if not stamp:return ""
    try:
        dt=datetime.fromisoformat(str(stamp).replace("Z","+00:00"))
        if dt.tzinfo is None:dt=dt.replace(tzinfo=timezone.utc)
        return dt.astimezone().strftime("%b %d, %Y · %I:%M %p")
    except Exception:
        return str(stamp)

def progress_parts(job):
    p=job.get("progress")
    if isinstance(p,dict):
        overall=p.get("job_percent")
        taskpct=p.get("task_percent")
        msg=p.get("message") or ""
        task=p.get("task") or ""
        try: overall=int(float(overall))
        except Exception: overall=None
        try: taskpct=int(float(taskpct))
        except Exception: taskpct=None
        return overall,taskpct,task,msg
    try:
        return int(float(p)),None,"",""
    except Exception:
        return None,None,"",""

def page(ctx,message="",error=""):
    try:
        state=api("/api/admin/state")
        service_error=""
    except Exception as e:
        state={"devices":[],"jobs":[],"enrollment":{}}
        service_error=str(e)

    devices=sorted(state.get("devices") or [],key=lambda d:(
        str(d.get("customer_name") or "").lower(),
        str(device_name(d)).lower()))
    jobs=list(reversed((state.get("jobs") or [])[-20:]))
    enrollment=state.get("enrollment") or {}
    action=ctx.url("action")

    css="""
    <style>
    .fleet-wrap{max-width:1200px}
    .fleet-head{display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-bottom:16px}
    .fleet-title{margin:0}.muted{opacity:.7}.ok{color:#33d17a}.bad{color:#ff6b6b}.warn{color:#f6c85f}
    .fleet-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(290px,1fr));gap:12px}
    .fleet-card{border:1px solid rgba(255,255,255,.12);border-radius:12px;padding:14px;background:rgba(255,255,255,.035)}
    .fleet-card h3{margin:0 0 5px}.fleet-meta{font-size:.92em;opacity:.72;margin-bottom:10px}
    .fleet-actions{display:flex;gap:7px;flex-wrap:wrap}.fleet-actions form{margin:0}
    .fleet-btn{display:inline-block;padding:8px 11px;border-radius:8px;border:1px solid rgba(255,255,255,.16);
      background:rgba(255,255,255,.08);color:inherit;cursor:pointer;text-decoration:none}
    .fleet-btn.primary{background:#245d42}.fleet-btn.danger{background:#632f36}.fleet-btn.warn{background:#68551d}
    .fleet-section{margin-top:22px}.fleet-section h2{margin-bottom:10px}
    .fleet-batch{border:1px solid rgba(255,255,255,.12);border-radius:12px;padding:14px}
    .fleet-checks{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:7px;margin:10px 0}
    .fleet-check{padding:8px;border-radius:8px;background:rgba(255,255,255,.045)}
    .fleet-job{display:grid;grid-template-columns:minmax(220px,1.5fr) minmax(220px,1fr) minmax(150px,.7fr);gap:14px;
      border-bottom:1px solid rgba(255,255,255,.08);padding:14px 2px;align-items:center}
    .fleet-job-title{font-weight:700;font-size:1.05em}.fleet-job-tasks{opacity:.68;margin-top:3px;line-height:1.45}
    .fleet-status{font-weight:700}.fleet-progress{height:8px;background:rgba(255,255,255,.08);border-radius:999px;overflow:hidden;margin-top:7px}
    .fleet-progress>span{display:block;height:100%;background:#33d17a}.fleet-progress-note{font-size:.88em;opacity:.68;margin-top:5px}
    .fleet-msg{padding:10px 12px;border-radius:9px;margin:10px 0;background:rgba(51,209,122,.12)}
    .fleet-err{padding:10px 12px;border-radius:9px;margin:10px 0;background:rgba(255,107,107,.12)}
    @media(max-width:650px){.fleet-job{grid-template-columns:1fr}.fleet-checks{grid-template-columns:1fr 1fr}}
    </style>
    """

    alerts=""
    if message:alerts+=f'<div class="fleet-msg">{esc(message)}</div>'
    if error:alerts+=f'<div class="fleet-err">{esc(error)}</div>'
    if service_error:alerts+=f'<div class="fleet-err"><b>Fleet service unavailable:</b> {esc(service_error)}</div>'

    cards=[]
    for d in devices:
        online=age_seconds(d.get("last_seen"))<90 and not d.get("revoked")
        status='<span class="ok">● ONLINE</span>' if online else '<span class="muted">● OFFLINE</span>'
        did=esc(d.get("id"))
        customer=esc(d.get("customer_name") or "No customer name")
        windows=esc(d.get("windows") or "Windows version unknown")
        model=esc(d.get("model") or "")
        buttons=f"""
        <div class="fleet-actions">
          <form method="post" action="{esc(action)}"><input type="hidden" name="op" value="diag"><input type="hidden" name="device_id" value="{did}">
            <button class="fleet-btn primary" {'disabled' if not online else ''}>Sentinel Snapshot</button></form>
          <form method="post" action="{esc(action)}"><input type="hidden" name="op" value="security"><input type="hidden" name="device_id" value="{did}">
            <button class="fleet-btn warn" {'disabled' if not online else ''}>Security Scan</button></form>
          <form method="post" action="{esc(action)}" onsubmit="return confirm('Remove this computer from Fleet?')">
            <input type="hidden" name="op" value="remove"><input type="hidden" name="device_id" value="{did}">
            <button class="fleet-btn danger">Remove</button></form>
        </div>"""
        cards.append(f"""<div class="fleet-card"><h3>{esc(device_name(d))}</h3>
          <div>{status}</div><div class="fleet-meta">{customer}<br>{windows}{'<br>'+model if model else ''}</div>{buttons}</div>""")

    if not cards:cards=["<div class='fleet-card muted'>No enrolled computers yet.</div>"]

    dev_checks="".join(
        f'<label class="fleet-check"><input type="checkbox" name="device_ids" value="{esc(d.get("id"))}"> '
        f'{esc(device_name(d))}</label>' for d in devices)
    task_checks="".join(
        f'<label class="fleet-check"><input type="checkbox" name="tasks" value="{esc(k)}"> {esc(label)}</label>'
        for k,label in TASKS)

    enroll_html=""
    if enrollment.get("code"):
        enroll_html=f"<b>Enrollment code:</b> <code>{esc(enrollment.get('code'))}</code>"
    else:
        enroll_html="No active enrollment code."

    job_rows=[]
    byid={str(d.get("id")):d for d in devices}
    for j in jobs:
        d=byid.get(str(j.get("device_id")),{})
        overall,taskpct,current_task,msg=progress_parts(j)
        status=friendly_status(j.get("status","unknown"))
        status_class="ok" if str(j.get("status","")).startswith("completed") else ("warn" if str(j.get("status",""))=="running" else "bad")
        task_text=", ".join(task_label(t) for t in (j.get("tasks") or []))
        progress_html=""
        if overall is not None:
            progress_html=f'<div class="fleet-progress"><span style="width:{max(0,min(100,overall))}%"></span></div>'
            note=[]
            if current_task: note.append(task_label(current_task))
            if taskpct is not None: note.append(str(taskpct)+"% current")
            if msg: note.append(str(msg))
            if note: progress_html+=f'<div class="fleet-progress-note">{esc(" · ".join(note))}</div>'
        job_rows.append(f"""<div class="fleet-job">
          <div><div class="fleet-job-title">{esc(device_name(d) if d else j.get("device_id"))}</div>
               <div class="fleet-job-tasks">{esc(task_text)}</div></div>
          <div><div class="fleet-status {status_class}">{esc(status)}{(" · "+str(overall)+"%") if overall is not None else ""}</div>{progress_html}</div>
          <div class="muted">{esc(friendly_time(j.get("updated_at") or j.get("created_at") or ""))}</div>
        </div>""")
    if not job_rows:
        job_rows=["<div class='muted'>No recent jobs.</div>"]


    return css+f"""
    <div class="fleet-wrap">
      <div class="fleet-head"><div><h1 class="fleet-title">🖥 Fleet Maintenance</h1>
        <div class="muted">Manage enrolled Windows PCs from the Hero Dashboard.</div></div>
        <a class="fleet-btn" href="{esc(ctx.url(''))}">Refresh</a>
      </div>
      {alerts}
      <div class="fleet-section"><h2>Computers <span class="muted">({len(devices)})</span></h2>
        <div class="fleet-grid">{''.join(cards)}</div></div>

      <div class="fleet-section"><h2>Batch Repairs</h2>
        <form class="fleet-batch" method="post" action="{esc(action)}">
          <input type="hidden" name="op" value="batch">
          <b>1. Computers</b><div class="fleet-checks">{dev_checks or '<span class="muted">No computers enrolled.</span>'}</div>
          <b>2. Repairs</b><div class="fleet-checks">{task_checks}</div>
          <button class="fleet-btn primary">Run Selected</button>
        </form>
      </div>

      <div class="fleet-section"><h2>Enrollment</h2><div class="fleet-card">{enroll_html}
        <form method="post" action="{esc(action)}" style="margin-top:10px"><input type="hidden" name="op" value="enroll">
          <button class="fleet-btn">Generate New Code</button></form></div></div>

      <div class="fleet-section"><h2>Recent Jobs</h2><div class="fleet-card">{''.join(job_rows)}</div></div>
    </div>
    """

def handle(ctx):
    # All human Fleet dashboard pages are PIN protected by app.json.
    # The Windows agents continue talking directly to the dedicated Fleet service on 8379.
    if ctx.path not in ("","/","action","action/"):
        return ("Not found",404)

    if ctx.request.method!="POST":
        return page(ctx)

    op=(ctx.request.form.get("op") or "").strip()
    try:
        if op=="diag":
            did=ctx.request.form.get("device_id","")
            api("/api/admin/jobs",{"device_ids":[did],"tasks":["system_info","device_manager","crash_review"]})
            return page(ctx,"Sentinel diagnostic snapshot queued.")
        if op=="security":
            did=ctx.request.form.get("device_id","")
            api("/api/admin/jobs",{"device_ids":[did],"tasks":["defender_full","adware_review"]})
            return page(ctx,"Security scan queued.")
        if op=="remove":
            did=ctx.request.form.get("device_id","")
            api("/api/admin/remove-device",{"device_id":did})
            return page(ctx,"Computer removed from Fleet.")
        if op=="enroll":
            r=api("/api/admin/enrollment-code",{})
            return page(ctx,"Enrollment code generated: "+str(r.get("code","")))
        if op=="batch":
            ids=ctx.request.form.getlist("device_ids")
            tasks=ctx.request.form.getlist("tasks")
            if not ids:return page(ctx,error="Select at least one computer.")
            if not tasks:return page(ctx,error="Select at least one repair.")
            r=api("/api/admin/jobs",{"device_ids":ids,"tasks":tasks})
            return page(ctx,"Queued %d repair(s) on %d computer(s)."%(len(tasks),len(r.get("jobs") or [])))
        return page(ctx,error="Unknown Fleet action.")
    except Exception as e:
        return page(ctx,error=str(e))
