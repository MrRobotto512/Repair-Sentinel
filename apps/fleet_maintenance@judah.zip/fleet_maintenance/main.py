import tkinter as tk, tkinter.font as tkfont
import os, sys, json, subprocess, threading, queue, time, socket, shutil, traceback
from urllib.request import Request, urlopen
from urllib.error import HTTPError

try:
    import ui_theme
except ImportError: ui_theme=None

BG='#0d0d0f'; CARD='#1b1b21'; CODE='#101014'; CHIP='#22222a'; BORDER='#2a2a32'
FG='#e8e8f0'; DIM='#aab0bf'; MUTED='#7a7a8c'; OK='#00c853'; WARN='#ffc107'; BAD='#ff5252'
BASE=os.path.dirname(os.path.abspath(__file__)); PORT=8379; API=f'http://127.0.0.1:{PORT}'; APP_VERSION='2.3.1'
VIRTUAL=('zram','loop','ram','md','dm-','sr','nbd','fd')
TASKS=[('sfc','SFC'),('dism_scan','DISM Scan'),('dism_restore','DISM Repair'),('chkdsk_scan','CHKDSK'),('defender_quick','Defender Quick'),('defender_full','Defender Full'),('system_info','System Info'),('device_manager','Device Manager'),('crash_review','Crash Review'),('adware_review','Adware Review'),('adware_cleanup','Adware Cleanup'),('browser_search_reset','Browser Search Reset'),('browser_notifications_reset','Browser Notifications Reset')]

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        try:
            if ui_theme: ui_theme.apply_root(self)
            else: self.geometry('800x480')
        except Exception: self.geometry('800x480')
        self.configure(bg=BG); self.title('Fleet Maintenance'); self.protocol('WM_DELETE_WINDOW',self.close)
        self.titlef=tkfont.Font(family='DejaVu Sans',size=25,weight='bold'); self.btnf=tkfont.Font(family='DejaVu Sans',size=17,weight='bold')
        self.bodyf=tkfont.Font(family='DejaVu Sans',size=13); self.smallf=tkfont.Font(family='DejaVu Sans',size=11)
        self.status=tk.StringVar(value='Starting Fleet service...'); self.state={'devices':[],'jobs':[],'enrollment':{}}
        self.q=queue.Queue(); self.usb=[]; self.usb_target=None; self.history=[]; self.pages={}; self.current='home'
        tk.Label(self,text='Fleet Maintenance',font=self.titlef,bg=BG,fg=FG,anchor='w').place(x=12,y=5,width=680,height=34)
        tk.Label(self,text='Windows tune-ups + Sentinel AI',font=self.bodyf,bg=BG,fg=DIM,anchor='w').place(x=14,y=39,width=660,height=21)
        tk.Button(self,text='X',font=self.titlef,bg=CARD,fg=FG,command=self.close).place(x=724,y=4,width=70,height=54)
        self.host=tk.Frame(self,bg=BG); self.host.place(x=8,y=66,width=784,height=354)
        tk.Label(self,textvariable=self.status,font=self.smallf,bg=BG,fg=DIM,anchor='w').place(x=10,y=424,width=780,height=22)
        tk.Button(self,text='BACK',font=self.bodyf,bg=CARD,fg=FG,command=self.back).place(x=10,y=450,width=110,height=28)
        tk.Button(self,text='HOME',font=self.bodyf,bg=CARD,fg=FG,command=lambda:self.show('home')).place(x=680,y=450,width=110,height=28)
        self.ensure_persistent_server(); self.after(500,self.poll_state); self.after(250,self.poll_queue); self.show('home')
    def set_status(self,s): self.status.set(s); print('[fleet-ui]',s)
    def ensure_persistent_server(self):
        # Do not blindly trust an already-running Fleet server. Older app updates could
        # leave the persistent systemd process running old code, causing the new UI to
        # call routes/tasks the server did not know about.
        server_ok=False
        try:
            raw=urlopen(API+'/api/health',timeout=.6).read().decode('utf-8','replace')
            health=json.loads(raw)
            server_ok=(str(health.get('version',''))==APP_VERSION)
            if server_ok:
                self.set_status('Fleet service online v'+APP_VERSION)
                return
            self.set_status('Updating Fleet background service...')
        except Exception:
            pass
        # Prefer a user systemd service so the fleet remains online even when this UI is closed or the Pi reboots.
        try:
            svcdir=os.path.expanduser('~/.config/systemd/user'); os.makedirs(svcdir,exist_ok=True)
            py='/usr/bin/python3'; svc=os.path.join(svcdir,'benchhero-fleet.service'); log=os.path.expanduser('~/.local/share/benchhero_fleet/server.log')
            os.makedirs(os.path.dirname(log),exist_ok=True)
            body=('[Unit]\nDescription=Bench Hero Fleet Service\nAfter=network-online.target\n\n[Service]\nType=simple\nExecStart={py} {server}\nRestart=always\nRestartSec=3\nStandardOutput=append:{log}\nStandardError=append:{log}\n\n[Install]\nWantedBy=default.target\n').format(py=py,server=os.path.join(BASE,'fleet_server.py'),log=log)
            open(svc,'w',encoding='utf-8').write(body)
            subprocess.run(['systemctl','--user','daemon-reload'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=8)
            subprocess.run(['systemctl','--user','enable','benchhero-fleet.service'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10)
            subprocess.run(['systemctl','--user','restart','benchhero-fleet.service'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10)
            self.after(500,self._verify_server)
            return
        except Exception as e: print('systemd user service unavailable:',e)
        # Fallback still detaches the server from the UI process.
        try:
            log=open(os.path.expanduser('~/.local/share/benchhero_fleet/server.log'),'a')
            subprocess.Popen(['/usr/bin/python3',os.path.join(BASE,'fleet_server.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True,close_fds=True)
            self.after(500,self._verify_server)
        except Exception as e:self.set_status('Fleet service failed: '+str(e))
    def _verify_server(self,n=0):
        try:urlopen(API+'/api/health',timeout=.5).read();self.set_status('Fleet service online')
        except Exception as e:
            if n<15:self.after(400,lambda:self._verify_server(n+1))
            else:self.set_status('Fleet service unavailable: '+str(e))
    def api(self,path,payload=None,timeout=15):
        data=None if payload is None else json.dumps(payload).encode(); req=Request(API+path,data=data,headers={'Content-Type':'application/json'})
        try:
            with urlopen(req,timeout=timeout) as r:
                return json.loads(r.read().decode())
        except HTTPError as e:
            try:
                raw=e.read().decode('utf-8','replace')
                try:
                    obj=json.loads(raw)
                    detail=obj.get('detail') or obj.get('error') or raw
                except Exception:
                    detail=raw
            except Exception:
                detail=''
            raise RuntimeError(f'HTTP {e.code}: {detail or e.reason}')
    def poll_state(self):
        def w():
            try:self.q.put(('state',self.api('/api/admin/state')))
            except Exception as e:self.q.put(('error','Fleet service unavailable: '+str(e)))
        threading.Thread(target=w,daemon=True).start(); self.after(2500,self.poll_state)
    def poll_queue(self):
        try:
            while True:
                kind,val=self.q.get_nowait()
                if kind=='state':
                    old_state=self.state
                    self.state=val
                    p=self.pages.get(self.current)
                    if p and hasattr(p,'refresh'):
                        # Pages such as Devices now update incrementally. Avoid redrawing pages
                        # when an identical state response arrives.
                        if old_state != val or self.current=='devices':
                            p.refresh()
                elif kind=='usb': self.usb=val; p=self.pages.get('usb'); p and p.refresh()
                elif kind=='analysis': self.show('analysis',analysis=val)
                elif kind=='refresh': self.after(100,self.poll_state)
                elif kind=='show_jobs': self.show('jobs')
                else:self.set_status(val)
        except queue.Empty:pass
        self.after(200,self.poll_queue)
    def show(self,name,**ctx):
        for w in self.host.winfo_children():w.destroy()
        makers={'home':Home,'devices':Devices,'batch':Batch,'jobs':Jobs,'job':JobDetail,'task_output':TaskOutput,'analysis':Analysis,'usb':USB}
        page=makers[name](self.host,self,ctx); page.pack(fill='both',expand=True);self.pages[name]=page;self.current=name;self.history.append(name)
    def back(self):
        if len(self.history)>1:self.history.pop();p=self.history.pop();self.show(p)
        else:self.show('home')
    def local_ip(self):
        try:
            s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.connect(('8.8.8.8',80));ip=s.getsockname()[0];s.close();return ip
        except Exception:return ''
    def local_hostname(self):
        try:return (socket.gethostname() or 'benchhero').strip().split('.')[0]
        except Exception:return 'benchhero'
    def advertised_servers(self):
        urls=[f'http://{self.local_hostname()}.local:{PORT}'];ip=self.local_ip()
        if ip:urls.append(f'http://{ip}:{PORT}')
        return list(dict.fromkeys(urls))
    def close(self): self.destroy();sys.exit(0)

class Page(tk.Frame):
    def __init__(self,p,a,c=None):super().__init__(p,bg=BG);self.app=a;self.ctx=c or {}
    def button(self,p,text,cmd,bg=CARD,fg=FG):return tk.Button(p,text=text,font=self.app.btnf,bg=bg,fg=fg,activebackground=CHIP,command=cmd,wraplength=230)

class Home(Page):
    def __init__(self,p,a,c):
        super().__init__(p,a,c);g=tk.Frame(self,bg=BG);g.pack(expand=True)
        for i,(t,cmd) in enumerate([('COMPUTERS',lambda:a.show('devices')),('BATCH TUNE-UP',lambda:a.show('batch')),('JOB HISTORY',lambda:a.show('jobs')),('CREATE AGENT USB',lambda:a.show('usb'))]):
            self.button(g,t,cmd).grid(row=i//2,column=i%2,padx=8,pady=7,sticky='nsew',ipadx=24,ipady=22)
        g.columnconfigure(0,weight=1);g.columnconfigure(1,weight=1)
        online=sum(1 for d in a.state.get('devices',[]) if age(d.get('last_seen'))<90 and not d.get('revoked'))
        tk.Label(self,text=f'{online} online | {len(a.state.get("devices",[]))} enrolled',font=a.bodyf,bg=BG,fg=OK).pack(pady=2)

class Devices(Page):
    def __init__(self,p,a,c):
        super().__init__(p,a,c)
        self.canvas,self.inner=scroll_area(self)
        self.cards={}
        self.empty=None
        self.refresh()

    def _device_key(self,d):
        return str(d.get('id',''))

    def _stable_order(self,devices):
        # Do not sort by last_seen. During a repair that field changes constantly,
        # which used to reorder/rebuild the entire list every poll and caused visible flicker.
        return sorted(devices,key=lambda d:(
            str(d.get('customer_name') or '').lower(),
            str(d.get('pc_name') or d.get('hostname') or '').lower(),
            str(d.get('id') or '')
        ))

    def _make_card(self,d):
        did=self._device_key(d)
        card=tk.Frame(self.inner,bg=CARD,highlightbackground=BORDER,highlightthickness=1)
        left=tk.Frame(card,bg=CARD);left.pack(side='left',fill='both',expand=True,padx=8,pady=7)

        name_var=tk.StringVar()
        sub_var=tk.StringVar()
        online_var=tk.StringVar()
        tk.Label(left,textvariable=name_var,font=self.app.btnf,bg=CARD,fg=FG,anchor='w').pack(fill='x')
        tk.Label(left,textvariable=sub_var,font=self.app.smallf,bg=CARD,fg=DIM,anchor='w').pack(fill='x')

        r=tk.Frame(card,bg=CARD);r.pack(side='right',padx=7,pady=5)
        online_label=tk.Label(r,textvariable=online_var,font=self.app.smallf,bg=CARD,fg=MUTED)
        online_label.pack()
        tk.Button(r,text='SENTINEL DIAG',font=self.app.smallf,bg=CHIP,fg=FG,
                  command=lambda did=did:self.diag_by_id(did)).pack(ipadx=4,ipady=2,pady=(5,2))
        tk.Button(r,text='SECURITY',font=self.app.smallf,bg=CHIP,fg=WARN,
                  command=lambda did=did:self.security_by_id(did)).pack(ipadx=4,ipady=2,pady=(0,2))
        tk.Button(r,text='REMOVE',font=self.app.smallf,bg=CHIP,fg=BAD,
                  command=lambda did=did:self.remove_by_id(did)).pack(ipadx=4,ipady=2)

        self.cards[did]={
            'frame':card,'name':name_var,'sub':sub_var,'online':online_var,
            'online_label':online_label,'snapshot':None
        }
        return self.cards[did]

    def _find(self,did):
        for d in self.app.state.get('devices',[]):
            if str(d.get('id',''))==str(did): return d
        return None

    def refresh(self):
        ds=self._stable_order(self.app.state.get('devices',[]))
        wanted={self._device_key(d) for d in ds}

        # Remove only computers that truly disappeared. Never destroy every card on each poll.
        for did in list(self.cards):
            if did not in wanted:
                try:self.cards[did]['frame'].destroy()
                except Exception:pass
                del self.cards[did]

        if not ds:
            if self.empty is None or not self.empty.winfo_exists():
                self.empty=tk.Label(self.inner,text='NO ENROLLED COMPUTERS\nCreate an Agent USB and enroll a PC.',
                                    font=self.app.bodyf,bg=BG,fg=DIM)
                self.empty.pack(pady=80)
            return
        elif self.empty is not None:
            try:self.empty.destroy()
            except Exception:pass
            self.empty=None

        # Create missing cards once, then only update their StringVars/status color.
        for d in ds:
            did=self._device_key(d)
            c=self.cards.get(did) or self._make_card(d)
            online=age(d.get('last_seen'))<90 and not d.get('revoked')
            snapshot=(
                d.get('pc_name'),d.get('hostname'),d.get('customer_name'),d.get('windows'),
                bool(online),bool(d.get('revoked'))
            )
            if snapshot!=c.get('snapshot'):
                c['name'].set(d.get('pc_name') or d.get('hostname') or 'Unnamed PC')
                c['sub'].set(f"{d.get('customer_name','')} | {d.get('windows','')}")
                c['online'].set('ONLINE' if online else 'OFFLINE')
                c['online_label'].configure(fg=OK if online else MUTED)
                c['snapshot']=snapshot

        # Pack in a stable order. pack_forget/repack is only necessary when membership/order changes.
        current=[w for w in self.inner.pack_slaves() if w is not self.empty]
        desired=[self.cards[self._device_key(d)]['frame'] for d in ds]
        if current!=desired:
            for frame in desired:
                frame.pack_forget()
                frame.pack(fill='x',padx=5,pady=4)

    def diag_by_id(self,did):
        d=self._find(did)
        if d:self.diag(d)

    def security_by_id(self,did):
        d=self._find(did)
        if d:self.security(d)

    def remove_by_id(self,did):
        d=self._find(did)
        if d:self.remove(d)

    def diag(self,d):
        if age(d.get('last_seen'))>=90:
            return self.app.set_status('That computer is offline. Start it and wait for it to check in.')
        def w():
            try:
                self.app.api('/api/admin/jobs',{'device_ids':[d['id']],'tasks':['system_info','device_manager','crash_review']})
                self.app.q.put(('msg','Sentinel diagnostic snapshot queued'))
                self.app.q.put(('refresh',None)); self.app.q.put(('show_jobs',None))
            except Exception as e:
                self.app.q.put(('error','Could not queue diagnostic snapshot: '+str(e)))
        threading.Thread(target=w,daemon=True).start()

    def security(self,d):
        if age(d.get('last_seen'))>=90:
            return self.app.set_status('That computer is offline. Start it and wait for it to check in.')
        def w():
            try:
                self.app.api('/api/admin/jobs',{'device_ids':[d['id']],'tasks':['defender_full','adware_review']})
                self.app.q.put(('msg','Security scan queued'))
                self.app.q.put(('refresh',None)); self.app.q.put(('show_jobs',None))
            except Exception as e:
                self.app.q.put(('error','Could not queue security scan: '+str(e)))
        threading.Thread(target=w,daemon=True).start()

    def remove(self,d):
        if not confirm(self.app,'REMOVE COMPUTER?',(d.get('pc_name') or d.get('hostname','PC'))+' will be removed from this Bench Hero.'):return
        def w():
            try:
                self.app.api('/api/admin/remove-device',{'device_id':d['id']})
                self.app.q.put(('msg','Computer removed'));self.app.q.put(('refresh',None))
            except Exception as e:self.app.q.put(('error','Remove failed: '+str(e)))
        threading.Thread(target=w,daemon=True).start()

class Batch(Page):
    def __init__(self,p,a,c):
        super().__init__(p,a,c)
        self.dv={};self.tv={};self.mode='devices';self.selected_text=tk.StringVar()
        self.render()

    def render(self):
        top=tk.Frame(self,bg=BG);top.pack(fill='x',pady=(0,3))
        tk.Button(top,text='1. COMPUTERS',font=self.app.bodyf,
                  bg=CHIP if self.mode=='devices' else CARD,fg=FG,
                  command=lambda:self.switch('devices')).pack(side='left',fill='x',expand=True,padx=3,ipady=5)
        tk.Button(top,text='2. REPAIRS',font=self.app.bodyf,
                  bg=CHIP if self.mode=='tasks' else CARD,fg=FG,
                  command=lambda:self.switch('tasks')).pack(side='left',fill='x',expand=True,padx=3,ipady=5)

        tools=tk.Frame(self,bg=BG);tools.pack(fill='x',pady=(1,3))
        tk.Button(tools,text='SELECT ALL',font=self.app.smallf,bg=CARD,fg=OK,
                  command=self.select_all).pack(side='left',padx=4,ipady=3)
        tk.Button(tools,text='CLEAR ALL',font=self.app.smallf,bg=CARD,fg=DIM,
                  command=self.clear_all).pack(side='left',padx=2,ipady=3)
        tk.Label(tools,textvariable=self.selected_text,font=self.app.smallf,bg=BG,fg=DIM).pack(side='right',padx=6)

        self.content=tk.Frame(self,bg=BG);self.content.pack(fill='both',expand=True)
        self.draw_content()

        foot=tk.Frame(self,bg=BG);foot.pack(fill='x',pady=2)
        self.button(foot,'RUN SELECTED',self.run,CHIP).pack(side='right',padx=6,ipadx=10,ipady=3)
        self.counts()

    def switch(self,m):
        self.mode=m;self.draw_content();self.counts()

    def _selected_style(self,button,var):
        if var.get():
            button.configure(bg=OK,fg='#000000',activebackground=OK,relief='sunken',text='✓  '+button._label)
        else:
            button.configure(bg=CARD,fg=FG,activebackground=CHIP,relief='raised',text='□  '+button._label)

    def _toggle(self,var,button):
        self._selected_style(button,var);self.counts()

    def draw_content(self):
        for w in self.content.winfo_children():w.destroy()
        canvas,inner=scroll_area(self.content,height=215)
        # Make mouse wheel useful on a desktop while touch users can drag/use scrollbar.
        canvas.bind_all('<MouseWheel>',lambda e:canvas.yview_scroll(int(-1*(e.delta/120)),'units'))

        if self.mode=='devices':
            for d in self.app.state.get('devices',[]):
                v=self.dv.setdefault(d['id'],tk.BooleanVar(value=False))
                name=d.get('pc_name') or d.get('hostname','PC')
                sub=(d.get('customer_name') or '')+'  '+(d.get('windows') or '')
                row=tk.Frame(inner,bg=BG);row.pack(fill='x',padx=5,pady=3)
                btn=tk.Checkbutton(row,variable=v,indicatoron=0,font=self.app.bodyf,
                                   selectcolor=OK,command=lambda v=v:None,anchor='w',
                                   padx=8,pady=7)
                btn._label=name
                btn.configure(command=lambda v=v,b=btn:self._toggle(v,b))
                btn.pack(fill='x',expand=True)
                self._selected_style(btn,v)
                if sub.strip():
                    tk.Label(row,text=sub,font=self.app.smallf,bg=BG,fg=DIM,anchor='w').pack(fill='x',padx=8)
        else:
            for k,label in TASKS:
                v=self.tv.setdefault(k,tk.BooleanVar(value=k in ('system_info','device_manager','crash_review')))
                btn=tk.Checkbutton(inner,variable=v,indicatoron=0,font=self.app.bodyf,
                                   selectcolor=OK,anchor='w',padx=10,pady=7)
                btn._label=label
                btn.configure(command=lambda v=v,b=btn:self._toggle(v,b))
                btn.pack(fill='x',padx=5,pady=3)
                self._selected_style(btn,v)

    def select_all(self):
        target=self.dv if self.mode=='devices' else self.tv
        if self.mode=='devices':
            for d in self.app.state.get('devices',[]):
                self.dv.setdefault(d['id'],tk.BooleanVar(value=False)).set(True)
        else:
            for k,_ in TASKS:self.tv.setdefault(k,tk.BooleanVar(value=False)).set(True)
        self.draw_content();self.counts()

    def clear_all(self):
        target=self.dv if self.mode=='devices' else self.tv
        for v in target.values():v.set(False)
        self.draw_content();self.counts()

    def counts(self):
        self.selected_text.set(f'{sum(v.get() for v in self.dv.values())} PCs | {sum(v.get() for v in self.tv.values())} repairs')

    def run(self):
        ids=[k for k,v in self.dv.items() if v.get()]
        tasks=[k for k,v in self.tv.items() if v.get()]
        if not ids or not tasks:
            return self.app.set_status('Select one or more computers and one or more repairs')
        self.app.set_status(f'Queueing {len(tasks)} repairs on {len(ids)} computer(s)...')
        def w():
            try:
                r=self.app.api('/api/admin/jobs',{'device_ids':ids,'tasks':tasks})
                made=r.get('jobs') or []
                if not made:
                    raise RuntimeError('Fleet server accepted the request but created no jobs. Refresh the computer list and try again.')
                self.app.q.put(('msg',f'Queued {len(tasks)} repairs on {len(made)} computer(s)'))
                self.app.q.put(('refresh',None))
                self.app.q.put(('show_jobs',None))
            except Exception as e:
                self.app.q.put(('error','Could not queue repairs: '+str(e)))
        threading.Thread(target=w,daemon=True).start()

class Jobs(Page):
    def __init__(self,p,a,c):super().__init__(p,a,c);self.canvas,self.inner=scroll_area(self);self.refresh()
    def refresh(self):
        for w in self.inner.winfo_children():w.destroy()
        jobs=list(reversed(self.app.state.get('jobs',[])));names={d['id']:d.get('pc_name') or d.get('hostname','PC') for d in self.app.state.get('devices',[])}
        if not jobs:return tk.Label(self.inner,text='NO MAINTENANCE JOBS YET',font=self.app.bodyf,bg=BG,fg=DIM).pack(pady=90)
        for j in jobs:
            prog=j.get('progress') or {};pct=int(prog.get('job_percent',100 if j.get('status','').startswith('completed') else 0) or 0)
            card=tk.Frame(self.inner,bg=CARD,highlightbackground=BORDER,highlightthickness=1);card.pack(fill='x',padx=5,pady=4)
            label=f"{names.get(j.get('device_id'),'PC')}\n{j.get('status','').upper()} | {pct}% | {len(j.get('tasks',[]))} repairs"
            tk.Button(card,text=label,font=self.app.bodyf,bg=CARD,fg=FG,anchor='w',justify='left',command=lambda j=j:self.app.show('job',job=j)).pack(side='left',fill='both',expand=True,ipady=5)
            bar=MiniBar(card,pct);bar.pack(side='right',padx=8,pady=10)

class JobDetail(Page):
    def __init__(self,p,a,c):
        super().__init__(p,a,c);self.job=c.get('job',{});prog=self.job.get('progress') or {}
        hdr=tk.Frame(self,bg=BG);hdr.pack(fill='x')
        tk.Label(hdr,text='Job Results',font=a.titlef,bg=BG,fg=FG).pack(side='left')
        if self.job.get('results'):
            tk.Button(hdr,text='ASK SENTINEL',font=a.bodyf,bg=CHIP,fg=FG,command=self.ask).pack(side='right',padx=4,ipady=5)

        meta=tk.Frame(self,bg=CARD,highlightbackground=BORDER,highlightthickness=1);meta.pack(fill='x',padx=4,pady=(3,5))
        tk.Label(meta,text=f"Status: {friendly_status(self.job.get('status',''))}",font=a.bodyf,bg=CARD,fg=FG,anchor='w').pack(fill='x',padx=8,pady=(5,0))
        tk.Label(meta,text=f"Started: {friendly_time(self.job.get('created_at',''))}",font=a.smallf,bg=CARD,fg=DIM,anchor='w').pack(fill='x',padx=8,pady=(0,5))

        if prog:
            box=tk.Frame(self,bg=CARD,highlightbackground=BORDER,highlightthickness=1);box.pack(fill='x',padx=4,pady=(0,5))
            tk.Label(box,text=f"{friendly_task(prog.get('task',''))} | {prog.get('job_percent',0)}% overall | {prog.get('task_percent',0)}% current",font=a.bodyf,bg=CARD,fg=FG,anchor='w').pack(fill='x',padx=8,pady=(6,2))
            LargeBar(box,int(prog.get('job_percent',0) or 0)).pack(fill='x',padx=8,pady=(0,7))

        self.canvas,self.inner=scroll_area(self)
        results=self.job.get('results') or []
        if not results:
            tk.Label(self.inner,text='This job is still running.',font=a.bodyf,bg=BG,fg=DIM).pack(pady=70)
            return

        for r in results:
            status=str(r.get('status','')).lower()
            color=OK if status=='completed' else BAD if status=='failed' else WARN
            card=tk.Frame(self.inner,bg=CARD,highlightbackground=BORDER,highlightthickness=1)
            card.pack(fill='x',padx=4,pady=4)
            top=tk.Frame(card,bg=CARD);top.pack(fill='x',padx=8,pady=(6,2))
            tk.Label(top,text=friendly_task(r.get('task','')),font=a.btnf,bg=CARD,fg=FG,anchor='w').pack(side='left')
            tk.Label(top,text=status.upper() or 'UNKNOWN',font=a.smallf,bg=CARD,fg=color).pack(side='right')
            tk.Label(card,text=clean_text(r.get('summary','')),font=a.bodyf,bg=CARD,fg=DIM,anchor='w',justify='left',wraplength=620).pack(fill='x',padx=8,pady=(0,6))
            output=clean_text(r.get('output',''))
            if output.strip():
                tk.Button(card,text='VIEW DETAILS',font=a.smallf,bg=CHIP,fg=FG,
                          command=lambda r=r:self.app.show('task_output',result=r,job=self.job)).pack(anchor='e',padx=8,pady=(0,6),ipadx=6,ipady=3)

    def ask(self):
        self.app.set_status('Asking Sentinel about system info, Device Manager, and crash evidence...')
        def w():
            try:
                r=self.app.api('/api/admin/ask-sentinel',{'job_id':self.job.get('id')},timeout=50)
                self.app.q.put(('analysis',r.get('analysis','No analysis returned.')))
            except Exception as e:self.app.q.put(('error',str(e)))
        threading.Thread(target=w,daemon=True).start()

class TaskOutput(Page):
    def __init__(self,p,a,c):
        super().__init__(p,a,c)
        r=c.get('result',{})
        tk.Label(self,text=friendly_task(r.get('task','')),font=a.titlef,bg=BG,fg=FG).pack(anchor='w',padx=5)
        tk.Label(self,text=clean_text(r.get('summary','')),font=a.bodyf,bg=BG,fg=DIM,anchor='w',justify='left',wraplength=740).pack(fill='x',padx=5,pady=(0,5))
        parent=tk.Frame(self,bg=BG);parent.pack(fill='both',expand=True,padx=4,pady=4)
        txt=tk.Text(parent,bg=CODE,fg=FG,font=a.smallf,wrap='word',bd=0)
        txt.pack(side='left',fill='both',expand=True)
        txt.insert('end',clean_text(r.get('output','')))
        txt.config(state='disabled')
        if ui_theme and hasattr(ui_theme,'bind_text_drag'):ui_theme.bind_text_drag(txt)
        if ui_theme and hasattr(ui_theme,'attach_scroll_rail'):ui_theme.attach_scroll_rail(txt)

class Analysis(Page):
    def __init__(self,p,a,c):
        super().__init__(p,a,c);tk.Label(self,text='Sentinel Analysis',font=a.titlef,bg=BG,fg=FG).pack(anchor='w',padx=5)
        parent=tk.Frame(self,bg=BG);parent.pack(fill='both',expand=True,padx=4,pady=4);txt=tk.Text(parent,bg=CODE,fg=FG,font=a.bodyf,wrap='word',bd=0);txt.pack(side='left',fill='both',expand=True)
        txt.insert('end',clean_text(c.get('analysis','')));txt.config(state='disabled')
        if ui_theme and hasattr(ui_theme,'bind_text_drag'):ui_theme.bind_text_drag(txt)
        if ui_theme and hasattr(ui_theme,'attach_scroll_rail'):ui_theme.attach_scroll_rail(txt)

class USB(Page):
    def __init__(self,p,a,c):
        super().__init__(p,a,c);self.list=tk.Frame(self,bg=BG);self.list.pack(fill='both',expand=True);row=tk.Frame(self,bg=BG);row.pack(fill='x')
        self.button(row,'REFRESH USB',self.scan).pack(side='left',padx=5,ipady=4);self.button(row,'CREATE AGENT',self.create,CHIP).pack(side='right',padx=5,ipady=4);self.scan()
    def scan(self):
        self.app.set_status('Scanning USB drives...')
        threading.Thread(target=lambda:self._scan(),daemon=True).start()
    def _scan(self):
        try:self.app.q.put(('usb',usb_mounts()))
        except Exception as e:self.app.q.put(('error','USB scan failed: '+str(e)))
    def refresh(self):
        for w in self.list.winfo_children():w.destroy()
        if not self.app.usb:return tk.Label(self.list,text='NO WRITABLE USB DRIVE DETECTED',font=self.app.bodyf,bg=BG,fg=DIM).pack(pady=80)
        for d in self.app.usb:
            sel=self.app.usb_target and self.app.usb_target.get('uuid')==d.get('uuid')
            self.button(self.list,f"{d.get('label') or d.get('model') or d.get('path')}\n{d.get('size')} | {d.get('fstype')}",lambda d=d:self.pick(d),CHIP if sel else CARD).pack(fill='x',padx=7,pady=4,ipady=5)
    def pick(self,d):self.app.usb_target=d;self.app.set_status('Selected '+(d.get('label') or d.get('path')));self.refresh()
    def create(self):
        d=self.app.usb_target
        if not d:return self.app.set_status('Select a USB drive first')
        def w():
            try:
                e=self.app.api('/api/admin/enrollment-code',{});dest=os.path.join(d['mountpoint'],'BENCH_HERO','FLEET_AGENT');os.makedirs(dest,exist_ok=True)
                for fn in ('Install-BenchHeroFleet.ps1','Uninstall-BenchHeroFleet.ps1','BenchHeroFleetAgent.cs','BenchHeroFleetStatus.cs','README.txt'):shutil.copy2(os.path.join(BASE,'agent',fn),os.path.join(dest,fn))
                servers=self.app.advertised_servers();cfg={'server_url':servers[0],'server_urls':servers,'bench_hostname':self.app.local_hostname()+'.local','enrollment_code':e['code']};atomic(os.path.join(dest,'enrollment.json'),json.dumps(cfg,indent=2).encode())
                atomic(os.path.join(dest,'INSTALL BENCH HERO FLEET.cmd'),b'@echo off\r\nPowerShell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-BenchHeroFleet.ps1"\r\npause\r\n')
                atomic(os.path.join(dest,'UNINSTALL OLD BENCH HERO FLEET.cmd'),b'@echo off\r\nPowerShell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall-BenchHeroFleet.ps1"\r\npause\r\n');subprocess.run(['sync'],check=False)
                self.app.q.put(('msg','Agent USB ready. After installation, the USB can be unplugged.'))
            except Exception as e:self.app.q.put(('error','Agent creation failed: '+str(e)))
        threading.Thread(target=w,daemon=True).start()

def clean_text(v):
    s=str(v or '')
    # NUL padding is the main source of "?" between every character in redirected
    # SFC/DISM/CHKDSK output. Remove it before printable-character filtering.
    s=s.replace('\x00','').replace('\\x00','')
    repls={'•':' | ','—':' - ','–':'-','✓':'PASS','✗':'FAIL','⚠':'WARNING','→':' -> ','…':'...',
           '\u201c':'"','\u201d':'"','\u2018':"'",'\u2019':"'"}
    for x,y in repls.items():s=s.replace(x,y)
    out=[]
    for ch in s:
        o=ord(ch)
        if ch in ('\n','\t','\r'): out.append(ch)
        elif 32<=o<127: out.append(ch)
        elif o>=160:
            # Keep ordinary Unicode letters/numbers; DejaVu Sans can display them.
            out.append(ch)
    return ''.join(out)

def friendly_status(s):
    return str(s or '').replace('_',' ').strip().title() or 'Unknown'

def friendly_time(iso):
    if not iso:return 'Unknown'
    try:
        from datetime import datetime
        d=datetime.fromisoformat(str(iso).replace('Z','+00:00'))
        return d.astimezone().strftime('%Y-%m-%d %I:%M %p')
    except Exception:return clean_text(iso)

def friendly_task(t):return dict(TASKS).get(t,t or 'Maintenance')
def atomic(path,data):
    tmp=path+'.tmp';f=open(tmp,'wb');f.write(data);f.flush();os.fsync(f.fileno());f.close();os.replace(tmp,path)
def age(iso):
    if not iso:return 999999
    try:
        from datetime import datetime,timezone;return (datetime.now(timezone.utc)-datetime.fromisoformat(iso)).total_seconds()
    except Exception:return 999999
def confirm(root,title,msg):
    out={'v':False};d=tk.Toplevel(root);d.configure(bg=BG);d.geometry('620x250+90+100');d.transient(root);d.grab_set()
    tk.Label(d,text=title,font=root.titlef,bg=BG,fg=FG).pack(pady=(20,8));tk.Label(d,text=msg,font=root.bodyf,bg=BG,fg=DIM,wraplength=560,justify='center').pack(padx=20,pady=10)
    r=tk.Frame(d,bg=BG);r.pack(fill='x',padx=35,pady=15);tk.Button(r,text='CANCEL',font=root.btnf,bg=CARD,fg=FG,command=d.destroy).pack(side='left',fill='x',expand=True,padx=5,ipady=8)
    def yes():out['v']=True;d.destroy()
    tk.Button(r,text='CONFIRM',font=root.btnf,bg=BAD,fg='white',command=yes).pack(side='right',fill='x',expand=True,padx=5,ipady=8);root.wait_window(d);return out['v']
def scroll_area(parent,height=None):
    canvas=tk.Canvas(parent,bg=BG,highlightthickness=0,height=height);inner=tk.Frame(canvas,bg=BG);win=canvas.create_window((0,0),window=inner,anchor='nw');canvas.pack(fill='both',expand=True)
    inner.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')));canvas.bind('<Configure>',lambda e:canvas.itemconfigure(win,width=e.width));bind_scroll(canvas,inner);return canvas,inner
def bind_scroll(canvas,inner):
    drag={'y':0,'m':False}
    def p(e):drag.update(y=e.y_root,m=False)
    def m(e):
        dy=e.y_root-drag['y'];
        if abs(dy)>10:drag['m']=True;canvas.yview_scroll(-int(dy/18),'units');drag['y']=e.y_root
    def rec(w):
        w.bind('<ButtonPress-1>',p,add='+');w.bind('<B1-Motion>',m,add='+')
        for c in w.winfo_children():rec(c)
    canvas.after(150,lambda:rec(inner))
class MiniBar(tk.Canvas):
    def __init__(self,p,pct):super().__init__(p,width=90,height=16,bg=CODE,highlightthickness=1,highlightbackground=BORDER);self.create_rectangle(0,0,int(88*max(0,min(100,pct))/100),14,fill=OK,outline='')
class LargeBar(tk.Canvas):
    def __init__(self,p,pct):super().__init__(p,height=18,bg=CODE,highlightthickness=1,highlightbackground=BORDER);self.pct=max(0,min(100,pct));self.bind('<Configure>',self.draw)
    def draw(self,e):self.delete('all');self.create_rectangle(0,0,int(e.width*self.pct/100),e.height,fill=OK,outline='')
def usb_mounts():
    fields='NAME,PATH,TYPE,TRAN,RM,HOTPLUG,RO,FSTYPE,LABEL,UUID,SIZE,MODEL,VENDOR,SERIAL,MOUNTPOINTS,PKNAME';tree=json.loads(subprocess.check_output(['lsblk','-J','-o',fields],text=True)).get('blockdevices',[]);rows=[]
    def mounts(n):
        m=[x for x in (n.get('mountpoints') or []) if x]
        for c in n.get('children') or []:m+=mounts(c)
        return m
    def walk(n,parent=None):
        name=n.get('name','');typ=n.get('type','');trans=n.get('tran') or (parent or {}).get('tran')
        if not name.startswith(VIRTUAL) and typ in ('part','disk') and trans=='usb':
            f=(n.get('fstype') or '').lower();mps=[x for x in (n.get('mountpoints') or []) if x]
            if f not in ('swap','') and mps and not n.get('ro') and all(x not in ('/','/boot','/boot/firmware') for x in mps):rows.append({'path':n.get('path'),'mountpoint':mps[0],'fstype':f,'label':n.get('label') or '','uuid':n.get('uuid') or '','size':n.get('size') or '','model':n.get('model') or (parent or {}).get('model') or ''})
        for c in n.get('children') or []:walk(c,n if n.get('type')=='disk' else parent)
    for d in tree:
        if d.get('type')=='disk' and any(m in ('/','/boot','/boot/firmware') for m in mounts(d)):continue
        walk(d,None)
    return rows
if __name__=='__main__':App().mainloop()
