# Bench Hero Fleet Maintenance v1.2

LAN-only fleet maintenance manager for explicitly enrolled Windows 10/11 PCs.

## v1.2 fixes
- Agent USB creation now correctly requests an enrollment code with POST instead of GET, fixing the HTTP 404 error.
- Generated agents use the Pi hostname (`http://<hostname>.local:8379`) as their primary address.
- The current LAN IP is stored only as a fallback.
- The Windows service tries every saved Bench address and remembers the one that worked most recently.
- Moving the Pi between `192.168.0.x`, `192.168.1.x`, or other networks no longer requires regenerating the agent as long as `<hostname>.local` resolves.

## Included
- Fleet receiver on TCP 8379
- One-time enrollment codes
- Per-device IDs and authentication tokens
- Online/offline device list
- Batch SFC, DISM, CHKDSK, Defender, and crash/shutdown review
- Job history and full output
- USB agent creator


## v1.3 Windows status GUI
The generated Windows agent now installs a visible tray/status application. It reports whether the service is running, whether the Bench Hero server can be reached, the last successful check-in, current maintenance task, enrollment state, and the last connection error. Closing the window hides it to the tray without stopping the service.


## v1.4
The Windows status window now shows a live progress bar, overall job percentage, current-task percentage, and task number. SFC, DISM, and CHKDSK percentages are parsed from command output; tasks without native percentage output still advance by completed task count.

## v1.6
- Fixes Agent USB creation omitting `BenchHeroFleetStatus.cs`, which caused Windows to report that it could not find BenchHeroFleetStatus.
- Installer now validates both C# source files before compiling and gives a clear recovery message if the USB package is incomplete.


## Uninstall

The Windows status window now includes **UNINSTALL AGENT**. It asks for confirmation and Windows administrator approval, then removes the Fleet service, tray application, startup entry, Start Menu shortcuts, enrollment credentials, local logs, and installed files.

The generated Agent USB also includes **UNINSTALL OLD BENCH HERO FLEET.cmd** so older installations can be removed before installing v1.6.


## v1.7
- Added a REMOVE button to each enrolled computer.
- Removal requires confirmation.
- Removing a computer deletes its Fleet record and related job history from the bench.
- The remote Windows agent becomes unauthorized but is not silently uninstalled.


## v1.8
- Fleet API is installed as a persistent user service on the Pi when possible.
- Windows agent is explicitly self-contained under ProgramData and does not depend on the Agent USB after install.
- Batch screen supports any number of computers and multiple repair actions.
- Live job progress is pushed from Windows to the Pi.
- Job results can be sent to Project Sentinel Ask AI for crash/error interpretation.
- UI progress bars and text were cleaned up for 800x480; non-ASCII glyphs are normalized.


## v1.9 fixes
- Bench Hero connectivity is no longer tied to the IP address saved at install time.
- Agents retry the configured `.local` hostname, resolve it to the Pi's current IPv4 address, then use UDP LAN discovery if all saved addresses are stale.
- Newly discovered addresses are saved automatically.
- The installer now persists the Pi hostname for future reconnects.
- Windows detection is build-aware: build 22000+ is reported as Windows 11 even when the legacy ProductName registry field still says Windows 10.
- The reported OS now includes edition, DisplayVersion, and build number.


## v2.0

- Fixed Windows command output that could display a question mark between every character.
  The agent now requests UTF-8 output, strips UTF-16 NUL padding before transport, and the Pi
  UI can also repair old stored output containing NUL padding.
- Job Results no longer dump every command's raw output onto one screen. Each repair is shown
  as a readable status card with its summary and a separate View Details screen.
- Added System Information collection: manufacturer/model, correct Windows family/build,
  BIOS, CPU, RAM modules, GPUs, drives, and uptime.
- Added Device Manager Issues collection with common ConfigManager error-code explanations.
- Crash Review remains available and now uses UTF-8-safe plain-text event formatting.
- Each enrolled PC now has a SENTINEL DIAG button. It queues System Info + Device Manager +
  Crash Review as a diagnostic snapshot.
- Ask Sentinel now includes the system profile, Device Manager issues, crash/shutdown/WHEA/
  storage evidence, plus any failed maintenance task results, so AI can correlate the evidence.


## v2.1 - Ask Sentinel 502 fix
- Fleet compacts System Info, Device Manager, crash evidence, and failed-task output before asking AI.
- The request now has a hard size ceiling so oversized diagnostic context cannot overwhelm smaller AI gateways.
- Fleet tries localhost first and probes several Ask Sentinel API route/request-field variants.
- A 502 from one request shape no longer aborts immediately.
- OpenAI-style choices/message/content responses are supported.
- If Sentinel's configured AI provider is actually unavailable, Fleet displays the backend detail instead of only "502 Bad Gateway".


## v2.2 - Security and browser cleanup

New Fleet tasks:
- Defender Full Scan updates Microsoft Defender signatures, performs a full scan, and reports recent detections.
- Adware Review collects startup entries, non-Microsoft scheduled tasks, installed applications, and Chrome/Edge/Brave extension IDs for technician/Sentinel review.
- Adware Cleanup uses a conservative cleanup pass: temporary files and policy-based homepage/search hijacks are removed, but arbitrary installed applications/extensions are not silently deleted.
- Browser Search Reset removes custom search-provider override data from Chrome, Edge, and Brave profiles so the browser can fall back to its built-in/default search behavior. Firefox is left for manual review.
- Each online computer gets a SECURITY quick action that queues Defender Full Scan + Adware Review.
- Security/adware findings are automatically included when ASK SENTINEL analyzes the job.

The review and removal steps are intentionally separate so a technician can inspect findings before deleting user-installed software or extensions.


## v2.2.1 - Windows uninstall fix
- Fixed the status GUI sometimes reporting `Uninstall could not start`.
- The GUI now copies the uninstaller to a temporary folder and launches it through an independent elevated command process before the tray app exits.
- UAC cancellation is reported explicitly instead of as a generic launch failure.
- The uninstaller shows each removal stage and verifies both the Windows service and installed folder are gone.
- The installed agent, enrollment credentials, logs, startup entry, service, and Start Menu shortcuts are removed.
- Temporary uninstall files self-delete after completion.
- Removing the Windows agent no longer claims to erase the historical device card on the Pi; that remains a separate Fleet action.


## v2.2.2 - Queue + batch-selection fix
- Fixed a persistent-service version mismatch: Bench Hero now checks the running Fleet server version and restarts the background service after an app update instead of continuing to talk to stale server code.
- `/api/health` now reports the Fleet server version.
- Diagnostic Snapshot, Security, and Batch Tune-Up stay on the current screen until the server confirms that jobs were actually created.
- Queue failures now preserve and display the real server error.
- Batch Repairs is fully vertically scrollable on the 800x480 display.
- Repairs are one large touch row each instead of a cramped two-column grid.
- Selected repairs turn bright green, show a check mark, and use a pressed state; unselected repairs show an empty box.
- Added SELECT ALL and CLEAR ALL.
- The selection counter stays visible while scrolling.
- Batch queueing verifies that at least one job was created instead of treating an empty response as success.


## v2.2.3 - Device-list flicker fix
- Fixed the enrolled-PC list blinking/flickering every time a running repair reported progress or checked in.
- Device cards are now created once and updated in place with StringVars instead of being destroyed and rebuilt every 2.5 seconds.
- The list no longer sorts by `last_seen`, which changed constantly during active repairs and could reorder cards.
- Online/offline state and Windows/customer text still update live without repainting the entire list.
- Cards are only created/removed/reordered when a computer is actually added, removed, or its stable sort order changes.


## v2.3.0 - Hero Dashboard page
- Fleet now publishes a native, PIN-protected page in the Hero Dashboard sidebar as **🖥 Fleet**.
- View enrolled Windows computers and live online/offline state from any browser on the shop LAN.
- Queue Sentinel diagnostic snapshots and security scans directly from each computer card.
- Run batch repairs across multiple selected computers from the dashboard.
- Generate Fleet enrollment codes without opening the 7-inch touchscreen app.
- Remove stale computers and review the 20 most recent jobs.
- The dashboard page talks to the existing persistent Fleet service on localhost:8379, so the Windows agent protocol does not change.


## v2.3.1 - Dashboard job cards + browser notification cleanup
- Recent Jobs on the Hero Dashboard no longer prints the raw Python progress dictionary.
- Running jobs now show a clean status, overall percentage, progress bar, current task, current-task percentage, and message.
- Completed/error statuses are converted from internal names such as `completed_with_errors` into readable labels.
- Internal task IDs are shown as human labels such as `Defender Full`, `Device Manager`, and `Browser Search Reset`.
- ISO timestamps are converted to normal local date/time text.
- Added `Browser Notifications Reset` as a Fleet repair task.
- That task clears stored website notification permissions for Chrome, Edge, and Brave profiles and sets notifications to blocked by default where the profile exposes that setting.
- Firefox notification permissions are left for manual review because Firefox stores them in `permissions.sqlite`, which should not be modified while the browser/profile may be active.
