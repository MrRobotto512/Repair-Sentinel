#!/usr/bin/env python3
import json, os, secrets, threading, time, uuid, socket
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

PORT = 8379
DATA_DIR = os.path.expanduser('~/.local/share/benchhero_fleet')
STATE_FILE = os.path.join(DATA_DIR, 'state.json')
LOCK = threading.RLock()
DISCOVERY_MAGIC = b'BENCHHERO_FLEET_DISCOVER_V1'

def _route_ip_for(peer_ip):
    s=None
    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        s.connect((peer_ip,9))
        return s.getsockname()[0]
    except Exception:
        return ''
    finally:
        if s:
            try:s.close()
            except Exception:pass

def discovery_loop():
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
    sock.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1)
    sock.bind(('',PORT))
    while True:
        try:
            raw,addr=sock.recvfrom(2048)
            if raw.strip()!=DISCOVERY_MAGIC:
                continue
            ip=_route_ip_for(addr[0])
            host=(socket.gethostname() or 'benchhero').split('.')[0]+'.local'
            payload={
                'service':'Bench Hero Fleet',
                'version':'2.3.1',
                'hostname':host,
                'url':('http://%s:%d'%(ip,PORT)) if ip else ('http://%s:%d'%(host,PORT))
            }
            sock.sendto(json.dumps(payload).encode('utf-8'),addr)
        except Exception as e:
            print('[fleet-discovery]',e)
            time.sleep(1)

TASKS = {
    'sfc': 'System File Checker',
    'dism_scan': 'DISM ScanHealth',
    'dism_restore': 'DISM RestoreHealth',
    'chkdsk_scan': 'CHKDSK Online Scan',
    'defender_quick': 'Defender Quick Scan',
    'system_info': 'System Information',
    'device_manager': 'Device Manager Issues',
    'crash_review': 'Crash & Shutdown Review',
    'defender_full': 'Defender Full Scan',
    'adware_review': 'Adware Review',
    'adware_cleanup': 'Adware Cleanup',
    'browser_search_reset': 'Browser Search Reset',
    'browser_notifications_reset': 'Browser Notifications Reset',
}

def utcnow():
    return datetime.now(timezone.utc).isoformat()

def default_state():
    return {'enrollment': {}, 'devices': {}, 'jobs': {}, 'audit': []}

def load_state():
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(STATE_FILE): return default_state()
    try:
        with open(STATE_FILE, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception:
        return default_state()

def save_state(state):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = STATE_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(state, f, indent=2)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, STATE_FILE)

STATE = load_state()

def public_device(d):
    x = dict(d); x.pop('token', None); return x

def is_local(handler):
    return handler.client_address[0] in ('127.0.0.1', '::1')

class Handler(BaseHTTPRequestHandler):
    server_version = 'BenchHeroFleet/2.3.1'
    def log_message(self, fmt, *args): print('[fleet]', self.address_string(), fmt % args)
    def send_json(self, code, obj):
        raw = json.dumps(obj).encode('utf-8')
        self.send_response(code); self.send_header('Content-Type','application/json')
        self.send_header('Content-Length', str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def read_json(self):
        n = int(self.headers.get('Content-Length','0') or 0)
        if n > 2_000_000: raise ValueError('request too large')
        return json.loads(self.rfile.read(n).decode('utf-8') or '{}')
    def auth_device(self, device_id):
        auth = self.headers.get('Authorization','')
        with LOCK: d = STATE['devices'].get(device_id)
        return d if d and secrets.compare_digest(auth, 'Bearer '+d.get('token','')) else None
    def do_GET(self):
        p = urlparse(self.path).path
        if p == '/api/health': return self.send_json(200, {'ok':True,'service':'Bench Hero Fleet','version':'2.3.1','time':utcnow()})
        if p == '/api/admin/state':
            if not is_local(self): return self.send_json(403, {'error':'local only'})
            with LOCK:
                devices=[public_device(d) for d in STATE['devices'].values()]
                jobs=list(STATE['jobs'].values())[-100:]
                enrollment=dict(STATE.get('enrollment') or {})
            return self.send_json(200, {'devices':devices,'jobs':jobs,'enrollment':enrollment,'tasks':TASKS})
        return self.send_json(404, {'error':'not found'})
    def do_POST(self):
        p = urlparse(self.path).path
        try: data = self.read_json()
        except Exception as e: return self.send_json(400, {'error':str(e)})
        if p.startswith('/api/admin/'):
            if not is_local(self): return self.send_json(403, {'error':'local only'})
            return self.admin_post(p, data)
        if p == '/api/enroll': return self.enroll(data)
        if p == '/api/checkin': return self.checkin(data)
        if p == '/api/job-result': return self.job_result(data)
        if p == '/api/job-progress': return self.job_progress(data)
        return self.send_json(404, {'error':'not found'})
    def admin_post(self, p, data):
        global STATE
        if p == '/api/admin/enrollment-code':
            code = ''.join(secrets.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(8))
            with LOCK:
                STATE['enrollment']={'code':code,'expires_at':time.time()+3600,'created_at':utcnow()}; save_state(STATE)
            return self.send_json(200, STATE['enrollment'])
        if p == '/api/admin/jobs':
            ids=data.get('device_ids') or []; tasks=data.get('tasks') or []
            bad=[t for t in tasks if t not in TASKS]
            if not ids or not tasks or bad: return self.send_json(400, {'error':'invalid device_ids/tasks','bad_tasks':bad})
            made=[]; missing=[]
            with LOCK:
                for did in ids:
                    if did not in STATE['devices']:
                        missing.append(did); continue
                    jid=str(uuid.uuid4())
                    job={'id':jid,'device_id':did,'tasks':tasks,'status':'queued','created_at':utcnow(),'updated_at':utcnow(),'results':[]}
                    STATE['jobs'][jid]=job; made.append(job)
                STATE['audit'].append({'at':utcnow(),'action':'create_jobs','device_ids':ids,'tasks':tasks})
                save_state(STATE)
            if not made:
                return self.send_json(404, {'error':'No matching enrolled computers were found. Refresh Fleet and try again.','missing_device_ids':missing})
            return self.send_json(200, {'jobs':made,'missing_device_ids':missing})
        if p == '/api/admin/revoke':
            did=data.get('device_id')
            with LOCK:
                d=STATE['devices'].get(did)
                if not d: return self.send_json(404, {'error':'device not found'})
                d['revoked']=True; d['updated_at']=utcnow(); save_state(STATE)
            return self.send_json(200, {'ok':True})
        if p == '/api/admin/ask-sentinel':
            jid=str(data.get('job_id','')).strip()
            with LOCK:
                j=STATE['jobs'].get(jid)
                if not j: return self.send_json(404, {'error':'job not found'})
                d=STATE['devices'].get(j.get('device_id')) or {}
                packet=sentinel_packet(j,d)
            try:
                result=ask_sentinel(packet)
                return self.send_json(200, {'ok':True,'analysis':result,'packet':packet})
            except Exception as e:
                return self.send_json(503, {'error':'Sentinel AI unavailable','detail':str(e),'packet':packet})
        if p == '/api/admin/remove-device':
            did=str(data.get('device_id','')).strip()
            if not did: return self.send_json(400, {'error':'device_id required'})
            with LOCK:
                d=STATE['devices'].get(did)
                if not d: return self.send_json(404, {'error':'device not found'})
                removed_jobs=[]
                for jid, job in list(STATE['jobs'].items()):
                    if job.get('device_id') == did:
                        removed_jobs.append(jid)
                        del STATE['jobs'][jid]
                del STATE['devices'][did]
                STATE['audit'].append({
                    'at':utcnow(),
                    'action':'remove_device',
                    'device_id':did,
                    'pc_name':d.get('pc_name',''),
                    'hostname':d.get('hostname',''),
                    'removed_job_count':len(removed_jobs),
                })
                save_state(STATE)
            return self.send_json(200, {'ok':True,'removed_jobs':len(removed_jobs)})
        return self.send_json(404, {'error':'not found'})
    def enroll(self, data):
        code=str(data.get('enrollment_code','')).strip().upper()
        with LOCK:
            e=STATE.get('enrollment') or {}
            if not code or code != e.get('code') or time.time() > float(e.get('expires_at',0)):
                return self.send_json(403, {'error':'invalid or expired enrollment code'})
            did=str(uuid.uuid4()); token=secrets.token_urlsafe(32)
            d={'id':did,'token':token,'customer_name':str(data.get('customer_name','')).strip()[:100],
               'pc_name':str(data.get('pc_name','')).strip()[:100], 'hostname':str(data.get('hostname',''))[:100],
               'model':str(data.get('model',''))[:160], 'windows':str(data.get('windows',''))[:160],
               'agent_version':str(data.get('agent_version','1.0'))[:30], 'last_seen':utcnow(), 'status':'online',
               'revoked':False,'created_at':utcnow(),'updated_at':utcnow()}
            STATE['devices'][did]=d; STATE['enrollment']={}; save_state(STATE)
        return self.send_json(200, {'device_id':did,'device_token':token,'poll_seconds':30})
    def checkin(self, data):
        did=str(data.get('device_id',''))
        d=self.auth_device(did)
        if not d: return self.send_json(403, {'error':'unauthorized'})
        with LOCK:
            if d.get('revoked'): return self.send_json(403, {'error':'revoked'})
            for k in ('hostname','model','windows','agent_version','status'):
                if k in data: d[k]=str(data[k])[:200]
            d['last_seen']=utcnow(); d['updated_at']=utcnow()
            jobs=[]
            for j in STATE['jobs'].values():
                if j['device_id']==did and j['status']=='queued':
                    j['status']='assigned'; j['updated_at']=utcnow(); jobs.append({'id':j['id'],'tasks':j['tasks']})
            save_state(STATE)
        return self.send_json(200, {'jobs':jobs,'poll_seconds':30})
    def job_progress(self, data):
        did=str(data.get('device_id','')); d=self.auth_device(did)
        if not d: return self.send_json(403, {'error':'unauthorized'})
        jid=str(data.get('job_id',''))
        with LOCK:
            j=STATE['jobs'].get(jid)
            if not j or j['device_id'] != did: return self.send_json(404, {'error':'job not found'})
            j['status']='running'
            j['progress']={
                'task':str(data.get('task',''))[:60],
                'task_index':int(data.get('task_index',0) or 0),
                'task_total':int(data.get('task_total',0) or 0),
                'task_percent':max(0,min(100,int(data.get('task_percent',0) or 0))),
                'job_percent':max(0,min(100,int(data.get('job_percent',0) or 0))),
                'message':str(data.get('message',''))[:240],
                'updated_at':utcnow(),
            }
            j['updated_at']=utcnow(); d['status']='maintenance'; d['last_seen']=utcnow(); save_state(STATE)
        return self.send_json(200, {'ok':True})

    def job_result(self, data):
        did=str(data.get('device_id','')); d=self.auth_device(did)
        if not d: return self.send_json(403, {'error':'unauthorized'})
        jid=str(data.get('job_id',''))
        with LOCK:
            j=STATE['jobs'].get(jid)
            if not j or j['device_id'] != did: return self.send_json(404, {'error':'job not found'})
            results=data.get('results') or []
            # output caps
            for r in results:
                if isinstance(r,dict):
                    out=str(r.get('output','')).replace('\\x00','').replace('\x00','')
                    # Repair the most common symptom of UTF-16LE text having been transported
                    # with NUL padding. Existing/new results both remain readable.
                    r['output']=out
                    if len(r['output']) > 100000: r['output']=r['output'][:100000]+'\n[truncated]'
            j['results']=results; j['status']=str(data.get('status','completed'))[:30]; j['progress']={}; j['updated_at']=utcnow()
            d['status']='online'; d['last_seen']=utcnow(); save_state(STATE)
        return self.send_json(200, {'ok':True})

def bench_hostname():
    try: return (socket.gethostname() or 'benchhero').split('.')[0]
    except Exception: return 'benchhero'

def _compact_text(value, limit):
    text=str(value or '').replace('\x00','').replace('\\x00','')
    text=text.replace('\r\n','\n').replace('\r','\n')
    while '\n\n\n' in text:
        text=text.replace('\n\n\n','\n\n')
    if len(text)>limit:
        text=text[:limit]+'\n[truncated for Sentinel]'
    return text

def sentinel_packet(job, device):
    evidence=[]
    limits={'system_info':5500,'device_manager':6500,'crash_review':12000,'defender_full':7000,'adware_review':9000,'adware_cleanup':5000,'browser_search_reset':5000,'browser_notifications_reset':5000}
    for r in job.get('results') or []:
        task=str(r.get('task','')); status=str(r.get('status',''))
        if task in ('system_info','device_manager','crash_review','defender_full','adware_review','adware_cleanup','browser_search_reset','browser_notifications_reset') or status=='failed':
            evidence.append({
                'task':task,
                'status':status,
                'exit_code':r.get('exit_code'),
                'summary':_compact_text(r.get('summary',''),800),
                'output':_compact_text(r.get('output',''),limits.get(task,3500)),
            })
    if not evidence:
        for r in (job.get('results') or [])[:6]:
            evidence.append({
                'task':r.get('task',''),
                'status':r.get('status',''),
                'summary':_compact_text(r.get('summary',''),600),
                'output':_compact_text(r.get('output',''),2000),
            })
    prompt=(
        'Analyze this Windows diagnostic evidence as a repair technician. '
        'Correlate the system profile, Device Manager problems, crash/shutdown/WHEA/storage events, Defender findings, adware indicators, browser changes, '
        'and failed maintenance tasks. Separate evidence from inference, rank likely causes, '
        'identify anything urgent, and recommend the next diagnostic steps. '
        'Do not call a component failed unless the evidence supports it.'
    )
    return {
        'source':'Bench Hero Fleet Maintenance',
        'customer_name':_compact_text(device.get('customer_name',''),120),
        'pc_name':_compact_text(device.get('pc_name') or device.get('hostname',''),120),
        'model':_compact_text(device.get('model',''),180),
        'windows':_compact_text(device.get('windows',''),180),
        'job_id':job.get('id',''),
        'job_status':job.get('status',''),
        'prompt':prompt,
        'evidence':evidence,
    }

def sentinel_prompt_text(packet):
    lines=[
        packet.get('prompt',''),'',
        'SYSTEM',
        'Customer: '+str(packet.get('customer_name','')),
        'PC: '+str(packet.get('pc_name','')),
        'Model: '+str(packet.get('model','')),
        'Windows: '+str(packet.get('windows','')),
        '','EVIDENCE'
    ]
    for e in packet.get('evidence') or []:
        lines += [
            '',
            '--- '+str(e.get('task','')).upper()+' ---',
            'Status: '+str(e.get('status','')),
            'Summary: '+str(e.get('summary','')),
            str(e.get('output',''))
        ]
    return _compact_text('\n'.join(lines),26000)

def ask_sentinel(packet):
    bases=['http://127.0.0.1:8377', f'http://{bench_hostname()}.local:8377']
    paths=['/api/ask','/api/sentinel/ask','/api/ask-sentinel','/ask']
    prompt_text=sentinel_prompt_text(packet)
    bodies=[
        {'question':prompt_text,'source':'fleet'},
        {'prompt':prompt_text,'source':'fleet'},
        {'message':prompt_text,'source':'fleet'},
        {'query':prompt_text,'source':'fleet'},
    ]
    errors=[]
    for base in bases:
        for path in paths:
            for payload in bodies:
                try:
                    body=json.dumps(payload,ensure_ascii=False).encode('utf-8')
                    req=Request(
                        base+path,
                        data=body,
                        headers={
                            'Content-Type':'application/json; charset=utf-8',
                            'Accept':'application/json,text/plain,*/*',
                            'User-Agent':'BenchHeroFleet/2.1'
                        },
                        method='POST'
                    )
                    with urlopen(req,timeout=55) as rsp:
                        raw=rsp.read().decode('utf-8','replace').strip()
                        if not raw:
                            errors.append(f'{base+path}: empty response'); continue
                        try: obj=json.loads(raw)
                        except Exception: return raw
                        if isinstance(obj,dict):
                            for key in ('answer','response','analysis','text','message','content'):
                                val=obj.get(key)
                                if val:
                                    return json.dumps(val,indent=2,ensure_ascii=False) if isinstance(val,(dict,list)) else str(val)
                            choices=obj.get('choices')
                            if isinstance(choices,list) and choices:
                                msg=(choices[0] or {}).get('message') or {}
                                if isinstance(msg,dict) and msg.get('content'):
                                    return str(msg['content'])
                        errors.append(f'{base+path}: unexpected JSON response')
                except HTTPError as e:
                    try: detail=e.read().decode('utf-8','replace')[:500]
                    except Exception: detail=''
                    errors.append(f'{base+path}: HTTP {e.code} {e.reason} {detail}')
                except Exception as e:
                    errors.append(f'{base+path}: {e}')
    raise RuntimeError(
        'Sentinel is running, but Fleet could not get an AI response from a compatible Ask endpoint. '
        'Most recent attempts: '+' | '.join(errors[-8:])
    )

def main():
    os.makedirs(DATA_DIR, exist_ok=True)
    threading.Thread(target=discovery_loop,daemon=True).start()
    srv=ThreadingHTTPServer(('0.0.0.0', PORT), Handler)
    print(f'Bench Hero Fleet server listening on {PORT}')
    try: srv.serve_forever()
    except KeyboardInterrupt: pass
    finally: srv.server_close()

if __name__=='__main__': main()
