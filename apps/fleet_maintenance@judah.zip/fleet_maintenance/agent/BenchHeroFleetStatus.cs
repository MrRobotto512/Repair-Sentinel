using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.ServiceProcess;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;

public class FleetStatusApp : ApplicationContext {
    readonly string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Nash Nerds", "Bench Hero Fleet");
    readonly JavaScriptSerializer js = new JavaScriptSerializer(){MaxJsonLength=2097152};
    readonly NotifyIcon tray;
    readonly Timer timer;
    StatusForm form;

    public FleetStatusApp(){
        var menu = new ContextMenuStrip();
        menu.Items.Add("Open Bench Hero Fleet", null, (s,e)=>ShowWindow());
        menu.Items.Add("Refresh status", null, (s,e)=>Refresh());
        menu.Items.Add("Open logs", null, (s,e)=>OpenLogs());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Uninstall Bench Hero Fleet", null, (s,e)=>ConfirmUninstall());
        menu.Items.Add("Exit status monitor", null, (s,e)=>ExitThread());
        tray = new NotifyIcon {
            Text = "Bench Hero Fleet",
            Icon = SystemIcons.Information,
            Visible = true,
            ContextMenuStrip = menu
        };
        tray.DoubleClick += (s,e)=>ShowWindow();
        timer = new Timer(){Interval=5000};
        timer.Tick += (s,e)=>Refresh();
        timer.Start();
        ShowWindow();
        Refresh();
    }

    void ShowWindow(){
        if(form==null || form.IsDisposed){ form=new StatusForm(Refresh,ConfirmUninstall); form.FormClosed += (s,e)=>form=null; }
        form.Show(); form.WindowState=FormWindowState.Normal; form.BringToFront(); form.Activate();
        Refresh();
    }

    Dictionary<string,object> ReadJson(string path){
        try { return js.Deserialize<Dictionary<string,object>>(File.ReadAllText(path)); }
        catch { return new Dictionary<string,object>(); }
    }

    string Get(Dictionary<string,object> d,string k,string fallback=""){
        object v; return d!=null && d.TryGetValue(k,out v) && v!=null ? Convert.ToString(v) : fallback;
    }

    int ToInt(Dictionary<string,object> d,string k,int fallback=0){
        try{object v;if(d!=null&&d.TryGetValue(k,out v)&&v!=null)return Convert.ToInt32(v);}catch{} return fallback;
    }

    bool ServiceRunning(){
        try { using(var sc=new ServiceController("BenchHeroFleet")){ return sc.Status==ServiceControllerStatus.Running; } }
        catch { return false; }
    }

    bool ServerReachable(Dictionary<string,object> cfg){
        var urls=new List<string>(); object raw;
        if(cfg.TryGetValue("server_urls",out raw)){
            var arr=raw as System.Collections.ArrayList;
            if(arr!=null)foreach(object x in arr){var u=Convert.ToString(x).Trim().TrimEnd('/');if(u.Length>0)urls.Add(u);}
        }
        var primary=Get(cfg,"server_url").Trim().TrimEnd('/'); if(primary.Length>0&&!urls.Contains(primary))urls.Insert(0,primary);
        foreach(var u in urls){
            try { var req=(HttpWebRequest)WebRequest.Create(u+"/api/health"); req.Timeout=1200; using(var rsp=req.GetResponse()) return true; }
            catch {}
        }
        return false;
    }

    void Refresh(){
        var cfg=ReadJson(Path.Combine(dataDir,"config.json"));
        var st=ReadJson(Path.Combine(dataDir,"status.json"));
        bool running=ServiceRunning();
        bool reachable=running && ServerReachable(cfg);
        string state=Get(st,"state", running?"Running":"Stopped");
        string customer=Get(cfg,"customer_name","Not assigned");
        string pc=Get(cfg,"pc_name",Environment.MachineName);
        string server=Get(cfg,"server_url","Not configured");
        string last=Get(st,"last_checkin_utc","Never");
        string task=Get(st,"current_task","");
        string err=Get(st,"last_error","");
        int taskPct=ToInt(st,"task_progress_percent",0);
        int jobPct=ToInt(st,"job_progress_percent",0);
        int taskIndex=ToInt(st,"task_index",0);
        int taskTotal=ToInt(st,"task_total",0);
        string enrolled=String.IsNullOrWhiteSpace(Get(cfg,"device_id"))?"Waiting for enrollment":"Enrolled";

        string headline;
        Color color;
        if(!running){headline="Agent service is stopped";color=Color.FromArgb(220,70,70);tray.Icon=SystemIcons.Error;}
        else if(!reachable){headline="Agent is running - Bench Hero is unavailable";color=Color.FromArgb(240,170,30);tray.Icon=SystemIcons.Warning;}
        else {headline="Agent is running and connected";color=Color.FromArgb(0,180,90);tray.Icon=SystemIcons.Information;}
        tray.Text=(headline.Length>63?headline.Substring(0,63):headline);
        if(form!=null&&!form.IsDisposed)form.SetStatus(headline,color,customer,pc,enrolled,server,last,state,task,err,taskPct,jobPct,taskIndex,taskTotal);
    }


    void ConfirmUninstall(){
        var answer=MessageBox.Show(
            "This will stop the Bench Hero Fleet service and completely remove the local agent, enrollment credentials, logs, tray startup, and shortcuts.\n\nThe computer's old Fleet history can still be removed separately from Bench Hero.\n\nContinue?",
            "Uninstall Bench Hero Fleet", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
        if(answer!=DialogResult.Yes)return;

        try {
            string installed=Path.Combine(dataDir,"Uninstall-BenchHeroFleet.ps1");
            if(!File.Exists(installed)){
                MessageBox.Show(
                    "The installed uninstaller is missing.\n\nReinstall/update the Fleet agent once, then use UNINSTALL AGENT again.",
                    "Uninstaller missing",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }

            string tempDir=Path.Combine(Path.GetTempPath(),"BenchHeroFleet-Uninstall-"+Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(tempDir);
            string temp=Path.Combine(tempDir,"Uninstall-BenchHeroFleet.ps1");
            File.Copy(installed,temp,true);

            // Use a tiny cmd launcher so the elevated PowerShell process is completely
            // independent of this tray executable before cleanup begins.
            string launcher=Path.Combine(tempDir,"uninstall.cmd");
            File.WriteAllText(launcher,
                "@echo off\r\n"+
                "timeout /t 2 /nobreak >nul\r\n"+
                "powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File \""+temp+"\"\r\n",
                Encoding.ASCII);

            var psi=new System.Diagnostics.ProcessStartInfo();
            psi.FileName=launcher;
            psi.WorkingDirectory=tempDir;
            psi.UseShellExecute=true;
            psi.Verb="runas";
            psi.WindowStyle=System.Diagnostics.ProcessWindowStyle.Normal;

            var proc=System.Diagnostics.Process.Start(psi);
            if(proc==null)throw new Exception("Windows did not create the elevated uninstall process.");

            tray.Visible=false;
            if(form!=null&&!form.IsDisposed)form.Hide();
            timer.Stop();
            Application.ExitThread();
        }
        catch(System.ComponentModel.Win32Exception ex){
            if(ex.NativeErrorCode==1223){
                MessageBox.Show(
                    "Windows canceled the administrator prompt, so nothing was removed.\n\nClick UNINSTALL AGENT again and choose Yes on the Windows UAC prompt.",
                    "Administrator approval required",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            } else {
                MessageBox.Show(
                    "Windows could not launch the elevated uninstaller.\n\n"+ex.Message+"\n\nYou can also use Start Menu > Uninstall Bench Hero Fleet.",
                    "Uninstall could not start",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
        catch(Exception ex){
            MessageBox.Show(
                "Uninstall could not start.\n\n"+ex.Message+"\n\nYou can also use Start Menu > Uninstall Bench Hero Fleet.",
                "Bench Hero Fleet",MessageBoxButtons.OK,MessageBoxIcon.Error);
        }
    }

    void OpenLogs(){
        try { Directory.CreateDirectory(dataDir); System.Diagnostics.Process.Start("explorer.exe", dataDir); }
        catch {}
    }

    protected override void ExitThreadCore(){ tray.Visible=false; tray.Dispose(); timer.Dispose(); if(form!=null&&!form.IsDisposed)form.Close(); base.ExitThreadCore(); }

    [STAThread]
    public static void Main(){ Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false); Application.Run(new FleetStatusApp()); }
}

public class StatusForm : Form {
    readonly Label banner=new Label(); readonly Label details=new Label(); readonly Label progressText=new Label(); readonly ProgressBar progress=new ProgressBar(); readonly Button refresh=new Button(); readonly Button uninstall=new Button(); readonly Button hide=new Button();
    readonly Action refreshAction; readonly Action uninstallAction;
    public StatusForm(Action refreshCallback,Action uninstallCallback){
        refreshAction=refreshCallback; uninstallAction=uninstallCallback;
        Text="Bench Hero Fleet"; ClientSize=new Size(560,438); MinimumSize=new Size(500,408); BackColor=Color.FromArgb(18,18,22); ForeColor=Color.White; StartPosition=FormStartPosition.CenterScreen;
        banner.SetBounds(18,18,524,62); banner.Font=new Font("Segoe UI",18,FontStyle.Bold); banner.TextAlign=ContentAlignment.MiddleCenter; Controls.Add(banner);
        details.SetBounds(24,94,512,178); details.Font=new Font("Segoe UI",10.5f); details.ForeColor=Color.Gainsboro; details.AutoSize=false; Controls.Add(details);
        progressText.SetBounds(24,278,512,22); progressText.Font=new Font("Segoe UI",10.5f,FontStyle.Bold); progressText.ForeColor=Color.White; progressText.Text="No maintenance job running"; Controls.Add(progressText);
        progress.SetBounds(24,302,512,18); progress.Minimum=0; progress.Maximum=100; progress.Style=ProgressBarStyle.Continuous; Controls.Add(progress);
        refresh.Text="REFRESH"; refresh.SetBounds(24,330,150,40); refresh.FlatStyle=FlatStyle.Flat; refresh.BackColor=Color.FromArgb(45,45,55); refresh.ForeColor=Color.White; refresh.Click+=(s,e)=>{if(refreshAction!=null)refreshAction();}; Controls.Add(refresh);
        uninstall.Text="UNINSTALL AGENT"; uninstall.SetBounds(190,330,180,40); uninstall.FlatStyle=FlatStyle.Flat; uninstall.BackColor=Color.FromArgb(120,35,35); uninstall.ForeColor=Color.White; uninstall.Click+=(s,e)=>{if(uninstallAction!=null)uninstallAction();}; Controls.Add(uninstall);
        hide.Text="HIDE TO TRAY"; hide.SetBounds(386,330,150,40); hide.FlatStyle=FlatStyle.Flat; hide.BackColor=Color.FromArgb(45,45,55); hide.ForeColor=Color.White; hide.Click+=(s,e)=>Hide(); Controls.Add(hide);
        var note=new Label(); note.SetBounds(24,380,512,40); note.Text="Uninstall removes the service, tray app, enrollment credentials, logs, startup entry and shortcuts."; note.Font=new Font("Segoe UI",9); note.ForeColor=Color.Silver; note.TextAlign=ContentAlignment.MiddleCenter; Controls.Add(note);
        FormClosing+=(s,e)=>{ if(e.CloseReason==CloseReason.UserClosing){e.Cancel=true;Hide();} };
    }
    public void SetStatus(string headline,Color color,string customer,string pc,string enrolled,string server,string last,string state,string task,string err,int taskPct,int jobPct,int taskIndex,int taskTotal){
        banner.Text=headline; banner.BackColor=color; banner.ForeColor=Color.White;
        var sb=new StringBuilder();
        sb.AppendLine("Customer / Company:  "+customer);
        sb.AppendLine("PC Name:             "+pc);
        sb.AppendLine("Enrollment:          "+enrolled);
        sb.AppendLine("Bench Hero Server:   "+server);
        sb.AppendLine("Last Check-in (UTC): "+last);
        sb.AppendLine("Agent State:         "+state);
        if(!String.IsNullOrWhiteSpace(task))sb.AppendLine("Current Task:        "+task);
        if(!String.IsNullOrWhiteSpace(err))sb.AppendLine("Last Error:          "+err);
        details.Text=sb.ToString();
        bool running=!String.IsNullOrWhiteSpace(task) || state.IndexOf("maintenance",StringComparison.OrdinalIgnoreCase)>=0;
        int shown=Math.Max(0,Math.Min(100,jobPct)); progress.Value=shown;
        if(running){
            string step=taskTotal>0 ? "Task "+taskIndex+" of "+taskTotal+" - " : "";
            progressText.Text=step+FriendlyTask(task)+"  |  "+shown+"% overall"+(taskPct>=0?"  ("+taskPct+"% current)":"");
        } else { progressText.Text="No maintenance job running"; progress.Value=0; }
    }
    string FriendlyTask(string task){
        switch(task){case "sfc":return "System File Checker";case "dism_scan":return "DISM ScanHealth";case "dism_restore":return "DISM RestoreHealth";case "chkdsk_scan":return "CHKDSK";case "defender_quick":return "Defender Quick Scan";case "crash_review":return "Crash Review";default:return String.IsNullOrWhiteSpace(task)?"Maintenance":task;}
    }
}
