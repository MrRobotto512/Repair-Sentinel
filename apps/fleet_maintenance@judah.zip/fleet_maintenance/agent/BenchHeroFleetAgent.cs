using System;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using Microsoft.Win32;

public class FleetService : ServiceBase {
    Thread worker; volatile bool stop;
    string dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Nash Nerds", "Bench Hero Fleet");
    Dictionary<string,object> cfg; JavaScriptSerializer js = new JavaScriptSerializer(){MaxJsonLength=2097152};
    string activeTask="", activeJobId=""; int activeTaskIndex=0, activeTaskTotal=0, activeTaskPercent=0, activeJobPercent=0; DateTime lastProgressPush=DateTime.MinValue;
    public FleetService(){ ServiceName="BenchHeroFleet"; CanStop=true; AutoLog=true; }
    protected override void OnStart(string[] args){ stop=false; Status("Starting"); worker=new Thread(Run); worker.IsBackground=true; worker.Start(); }
    protected override void OnStop(){ stop=true; Status("Stopped"); if(worker!=null) worker.Join(10000); }
    void Log(string s){ try{Directory.CreateDirectory(dataDir);File.AppendAllText(Path.Combine(dataDir,"agent.log"),DateTime.Now.ToString("s")+" "+s+Environment.NewLine);}catch{} }
    void Status(string state,string currentTask="",string lastError="",bool checkedIn=false,int taskPercent=-1,int jobPercent=-1,int taskIndex=-1,int taskTotal=-1){
        try{
            Directory.CreateDirectory(dataDir);
            if(taskPercent<0)taskPercent=activeTaskPercent;
            if(jobPercent<0)jobPercent=activeJobPercent;
            if(taskIndex<0)taskIndex=activeTaskIndex;
            if(taskTotal<0)taskTotal=activeTaskTotal;
            var d=new Dictionary<string,object>{{"state",state},{"current_task",currentTask},{"last_error",lastError},{"updated_utc",DateTime.UtcNow.ToString("o")},
                {"task_progress_percent",Math.Max(0,Math.Min(100,taskPercent))},{"job_progress_percent",Math.Max(0,Math.Min(100,jobPercent))},
                {"task_index",Math.Max(0,taskIndex)},{"task_total",Math.Max(0,taskTotal)}};
            if(checkedIn)d["last_checkin_utc"]=DateTime.UtcNow.ToString("o");
            else{
                string old=Path.Combine(dataDir,"status.json");
                if(File.Exists(old)){try{var prev=js.Deserialize<Dictionary<string,object>>(File.ReadAllText(old));object v;if(prev.TryGetValue("last_checkin_utc",out v))d["last_checkin_utc"]=v;}catch{}}
            }
            string tmp=Path.Combine(dataDir,"status.json.tmp"), dst=Path.Combine(dataDir,"status.json");
            File.WriteAllText(tmp,js.Serialize(d)); if(File.Exists(dst))File.Delete(dst); File.Move(tmp,dst);
        }catch{}
    }
    Dictionary<string,object> Load(){ return js.Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(dataDir,"config.json"))); }
    void Save(){ File.WriteAllText(Path.Combine(dataDir,"config.json"),js.Serialize(cfg)); }
    void AddUrl(List<string> urls,string u){
        if(String.IsNullOrWhiteSpace(u))return;
        u=u.Trim().TrimEnd('/');
        if(!urls.Contains(u))urls.Add(u);
    }
    List<string> ServerUrls(){
        var urls=new List<string>();
        object raw;

        if(cfg.TryGetValue("bench_hostname",out raw)){
            string host=Convert.ToString(raw).Trim();
            if(host.Length>0){
                if(!host.Contains("."))host += ".local";
                AddUrl(urls,"http://"+host+":8379");
                try{
                    foreach(var ip in Dns.GetHostAddresses(host)){
                        if(ip.AddressFamily==AddressFamily.InterNetwork)
                            AddUrl(urls,"http://"+ip.ToString()+":8379");
                    }
                }catch(Exception e){Log("Hostname resolution failed for "+host+": "+e.Message);}
            }
        }

        if(cfg.TryGetValue("server_url",out raw)) AddUrl(urls,Convert.ToString(raw));
        if(cfg.TryGetValue("server_urls",out raw)){
            var arr=raw as ArrayList;
            if(arr!=null)foreach(object x in arr)AddUrl(urls,Convert.ToString(x));
        }
        return urls;
    }
    List<string> DiscoverBenchHero(){
        var found=new List<string>();
        UdpClient udp=null;
        try{
            udp=new UdpClient();
            udp.EnableBroadcast=true;
            udp.Client.ReceiveTimeout=1800;
            byte[] msg=Encoding.UTF8.GetBytes("BENCHHERO_FLEET_DISCOVER_V1");
            udp.Send(msg,msg.Length,new IPEndPoint(IPAddress.Broadcast,8379));
            DateTime until=DateTime.UtcNow.AddMilliseconds(1900);
            while(DateTime.UtcNow<until){
                try{
                    IPEndPoint ep=new IPEndPoint(IPAddress.Any,0);
                    byte[] raw=udp.Receive(ref ep);
                    string txt=Encoding.UTF8.GetString(raw);
                    var d=js.Deserialize<Dictionary<string,object>>(txt);
                    object service;
                    if(!d.TryGetValue("service",out service) || Convert.ToString(service)!="Bench Hero Fleet")continue;
                    object url;
                    if(d.TryGetValue("url",out url))AddUrl(found,Convert.ToString(url));
                    object host;
                    if(d.TryGetValue("hostname",out host)){
                        string h=Convert.ToString(host).Trim();
                        if(h.Length>0)AddUrl(found,"http://"+h+":8379");
                    }
                }catch(SocketException){break;}
                catch(Exception e){Log("Discovery packet ignored: "+e.Message);}
            }
        }catch(Exception e){Log("LAN discovery failed: "+e.Message);}
        finally{if(udp!=null)udp.Close();}
        return found;
    }
    string TryPostTo(string baseUrl,string path,byte[] raw,string token){
        var req=(HttpWebRequest)WebRequest.Create(baseUrl+path);
        req.Method="POST";
        req.ContentType="application/json";
        req.Timeout=12000;
        req.ReadWriteTimeout=12000;
        req.ContentLength=raw.Length;
        if(!String.IsNullOrEmpty(token))req.Headers["Authorization"]="Bearer "+token;
        using(var st=req.GetRequestStream())st.Write(raw,0,raw.Length);
        using(var rsp=(HttpWebResponse)req.GetResponse())
        using(var sr=new StreamReader(rsp.GetResponseStream())){
            string result=sr.ReadToEnd();
            cfg["server_url"]=baseUrl;
            var merged=new List<string>();
            AddUrl(merged,baseUrl);
            foreach(string u in ServerUrls())AddUrl(merged,u);
            cfg["server_urls"]=merged.ToArray();
            Save();
            return result;
        }
    }
    string Post(string path, object body, string token=null){
        byte[] raw=Encoding.UTF8.GetBytes(js.Serialize(body));
        Exception last=null;
        var tried=new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach(string baseUrl in ServerUrls()){
            if(!tried.Add(baseUrl))continue;
            try{return TryPostTo(baseUrl,path,raw,token);}
            catch(Exception e){last=e;Log("Server failed "+baseUrl+": "+e.Message);}
        }

        foreach(string baseUrl in DiscoverBenchHero()){
            if(!tried.Add(baseUrl))continue;
            try{
                Log("Discovered Bench Hero at "+baseUrl);
                return TryPostTo(baseUrl,path,raw,token);
            }catch(Exception e){last=e;Log("Discovered server failed "+baseUrl+": "+e.Message);}
        }

        throw new Exception("Bench Hero could not be reached. Tried saved hostname/IP addresses and automatic LAN discovery.",last);
    }
    string Wmi(string cls,string prop){
        try{
            string cmd="$x=Get-CimInstance "+cls+" | Select-Object -First 1 -ExpandProperty "+prop+"; [string]$x";
            return RunProcess("powershell.exe","-NoProfile -ExecutionPolicy Bypass -Command \""+cmd.Replace("\"","\\\"")+"\"",60).output.Trim();
        }catch{return "";}
    }
    string Reg(string name){
        try{return Convert.ToString(Registry.GetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion",name,""));}
        catch{return "";}
    }
    string WindowsName(){
        try{
            string product=Reg("ProductName");
            string edition=Reg("EditionID");
            string display=Reg("DisplayVersion");
            string buildText=Reg("CurrentBuildNumber");
            int build=0;
            Int32.TryParse(buildText,out build);

            string family;
            if(build>=22000) family="Windows 11";
            else if(build>=10240) family="Windows 10";
            else family=product.Length>0?product:"Windows";

            string suffix="";
            var map=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase){
                {"Professional","Pro"},{"ProfessionalN","Pro N"},
                {"Core","Home"},{"CoreN","Home N"},
                {"Enterprise","Enterprise"},{"EnterpriseN","Enterprise N"},
                {"Education","Education"},{"EducationN","Education N"},
                {"IoTEnterprise","IoT Enterprise"}
            };
            string nice;
            if(!String.IsNullOrWhiteSpace(edition))
                suffix=map.TryGetValue(edition,out nice)?nice:edition;
            else if(product.Length>0)
                suffix=Regex.Replace(product,@"^Microsoft\s+Windows\s+(10|11)\s*","",RegexOptions.IgnoreCase).Trim();

            string name=family+(suffix.Length>0?" "+suffix:"");
            if(display.Length>0)name+=" "+display;
            if(build>0)name+=" (Build "+build+")";
            return name;
        }catch{
            string cap=Wmi("Win32_OperatingSystem","Caption");
            return String.IsNullOrWhiteSpace(cap)?"Windows":cap;
        }
    }
    void Run(){
        while(!stop){
            try{
                cfg=Load(); string did=cfg.ContainsKey("device_id")?Convert.ToString(cfg["device_id"]):"";
                if(String.IsNullOrEmpty(did)) Enroll(); else CheckIn();
            }catch(Exception e){Log(e.ToString());Status("Connection error","",e.Message);}
            for(int i=0;i<30 && !stop;i++)Thread.Sleep(1000);
        }
    }
    void Enroll(){
        var body=new Dictionary<string,object>{{"enrollment_code",cfg["enrollment_code"]},{"customer_name",cfg["customer_name"]},{"pc_name",cfg["pc_name"]},{"hostname",Environment.MachineName},{"model",Wmi("Win32_ComputerSystem","Model")},{"windows",WindowsName()},{"agent_version","2.3.1"}};
        var rsp=js.Deserialize<Dictionary<string,object>>(Post("/api/enroll",body));cfg["device_id"]=rsp["device_id"];cfg["device_token"]=rsp["device_token"];Save();Log("Enrolled "+cfg["device_id"]);Status("Online","","",true);
    }
    void CheckIn(){
        string did=Convert.ToString(cfg["device_id"]), tok=Convert.ToString(cfg["device_token"]);
        var body=new Dictionary<string,object>{{"device_id",did},{"hostname",Environment.MachineName},{"model",Wmi("Win32_ComputerSystem","Model")},{"windows",WindowsName()},{"agent_version","2.3.1"},{"status","online"}};
        var rsp=js.Deserialize<Dictionary<string,object>>(Post("/api/checkin",body,tok));Status("Online","","",true);Log("Check-in successful");
        if(!rsp.ContainsKey("jobs"))return; var jobs=rsp["jobs"] as System.Collections.ArrayList; if(jobs==null)return;
        foreach(object jo in jobs){var j=jo as Dictionary<string,object>;if(j!=null)RunJob(j,did,tok);}
    }
    void RunJob(Dictionary<string,object> job,string did,string tok){
        string jid=Convert.ToString(job["id"]);activeJobId=jid;var results=new List<Dictionary<string,object>>();var arr=job["tasks"] as System.Collections.ArrayList;
        activeTaskTotal=arr==null?0:arr.Count; activeTaskIndex=0; activeTaskPercent=0; activeJobPercent=0;
        if(arr!=null)foreach(object t in arr){
            activeTaskIndex++; activeTask=Convert.ToString(t); activeTaskPercent=0;
            activeJobPercent=activeTaskTotal>0?(int)Math.Floor(((activeTaskIndex-1)*100.0)/activeTaskTotal):0;
            Status("Running maintenance",activeTask,"",false,activeTaskPercent,activeJobPercent,activeTaskIndex,activeTaskTotal); PushProgress("Starting "+activeTask);
            results.Add(ExecuteTask(activeTask));
            activeTaskPercent=100; activeJobPercent=activeTaskTotal>0?(int)Math.Floor((activeTaskIndex*100.0)/activeTaskTotal):100;
            Status("Running maintenance",activeTask,"",false,100,activeJobPercent,activeTaskIndex,activeTaskTotal); PushProgress("Completed "+activeTask);
        }
        string status="completed";foreach(var r in results)if(Convert.ToString(r["status"])=="failed")status="completed_with_errors";
        Post("/api/job-result",new Dictionary<string,object>{{"device_id",did},{"job_id",jid},{"status",status},{"results",results}},tok);
        activeTask="";activeJobId="";activeTaskIndex=0;activeTaskTotal=0;activeTaskPercent=0;activeJobPercent=0;Status("Online","","",true,0,0,0,0);
    }
    string PsQuote(string text){
        return "'" + (text??"").Replace("'","''") + "'";
    }
    string PowerShellUtf8Prefix(){
        return "$utf8=New-Object System.Text.UTF8Encoding($false); [Console]::OutputEncoding=$utf8; $OutputEncoding=$utf8; ";
    }
    string SanitizeOutput(string text){
        if(String.IsNullOrEmpty(text))return "";
        // Some Windows utilities emit UTF-16 style NUL padding when redirected.
        // Strip the padding before JSON transport rather than rendering it as '?' on the Pi.
        text=text.Replace("\0","");
        text=text.Replace("\uFFFD","");
        return text;
    }
    string SystemInfoScript(){
        return PowerShellUtf8Prefix() +
        "$os=Get-CimInstance Win32_OperatingSystem; " +
        "$cs=Get-CimInstance Win32_ComputerSystem; " +
        "$bios=Get-CimInstance Win32_BIOS; " +
        "$cpu=Get-CimInstance Win32_Processor | Select-Object -First 1; " +
        "$ram=Get-CimInstance Win32_PhysicalMemory; " +
        "$gpu=Get-CimInstance Win32_VideoController; " +
        "$disks=Get-CimInstance Win32_DiskDrive; " +
        "$cv=Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion'; " +
        "$build=[int]$cv.CurrentBuildNumber; " +
        "$family=if($build -ge 22000){'Windows 11'}elseif($build -ge 10240){'Windows 10'}else{$os.Caption}; " +
        "Write-Output ('COMPUTER: '+$env:COMPUTERNAME); " +
        "Write-Output ('MANUFACTURER: '+$cs.Manufacturer); " +
        "Write-Output ('MODEL: '+$cs.Model); " +
        "Write-Output ('OS: '+$family+' '+$cv.EditionID+' '+$cv.DisplayVersion+' (Build '+$build+')'); " +
        "Write-Output ('BIOS: '+$bios.Manufacturer+' '+$bios.SMBIOSBIOSVersion); " +
        "Write-Output ('CPU: '+$cpu.Name.Trim()+' | '+$cpu.NumberOfCores+' cores / '+$cpu.NumberOfLogicalProcessors+' threads'); " +
        "Write-Output ('RAM TOTAL: '+[math]::Round($cs.TotalPhysicalMemory/1GB,1)+' GB'); " +
        "$i=0; foreach($m in $ram){$i++; Write-Output ('RAM '+$i+': '+[math]::Round($m.Capacity/1GB,1)+' GB | '+$m.Manufacturer+' | '+$m.PartNumber.Trim()+' | '+$m.ConfiguredClockSpeed+' MHz')}; " +
        "$i=0; foreach($g in $gpu){$i++; Write-Output ('GPU '+$i+': '+$g.Name+' | Driver '+$g.DriverVersion)}; " +
        "$i=0; foreach($d in $disks){$i++; Write-Output ('DRIVE '+$i+': '+$d.Model+' | '+[math]::Round($d.Size/1GB,1)+' GB | '+$d.InterfaceType+' | Status '+$d.Status)}; " +
        "Write-Output ('UPTIME: '+((Get-Date)-$os.LastBootUpTime).ToString());";
    }
    string DeviceManagerScript(){
        return PowerShellUtf8Prefix() +
        "$bad=Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object {$_.ConfigManagerErrorCode -ne 0}; " +
        "if(-not $bad){Write-Output 'NO DEVICE MANAGER ERRORS FOUND'; exit 0}; " +
        "foreach($d in $bad){ " +
        "$code=[int]$d.ConfigManagerErrorCode; " +
        "$meaning=switch($code){1{'Device is not configured correctly'}3{'Driver may be corrupted'}10{'Device cannot start'}12{'Insufficient resources'}18{'Reinstall drivers'}19{'Registry configuration problem'}22{'Device is disabled'}28{'Drivers are not installed'}31{'Windows cannot load required drivers'}43{'Device reported a problem'}default{'See Device Manager code documentation'}}; " +
        "Write-Output ('DEVICE: '+$d.Name); Write-Output ('STATUS: '+$d.Status); Write-Output ('ERROR CODE: '+$code+' - '+$meaning); Write-Output ('PNP ID: '+$d.PNPDeviceID); Write-Output ''; }";
    }
    string CrashReviewScript(){
        return PowerShellUtf8Prefix() +
        "$s=(Get-Date).AddDays(-30); " +
        "$events=Get-WinEvent -FilterHashtable @{LogName='System';StartTime=$s;Id=41,1001,6008,1074,19,20,46,7,11,15,51,55,129,153} -ErrorAction SilentlyContinue | Select-Object -First 150; " +
        "if(-not $events){Write-Output 'NO MATCHING CRASH, SHUTDOWN, WHEA, OR STORAGE EVENTS FOUND IN THE LAST 30 DAYS'; exit 0}; " +
        "foreach($e in $events){ " +
        "$msg=($e.Message -replace '[\\r\\n]+',' '); " +
        "Write-Output ($e.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss')+' | Event '+$e.Id+' | '+$e.ProviderName+' | '+$e.LevelDisplayName); " +
        "Write-Output $msg; Write-Output ''; }";
    }
    string DefenderFullScanScript(){
        return PowerShellUtf8Prefix() +
        "$ErrorActionPreference='SilentlyContinue'; " +
        "Update-MpSignature; Start-MpScan -ScanType FullScan; " +
        "$status=Get-MpComputerStatus; " +
        "Write-Output ('DEFENDER ENABLED: '+$status.AntivirusEnabled); " +
        "Write-Output ('REALTIME PROTECTION: '+$status.RealTimeProtectionEnabled); " +
        "Write-Output ('SIGNATURE AGE: '+$status.AntivirusSignatureAge); " +
        "Write-Output ('FULL SCAN AGE: '+$status.FullScanAge); " +
        "$d=Get-MpThreatDetection | Sort-Object InitialDetectionTime -Descending | Select-Object -First 50; " +
        "if($d){Write-Output 'THREAT DETECTIONS:'; foreach($t in $d){Write-Output ($t.InitialDetectionTime.ToString('yyyy-MM-dd HH:mm:ss')+' | '+$t.ThreatName+' | ActionSuccess='+$t.ActionSuccess+' | Resources='+(($t.Resources -join '; ')))}} " +
        "else{Write-Output 'NO THREAT DETECTIONS REPORTED'}";
    }
    string AdwareReviewScript(){
        return PowerShellUtf8Prefix() +
        "$ErrorActionPreference='SilentlyContinue'; " +
        "Write-Output 'STARTUP ENTRIES'; " +
        "Get-CimInstance Win32_StartupCommand | Sort-Object Name | ForEach-Object {Write-Output ($_.Name+' | '+$_.Command+' | '+$_.Location)}; " +
        "Write-Output ''; Write-Output 'SCHEDULED TASKS - NON-MICROSOFT'; " +
        "Get-ScheduledTask | Where-Object {$_.TaskPath -notlike '\\Microsoft\\*'} | ForEach-Object {Write-Output ($_.TaskPath+$_.TaskName+' | '+$_.State)}; " +
        "Write-Output ''; Write-Output 'INSTALLED SOFTWARE'; " +
        "$apps=@(); $keys=@('HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*','HKLM:\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*','HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*'); " +
        "foreach($k in $keys){$apps += Get-ItemProperty $k | Where-Object {$_.DisplayName}}; " +
        "$apps | Sort-Object DisplayName -Unique | ForEach-Object {Write-Output ($_.DisplayName+' | '+$_.Publisher+' | '+$_.InstallDate)}; " +
        "Write-Output ''; Write-Output 'BROWSER EXTENSIONS'; " +
        "$roots=@(@{n='Chrome';p=\"$env:LOCALAPPDATA\\Google\\Chrome\\User Data\"},@{n='Edge';p=\"$env:LOCALAPPDATA\\Microsoft\\Edge\\User Data\"},@{n='Brave';p=\"$env:LOCALAPPDATA\\BraveSoftware\\Brave-Browser\\User Data\"}); " +
        "foreach($r in $roots){if(Test-Path $r.p){Get-ChildItem $r.p -Directory | Where-Object {$_.Name -match '^(Default|Profile )'} | ForEach-Object {$ext=Join-Path $_.FullName 'Extensions'; if(Test-Path $ext){Get-ChildItem $ext -Directory | ForEach-Object {Write-Output ($r.n+' | '+$_.Name+' | '+$_.FullName)}}}}};";
    }
    string AdwareCleanupScript(){
        return PowerShellUtf8Prefix() +
        "$ErrorActionPreference='SilentlyContinue'; " +
        "Write-Output 'ADWARE CLEANUP - CONSERVATIVE MODE'; " +
        "Remove-Item $env:TEMP\\* -Recurse -Force -ErrorAction SilentlyContinue; " +
        "$policyRoots=@('HKCU:\\Software\\Policies\\Google\\Chrome','HKCU:\\Software\\Policies\\Microsoft\\Edge','HKLM:\\Software\\Policies\\Google\\Chrome','HKLM:\\Software\\Policies\\Microsoft\\Edge'); " +
        "foreach($p in $policyRoots){if(Test-Path $p){foreach($name in @('HomepageLocation','HomepageIsNewTabPage','RestoreOnStartup','RestoreOnStartupURLs','DefaultSearchProviderEnabled','DefaultSearchProviderName','DefaultSearchProviderSearchURL','DefaultSearchProviderSuggestURL')){Remove-ItemProperty -Path $p -Name $name -ErrorAction SilentlyContinue}; Write-Output ('CLEANED POLICY OVERRIDES: '+$p)}}; " +
        "Write-Output 'Cleanup complete. Installed applications and extensions were not silently removed.';";
    }
    string BrowserSearchResetScript(){
        return PowerShellUtf8Prefix() +
        "$ErrorActionPreference='SilentlyContinue'; " +
        "$browsers=@(@{n='Chrome';p=\"$env:LOCALAPPDATA\\Google\\Chrome\\User Data\"},@{n='Edge';p=\"$env:LOCALAPPDATA\\Microsoft\\Edge\\User Data\"},@{n='Brave';p=\"$env:LOCALAPPDATA\\BraveSoftware\\Brave-Browser\\User Data\"}); " +
        "foreach($b in $browsers){if(Test-Path $b.p){Get-ChildItem $b.p -Directory | Where-Object {$_.Name -match '^(Default|Profile )'} | ForEach-Object {$prof=$_.Name; $pref=Join-Path $_.FullName 'Preferences'; if(Test-Path $pref){try{$j=Get-Content $pref -Raw | ConvertFrom-Json; if($j.default_search_provider_data){$j.PSObject.Properties.Remove('default_search_provider_data')}; if($j.default_search_provider){$j.PSObject.Properties.Remove('default_search_provider')}; if($j.search){$j.PSObject.Properties.Remove('search')}; $tmp=$pref+'.benchhero.tmp'; $j | ConvertTo-Json -Depth 100 | Set-Content $tmp -Encoding UTF8; Move-Item $tmp $pref -Force; Write-Output ('RESET SEARCH OVERRIDES: '+$b.n+' | '+$prof)}catch{Write-Output ('SKIPPED '+$b.n+' | '+$prof+' | '+$_.Exception.Message)}}}}}}; " +
        "Write-Output 'Firefox search-engine cleanup is left for manual review.';";
    }
    string BrowserNotificationResetScript(){
        return PowerShellUtf8Prefix() +
        "$ErrorActionPreference='SilentlyContinue'; " +
        "Write-Output 'BROWSER NOTIFICATION RESET'; " +
        "$browsers=@(" +
        "@{n='Chrome';p=\"$env:LOCALAPPDATA\\Google\\Chrome\\User Data\"}," +
        "@{n='Edge';p=\"$env:LOCALAPPDATA\\Microsoft\\Edge\\User Data\"}," +
        "@{n='Brave';p=\"$env:LOCALAPPDATA\\BraveSoftware\\Brave-Browser\\User Data\"}" +
        "); " +
        "foreach($b in $browsers){if(Test-Path $b.p){ " +
        "Get-ChildItem $b.p -Directory | Where-Object {$_.Name -match '^(Default|Profile )'} | ForEach-Object {" +
        "$prof=$_.Name; $pref=Join-Path $_.FullName 'Preferences'; " +
        "if(Test-Path $pref){try{" +
        "$j=Get-Content $pref -Raw | ConvertFrom-Json; " +
        "$changed=$false; " +
        "if($j.profile -and $j.profile.content_settings -and $j.profile.content_settings.exceptions -and $j.profile.content_settings.exceptions.notifications){" +
        "$j.profile.content_settings.exceptions.notifications=New-Object PSCustomObject; $changed=$true}; " +
        "if($j.profile -and $j.profile.default_content_setting_values -and $j.profile.default_content_setting_values.notifications){" +
        "$j.profile.default_content_setting_values.notifications=2; $changed=$true}; " +
        "if($changed){$tmp=$pref+'.benchhero.tmp'; $j | ConvertTo-Json -Depth 100 | Set-Content $tmp -Encoding UTF8; Move-Item $tmp $pref -Force; " +
        "Write-Output ('CLEARED WEBSITE NOTIFICATIONS: '+$b.n+' | '+$prof)} " +
        "else{Write-Output ('NO NOTIFICATION EXCEPTIONS FOUND: '+$b.n+' | '+$prof)}" +
        "}catch{Write-Output ('SKIPPED '+$b.n+' | '+$prof+' | '+$_.Exception.Message)}}}}}}; " +
        "Write-Output 'Firefox notification permissions are left for manual review because permissions.sqlite should not be edited while Firefox is in use.';";
    }
    Dictionary<string,object> ExecuteTask(string task){
        string exe="cmd.exe", args="/d /s /c ", summary=""; int timeout=3600;
        switch(task){
            // Force UTF-8 console output for native Windows tools.
            case "sfc":
                args+="\"chcp 65001>nul & sfc /scannow\"";
                break;
            case "dism_scan":
                args+="\"chcp 65001>nul & DISM /Online /Cleanup-Image /ScanHealth\"";
                break;
            case "dism_restore":
                args+="\"chcp 65001>nul & DISM /Online /Cleanup-Image /RestoreHealth\"";
                break;
            case "chkdsk_scan":
                args+="\"chcp 65001>nul & chkdsk C: /scan\"";
                break;
            case "defender_quick":
                exe="powershell.exe";
                args="-NoProfile -ExecutionPolicy Bypass -Command \""+
                    (PowerShellUtf8Prefix()+"Start-MpScan -ScanType QuickScan; Get-MpComputerStatus | Select AntivirusEnabled,RealTimeProtectionEnabled,QuickScanAge | Format-List").Replace("\"","\\\"")+"\"";
                break;
            case "system_info":
                exe="powershell.exe";
                args="-NoProfile -ExecutionPolicy Bypass -Command \""+SystemInfoScript().Replace("\"","\\\"")+"\"";
                timeout=180;
                break;
            case "device_manager":
                exe="powershell.exe";
                args="-NoProfile -ExecutionPolicy Bypass -Command \""+DeviceManagerScript().Replace("\"","\\\"")+"\"";
                timeout=180;
                break;
            case "crash_review":
                exe="powershell.exe";
                args="-NoProfile -ExecutionPolicy Bypass -Command \""+CrashReviewScript().Replace("\"","\\\"")+"\"";
                timeout=300;
                break;
            case "defender_full":
                exe="powershell.exe";
                args="-NoProfile -ExecutionPolicy Bypass -Command \""+DefenderFullScanScript().Replace("\"","\\\"")+"\"";
                timeout=14400;
                break;
            case "adware_review":
                exe="powershell.exe";
                args="-NoProfile -ExecutionPolicy Bypass -Command \""+AdwareReviewScript().Replace("\"","\\\"")+"\"";
                timeout=600;
                break;
            case "adware_cleanup":
                exe="powershell.exe";
                args="-NoProfile -ExecutionPolicy Bypass -Command \""+AdwareCleanupScript().Replace("\"","\\\"")+"\"";
                timeout=600;
                break;
            case "browser_search_reset":
                exe="powershell.exe";
                args="-NoProfile -ExecutionPolicy Bypass -Command \""+BrowserSearchResetScript().Replace("\"","\\\"")+"\"";
                timeout=600;
                break;
            case "browser_notifications_reset":
                exe="powershell.exe";
                args="-NoProfile -ExecutionPolicy Bypass -Command \""+BrowserNotificationResetScript().Replace("\"","\\\"")+"\"";
                timeout=600;
                break;
            default:
                return Result(task,"failed",-1,"Unknown task","Task is not in the agent allowlist.");
        }
        var rr=RunProcess(exe,args,timeout,(line)=>UpdateProgressFromOutput(task,line));
        rr.output=SanitizeOutput(rr.output);
        summary=Summarize(task,rr.code,rr.output);
        return Result(task,rr.code==0?"completed":"failed",rr.code,summary,rr.output);
    }
    Dictionary<string,object> Result(string t,string s,int c,string sum,string output){return new Dictionary<string,object>{{"task",t},{"status",s},{"exit_code",c},{"summary",sum},{"output",output},{"completed_at",DateTime.UtcNow.ToString("o")}};}
    string Summarize(string task,int code,string output){
        string l=(output??"").ToLowerInvariant();
        if(task=="sfc"){if(l.Contains("did not find any integrity violations"))return "Windows Resource Protection found no integrity violations.";if(l.Contains("found corrupt files and successfully repaired"))return "SFC repaired corrupted Windows files.";if(l.Contains("found corrupt files but was unable"))return "SFC found corruption it could not fully repair.";}
        if(task.StartsWith("dism")){if(l.Contains("restore operation completed successfully")||l.Contains("component store corruption detected")&&code==0)return "DISM completed successfully.";}
        if(task=="chkdsk_scan"&&code==0)return "CHKDSK online scan completed.";
        if(task=="crash_review")return String.IsNullOrWhiteSpace(output)?"No matching crash or shutdown events found in the last 30 days.":"Crash and shutdown events were collected for review.";
        if(task=="system_info")return code==0?"System information collected.":"System information collection returned an error.";
        if(task=="defender_full")return code==0?"Windows Defender full scan completed.":"Windows Defender full scan returned an error.";
        if(task=="adware_review")return code==0?"Startup items, scheduled tasks, installed apps, and browser extensions were collected for adware review.":"Adware review returned an error.";
        if(task=="adware_cleanup")return code==0?"Conservative adware cleanup completed.":"Adware cleanup returned an error.";
        if(task=="browser_search_reset")return code==0?"Chrome/Edge/Brave search overrides were reset where possible.":"Browser search reset returned an error.";
        if(task=="browser_notifications_reset")return code==0?"Website notification permissions were cleared for Chrome/Edge/Brave profiles where possible.":"Browser notification reset returned an error.";
        if(task=="device_manager"){
            if((output??"").IndexOf("NO DEVICE MANAGER ERRORS FOUND",StringComparison.OrdinalIgnoreCase)>=0)return "No Device Manager errors were found.";
            return code==0?"Device Manager problem devices were collected.":"Device Manager scan returned an error.";
        }
        return code==0?"Task completed successfully.":"Task returned an error. Review the technical output.";
    }
    void PushProgress(string message=""){
        if(String.IsNullOrEmpty(activeJobId) || !cfg.ContainsKey("device_id") || !cfg.ContainsKey("device_token"))return;
        try{
            // Keep progress useful without hammering the Pi for every output line.
            if((DateTime.UtcNow-lastProgressPush).TotalMilliseconds<700 && activeTaskPercent<100)return;
            lastProgressPush=DateTime.UtcNow;
            Post("/api/job-progress",new Dictionary<string,object>{
                {"device_id",Convert.ToString(cfg["device_id"])},{"job_id",activeJobId},{"task",activeTask},
                {"task_index",activeTaskIndex},{"task_total",activeTaskTotal},{"task_percent",activeTaskPercent},
                {"job_percent",activeJobPercent},{"message",message}
            },Convert.ToString(cfg["device_token"]));
        }catch(Exception e){Log("Progress push failed: "+e.Message);}
    }

    void UpdateProgressFromOutput(string task,string line){
        if(String.IsNullOrWhiteSpace(line))return;
        try{
            var m=Regex.Match(line,@"(?<!\d)(\d{1,3}(?:[\.,]\d+)?)\s*%");
            if(!m.Success)return;
            double parsed; if(!Double.TryParse(m.Groups[1].Value.Replace(',','.'),System.Globalization.NumberStyles.Any,System.Globalization.CultureInfo.InvariantCulture,out parsed))return;
            int pct=Math.Max(0,Math.Min(100,(int)Math.Round(parsed)));
            if(pct<activeTaskPercent && activeTaskPercent-pct<20)return;
            activeTaskPercent=pct;
            activeJobPercent=activeTaskTotal>0?(int)Math.Floor((((activeTaskIndex-1)+(pct/100.0))*100.0)/activeTaskTotal):pct;
            Status("Running maintenance",task,"",false,activeTaskPercent,activeJobPercent,activeTaskIndex,activeTaskTotal); PushProgress(line);
        }catch{}
    }
    struct ProcResult{public int code;public string output;}
    ProcResult RunProcess(string exe,string args,int timeoutSec,Action<string> onLine=null){
        var p=new Process();
        var psi=new ProcessStartInfo(exe,args){
            UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true,
            StandardOutputEncoding=new UTF8Encoding(false),StandardErrorEncoding=new UTF8Encoding(false)
        };
        p.StartInfo=psi;
        var sb=new StringBuilder();
        DataReceivedEventHandler handler=(sender,e)=>{
            if(e.Data!=null){
                string line=SanitizeOutput(e.Data);
                if(sb.Length<100000)sb.AppendLine(line);
                if(onLine!=null)onLine(line);
            }
        };
        p.OutputDataReceived+=handler;p.ErrorDataReceived+=handler;
        p.Start();p.BeginOutputReadLine();p.BeginErrorReadLine();
        if(!p.WaitForExit(timeoutSec*1000)){
            try{p.Kill();}catch{}
            return new ProcResult{code=-2,output="Task timed out."};
        }
        p.WaitForExit();
        return new ProcResult{code=p.ExitCode,output=SanitizeOutput(sb.ToString())};
    }
    ProcResult RunProcess(string exe,string args,int timeoutSec){return RunProcess(exe,args,timeoutSec,null);}
    public static void Main(){ServiceBase.Run(new FleetService());}
}
