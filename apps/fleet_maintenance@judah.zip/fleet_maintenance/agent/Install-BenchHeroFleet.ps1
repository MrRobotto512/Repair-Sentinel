#Requires -RunAsAdministrator
$ErrorActionPreference='Stop'
$Here=Split-Path -Parent $MyInvocation.MyCommand.Path
$Enroll=Get-Content (Join-Path $Here 'enrollment.json') -Raw | ConvertFrom-Json
Write-Host "BENCH HERO FLEET ENROLLMENT" -ForegroundColor Cyan
Write-Host ("Bench: " + $Enroll.bench_hostname) -ForegroundColor DarkCyan
$Customer=Read-Host 'Customer or company name'
$DefaultPC=$env:COMPUTERNAME
$PC=Read-Host "Friendly PC name [$DefaultPC]"
if([string]::IsNullOrWhiteSpace($PC)){$PC=$DefaultPC}
$Dir=Join-Path $env:ProgramData 'Nash Nerds\Bench Hero Fleet'
Write-Host 'Installing a self-contained local copy. The USB can be removed after setup completes.' -ForegroundColor DarkGray
New-Item -ItemType Directory -Path $Dir -Force | Out-Null
$Exe=Join-Path $Dir 'BenchHeroFleetAgent.exe'
$StatusExe=Join-Path $Dir 'BenchHeroFleetStatus.exe'
$AgentSourcePath=Join-Path $Here 'BenchHeroFleetAgent.cs'
$StatusSourcePath=Join-Path $Here 'BenchHeroFleetStatus.cs'
$UninstallSourcePath=Join-Path $Here 'Uninstall-BenchHeroFleet.ps1'
if(-not (Test-Path $AgentSourcePath)){ throw "Installer package is incomplete: BenchHeroFleetAgent.cs is missing. Recreate the Agent USB from Fleet Maintenance." }
if(-not (Test-Path $StatusSourcePath)){ throw "Installer package is incomplete: BenchHeroFleetStatus.cs is missing. Recreate the Agent USB from Fleet Maintenance v1.6 or newer." }
if(-not (Test-Path $UninstallSourcePath)){ throw "Installer package is incomplete: Uninstall-BenchHeroFleet.ps1 is missing. Recreate the Agent USB from Fleet Maintenance v1.6 or newer." }
$Source=Get-Content $AgentSourcePath -Raw
$StatusSource=Get-Content $StatusSourcePath -Raw
$InstalledUninstaller=Join-Path $Dir 'Uninstall-BenchHeroFleet.ps1'
Copy-Item $UninstallSourcePath $InstalledUninstaller -Force
if(Get-Service BenchHeroFleet -ErrorAction SilentlyContinue){
    Stop-Service BenchHeroFleet -Force -ErrorAction SilentlyContinue
    sc.exe delete BenchHeroFleet | Out-Null
    Start-Sleep 2
}
Get-Process BenchHeroFleetStatus -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 500
Remove-Item $Exe,$StatusExe -Force -ErrorAction SilentlyContinue
Add-Type -TypeDefinition $Source -Language CSharp -OutputAssembly $Exe -OutputType ConsoleApplication -ReferencedAssemblies @('System.dll','System.Core.dll','System.ServiceProcess.dll','System.Web.Extensions.dll')
Add-Type -TypeDefinition $StatusSource -Language CSharp -OutputAssembly $StatusExe -OutputType WindowsApplication -ReferencedAssemblies @('System.dll','System.Core.dll','System.Drawing.dll','System.Windows.Forms.dll','System.ServiceProcess.dll','System.Web.Extensions.dll')
$Urls=@()
if($Enroll.server_urls){$Urls=@($Enroll.server_urls)}
elseif($Enroll.server_url){$Urls=@([string]$Enroll.server_url)}
$Cfg=[ordered]@{
    server_url=[string]$Enroll.server_url
    server_urls=$Urls
    bench_hostname=[string]$Enroll.bench_hostname
    enrollment_code=[string]$Enroll.enrollment_code
    customer_name=$Customer
    pc_name=$PC
    device_id=''
    device_token=''
}
$Cfg | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $Dir 'config.json') -Encoding UTF8
# Keep all runtime files local; nothing below points back to the installer USB.
Copy-Item $AgentSourcePath (Join-Path $Dir 'BenchHeroFleetAgent.cs') -Force
Copy-Item $StatusSourcePath (Join-Path $Dir 'BenchHeroFleetStatus.cs') -Force
sc.exe create BenchHeroFleet binPath= "`"$Exe`"" start= auto DisplayName= "Bench Hero Fleet Agent" | Out-Null
sc.exe description BenchHeroFleet "Nash Nerds authorized maintenance agent" | Out-Null
Start-Service BenchHeroFleet
$RunKey='HKLM:\Software\Microsoft\Windows\CurrentVersion\Run'
New-ItemProperty -Path $RunKey -Name 'BenchHeroFleetStatus' -Value ('"'+$StatusExe+'"') -PropertyType String -Force | Out-Null
$StartMenu=Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Bench Hero Fleet.lnk'
$Wsh=New-Object -ComObject WScript.Shell
$Shortcut=$Wsh.CreateShortcut($StartMenu)
$Shortcut.TargetPath=$StatusExe
$Shortcut.WorkingDirectory=$Dir
$Shortcut.Description='View Bench Hero Fleet agent status'
$Shortcut.Save()
$UninstallShortcutPath=Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\Uninstall Bench Hero Fleet.lnk'
$UninstallShortcut=$Wsh.CreateShortcut($UninstallShortcutPath)
$UninstallShortcut.TargetPath='powershell.exe'
$UninstallShortcut.Arguments='-NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -Verb RunAs -ArgumentList ''-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"'+$InstalledUninstaller+'`"''"'
$UninstallShortcut.WorkingDirectory=$Dir
$UninstallShortcut.Description='Completely remove Bench Hero Fleet from this computer'
$UninstallShortcut.Save()
Start-Process $StatusExe
Write-Host "Installed locally and started. You can now unplug the Agent USB.  The green Bench Hero Fleet status window confirms the agent is running and connected." -ForegroundColor Green
Write-Host "A tray icon and Start Menu shortcut were also installed." -ForegroundColor Green
Write-Host ("Primary Bench address: " + $Cfg.server_url) -ForegroundColor Cyan
Write-Host "The agent will use the Pi hostname first and the current IP only as a fallback." -ForegroundColor DarkGray
Write-Host "To remove, use the UNINSTALL AGENT button in the status window or Start Menu > Uninstall Bench Hero Fleet." -ForegroundColor Yellow
