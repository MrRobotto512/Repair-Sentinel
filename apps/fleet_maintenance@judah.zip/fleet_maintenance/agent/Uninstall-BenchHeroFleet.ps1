#Requires -RunAsAdministrator
$ErrorActionPreference = 'Continue'
$ServiceName = 'BenchHeroFleet'
$InstallDir = Join-Path $env:ProgramData 'Nash Nerds\Bench Hero Fleet'
$RunKey = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run'
$StartMenuDir = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs'
$Self = $MyInvocation.MyCommand.Path

$Host.UI.RawUI.WindowTitle = 'Uninstall Bench Hero Fleet'
Write-Host ''
Write-Host 'BENCH HERO FLEET UNINSTALLER' -ForegroundColor Cyan
Write-Host '----------------------------------------' -ForegroundColor DarkGray

function Step($Text) { Write-Host ('> ' + $Text) -ForegroundColor Cyan }

Step 'Stopping Bench Hero Fleet service'
Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
& sc.exe stop $ServiceName 2>$null | Out-Null
Start-Sleep -Milliseconds 800

Step 'Removing Windows service'
& sc.exe delete $ServiceName 2>$null | Out-Null

Step 'Disabling tray auto-start'
if(Test-Path $RunKey){
    Remove-ItemProperty -Path $RunKey -Name 'BenchHeroFleetStatus' -Force -ErrorAction SilentlyContinue
}

Step 'Removing Start Menu shortcuts'
Remove-Item (Join-Path $StartMenuDir 'Bench Hero Fleet.lnk') -Force -ErrorAction SilentlyContinue
Remove-Item (Join-Path $StartMenuDir 'Uninstall Bench Hero Fleet.lnk') -Force -ErrorAction SilentlyContinue

Step 'Stopping remaining Fleet processes'
Get-Process -Name 'BenchHeroFleetAgent' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Get-Process -Name 'BenchHeroFleetStatus' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2

Step 'Removing local agent, enrollment credentials, and logs'
if(Test-Path $InstallDir){
    for($i=0;$i -lt 4 -and (Test-Path $InstallDir);$i++){
        Remove-Item $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
        if(Test-Path $InstallDir){ Start-Sleep -Seconds 1 }
    }
}

Start-Sleep -Milliseconds 500
$serviceLeft = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
$folderLeft = Test-Path $InstallDir

Write-Host ''
if($serviceLeft -or $folderLeft){
    Write-Host 'UNINSTALL INCOMPLETE' -ForegroundColor Yellow
    if($serviceLeft){ Write-Host '- Windows still has the Fleet service registered.' -ForegroundColor Yellow }
    if($folderLeft){ Write-Host ('- Windows still has a locked Fleet folder: '+$InstallDir) -ForegroundColor Yellow }
    Write-Host ''
    Write-Host 'Restart Windows, then run the Start Menu uninstaller again if it is still present.' -ForegroundColor Yellow
    Write-Host 'The Fleet agent will no longer start automatically.' -ForegroundColor Yellow
    Write-Host ''
    Read-Host 'Press Enter to close'
    exit 1
}

Write-Host 'UNINSTALL COMPLETE' -ForegroundColor Green
Write-Host 'Bench Hero Fleet was removed from this computer.' -ForegroundColor Green
Write-Host 'Its historical device card can be removed separately from the Bench Hero Pi.' -ForegroundColor DarkGray
Write-Host ''

# Delete the temporary launcher/script after this process exits.
$tempRoot = Split-Path -Parent $Self
$cleanup = Join-Path $env:TEMP ('BenchHeroFleet-cleanup-'+[guid]::NewGuid().ToString('N')+'.cmd')
@"
@echo off
timeout /t 3 /nobreak >nul
rmdir /s /q "$tempRoot" >nul 2>&1
del /f /q "%~f0" >nul 2>&1
"@ | Set-Content $cleanup -Encoding ASCII
Start-Process -FilePath 'cmd.exe' -ArgumentList '/c',('start "" /min "'+$cleanup+'"') -WindowStyle Hidden

Read-Host 'Press Enter to close'
