BENCH HERO FLEET AGENT v1.3

1. Right-click Install-BenchHeroFleet.ps1 and run it with PowerShell as Administrator.
2. Enter the customer/company name and a friendly PC name.
3. The background service will enroll with Bench Hero and check in about every 30 seconds.
4. A Windows status window and tray icon show whether the agent service is running and whether Bench Hero can be reached.
5. Close the status window to hide it to the tray; the background service continues running.
6. Open the status window again from the tray icon or Start Menu > Bench Hero Fleet.

The status window shows:
- Customer/company and PC label
- Enrollment state
- Bench Hero server address
- Agent service state
- Last successful check-in
- Current maintenance task
- Last connection error, when present

The agent runs only the fixed maintenance-task allowlist sent by your authorized Bench Hero controller.
