# Google Review QR

Shows the customer a QR code that opens your review page.

## Where the link comes from

**Hero Dashboard ▸ Shop info ▸ ⭐ Review link.** That one setting already
feeds the review QR on printed receipts; this app now reads the same value,
so there is a single source of truth. Set it once — from a phone or a
desktop, wherever typing is easy — and change it there whenever you like.

Nothing is typed on the bench. If the link isn't set yet, the app shows a QR
that opens the Shop info page so the owner can scan it and set it on their
phone.

The setting accepts whatever your phone handed you: a full Google/Facebook/
Yelp review URL, a bare Google Place ID (`ChIJ…`, turned into the direct
write-a-review link), or a bare host like `www.shop.com/review`. Anything
that isn't http(s) after normalising is rejected rather than turned into a
QR — a customer can't inspect a QR before following it.

## Upgrading from the old version

Earlier builds made a tech type the URL on the touchscreen and kept a copy
in `config.json`. On first run after the update, if that old link is still
there and Shop info is empty, the app offers **✓ USE THIS LINK SHOP-WIDE** —
one tap moves it into Shop info and renames the old file. No typing.

## Notes

- No pip dependencies. The QR is drawn with the bench's stdlib renderer
  (`qr_tk`); `qrcode` + Pillow are only a fallback for running off-bench.
- The wording above the QR comes from Shop info's **review ask** line, so
  the screen and the receipts say the same thing.
- Nothing is sent anywhere. The Pi makes no network call and never records
  who scanned.
