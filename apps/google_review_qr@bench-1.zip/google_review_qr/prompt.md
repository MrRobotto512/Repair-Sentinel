## 2026-08-07 07:46
can we make an app that allows the user to show customers a qr code that links to a google review page. users will need a way to set their own link to their google review.

