#!/usr/bin/env python3
"""
Google Review QR — show the customer a QR that opens your review page.

REWORKED 2026-08-22: no typing on the bench.

The old version made a tech type the review URL on the touchscreen and kept
its own copy in the app folder. That was wrong twice over — a long URL on an
on-screen keyboard is miserable, and it meant the shop's review link lived
in two places that could disagree.

Now there is ONE source of truth: **Shop info ▸ ⭐ Review link** on the Hero
Dashboard, the same setting that already puts a review QR on printed
receipts. Set it once, from a phone or a desktop, and this app just shows
it. Change it there and this app follows on the next open.

If the link isn't set yet, the app doesn't nag you to type it — it shows a
QR that opens the Shop info page, so the owner can scan it and set the link
on their phone.

Contract: standalone Tk process, fullscreen, EXIT top-right, exit code 0.
"""

import json
import os
import re
import socket
import sys

os.environ.setdefault("DISPLAY", ":0")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import tkinter as tk
from tkinter import font

# ── the bench's own helpers, all optional so this still runs on a laptop ────
try:
    import ui_theme as _ui
except ImportError:
    _ui = None
try:
    import repair_report as _rr          # shop_info() / save_shop_info()
except ImportError:
    _rr = None
try:
    import qr_tk as _qr                  # stdlib QR renderer — no Pillow
except ImportError:
    _qr = None

APP_DIR = os.path.dirname(os.path.abspath(__file__))
LEGACY_CONFIG = os.path.join(APP_DIR, "config.json")   # pre-rework copy
DASH_PORT = 8377

BG = "#0d0d0f"
CARD = "#1b1b21"
EDGE = "#2a2a32"
INK = "#e8e8f0"
DIM = "#aab0bf"
MUTED = "#7a7a8c"
ACCENT = "#ffc94d"
OK_FILL, OK_INK = "#0d3318", "#69f0ae"
ERR_INK = "#ff6e6e"

# Mirrors tech_notes_server._review_link(). Kept in step with it on purpose:
# a QR is a link the customer cannot inspect before following, so only
# http(s) may ever reach one — not even from a typo in the owner's settings.
REVIEW_URL_MAX = 500
PLACE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{15,}$")


def normalise_review_url(raw):
    """Accept what an owner actually pastes; return "" for anything unsafe.
      · full http(s) URL              → as-is
      · bare Google Place ID (ChIJ…)  → the direct write-a-review link
      · "www.shop.com/review"         → https:// prepended
    """
    from urllib.parse import quote
    raw = (raw or "").strip()
    if not raw or len(raw) > REVIEW_URL_MAX or any(c.isspace() for c in raw):
        return ""
    low = raw.lower()
    if ("/" not in raw and "." not in raw and ":" not in raw
            and PLACE_ID_RE.match(raw)):
        return ("https://search.google.com/local/writereview?placeid="
                + quote(raw, safe=""))
    if not (low.startswith("http://") or low.startswith("https://")):
        host = raw.split("/")[0]
        if ":" in host or "." not in host:
            return ""                     # "javascript:…" / a bare typo
        raw = "https://" + raw
        low = raw.lower()
    if not (low.startswith("http://") or low.startswith("https://")):
        return ""
    return raw[:REVIEW_URL_MAX]


def shop():
    if _rr is None:
        return {}
    try:
        return _rr.shop_info() or {}
    except Exception:
        return {}


def review_link():
    return normalise_review_url(shop().get("review_url"))


def review_ask():
    """The one line above the QR, {shop} filled in — owner-editable in Shop
    info, same text the printed receipts use."""
    info = shop()
    name = (info.get("name") or "").strip() or "our shop"
    tpl = (info.get("review_ask") or "").strip() \
        or "Happy with the repair? A quick review means a lot to {shop}."
    try:
        line = tpl.format(shop=name)
    except (KeyError, IndexError, ValueError):
        line = "Happy with the repair? A quick review means a lot to %s." % name
    return " ".join(line.split())[:200]


def legacy_url():
    """A URL left behind by the old typed-in version, if any."""
    try:
        with open(LEGACY_CONFIG, encoding="utf-8") as f:
            return normalise_review_url((json.load(f) or {}).get("url"))
    except Exception:
        return ""


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return ""


def shopinfo_url():
    ip = lan_ip()
    return "http://%s:%d/shopinfo" % (ip, DASH_PORT) if ip else ""


class ReviewQR(tk.Tk):
    TITLE = "⭐ GOOGLE REVIEW"

    def __init__(self):
        super().__init__()
        if _ui is not None and hasattr(_ui, "apply_root"):
            _ui.apply_root(self)
        else:
            self.geometry("800x480")
            self.title(self.TITLE + " (dev)")
        self.configure(bg=BG)
        self._photo = None                # Tk drops un-referenced images

        w = self.winfo_screenwidth() or 800
        self.narrow = w < 640
        self.wrap = max(260, w - 60)
        sz = (26, 15, 13) if not self.narrow else (20, 13, 12)
        self.f_big = font.Font(family="DejaVu Sans", size=sz[0], weight="bold")
        self.f_b = font.Font(family="DejaVu Sans", size=sz[1])
        self.f_btn = font.Font(family="DejaVu Sans", size=sz[2], weight="bold")

        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", padx=8, pady=4)
        tk.Button(bar, text="X", font=self.f_btn, bg="#3a1a1a", fg=ERR_INK,
                  activebackground="#5a2a2a", activeforeground=ERR_INK,
                  bd=2, relief="raised", width=3,
                  command=self.close).pack(side="right")
        tk.Button(bar, text="↻", font=self.f_btn, bg="#22222a", fg=DIM,
                  activebackground="#2a2a34", activeforeground=INK, bd=0,
                  relief="flat", width=3,
                  command=self.render).pack(side="right", padx=6)

        self.body = tk.Frame(self, bg=BG)
        self.body.pack(fill="both", expand=True)
        self.after(120, self.render)

    # ---- drawing --------------------------------------------------------
    def clear(self):
        for w in self.body.winfo_children():
            w.destroy()

    def qr_widget(self, parent, data, box=None):
        """QR via the bench's stdlib renderer; Pillow/qrcode only as a
        last resort on a dev machine."""
        if box is None:
            box = 5 if self.narrow else 8
        if _qr is not None:
            try:
                self._photo = _qr.make_qr_photo(self, data, box=box, border=2)
                return tk.Label(parent, image=self._photo, bg="#ffffff",
                                bd=0)
            except Exception:
                pass
        try:
            import qrcode
            from PIL import ImageTk
            img = qrcode.QRCode(box_size=box, border=2)
            img.add_data(data)
            img.make(fit=True)
            self._photo = ImageTk.PhotoImage(
                img.make_image(fill_color="black", back_color="white"))
            return tk.Label(parent, image=self._photo, bg="#ffffff", bd=0)
        except Exception as e:  # noqa: BLE001
            return tk.Label(parent, text="Can't draw a QR code here:\n%s" % e,
                            font=self.f_b, bg=CARD, fg=ERR_INK,
                            wraplength=self.wrap, justify="left")

    def render(self):
        self.clear()
        link = review_link()
        if link:
            self.view_qr(link)
        else:
            self.view_setup()

    # ---- the customer-facing screen -------------------------------------
    def view_qr(self, link):
        wrap = tk.Frame(self.body, bg=BG)
        wrap.pack(expand=True)
        tk.Label(wrap, text=review_ask(), font=self.f_big, bg=BG, fg=INK,
                 wraplength=self.wrap, justify="center").pack(pady=(0, 14))
        holder = tk.Frame(wrap, bg="#ffffff", padx=10, pady=10)
        holder.pack()
        self.qr_widget(holder, link).pack()
        tk.Label(wrap, text="Scan with your phone camera", font=self.f_b,
                 bg=BG, fg=MUTED).pack(pady=(12, 0))

    # ---- not configured yet ---------------------------------------------
    def view_setup(self):
        wrap = tk.Frame(self.body, bg=BG)
        wrap.pack(expand=True, fill="both", padx=16)
        tk.Label(wrap, text="No review link set yet", font=self.f_big,
                 bg=BG, fg=ACCENT).pack(pady=(4, 8))

        old = legacy_url()
        if old and _rr is not None:
            tk.Label(wrap, text="This app has an old link saved from before:\n"
                                "%s\n\nSave it to Shop info and every review "
                                "QR — here and on printed receipts — uses it."
                                % old, font=self.f_b, bg=BG, fg=DIM,
                     wraplength=self.wrap, justify="center").pack(pady=6)
            tk.Button(wrap, text="✓  USE THIS LINK SHOP-WIDE", font=self.f_btn,
                      bg=OK_FILL, fg=OK_INK, activebackground="#1a5a28",
                      activeforeground=OK_INK, bd=0, relief="flat", height=2,
                      command=lambda: self.adopt(old)).pack(fill="x", pady=8)
            return

        info = ("Set it once in the Hero Dashboard, under\n"
                "Shop info ▸ ⭐ Review link.\n\n"
                "Paste your Google review URL or Place ID there — the same "
                "setting already used for review QRs on printed receipts. "
                "Then tap ↻ up top.")
        tk.Label(wrap, text=info, font=self.f_b, bg=BG, fg=DIM,
                 wraplength=self.wrap, justify="center").pack(pady=(0, 10))
        url = shopinfo_url()
        if url:
            tk.Label(wrap, text="Scan to open Shop info on your phone:",
                     font=self.f_b, bg=BG, fg=MUTED).pack()
            holder = tk.Frame(wrap, bg="#ffffff", padx=8, pady=8)
            holder.pack(pady=6)
            self.qr_widget(holder, url, box=4).pack()
            tk.Label(wrap, text=url, font=self.f_b, bg=BG,
                     fg=MUTED).pack()
        elif _rr is None:
            tk.Label(wrap, text="(Shop info isn't reachable — this app is "
                                "running off-bench.)", font=self.f_b, bg=BG,
                     fg=MUTED).pack(pady=6)

    def adopt(self, url):
        """One tap moves the old typed-in link into Shop info — no typing,
        and afterwards there is only one copy of it."""
        try:
            _rr.save_shop_info({"review_url": url})
        except Exception as e:  # noqa: BLE001
            self.clear()
            tk.Label(self.body, text="Couldn't save it to Shop info:\n%s" % e,
                     font=self.f_b, bg=BG, fg=ERR_INK, wraplength=self.wrap,
                     justify="center").pack(expand=True)
            return
        try:
            os.replace(LEGACY_CONFIG, LEGACY_CONFIG + ".migrated")
        except OSError:
            pass
        self.render()

    def close(self):
        self.destroy()
        sys.exit(0)


if __name__ == "__main__":
    app = ReviewQR()
    try:
        import benchversion as _bv
        _bv.stamp(app, __file__)
    except Exception:
        pass
    app.mainloop()
