#!/usr/bin/env python3
"""
af_examples.py — starter workflows for Keystroke Flasher.

The bench's main job for this tool is bypassing the Windows OOBE (Out-Of-Box
Experience) to set up a local account — so the app ships with ready-to-flash
OOBE workflows. They're seeded into the library on first run and can be
re-imported any time from the dashboard ("Load Windows OOBE examples").

The dongle is a USB HID keyboard, so these work on any PC at the OOBE screen.
Method note: `start ms-cxh:localonly` is the current (Win11 24H2/25H2) way to
reach local-account setup; the BypassNRO registry route is kept for older
builds. Edit or add your own on the dashboard.
"""

from __future__ import annotations

import af_model as wm


def _wf(name, note, steps, button=None):
    wf = {"name": name, "note": note, "steps": steps}
    if button is not None:
        wf["button"] = button
    return wf


def windows_oobe():
    """The Windows OOBE bypass starter set."""
    return [
        # ---- the primary one the shop asked for (with focus nudge) -------- #
        #  On recent builds the Shift+F10 cmd window opens WITHOUT keyboard
        #  focus (you'd normally have to click it). The dongle can't click, so
        #  we nudge focus with Alt+Tab before typing. If your build already
        #  focuses the cmd window, use the "no focus fix" variant instead.
        _wf("OOBE: Local account (25H2)",
            "Shift+F10, Alt+Tab to focus cmd, start ms-cxh:localonly",
            [
                wm.make_step("status", text="Shift+F10 - open Command Prompt"),
                wm.make_step("key", mods="shift", key="f10"),
                wm.make_step("delay", ms=2000),
                wm.make_step("status", text="Alt+Tab - focus the cmd window"),
                wm.make_step("key", mods="alt", key="tab"),
                wm.make_step("delay", ms=700),
                wm.make_step("status", text="Launch local-only setup"),
                wm.make_step("line", text="start ms-cxh:localonly"),
                wm.make_step("delay", ms=800),
                wm.make_step("status", text="Follow the local-account prompts"),
            ],
            button=0),

        # ---- same, for builds where cmd already takes focus -------------- #
        _wf("OOBE: Local account (no focus fix)",
            "Shift+F10 then type (no Alt+Tab)",
            [
                wm.make_step("status", text="Shift+F10 - open Command Prompt"),
                wm.make_step("key", mods="shift", key="f10"),
                wm.make_step("delay", ms=2000),
                wm.make_step("status", text="Launch local-only setup"),
                wm.make_step("line", text="start ms-cxh:localonly"),
                wm.make_step("delay", ms=800),
                wm.make_step("status", text="Follow the local-account prompts"),
            ]),

        # ---- reusable focus building block ------------------------------- #
        _wf("OOBE: Focus cmd window",
            "Alt+Tab - use if the cmd window won't accept typing",
            [
                wm.make_step("status", text="Alt+Tab to the cmd window"),
                wm.make_step("key", mods="alt", key="tab"),
            ]),

        # ---- a plain building block -------------------------------------- #
        _wf("OOBE: Open Command Prompt",
            "just Shift+F10 (some laptops: Shift+Fn+F10)",
            [
                wm.make_step("status", text="Opening Command Prompt"),
                wm.make_step("key", mods="shift", key="f10"),
            ],
            button=1),

        # ---- older builds: re-enable the 'no internet' path -------------- #
        _wf("OOBE: BypassNRO (older builds)",
            "reg BypassNRO=1 then reboot to OOBE",
            [
                wm.make_step("status", text="Shift+F10 - Command Prompt"),
                wm.make_step("key", mods="shift", key="f10"),
                wm.make_step("delay", ms=1500),
                wm.make_step("status", text="Enable BypassNRO"),
                wm.make_step("line", text=(
                    'reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\'
                    'CurrentVersion\\OOBE" /v BypassNRO /t REG_DWORD /d 1 /f')),
                wm.make_step("delay", ms=800),
                wm.make_step("status", text="Rebooting to OOBE"),
                wm.make_step("line", text="shutdown /r /t 0"),
            ],
            button=2),
    ]


# PowerShell the dongle types on the target laptop. Uses powercfg's battery
# report (reliable where the raw root/wmi battery class throws "generic failure")
# for the design + full-charge capacities, finds THIS dongle's COM port by its
# Espressif VID, and writes "BATT:<design>,<full>,,<cycles>" back to it — the
# firmware computes and shows the health %. Windows PowerShell 5.1, US layout.
#
# Cycle count on Windows is best-effort: it comes from the battery controller's
# ACPI _BIX table, where the field is OPTIONAL, and many OEM packs (MSI, Dell,
# HP, Lenovo...) just report 0. Every generic Windows source (powercfg, the
# root/wmi battery classes) reads that same ACPI data, so a 0 means "this pack
# doesn't expose it", not "brand new" — a 66%-health battery can't have 0
# cycles. We therefore send the field EMPTY on 0/blank so the dongle hides the
# Cycles line instead of showing a misleading "Cycles: 0". No baud is set on
# the port (native USB-CDC ignores it) to keep the command inside 480 chars.
_BATTERY_PS = (
    "powercfg /batteryreport /xml /output \"$env:TEMP\\b.xml\">$null;"
    "[xml]$r=gc \"$env:TEMP\\b.xml\" -Raw;"
    "$b=@($r.BatteryReport.Batteries.Battery)[0];"
    "$d=$b.DesignCapacity;$f=$b.FullChargeCapacity;$k=$b.CycleCount;"
    "if(!$k -or $k -eq 0){$k=''};"
    "$n=(Get-PnpDevice -Class Ports -PresentOnly|"
    "?{$_.InstanceId -match 'VID_303A'}|select -Fi 1).FriendlyName;"
    "$m=[regex]::Match($n,'COM\\d+').Value;"
    "$s=New-Object IO.Ports.SerialPort $m;$s.Open();"
    "$s.WriteLine(\"BATT:$d,$f,,$k\");sleep -m 500;$s.Close()"
)

# The macOS twin. Opens Terminal (Spotlight) and reads the battery from ioreg:
# DesignCapacity + AppleRawMaxCapacity (health = ratio) + CycleCount. Writes
# "BATT:<design>,<max>,<pct>,<cycles>" to the dongle's own CDC port
# (/dev/cu.usbmodem*). No baud needed on native USB-CDC. US keyboard layout;
# works in the default zsh (and bash). Works on Intel and Apple Silicon.
#
# Two gotchas this is built around (both bit us on a real MacBook Air):
#  * `ioreg -rn AppleSmartBattery -w0` — only the battery subtree, unclipped.
#    A whole-tree `ioreg -l` is multi-MB, clipped at 80 cols when piped, and
#    full of raw bytes that make awk abort ("towc: multibyte conversion
#    failure") — LC_ALL=C is kept as belt-and-braces for that.
#  * The battery object ALSO carries a "BatteryData" = {...} INLINE dictionary
#    that sorts before the real keys and repeats the same names with no spaces
#    ("DesignCapacity"=4382). A loose /"Key"/ match grabs that whole blob first,
#    its commas shred the dongle's field split, and everything reads as 0.
#    So each match is anchored to the scalar form: `"Key" = <digits>` at end of
#    line — the blob line ends in "}" and can never satisfy it.
_BATTERY_MAC = (
    "export LC_ALL=C;IO=$(ioreg -rn AppleSmartBattery -w0);"
    "D=$(echo \"$IO\"|awk '/\"DesignCapacity\" = [0-9]+$/{print $NF;exit}');"
    "M=$(echo \"$IO\"|awk '/\"AppleRawMaxCapacity\" = [0-9]+$/{print $NF;exit}');"
    "C=$(echo \"$IO\"|awk '/\"CycleCount\" = [0-9]+$/{print $NF;exit}');"
    "H=0;[ \"$D\" -gt 0 ] 2>/dev/null && [ \"$M\" -gt 0 ] 2>/dev/null && H=$((100*M/D));"
    "P=$(ls /dev/cu.usbmodem* 2>/dev/null|head -1);"
    "{ printf 'BATT:%s,%s,%s,%s\\n' \"$D\" \"$M\" \"$H\" \"$C\"; sleep 0.3; } > \"$P\""
)


# The Mac's spec sheet, sent the same way: "SYS:<serial>|<cpu>|<ramGB>|<disk>".
# Typed BEFORE the battery command so the specs are already on the dongle when
# the BATT: reply flips it to the readout screen (firmware >= v1.4 draws them
# under the battery block; older firmware just ignores the SYS: line).
#  * serial : IOPlatformSerialNumber from the platform expert node (tiny, fast)
#  * cpu    : machdep.cpu.brand_string, with Intel's "Intel(R) Core(TM) ... CPU
#             @ 2.30GHz" noise stripped to the model ("i7-1068NG7") so it fits a
#             26-column line; Apple Silicon strings ("Apple M2 Pro") pass through
#  * ram    : hw.memsize in whole GB
#  * disk   : diskutil's "Disk Size" of disk0 (the internal SSD), e.g. 251.0GB
# '|' delimits because CPU strings can contain spaces/commas but never a pipe.
# All unprivileged, so it works as _mbsetupuser at Setup Assistant.
_SYSINFO_MAC = (
    "export LC_ALL=C;"
    "S=$(ioreg -rd1 -c IOPlatformExpertDevice|awk -F'\"' '/IOPlatformSerialNumber/{print $4}');"
    "C=$(sysctl -n machdep.cpu.brand_string|sed -E 's/\\(R\\)|\\(TM\\)|Intel|Core|CPU|@.*//g;s/  */ /g;s/^ | $//g');"
    "R=$(($(sysctl -n hw.memsize)/1073741824));"
    "T=$(diskutil info disk0|awk '/Disk Size/{print $3$4}');"
    "P=$(ls /dev/cu.usbmodem* 2>/dev/null|head -1);"
    "{ printf 'SYS:%s|%s|%s|%s\\n' \"$S\" \"$C\" \"$R\" \"$T\"; sleep 0.3; } > \"$P\""
)


def windows_battery():
    """Read a laptop's battery health and show it on the dongle screen.

    The dongle is a blind keyboard, so it can't read the report itself — it
    types a command that computes the % on the PC and writes it back over the
    dongle's own USB-CDC COM port. Needs firmware with the BATT: screen.
    """
    return [
        _wf("Battery Health (Windows)",
            "PowerShell -> health % back to the dongle screen (US layout)",
            [
                wm.make_step("status", text="Win+R - Run"),
                wm.make_step("key", mods="cmd", key="r"),
                wm.make_step("delay", ms=900),
                wm.make_step("line", text="powershell"),
                wm.make_step("delay", ms=2200),
                wm.make_step("status", text="Reading battery..."),
                wm.make_step("line", text=_BATTERY_PS),
                wm.make_step("delay", ms=500),
                wm.make_step("status", text="Check dongle screen"),
            ]),
    ]


def mac_battery():
    """Battery health + spec sheet for a logged-in Mac. Opens Terminal via
    Spotlight, sends the specs (serial/CPU/RAM/SSD), then the battery readout;
    the dongle shows all of it on one screen."""
    return [
        _wf("Battery Health (macOS)",
            "Terminal -> specs + health % + cycles to the dongle (US layout)",
            [
                wm.make_step("status", text="Cmd+Space - Spotlight"),
                wm.make_step("key", mods="cmd", key="space"),
                wm.make_step("delay", ms=900),
                wm.make_step("line", text="Terminal"),
                wm.make_step("delay", ms=2200),
                wm.make_step("status", text="Reading specs..."),
                wm.make_step("line", text=_SYSINFO_MAC),
                wm.make_step("delay", ms=600),
                wm.make_step("status", text="Reading battery..."),
                wm.make_step("line", text=_BATTERY_MAC),
                wm.make_step("delay", ms=800),
                wm.make_step("status", text="Check dongle screen"),
            ]),
    ]


def mac_battery_setup():
    """Battery health on a Mac still sitting at Setup Assistant (fresh or just
    erased — no user, so no Spotlight to launch Terminal with).

    Setup Assistant has a built-in shortcut that opens Terminal directly:
    Control-Option-Command-T. That Terminal runs as _mbsetupuser (not root),
    which is all we need: ioreg is world-readable and the dongle's /dev/cu.*
    node is mode 666, so the exact same battery command works unchanged.
    The delay after the chord is generous because Terminal is launching cold
    on a machine that has never run it. Same BATT: readout on the dongle.
    """
    return [
        _wf("Battery Health (macOS Setup)",
            "Ctrl+Opt+Cmd+T at Setup Assistant -> specs + health % + cycles",
            [
                wm.make_step("status", text="Ctrl+Opt+Cmd+T - Terminal"),
                wm.make_step("key", mods="ctrl+alt+cmd", key="t"),
                wm.make_step("delay", ms=4000),
                wm.make_step("status", text="Reading specs..."),
                wm.make_step("line", text=_SYSINFO_MAC),
                wm.make_step("delay", ms=600),
                wm.make_step("status", text="Reading battery..."),
                wm.make_step("line", text=_BATTERY_MAC),
                wm.make_step("delay", ms=800),
                wm.make_step("status", text="Check dongle screen"),
            ]),
    ]


# Phase 0a of AUTOMATON_MAC_SETUP_RESEARCH.md: the WHOLE Mac Diagnostics
# Dashboard (Summary / Disks / hardware Tests page / QC checklist) on a Mac
# still sitting at Setup Assistant — one tap at the Country screen.
#
# Why it comes over the network and not from the MACDIAG stick: Terminal at
# Setup Assistant is DENIED removable volumes by TCC (Ryan verified — no
# consent dialog for _mbsetupuser), so nothing on a USB stick can be read
# there. The network is not blocked, so the bench serves the profile as a
# tarball and the Mac pulls it into /tmp:
#   GET http://{BENCH}/x/{APP}/macdiag.tgz   (web.py, no PIN; {APP} = the
#   folder THIS app is installed under — My Apps Upload creates _2/_3 copies
#   instead of replacing, so the name is read from the running app at flash)
#
# Step 1 joins the shop Wi-Fi itself: `networksetup -setairportnetwork` works
# as _mbsetupuser (Ryan verified on a real Mac), and the Wi-Fi port is looked
# up (en0 on every MacBook, en1 on desktops with Ethernet). "{WIFI_SSID}",
# "{WIFI_PASS}" and "{BENCH}" are filled in when the workflow is FLASHED
# (af_bench.placeholders: flasher settings -> env -> this bench's own Wi-Fi),
# so the dongle only ever holds real values. An already-joined Mac (or one on
# Ethernet) is unaffected — the join is harmless.
#
# Step 2 fetches with a retry loop because DHCP takes a few seconds after the
# join; curl -sfS prints its own one-liner on each miss ("Failed to connect"
# = still no network; "returned error: 404" = the bench route) and && stops
# the chain at the first failure. Then -NoSudo (no password exists for
# _mbsetupuser; benchmac.sh must never prompt) and bash, not `open` (no
# Gatekeeper dialog); the launcher opens Safari on the dashboard itself.
# US keyboard layout assumed (the awk/quotes need it), same as Battery Health.
_WIFI_JOIN_MAC = (
    "W=$(networksetup -listallhardwareports|awk '/Wi-Fi/{getline;print $2}');"
    "networksetup -setairportnetwork $W \"{WIFI_SSID}\" \"{WIFI_PASS}\""
)
_DASHBOARD_MAC_SETUP = (
    "for i in $(seq 15);do curl -sfS -o /tmp/md.tgz "
    "http://{BENCH}/x/{APP}/macdiag.tgz&&break;sleep 2;done;"
    "tar xzf /tmp/md.tgz -C /tmp&&bash /tmp/mac-diag/Start*.command -NoSudo"
    " -Setup -Bench http://{BENCH}/x/{APP}"
)


def mac_dashboard_setup():
    """Start the Mac Diagnostics Dashboard (Summary/Disks/Tests/...) on a Mac
    at Setup Assistant: Ctrl+Opt+Cmd+T opens Terminal as _mbsetupuser, the
    Mac joins the shop Wi-Fi, fetches the profile from THIS bench into /tmp,
    and the launcher runs without sudo and opens Safari on the dashboard."""
    return [
        _wf("Mac Dashboard (macOS Setup)",
            "Ctrl+Opt+Cmd+T at Setup Assistant -> join shop Wi-Fi -> pull Dashboard from this bench -> Tests page in Safari",
            [
                wm.make_step("status", text="Ctrl+Opt+Cmd+T - Terminal"),
                wm.make_step("key", mods="ctrl+alt+cmd", key="t"),
                wm.make_step("delay", ms=4000),
                wm.make_step("status", text="Joining shop Wi-Fi"),
                wm.make_step("line", text=_WIFI_JOIN_MAC),
                wm.make_step("delay", ms=1500),
                wm.make_step("status", text="Fetching Dashboard from bench"),
                wm.make_step("line", text=_DASHBOARD_MAC_SETUP),
                wm.make_step("delay", ms=2500),
                wm.make_step("status", text="Safari -> Tests page"),
            ]),
    ]

def all_examples():
    return (windows_oobe() + windows_battery() + mac_battery()
            + mac_battery_setup() + mac_dashboard_setup())
