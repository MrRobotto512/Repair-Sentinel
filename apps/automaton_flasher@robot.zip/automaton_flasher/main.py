#!/usr/bin/env python3
"""
main.py — Keystroke Flasher (BenchTool touchscreen app)

Flashes custom keyboard commands to the ESP32-S3 dongle over its
USB-CDC serial console — no drive to mount, no bootloader dance. The tech builds
and stages workflows on the Hero Dashboard (web.py); here they plug the dongle
into the bench's USB and tap FLASH.

Primary use: bypassing the Windows OOBE to set up a local account (the dongle is
a USB HID keyboard, so it drives any PC at the setup screen).

Follows the BenchTool app contract: standalone Tk root, fullscreen dark theme,
big EXIT button top-right, never crashes on missing hardware (all device I/O is
guarded and reported on screen), exit code 0 on clean close.
"""

import os
import sys
import threading
import queue
import tkinter as tk
from tkinter import font

APP_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP_DIR)

import af_store as store
import af_serial as link
import af_blob as blob
import af_examples as examples
import af_model as wm

try:
    import ui_theme as _ui
    ON_BENCH = True
except ImportError:
    _ui = None
    ON_BENCH = False

# design tokens (match the bench built-ins)
BG = "#0d0d0f"
CARD = "#1b1b21"
CODE = "#101014"
BORDER = "#2a2a32"
FG = "#e8e8f0"
DIM = "#aab0bf"
MUT = "#7a7a8c"
ACC = "#40c4ff"
OK = "#00c853"
WARN = "#ffab00"
ERR = "#ff5252"

# A single NVS string value tops out at ~4000 bytes; stay safely under.
MAX_SCRIPT_BYTES = 3900

# Presets pre-selected on a fresh bench, in flash order — index 0 becomes the
# dongle's boot-default workflow. Battery Health first, then OOBE focus-fix.
# Matches the firmware built-in order in esp32s3_automaton/src/workflows.h.
DEFAULT_PRESETS = ["Battery Health (Windows)", "OOBE: Local account (25H2)"]
DRAG_THRESH = 10        # px of finger travel before a tap becomes a scroll


class App(tk.Tk):
    TITLE = "KEYSTROKE FLASHER"

    def __init__(self):
        super().__init__()
        if ON_BENCH and hasattr(_ui, "apply_root"):
            _ui.apply_root(self)
        else:
            self.geometry("800x480")
            self.title(self.TITLE + " (dev)")
        self.configure(bg=BG)

        self.f_title = font.Font(family="DejaVu Sans", size=24, weight="bold")
        self.f_h = font.Font(family="DejaVu Sans", size=15, weight="bold")
        self.f_body = font.Font(family="DejaVu Sans", size=14)
        self.f_small = font.Font(family="DejaVu Sans", size=12)
        self.f_exit = font.Font(family="DejaVu Sans", size=22, weight="bold")
        self.f_flash = font.Font(family="DejaVu Sans", size=22, weight="bold")

        # seed the Windows OOBE starter workflows on first run
        try:
            store.seed_if_new(APP_DIR, examples.all_examples())
        except Exception as e:
            print("seed failed:", e)

        self.device = None          # {"port","ident"} when found
        self.staged = []            # ordered selected workflow dicts (to flash)
        self.selected = set()       # lower-cased names currently ticked
        self.library = []           # all presets
        self._press_name = None
        self._press_y = 0
        self._moved = False
        self.q = queue.Queue()
        self.busy = False

        self._build_header()
        self._build_body()
        self.after(150, self.rescan)
        self.after(120, self._pump)

    # ---- chrome -----------------------------------------------------------
    def _build_header(self):
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill=tk.X, padx=12, pady=(10, 4))
        tk.Label(bar, text="⌨ " + self.TITLE, font=self.f_title,
                 bg=BG, fg=ACC).pack(side=tk.LEFT)
        tk.Button(bar, text="X", font=self.f_exit, bg="#3a1a1a", fg=ERR,
                  activebackground="#5a2a2a", activeforeground=ERR, bd=2,
                  relief="raised", width=3, command=self.close
                  ).pack(side=tk.RIGHT)

    def _build_body(self):
        body = tk.Frame(self, bg=BG)
        body.pack(fill=tk.BOTH, expand=True, padx=12, pady=6)
        body.grid_columnconfigure(0, weight=1, uniform="c")
        body.grid_columnconfigure(1, weight=1, uniform="c")
        body.grid_rowconfigure(0, weight=1)

        # left: device panel
        left = tk.Frame(body, bg=CARD, highlightbackground=BORDER,
                        highlightthickness=1)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        tk.Label(left, text="ESP32 DONGLE (USB)", font=self.f_h, bg=CARD,
                 fg=DIM).pack(anchor="w", padx=12, pady=(10, 2))
        self.dev_dot = tk.Label(left, text="●  scanning…", font=self.f_body,
                                bg=CARD, fg=MUT, justify="left",
                                wraplength=360, anchor="w")
        self.dev_dot.pack(anchor="w", fill=tk.X, padx=12, pady=2)
        self.dev_msg = tk.Label(left, text="", font=self.f_small, bg=CARD,
                                fg=MUT, justify="left", wraplength=360,
                                anchor="w")
        self.dev_msg.pack(anchor="w", fill=tk.X, padx=12, pady=(2, 8))

        btns = tk.Frame(left, bg=CARD)
        btns.pack(fill=tk.X, padx=12, pady=4)
        self.btn_rescan = tk.Button(btns, text="⟳ Rescan", font=self.f_body,
                                    bg=CODE, fg=FG, activebackground="#20202a",
                                    activeforeground=FG, bd=0,
                                    command=self.rescan)
        self.btn_rescan.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 3))
        self.btn_ports = tk.Button(btns, text="🔎 Ports", font=self.f_body,
                                   bg=CODE, fg=DIM, activebackground="#20202a",
                                   activeforeground=FG, bd=0,
                                   command=self.show_ports)
        self.btn_ports.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(3, 0))

        # right: preset picker (tap to choose which to flash)
        right = tk.Frame(body, bg=CARD, highlightbackground=BORDER,
                         highlightthickness=1)
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        hdr = tk.Frame(right, bg=CARD)
        hdr.pack(fill=tk.X, padx=12, pady=(10, 2))
        tk.Label(hdr, text="PRESETS — TAP TO CHOOSE", font=self.f_h, bg=CARD,
                 fg=DIM).pack(side=tk.LEFT)
        self.presets_count = tk.Label(hdr, text="", font=self.f_small, bg=CARD,
                                      fg=ACC)
        self.presets_count.pack(side=tk.RIGHT)

        # scrollable list (finger-drag to scroll; short tap toggles a preset)
        wrap = tk.Frame(right, bg=CARD)
        wrap.pack(fill=tk.BOTH, expand=True, padx=8, pady=(2, 8))
        self.presets_canvas = tk.Canvas(wrap, bg=CARD, highlightthickness=0,
                                        bd=0)
        self.presets_canvas.pack(fill=tk.BOTH, expand=True)
        self.staged_box = tk.Frame(self.presets_canvas, bg=CARD)
        self._pw = self.presets_canvas.create_window((0, 0), window=self.staged_box,
                                                     anchor="nw")
        self.staged_box.bind(
            "<Configure>",
            lambda e: self.presets_canvas.configure(
                scrollregion=self.presets_canvas.bbox("all")))
        self.presets_canvas.bind(
            "<Configure>",
            lambda e: self.presets_canvas.itemconfig(self._pw, width=e.width))
        # drag-scroll on empty canvas area
        self.presets_canvas.bind("<ButtonPress-1>", self._scroll_press)
        self.presets_canvas.bind("<B1-Motion>", self._scroll_motion)

        # bottom: status + FLASH
        bottom = tk.Frame(self, bg=BG)
        bottom.pack(fill=tk.X, padx=12, pady=(4, 10))
        self.status = tk.Label(bottom, text="", font=self.f_small, bg=BG,
                               fg=DIM, anchor="w", justify="left",
                               wraplength=760)
        self.status.pack(fill=tk.X, pady=(0, 6))
        self.btn_flash = tk.Button(bottom, text="⚡ FLASH", font=self.f_flash,
                                   bg="#0d3318", fg=OK,
                                   activebackground="#12401f",
                                   activeforeground=OK, bd=0, height=2,
                                   state=tk.DISABLED, command=self.flash)
        self.btn_flash.pack(fill=tk.X)

    # ---- preset picker ----------------------------------------------------
    def refresh_presets(self):
        for w in self.staged_box.winfo_children():
            w.destroy()
        try:
            lib = store.load_library(APP_DIR)
            self.library = lib.get("workflows", [])
            sel = store.load_selection(APP_DIR)
        except Exception as e:
            self.library, sel = [], {"names": [], "updated": ""}
            print("library load failed:", e)

        names = list(sel.get("names", []))
        # first run (never chosen): default to Battery Health, then OOBE focus-fix
        if not names and self.library and not sel.get("updated"):
            libset = {w.get("name") for w in self.library}
            names = [n for n in DEFAULT_PRESETS if n in libset]
            if names:
                try:
                    store.save_selection(APP_DIR, names)
                except Exception:
                    pass
        libnames = {w.get("name", "").lower() for w in self.library}
        self.selected = {n.lower() for n in names if n.lower() in libnames}

        if not self.library:
            box = tk.Frame(self.staged_box, bg=CARD)
            box.pack(fill=tk.X)
            tk.Label(box, text="No presets yet.", font=self.f_body, bg=CARD,
                     fg=MUT, wraplength=340, justify="left"
                     ).pack(anchor="w", pady=(4, 8))
            tk.Button(box, text="⭳ Load Windows OOBE presets", font=self.f_body,
                      bg=CODE, fg=OK, activebackground="#20202a",
                      activeforeground=OK, bd=0, command=self._load_examples
                      ).pack(fill=tk.X, ipady=6)
            self._sync_staged()
            return

        for w in self.library:
            self._make_preset_row(w)
        self._sync_staged()

    def _make_preset_row(self, w):
        name = w.get("name", "?")
        on = name.lower() in self.selected
        rowbg = "#123a1f" if on else CODE
        row = tk.Frame(self.staged_box, bg=rowbg,
                       highlightbackground=OK if on else BORDER,
                       highlightthickness=1)
        row.pack(fill=tk.X, pady=3)
        check = tk.Label(row, text="✓" if on else "○", font=self.f_h, bg=rowbg,
                         fg=OK if on else MUT, width=2)
        check.pack(side=tk.LEFT, padx=(8, 4), pady=6)
        cell = tk.Frame(row, bg=rowbg)
        cell.pack(side=tk.LEFT, fill=tk.X, expand=True)
        sub = f"{len(w.get('steps', []))} steps"
        if w.get("note"):
            sub += " · " + w["note"]
        tag = ("   ★ default" if name == DEFAULT_PRESETS[0]
               else "   ★" if name in DEFAULT_PRESETS else "")
        tk.Label(cell, text=name + tag, font=self.f_body, bg=rowbg, fg=FG,
                 anchor="w").pack(anchor="w")
        tk.Label(cell, text=sub, font=self.f_small, bg=rowbg, fg=MUT,
                 anchor="w", wraplength=250, justify="left").pack(anchor="w")
        for wdg in (row, check, cell) + tuple(cell.winfo_children()):
            wdg.bind("<ButtonPress-1>", lambda e, n=name: self._row_press(e, n))
            wdg.bind("<B1-Motion>", self._scroll_motion)
            wdg.bind("<ButtonRelease-1>", self._row_release)

    def _toggle_preset(self, name):
        key = name.lower()
        if key in self.selected:
            self.selected.discard(key)
        else:
            self.selected.add(key)
        # persist with the DEFAULT_PRESETS first (in their order) so the dongle's
        # boot default (index 0) is Battery Health, then OOBE focus-fix.
        sel_names = [w.get("name") for w in self.library
                     if w.get("name", "").lower() in self.selected]
        ordered = ([n for n in DEFAULT_PRESETS if n in sel_names]
                   + [n for n in sel_names if n not in DEFAULT_PRESETS])
        try:
            store.save_selection(APP_DIR, ordered)
        except Exception as e:
            print("save selection failed:", e)
        self.refresh_presets()

    def _sync_staged(self):
        """Resolve the selection to ordered dicts and refresh counts/buttons."""
        try:
            self.staged = store.selected_workflows(APP_DIR)
        except Exception:
            self.staged = []
        self.presets_count.config(text=f"{len(self.staged)} selected")
        can = bool(self.device) and bool(self.staged)
        self.btn_flash.config(state=tk.NORMAL if can else tk.DISABLED,
                              fg=OK if can else MUT,
                              bg="#0d3318" if can else "#161a16")
        self.update_status()

    def _load_examples(self):
        try:
            store.import_workflows(APP_DIR, examples.all_examples())
        except Exception as e:
            print("load examples failed:", e)
        self.refresh_presets()

    # ---- scroll + tap plumbing --------------------------------------------
    def _cxy(self):
        c = self.presets_canvas
        return (c.winfo_pointerx() - c.winfo_rootx(),
                c.winfo_pointery() - c.winfo_rooty())

    def _scroll_press(self, e):
        x, y = self._cxy()
        self.presets_canvas.scan_mark(x, y)
        self._press_y = e.y_root
        self._moved = False

    def _scroll_motion(self, e):
        if abs(e.y_root - self._press_y) > DRAG_THRESH:
            self._moved = True
            x, y = self._cxy()
            try:
                self.presets_canvas.scan_dragto(x, y, gain=1)
            except Exception:
                pass

    def _row_press(self, e, name):
        self._press_name = name
        x, y = self._cxy()
        self.presets_canvas.scan_mark(x, y)
        self._press_y = e.y_root
        self._moved = False

    def _row_release(self, e):
        if not self._moved and self._press_name is not None:
            self._toggle_preset(self._press_name)
        self._press_name = None

    # ---- detection --------------------------------------------------------
    def rescan(self):
        if self.busy:
            return
        self.set_dev("●  scanning USB…", MUT)
        self.refresh_presets()
        threading.Thread(target=self._scan_worker, daemon=True).start()

    def _scan_worker(self):
        try:
            dev = link.find_device()
        except Exception as e:
            dev = None
            print("scan error:", e)
        self.q.put(("device", dev))

    def _apply_device(self, dev):
        self.device = dev
        if dev:
            self.set_dev("● CONNECTED", OK)
            self.dev_msg.config(
                text=f"{dev['ident']}\n{dev.get('label', dev['port'])}\n"
                     f"{dev['port']}")
        else:
            self.set_dev("● not found", MUT)
            self.dev_msg.config(
                text="No dongle found. Plug the ESP32 into the Pi's USB "
                     "(native USB-C port) — it shows as /dev/ttyACM*. The board "
                     "must be running the ESP32 firmware (esp32s3_automaton "
                     "v1.4). Tap 🔎 Ports to see what's detected.")
        can = bool(dev) and bool(self.staged)
        self.btn_flash.config(state=tk.NORMAL if can else tk.DISABLED,
                              fg=OK if can else MUT,
                              bg="#0d3318" if can else "#161a16")
        self.update_status()

    # ---- ports diagnostic -------------------------------------------------
    def show_ports(self):
        if self.busy:
            return
        self.set_dev("●  probing ports…", MUT)
        self.dev_msg.config(text="")
        threading.Thread(target=self._diag_worker, daemon=True).start()

    def _diag_worker(self):
        try:
            rows = link.diagnose()
        except Exception as e:
            rows = None
            print("diagnose error:", e)
        self.q.put(("ports", rows))

    def _apply_ports(self, rows):
        if not rows:
            self.set_dev("● no serial ports", WARN)
            self.dev_msg.config(
                text="No serial ports on the Pi. Check the USB cable is a DATA "
                     "cable, the dongle is plugged into the Pi (not the target "
                     "PC), and it's powered (screen on).")
            return
        hit = any(r["matched"] for r in rows)
        self.set_dev(f"● {len(rows)} port(s) found", OK if hit else WARN)
        lines = []
        esp_wrong_fw = False
        for r in rows:
            tag = "✓ " if r["matched"] else "✗ "
            name = os.path.basename(r["port"])
            label = r.get("label", "")
            lines.append(f"{tag}{name}  {label}")
            if r["matched"]:
                lines.append(f"    {r['ident']}")
            elif r["lines"]:
                lines.append(f"    reply: {r['lines'][-1][:40]}")
            else:
                lines.append("    (no reply to IDENT)")
            # An Espressif device that won't answer = an ESP32 that isn't
            # running our firmware (or is in the bootloader / JTAG mode).
            low = (label + " " + " ".join(r.get("lines", []))).lower()
            if (not r["matched"]) and ("espressif" in low or "303a" in low
                                       or "jtag" in low):
                esp_wrong_fw = True
        if esp_wrong_fw:
            lines.append("")
            lines.append("→ ESP32 found but not answering: it's in JTAG/")
            lines.append("  bootloader mode or running other firmware.")
            lines.append("  Flash esp32s3_automaton v1.4, then replug.")
        self.dev_msg.config(text="\n".join(lines))

    def update_status(self):
        n = len(self.staged)
        if n == 0:
            self.set_status("Tap a preset on the right to choose what to flash.")
        elif not self.device:
            self.set_status(f"{n} preset(s) selected — waiting for the dongle.")
        else:
            try:
                script = blob.to_script(self.staged,
                                        store.load_library(APP_DIR).get("settings"),
                                        app_dir=APP_DIR)
                _, nb = blob.script_stats(script)
                self.set_status(f"{n} preset(s) selected ({nb} B). Tap FLASH "
                                f"to write them to the dongle.")
            except Exception as e:
                self.set_status(f"⚠ {e}", ERR)

    # ---- flash ------------------------------------------------------------
    def flash(self):
        if self.busy or not self.device or not self.staged:
            return
        try:
            script = blob.to_script(
                self.staged, store.load_library(APP_DIR).get("settings"),
                app_dir=APP_DIR)
        except (blob.BlobError, wm.WorkflowError) as e:
            return self.set_status(f"⚠ can't build script: {e}", ERR)
        n, nb = blob.script_stats(script)
        if nb > MAX_SCRIPT_BYTES:
            return self.set_status(
                f"⚠ too large for the dongle ({nb} B > {MAX_SCRIPT_BYTES}). "
                f"Select fewer/shorter presets.", ERR)
        self.busy = True
        self.btn_flash.config(state=tk.DISABLED, fg=MUT)
        self.set_status(f"Flashing {n} workflow(s)…", ACC)
        threading.Thread(target=self._flash_worker,
                         args=(self.device["port"], script), daemon=True).start()

    def _flash_worker(self, port, script):
        t = None
        try:
            t = link.open_serial(port, timeout=1.0)
            al = link.AutomatonLink(t)
            res = al.upload(script,
                            progress=lambda i, tot: self.q.put(
                                ("prog", (i, tot))))
            self.q.put(("done", f"Flashed {res['workflows']} workflow(s) "
                                f"({res['bytes']} B) to the dongle. It reloaded "
                                f"and is ready — trigger with its BOOT button."))
        except link.SerialError as e:
            self.q.put(("err", str(e)))
        except Exception as e:
            self.q.put(("err", f"unexpected: {e}"))
        finally:
            if t is not None:
                t.close()
        self.busy = False
        self.q.put(("rescan", None))

    # ---- event pump -------------------------------------------------------
    def _pump(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "device":
                    self._apply_device(payload)
                elif kind == "ports":
                    self._apply_ports(payload)
                elif kind == "prog":
                    i, tot = payload
                    self.set_status(f"Flashing… line {i}/{tot}", ACC)
                elif kind == "err":
                    self.set_status("⚠ " + str(payload), ERR)
                elif kind == "done":
                    self.set_status("✓ " + str(payload), OK)
                elif kind == "rescan":
                    self.after(500, self.rescan)
        except queue.Empty:
            pass
        self.after(120, self._pump)

    # ---- helpers ----------------------------------------------------------
    def set_dev(self, text, color):
        self.dev_dot.config(text=text, fg=color)
        self.update_idletasks()

    def set_status(self, msg, color=DIM):
        self.status.config(text=msg, fg=color)
        self.update_idletasks()

    def close(self):
        self.destroy()
        sys.exit(0)


if __name__ == "__main__":
    App().mainloop()
