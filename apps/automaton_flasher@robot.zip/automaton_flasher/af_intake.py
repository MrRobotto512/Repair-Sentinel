#!/usr/bin/env python3
"""
af_intake.py — where a Mac's Intake / QC report lands on the bench.

A Mac still at Setup Assistant has no stick and its /tmp dies at reboot, so
Dashboard 1.7 (setup mode) POSTs its Intake JSON (trade-in verdict, identity,
battery, disk, ownership flags, optional QC checklist) to this app's /report
route. We keep the raw JSON under data/mac_intake/ and, when the bench's
bench_session logger is importable (it is inside the Hero Dashboard), also
record a session (tool "mac_intake", device class "Computer") so the intake
shows up wherever sessions do. Pure functions; no Flask.
"""

from __future__ import annotations

import json
import os
import re
import time

MAX_BYTES = 512 * 1024
DIRNAME = "mac_intake"


def _dir(app_dir):
    d = os.path.join(app_dir, "data", DIRNAME)
    os.makedirs(d, exist_ok=True)
    return d


def _safe(s, n=40):
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", str(s or "")).strip("_")
    return s[:n] or "unknown"


def _session(rep):
    """Best effort: record a bench_session. Returns session id or ''."""
    try:
        import bench_session as bs
    except Exception:
        return ""
    try:
        si = rep.get("sysinfo") or {}
        b = rep.get("battery") or {}
        d = rep.get("disk") or {}
        model = rep.get("model") or si.get("market") or si.get("model") or "Mac"
        s = bs.new_session("Computer", tool="mac_intake", model=model)
        tel = {
            "serial": rep.get("serial") or si.get("serial") or "",
            "model_id": rep.get("model_id") or si.get("model_id") or "",
            "macos": si.get("os") or "",
            "activation_lock": si.get("activation_lock") or "",
            "enrollment": si.get("enrollment") or "",
            "battery_health_pct": b.get("pct"),
            "battery_cycles": b.get("cycles"),
            "battery_pfs": b.get("pfs"),
            "disk_size": d.get("size") or "",
            "disk_smart": d.get("smart") or "",
            "intake_verdict": rep.get("verdict") or "",
            "ticket": rep.get("ticket") or "",
        }
        s.telemetry(**{k: v for k, v in tel.items() if v not in (None, "")})
        reasons = "; ".join(t for _c, t in (rep.get("reasons") or []) if _c in ("bad", "warn"))
        s.note("Mac intake at Setup Assistant: %s%s" % (rep.get("verdict") or "?",
                                                         (" - " + reasons) if reasons else ""))
        q = rep.get("qc") or {}
        if q.get("verdict") or q.get("result"):
            s.note("QC checklist: %s" % (q.get("verdict") or q.get("result")))
        s.save()
        return str(s.data.get("session_id") or s.data.get("id") or "")
    except Exception:
        return ""


def receive(app_dir, raw):
    """Validate + store one POSTed report. Returns the JSON reply dict."""
    if not raw:
        return {"ok": False, "error": "empty body"}
    if len(raw) > MAX_BYTES:
        return {"ok": False, "error": "report too large (%d bytes)" % len(raw)}
    try:
        rep = json.loads(raw.decode("utf-8") if isinstance(raw, bytes) else raw)
    except Exception as e:
        return {"ok": False, "error": "not JSON: %s" % e}
    if not isinstance(rep, dict):
        return {"ok": False, "error": "report must be a JSON object"}
    si = rep.get("sysinfo") or {}
    serial = rep.get("serial") or si.get("serial") or ""
    ts = time.strftime("%Y%m%d-%H%M%S")
    name = "%s_%s.json" % (ts, _safe(serial))
    rep.setdefault("received", time.strftime("%Y-%m-%dT%H:%M:%S"))
    sid = _session(rep)
    if sid:
        rep["session"] = sid
    path = os.path.join(_dir(app_dir), name)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(rep, f, indent=1)
    return {"ok": True, "saved": name, "session": sid, "verdict": rep.get("verdict") or ""}


def list_reports(app_dir, limit=50):
    d = _dir(app_dir)
    out = []
    for n in sorted(os.listdir(d), reverse=True)[:limit]:
        if not n.endswith(".json"):
            continue
        try:
            with open(os.path.join(d, n), encoding="utf-8") as f:
                r = json.load(f)
        except Exception:
            continue
        si = r.get("sysinfo") or {}
        q = r.get("qc") or {}
        out.append({
            "file": n,
            "when": (r.get("received") or "").replace("T", " "),
            "verdict": r.get("verdict") or "",
            "serial": r.get("serial") or si.get("serial") or "",
            "model": r.get("model") or si.get("market") or si.get("model") or "",
            "ticket": r.get("ticket") or "",
            "qc": q.get("verdict") or q.get("result") or "",
            "session": r.get("session") or "",
        })
    return out


def read_raw(app_dir, name):
    name = os.path.basename(name)
    if not name.endswith(".json"):
        return None
    p = os.path.join(_dir(app_dir), name)
    if not os.path.isfile(p):
        return None
    with open(p, "rb") as f:
        return f.read()
