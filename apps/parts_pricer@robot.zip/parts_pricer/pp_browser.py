#!/usr/bin/env python3
"""
pp_browser.py — fetch pages through the bench's own Chromium.

Why: mobilesentrix.com sits behind Cloudflare, which challenges plain HTTP
clients but waves a real browser through. And `chromium --dump-dom` isn't
enough: the site's JavaScript strips the model menu out of the DOM until you
hover it, so a rendered page has no model list. What we want is the RAW
HTML exactly as the server sent it — so we open one headless Chromium with
remote debugging, let it settle the Cloudflare check once (a persistent
profile keeps the clearance cookie), and then ask the page to
`fetch(url).then(r => r.text())` for every page we need. Same origin, same
cookies, raw HTML.

Only the DevTools protocol is used (the `websockets` package the bench
already ships). Nothing here fakes a browser — it *is* the browser.

    html = get(url)          # raises BrowserError when Chromium can't help
    close()                  # after a crawl, or when idle
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import threading
import time
import urllib.request

UA = ("Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/128.0.0.0 Safari/537.36")

IDLE_CLOSE_S = 180        # shut the browser after this long with no fetches
CHALLENGE_WAIT_S = 45     # how long we give Cloudflare's check to finish


class BrowserError(Exception):
    pass


def chromium_bin():
    env = os.environ.get("PP_CHROMIUM")
    if env and os.path.isfile(env):
        return env
    for name in ("chromium", "chromium-browser", "google-chrome",
                 "google-chrome-stable", "chrome"):
        p = shutil.which(name)
        if p:
            return p
    return None


def _free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _is_challenge(text):
    head = (text or "")[:4000]
    return ("challenges.cloudflare.com" in head or "<title>Just a moment" in head
            or "cf-chl" in head)


class _Session:
    """One headless Chromium + one page tab, driven over CDP."""

    def __init__(self, profile_dir, base_url):
        self.base_url = base_url
        self.proc = None
        self.ws = None
        self.msg_id = 0
        self.last_used = time.time()
        self.profile_dir = profile_dir
        self._start()

    # ---- lifecycle ---------------------------------------------------- #
    def _start(self):
        binary = chromium_bin()
        if not binary:
            raise BrowserError("Chromium is not installed on this bench.")
        try:
            from websockets.sync.client import connect  # noqa: F401
        except ImportError:
            raise BrowserError("the 'websockets' package is missing from the bench venv.")
        os.makedirs(self.profile_dir, exist_ok=True)
        port = _free_port()
        cmd = [binary, "--headless=new", "--disable-gpu", "--no-first-run",
               "--no-default-browser-check", "--disable-extensions",
               "--disable-background-networking", "--mute-audio",
               "--window-size=1280,900", f"--user-agent={UA}",
               f"--user-data-dir={self.profile_dir}",
               f"--remote-debugging-port={port}", "--remote-allow-origins=*",
               "about:blank"]
        if os.environ.get("PP_NO_SANDBOX"):
            cmd.insert(1, "--no-sandbox")
        try:
            self.proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                         stderr=subprocess.DEVNULL,
                                         env=dict(os.environ, HOME=os.environ.get("HOME", "/tmp")))
        except OSError as e:
            raise BrowserError(f"could not start Chromium: {e}")
        # wait for DevTools to answer, then open a tab
        deadline = time.time() + 20
        target = None
        while time.time() < deadline:
            try:
                req = urllib.request.Request(f"http://127.0.0.1:{port}/json/new?about:blank",
                                             method="PUT")
                with urllib.request.urlopen(req, timeout=2) as r:
                    target = json.loads(r.read().decode())
                break
            except Exception:
                if self.proc.poll() is not None:
                    raise BrowserError("Chromium exited right after starting "
                                       "(is a display or sandbox setting in the way?)")
                time.sleep(0.4)
        if not target:
            self.close()
            raise BrowserError("Chromium started but DevTools never answered.")
        from websockets.sync.client import connect
        self.ws = connect(target["webSocketDebuggerUrl"], max_size=None, open_timeout=10)
        self.call("Page.enable")
        self.call("Runtime.enable")
        self._navigate(self.base_url)

    def close(self):
        try:
            if self.ws:
                self.ws.close()
        except Exception:
            pass
        self.ws = None
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=8)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
        self.proc = None

    def alive(self):
        return self.ws is not None and self.proc is not None and self.proc.poll() is None

    # ---- protocol ----------------------------------------------------- #
    def call(self, method, timeout=60, **params):
        self.msg_id += 1
        mid = self.msg_id
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params}))
        deadline = time.time() + timeout
        while True:
            left = deadline - time.time()
            if left <= 0:
                raise BrowserError(f"Chromium did not answer {method} in time.")
            try:
                raw = self.ws.recv(timeout=left)
            except TimeoutError:
                raise BrowserError(f"Chromium did not answer {method} in time.")
            msg = json.loads(raw)
            if msg.get("id") == mid:
                if "error" in msg:
                    raise BrowserError(f"{method}: {msg['error'].get('message')}")
                return msg.get("result", {})
            # events and other ids are dropped

    def evaluate(self, expression, timeout=60):
        r = self.call("Runtime.evaluate", timeout=timeout, expression=expression,
                      awaitPromise=True, returnByValue=True)
        if "exceptionDetails" in r:
            ex = r["exceptionDetails"]
            text = ex.get("exception", {}).get("description") or ex.get("text") or "page error"
            raise BrowserError(text.splitlines()[0][:200])
        return r.get("result", {}).get("value")

    def _navigate(self, url):
        self.call("Page.navigate", url=url)
        # settle: wait for a title that isn't Cloudflare's, up to CHALLENGE_WAIT_S
        deadline = time.time() + CHALLENGE_WAIT_S
        while time.time() < deadline:
            time.sleep(1.0)
            try:
                state = self.evaluate("document.readyState + '|' + document.title", timeout=10)
            except BrowserError:
                continue
            ready, _, title = (state or "").partition("|")
            if ready == "complete" and "just a moment" not in title.lower() \
                    and "attention required" not in title.lower():
                return
        raise BrowserError("Cloudflare's browser check did not finish in "
                           f"{CHALLENGE_WAIT_S}s — try again in a few minutes.")

    # ---- the one thing callers want ----------------------------------- #
    def get(self, url, timeout=90):
        self.last_used = time.time()
        js = ("fetch(%s, {credentials:'include', cache:'no-store'})"
              ".then(r => r.text().then(t => ({s: r.status, t: t})))" % json.dumps(url))
        res = self.evaluate(js, timeout=timeout)
        if not isinstance(res, dict) or not isinstance(res.get("t"), str):
            raise BrowserError("Chromium returned no page body.")
        if _is_challenge(res["t"]):
            # clearance expired mid-session: reload the base page to renew it
            self._navigate(self.base_url)
            res = self.evaluate(js, timeout=timeout)
            if not isinstance(res, dict) or _is_challenge(res.get("t", "")):
                raise BrowserError("Cloudflare is still asking for a browser check.")
        if int(res.get("s", 200)) >= 400:
            raise BrowserError(f"HTTP {res['s']} for {url}")
        return res["t"]


_lock = threading.Lock()
_session = None
_reaper_started = False


def _profile_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(here, "data", "chromium-profile")


def get(url, base_url="https://www.mobilesentrix.com/"):
    """Raw HTML of `url` fetched from inside a real browser session."""
    global _session
    with _lock:
        _ensure_reaper()
        if _session is None or not _session.alive():
            if _session is not None:
                _session.close()
            _session = _Session(_profile_dir(), base_url)
        try:
            return _session.get(url)
        except BrowserError:
            # one retry with a fresh browser (a crashed tab, a stale socket)
            _session.close()
            _session = _Session(_profile_dir(), base_url)
            return _session.get(url)


def close():
    global _session
    with _lock:
        if _session is not None:
            _session.close()
            _session = None


def available():
    return chromium_bin() is not None


def _ensure_reaper():
    global _reaper_started
    if _reaper_started:
        return
    _reaper_started = True

    def reap():
        global _session
        while True:
            time.sleep(30)
            with _lock:
                if _session is not None and time.time() - _session.last_used > IDLE_CLOSE_S:
                    _session.close()
                    _session = None
    threading.Thread(target=reap, name="parts_pricer-browser-reaper", daemon=True).start()
