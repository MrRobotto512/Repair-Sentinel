#!/usr/bin/env python3
"""
dev_server.py — run the dashboard page on a dev PC without a bench.

    python3 dev_server.py            # http://127.0.0.1:8377/x/parts_pricer/
    python3 dev_server.py --seed     # also load the test fixtures so search
                                     # works with no MobileSentrix access

It mimics the Hero Dashboard's tiny contract (ctx.path / request / app_dir /
url) and wraps string responses in a dark page. Needs Flask (pip install
flask requests). Never installed on the bench — the real dashboard hosts
web.py there.
"""

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from flask import Flask, request  # noqa: E402

import web  # noqa: E402

FOLDER = os.path.basename(HERE)
app = Flask(__name__)

SHELL = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>BenchTool dev — %s</title>
<style>body{margin:0;background:#0d0d0f;color:#e8e8f0;font:14px/1.45 system-ui,Segoe UI,Roboto,sans-serif}
.wrap{max-width:980px;margin:0 auto;padding:16px}a{color:#40c4ff}</style></head>
<body><div class="wrap">%s</div></body></html>"""


class Ctx:
    def __init__(self, sub):
        self.path = sub
        self.request = request
        self.app_dir = HERE
        self.name = FOLDER
        self.meta = {}

    def url(self, sub=""):
        return f"/x/{FOLDER}/" + sub.lstrip("/")

    def data_path(self, *parts):
        return os.path.join(HERE, "data", *parts)


@app.route(f"/x/{FOLDER}/", defaults={"sub": ""}, methods=["GET", "POST"])
@app.route(f"/x/{FOLDER}/<path:sub>", methods=["GET", "POST"])
def page(sub):
    out = web.handle(Ctx(sub))
    if isinstance(out, str):
        return SHELL % (FOLDER, out)
    if isinstance(out, (dict, list)):
        from flask import jsonify
        return jsonify(out)
    return out


@app.route("/")
def root():
    from flask import redirect
    return redirect(f"/x/{FOLDER}/")


def seed():
    import pp_sentrix as sx
    import pp_store as store
    fx = os.path.join(HERE, "tests", "fixtures")
    with open(os.path.join(fx, "home_menu.html"), encoding="utf-8") as f:
        store.replace_model_index(HERE, sx.parse_model_index(f.read()))
    with open(os.path.join(fx, "listing_iphone13.html"), encoding="utf-8") as f:
        store.replace_products(HERE, "replacement-parts/apple/iphone-parts/iphone-13",
                               sx.parse_listing(f.read()))
    store.import_sheet_csv(HERE, "device,repair,price,note\niPhone 13,Battery,69,AmpSentrix\n")
    print("seeded fixtures into data/parts_pricer.db")


if __name__ == "__main__":
    if "--seed" in sys.argv:
        seed()
    port = int(os.environ.get("PORT", "8377"))
    app.run(host="0.0.0.0", port=port, debug=False)
