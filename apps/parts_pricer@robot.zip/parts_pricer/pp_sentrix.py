#!/usr/bin/env python3
"""
pp_sentrix.py — talk to mobilesentrix.com and turn its pages into plain dicts.

Three things live here, and the parsers are pure functions (no network) so
they can be unit-tested against saved HTML:

  fetch(url)                  GET a page. Plain `requests` first; if Cloudflare
                              answers with its "Just a moment…" challenge, retry
                              through the bench's own Chromium (a real browser
                              passes the check the way any browser would). If
                              that fails too, raise ChallengeError so the
                              dashboard can say so instead of showing nothing.
  parse_model_index(html)     the site's mega-menu (present in the homepage
                              HTML) -> every model page: name, path, brand,
                              family. ~3000 entries.
  parse_listing(html)         a model page fetched with ?limit=all -> every
                              part: id, name, path, price, stock, quality.
  parse_product(html)         a single product page -> name / sku / price /
                              in-stock from its JSON-LD block (live confirm).

Nothing here is clever about the site: it's stock Magento markup. When
MobileSentrix redesigns, this is the only file that should need touching.
"""

from __future__ import annotations

import html as _html
import json
import os
import random
import re
import time

try:
    import requests
except ImportError:          # bench venv always has it; dev PCs might not
    requests = None

BASE = "https://www.mobilesentrix.com"

# Where model pages live. Everything else on the site (accessories, tools,
# board components) is deliberately *not* indexed — a repair quote wants a
# device model, then a part for it.
MODEL_PREFIXES = ("replacement-parts/", "game-console-parts/")

# Look like the browser the shop already uses on the site. Nothing more
# exotic than that — if Cloudflare wants a real browser we hand it one.
UA = ("Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/128.0.0.0 Safari/537.36")
HEADERS = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Connection": "keep-alive",
}

TIMEOUT = 60           # a ?limit=all page can be 2–3 MB
POLITE_DELAY = (1.5, 3.5)   # seconds between requests in a crawl (jittered)


class FetchError(Exception):
    """Network / HTTP problem; message is shop-readable."""


class ChallengeError(FetchError):
    """Cloudflare wants a browser check we could not satisfy."""


# --------------------------------------------------------------------------- #
#  Fetching
# --------------------------------------------------------------------------- #
_session = None


def _sess():
    global _session
    if _session is None and requests is not None:
        _session = requests.Session()
        _session.headers.update(HEADERS)
    return _session


def is_challenge(text):
    """True when the body is Cloudflare's interstitial rather than the site."""
    if not text:
        return False
    head = text[:4000]
    return ("challenges.cloudflare.com" in head
            or "<title>Just a moment" in head
            or "cf-chl" in head
            or "Attention Required! | Cloudflare" in head)


_browser_until = 0.0     # after a challenge, go straight to the browser for a while
BROWSER_STICKY_S = 1800


def fetch(url, allow_browser=True):
    """GET `url` and return its HTML. Raises FetchError / ChallengeError.

    Plain requests first (fast). When Cloudflare answers with its browser
    check, the same URL is fetched from inside the bench's own headless
    Chromium (pp_browser) — raw HTML, cookies kept — and the browser stays
    the first choice for the next half hour."""
    global _browser_until
    if not url.startswith("http"):
        url = BASE + "/" + url.lstrip("/")
    err = None
    if time.time() > _browser_until:
        s = _sess()
        if s is not None:
            try:
                r = s.get(url, timeout=TIMEOUT)
                if r.status_code == 200 and not is_challenge(r.text):
                    return r.text
                if r.status_code == 404:
                    raise FetchError("MobileSentrix says that page no longer exists (404).")
                if is_challenge(r.text):
                    err = "Cloudflare browser check"
                    _browser_until = time.time() + BROWSER_STICKY_S
                else:
                    err = f"HTTP {r.status_code}"
            except requests.RequestException as e:   # type: ignore[union-attr]
                err = f"network error: {e.__class__.__name__}"
        else:
            err = "python-requests is not installed"
    else:
        err = "Cloudflare browser check (recent)"

    if allow_browser:
        try:
            import pp_browser
        except ImportError:
            pp_browser = None
        if pp_browser is not None and pp_browser.available():
            try:
                text = pp_browser.get(url, BASE + "/")
                if text and not is_challenge(text):
                    print(f"[sentrix] fetched via chromium: {url}")
                    return text
                raise ChallengeError(
                    "MobileSentrix (Cloudflare) is asking for a browser check that the "
                    "bench's Chromium couldn't finish. Try again in a few minutes.")
            except pp_browser.BrowserError as e:
                raise ChallengeError(
                    f"MobileSentrix blocked the plain request ({err}) and the bench's "
                    f"Chromium fallback failed: {e}")
        if err and "Cloudflare" in err:
            raise ChallengeError(
                "MobileSentrix (Cloudflare) wants a browser check and this bench has "
                "no Chromium to pass it with. Import prices from a CSV instead.")
    raise FetchError(f"Could not load MobileSentrix ({err}).")


def diagnose():
    """What each fetch path returns for the homepage — for the Cache page."""
    out = {}
    s = _sess()
    if s is not None:
        try:
            r = s.get(BASE + "/", timeout=TIMEOUT)
            out["requests"] = {"status": r.status_code, "bytes": len(r.text),
                               "challenge": is_challenge(r.text),
                               "model_links": len(parse_model_index(r.text)),
                               "title": (re.search(r"<title>([^<]*)", r.text) or [None, ""])[1][:80]}
        except Exception as e:
            out["requests"] = {"error": f"{e.__class__.__name__}: {e}"[:200]}
    else:
        out["requests"] = {"error": "requests not installed"}
    try:
        import pp_browser
        out["chromium"] = {"binary": pp_browser.chromium_bin()}
        if pp_browser.available():
            t0 = time.time()
            text = pp_browser.get(BASE + "/", BASE + "/")
            out["chromium"].update({"bytes": len(text), "challenge": is_challenge(text),
                                    "model_links": len(parse_model_index(text)),
                                    "seconds": round(time.time() - t0, 1)})
    except Exception as e:
        out.setdefault("chromium", {})["error"] = f"{e.__class__.__name__}: {e}"[:200]
    return out


def polite_sleep():
    time.sleep(random.uniform(*POLITE_DELAY))


# --------------------------------------------------------------------------- #
#  Parsers
# --------------------------------------------------------------------------- #
_A_RE = re.compile(
    r'<a\b[^>]*?href="(?:https?://www\.mobilesentrix\.com/)?([^"?#]+)"[^>]*>(.*?)</a>',
    re.I | re.S)
_TAG_RE = re.compile(r"<[^>]+>")


def _clean(s):
    return _html.unescape(_TAG_RE.sub("", s or "")).replace("\xa0", " ").strip()


def _squash(s):
    return re.sub(r"\s+", " ", s or "").strip()


def parse_model_index(html):
    """Every model-page link in the mega-menu, de-duplicated by path.
    Returns list of {path, name, brand, family, depth}."""
    out, seen = [], set()
    for m in _A_RE.finditer(html):
        path = m.group(1).strip("/")
        if not path.startswith(MODEL_PREFIXES):
            continue
        name = _squash(_clean(m.group(2)))
        if not name or len(name) > 80:
            continue
        low = name.lower()
        if low.startswith("view all") or low in ("shop all", "see all", "all"):
            continue
        if path in seen:
            continue
        segs = path.split("/")
        if len(segs) < 3:
            continue              # "replacement-parts/apple" — a brand page
        seen.add(path)
        out.append({
            "path": path,
            "name": name,
            "brand": segs[1],
            "family": segs[2] if len(segs) > 3 else segs[1],
            "depth": len(segs),
        })
    # A page that has children in the menu is a family ("iPhone", "iPad Pro"),
    # not a model — it would list thousands of parts. Keep only the leaves.
    prefixes = set()
    for m in out:
        parts = m["path"].split("/")
        for i in range(3, len(parts)):
            prefixes.add("/".join(parts[:i]))
    return [m for m in out if m["path"] not in prefixes]


_LI_START = re.compile(r'<li class="item[ "]')
_PID_RE = re.compile(r'id="product-price-(\d+)"')
_PID2_RE = re.compile(r'name="products\[\]"[^>]*value="(\d+)"|value="(\d+)"[^>]*name="products\[\]"')
_LINK_RE = re.compile(
    r'<a\b[^>]*href="(?:https?://www\.mobilesentrix\.com/)?([^"?#]+)"[^>]*class="[^"]*product-image[^"]*"',
    re.I | re.S)
_LINK_RE2 = re.compile(
    r'<a\b[^>]*class="[^"]*product-image[^"]*"[^>]*href="(?:https?://www\.mobilesentrix\.com/)?([^"?#]+)"',
    re.I | re.S)
_NAME_RE = re.compile(r'<h2 class="product-name"[^>]*>(.*?)</h2>', re.I | re.S)
_TITLE_RE = re.compile(r'title="([^"]+)"[^>]*class="[^"]*product-image', re.I)
_PRICEBOX_RE = re.compile(r'<div class="price-box[^"]*">(.*?)</div>\s*<div', re.I | re.S)
_MONEY_RE = re.compile(r"\$\s*([0-9][0-9,]*\.?[0-9]*)")
_SPECIAL_RE = re.compile(r'class="[^"]*special-price[^"]*"[^>]*>(.*?)</', re.I | re.S)
_QTY_RE = re.compile(r'class="productqty"[^>]*value="(\d+)"|value="(\d+)"[^>]*class="productqty"')
_QUALITY_RE = re.compile(r'class="[^"]*product-badges[^"]*"[^>]*\balt="([^"]*)"', re.I)
_QUALITY_RE2 = re.compile(r'\balt="([^"]*)"[^>]*class="[^"]*product-badges', re.I)


def _money(s):
    m = _MONEY_RE.search(s or "")
    if not m:
        return None
    try:
        return round(float(m.group(1).replace(",", "")), 2)
    except ValueError:
        return None


def _split_items(html):
    starts = [m.start() for m in _LI_START.finditer(html)]
    for i, st in enumerate(starts):
        if i + 1 < len(starts):
            end = starts[i + 1]
        else:
            # last item: stop at the grid's closing </ul> so the page footer
            # (which also says "Notify Me" etc.) never bleeds into it
            ul = html.find("</ul>", st)
            end = ul if ul > 0 else len(html)
        block = html[st:end]
        close = block.rfind("</li>")
        if close > 0:
            block = block[:close + 5]
        yield block


def parse_listing(html):
    """Parse a category / model page into products. Returns a list of dicts:
    pid, name, path, price (float|None), in_stock (bool), qty (int|None),
    quality (str), all_colors (bool)."""
    out, seen = [], set()
    for block in _split_items(html):
        m = _PID_RE.search(block)
        if not m:
            m2 = _PID2_RE.search(block)
            pid = (m2.group(1) or m2.group(2)) if m2 else None
        else:
            pid = m.group(1)
        if not pid or pid in seen:
            continue
        name = ""
        nm = _NAME_RE.search(block)
        if nm:
            name = _squash(_clean(nm.group(1)))
        if not name:
            tm = _TITLE_RE.search(block)
            name = _squash(_html.unescape(tm.group(1))) if tm else ""
        if not name:
            continue
        lk = _LINK_RE.search(block) or _LINK_RE2.search(block)
        path = lk.group(1).strip("/") if lk else ""

        price = None
        pb = _PRICEBOX_RE.search(block)
        pbtext = pb.group(1) if pb else block
        sp = _SPECIAL_RE.search(pbtext)
        if sp:
            price = _money(sp.group(1))
        if price is None:
            price = _money(pbtext)

        qty = None
        qm = _QTY_RE.search(block)
        if qm:
            try:
                qty = int(qm.group(1) or qm.group(2))
            except (TypeError, ValueError):
                qty = None
        oos = ("outofstockbtn" in block or "Notify Me" in block
               or "productOutOfStockForm" in block)
        in_stock = (not oos) and (qty is None or qty > 0)

        quality = ""
        qmatch = _QUALITY_RE.search(block) or _QUALITY_RE2.search(block)
        if qmatch:
            quality = _squash(_html.unescape(qmatch.group(1)))
            quality = re.sub(r"^quality\s*[-:]\s*", "", quality, flags=re.I)
        all_colors = 'alt="All Colors"' in block or "All Colors" in block

        seen.add(pid)
        out.append({
            "pid": pid, "name": name, "path": path, "price": price,
            "in_stock": in_stock, "qty": qty, "quality": quality,
            "all_colors": all_colors,
        })
    return out


_LD_RE = re.compile(
    r'<script[^>]+type="application/ld\+json"[^>]*>(.*?)</script>', re.I | re.S)


def parse_product(html):
    """A single product page -> {name, sku, price, in_stock, url} or None."""
    for m in _LD_RE.finditer(html):
        try:
            data = json.loads(m.group(1))
        except ValueError:
            continue
        nodes = data.get("@graph", [data]) if isinstance(data, dict) else data
        if not isinstance(nodes, list):
            continue
        for n in nodes:
            if not isinstance(n, dict):
                continue
            t = n.get("@type")
            if t == "Product" or (isinstance(t, list) and "Product" in t):
                offers = n.get("offers") or {}
                if isinstance(offers, list):
                    offers = offers[0] if offers else {}
                price = None
                try:
                    price = round(float(str(offers.get("price", "")).replace(",", "")), 2)
                except ValueError:
                    price = None
                avail = str(offers.get("availability", ""))
                return {
                    "name": _squash(str(n.get("name", ""))),
                    "sku": str(n.get("sku", "")),
                    "price": price,
                    "in_stock": "InStock" in avail or "LimitedAvailability" in avail,
                    "url": str(offers.get("url") or n.get("url") or ""),
                }
    # fallback: the listing-style price span exists on product pages too
    pm = re.search(r'id="product-price-\d+"[^>]*>\s*\$\s*([0-9][0-9,]*\.?\d*)', html)
    if pm:
        return {"name": "", "sku": "", "price": _money("$" + pm.group(1)),
                "in_stock": "Notify Me" not in html[:400000], "url": ""}
    return None


def listing_url(path):
    return f"{BASE}/{path.strip('/')}?limit=all"


SEARCH_PREFIX = "search/"


def search_path(query):
    """Pseudo model path for a site search: 'x218 lcd' -> 'search/x218-lcd'."""
    slug = re.sub(r"[^a-z0-9]+", "-", (query or "").lower()).strip("-")[:80]
    return SEARCH_PREFIX + slug


def search_query(path):
    return path[len(SEARCH_PREFIX):].replace("-", " ") if path.startswith(SEARCH_PREFIX) else ""


def search_url(query, page=1):
    from urllib.parse import quote_plus
    u = f"{BASE}/catalogsearch/result/?q={quote_plus(query)}"
    return u + (f"&p={page}" if page > 1 else "")


def product_url(path):
    return f"{BASE}/{path.strip('/')}"
