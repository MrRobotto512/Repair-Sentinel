# 💲 Parts Pricer — MobileSentrix cost → customer price, in seconds

**The problem it solves.** A customer asks for a repair that isn't on the
price sheet. Today that means: open mobilesentrix.com, hunt for the model,
find the part, work out markup + labor by hand, then quote. Parts Pricer
turns that into one search box on the Hero Dashboard:

```
iphone 13 pro max screen      →   cost $37.03  →  $105.00
s23 ultra battery             →   cost $12.40  →  $65.00
ps5 hdmi port                 →   cost  $4.20  →  $55.00
```

Your own price sheet answers first. Anything not on it is priced from
MobileSentrix's cost using the shop's rule (% markup + the labor rate that
fits the job, rounded), with the breakdown one tap away, and every quote
is logged so the repeat ones can be added to the sheet. Queries with no
model name in them ("x218 lcd", "sm-a536 battery") fall back to
MobileSentrix's own search, which knows the model codes, and the results
carry "looks like: Tab A9 Plus…" chips to jump to the full model page.

## Pages (Hero Dashboard ▸ 💲 Parts Pricer)

| Page | What it does |
|---|---|
| **Search** | Type model + part. Sheet hits on top, then every matching MobileSentrix part with quality grade, stock, cost and the customer price. **Quote** logs it; **Live check** re-reads that product's page right now; **↗ MobileSentrix** opens it. |
| **Price sheet** | Import your sheet as CSV (`device, repair, price[, note]` — headers matched loosely), add rows by hand, export. |
| **Quotes** | Everything quoted, newest first; **+ sheet** turns one into a price-sheet row; export CSV. |
| **Cache** | The MobileSentrix model list (~3,000 models), which models are cached, the overnight refresh window, and optional pre-caching of whole families (iPhone, Galaxy S, PlayStation…). |
| **Pricing rules** | Markup %, default labor, rounding (none / next $5 / next $10 / end in 9), minimum price, a "+ tax" note — and the **labor rates** table: named rates by part word (`screen`, `battery`, `back glass`…), by model (`galaxy fold`), or both for special cases (`ipad` + `screen`, `iphone 14 pro max` + `back glass`, `ps5` + `hdmi`). Most specific rate wins; each search result has a labor dropdown (any rate, default, or a custom amount) that recalculates the price before you tap Quote. |

The bench tile shows a QR code for the dashboard page, cache health, and a
**QUICK LOOKUP** (on-screen keyboard → top matches with prices).

## How it gets the prices

MobileSentrix shows prices without a login and gives every device model its
own page; `?limit=all` returns every part of a model in one request. So the
bench:

1. loads the **model list** from the site's menu (once; refreshed weekly),
2. fetches a model's parts **the first time you search it** (~3–5 s, one
   request) and keeps them in `data/parts_pricer.db`,
3. **refreshes cached models overnight** (default: anything older than 3
   days, between 02:00 and 06:00), spaced out politely,
4. re-reads a single product page when you tap **Live check**.

MobileSentrix sits behind Cloudflare, which challenges plain requests but
lets a real browser through. When that happens the bench opens its own
headless Chromium once (persistent profile in `data/chromium-profile/`, so
the clearance sticks), lets the check finish, and pulls the **raw HTML** of
every page through that browser session — raw, because the site's own
JavaScript strips the model menu out of the rendered page. If even that
fails, the page says so plainly and nothing is retried until you tap **Try
again** — a blocked bench never hammers the site. **🩺 Connection test** on
the Cache page shows what each path gets back.

Public (logged-out) prices are used. If your account sees different tier
prices, say so — a login option can be added.

## Files

```
parts_pricer/
  app.json        manifest (web page + open api/status endpoint)
  main.py         bench touchscreen face
  web.py          Hero Dashboard pages + JSON actions
  pp_sentrix.py   fetch + parsers for mobilesentrix.com (the only site-specific file)
  pp_browser.py   raw-HTML fetch through the bench's headless Chromium (DevTools protocol)
  pp_search.py    "iphone 13 pro max screen" → model + part filter (pure)
  pp_pricing.py   the pricing rule (pure)
  pp_store.py     SQLite: models, products, sheet, quotes, settings
  pp_worker.py    background fetch queue + overnight scheduler
  dev_server.py   run the dashboard page on a dev PC (python3 dev_server.py --seed)
  tests/          python3 tests/test_parts_pricer.py  (no network needed)
```

## Install

Upload the zipped folder on **Hero Dashboard ▸ 🧩 My Apps**, or
`scp -r parts_pricer <user>@<bench-ip>:~/benchtool-apps/`. No extra
packages: it uses `requests` and `sqlite3` from the bench stack (QR code on
the tile uses `qrcode` + Pillow when present).

## Status

Parsers and pricing are unit-tested against saved MobileSentrix markup
(Sept 2026); the Chromium fetch path is tested against a local server.
v1.1: first bench run showed Cloudflare challenging plain requests and the
Pi's Chromium passing — v1.0's rendered-DOM fallback lost the model menu,
so v1.1 fetches raw HTML through the browser session instead.
