#!/usr/bin/env python3
"""
pp_worker.py — the one background thread that talks to MobileSentrix.

The dashboard must never block a request on the network, so every fetch is
a job on this queue and the page polls `status()` until it's done:

  enqueue_index(app_dir)            refresh the ~3000-model list (homepage)
  enqueue_model(app_dir, path)      cache every part of one model (?limit=all)
  enqueue_family(app_dir, brand, family)   every model of a family, in turn
  refresh_stale(app_dir, days)      re-fetch cached models older than N days

`status()` is a snapshot the page can render: what's running, what's queued,
the last error, and per-model progress. A scheduler thread wakes hourly and,
inside the configured night window, refreshes stale models on its own.
"""

from __future__ import annotations

import queue
import threading
import time
import traceback

import pp_sentrix as sx
import pp_store as store

_q = queue.Queue()
_lock = threading.Lock()
_state = {
    "running": None,       # {"kind":..., "label":..., "started":...}
    "queued": [],          # labels
    "last_error": "",
    "last_done": "",
    "last_done_at": 0.0,
    "done_paths": {},      # path -> ts (recent completions, for polling)
    "total_fetched": 0,
}
_threads_started = False


def _label(job):
    kind = job[0]
    if kind == "index":
        return "model list"
    if kind == "diag":
        return "connection test"
    if kind == "model":
        return job[2] if len(job) > 2 else job[1]
    if kind == "family":
        return f"{job[1]}/{job[2]}"
    return kind


def status():
    with _lock:
        s = dict(_state)
        s["queued"] = list(_state["queued"])
        s["done_paths"] = dict(_state["done_paths"])
    return s


def is_pending(path):
    with _lock:
        r = _state["running"]
        if r and r.get("path") == path:
            return True
        return any(q.get("path") == path for q in _state["queued"])


def _set_running(job, path=None):
    with _lock:
        _state["running"] = {"kind": job[0], "label": _label(job),
                             "started": time.time(), "path": path}
        _state["queued"] = [q for q in _state["queued"]
                            if not (q["label"] == _label(job))]


def _push(job, path=None):
    with _lock:
        lbl = _label(job)
        if any(q["label"] == lbl for q in _state["queued"]):
            return False
        r = _state["running"]
        if r and r["label"] == lbl:
            return False
        _state["queued"].append({"kind": job[0], "label": lbl, "path": path})
    _q.put(job)
    return True


def enqueue_index(app_dir):
    ensure_threads(app_dir)
    return _push(("index", app_dir))


def enqueue_model(app_dir, path, name=""):
    ensure_threads(app_dir)
    return _push(("model", app_dir, name or path, path), path=path)


def enqueue_family(app_dir, brand, family):
    ensure_threads(app_dir)
    return _push(("family", app_dir, brand, family))


def refresh_stale(app_dir, days):
    n = 0
    for m in store.stale_models(app_dir, days):
        if enqueue_model(app_dir, m["path"], m["name"]):
            n += 1
    return n


# --------------------------------------------------------------------------- #
#  jobs
# --------------------------------------------------------------------------- #
def do_index(app_dir):
    html = sx.fetch(sx.BASE + "/")
    models = sx.parse_model_index(html)
    if len(models) < 50:
        raise sx.FetchError(
            f"The MobileSentrix homepage came back with only {len(models)} model "
            "links — the site layout may have changed.")
    total, new = store.replace_model_index(app_dir, models)
    return f"Model list refreshed: {total} models ({new} new)."


def _fetch_search(query):
    """MobileSentrix's own search, page by page (it ignores limit=all)."""
    out, seen = [], set()
    for page in range(1, 5):
        html = sx.fetch(sx.search_url(query, page))
        items = [p for p in sx.parse_listing(html) if p["pid"] not in seen]
        if not items:
            break
        for p in items:
            seen.add(p["pid"])
            out.append(p)
        if len(items) < 20:
            break
        sx.polite_sleep()
    return out, html


def do_model(app_dir, path, name=""):
    store.set_model_status(app_dir, path, "fetching")
    try:
        if path.startswith(sx.SEARCH_PREFIX):
            products, html = _fetch_search(sx.search_query(path))
        else:
            html = sx.fetch(sx.listing_url(path))
            products = sx.parse_listing(html)
    except Exception as e:
        store.set_model_status(app_dir, path, "error", str(e))
        raise
    if path.startswith(sx.SEARCH_PREFIX):
        store.replace_products(app_dir, path, products)
        return f"site search “{sx.search_query(path)}”: {len(products)} result(s)."
    if not products and ("product-name" in html or "products-grid" in html):
        store.set_model_status(app_dir, path, "error",
                               "page loaded but no parts were recognised")
        raise sx.FetchError(f"{name or path}: page loaded but no parts were "
                            "recognised — the site layout may have changed.")
    store.replace_products(app_dir, path, products)
    return f"{name or path}: {len(products)} parts cached."


def do_family(app_dir, brand, family):
    ms = store.models_in_family(app_dir, brand, family)
    n = 0
    for m in ms:
        if m.get("fetched_at") and time.time() - m["fetched_at"] < 6 * 3600:
            continue
        enqueue_model(app_dir, m["path"], m["name"])
        n += 1
    return f"{brand}/{family}: queued {n} model(s)."


def do_diag(app_dir):
    res = sx.diagnose()
    res["at"] = time.time()
    store.kv_set(app_dir, "last_diag", res)
    r, c = res.get("requests", {}), res.get("chromium", {})
    return (f"Connection test done — plain request: "
            f"{r.get('model_links', 0) if 'error' not in r else 'failed'} models; "
            f"Chromium: {c.get('model_links', 0) if 'error' not in c else 'failed'} models.")


def enqueue_diag(app_dir):
    ensure_threads(app_dir)
    return _push(("diag", app_dir))


def _run(job):
    kind = job[0]
    if kind == "diag":
        return do_diag(job[1])
    if kind == "index":
        return do_index(job[1])
    if kind == "model":
        return do_model(job[1], job[3], job[2])
    if kind == "family":
        return do_family(job[1], job[2], job[3])
    return "?"


def _worker():
    while True:
        job = _q.get()
        path = job[3] if job[0] == "model" else None
        _set_running(job, path)
        try:
            msg = _run(job)
            with _lock:
                _state["last_done"] = msg
                _state["last_done_at"] = time.time()
                _state["last_error"] = ""
                _state["total_fetched"] += 1
                if path:
                    _state["done_paths"][path] = time.time()
            print(f"[parts_pricer] {msg}")
        except Exception as e:
            err = str(e) or e.__class__.__name__
            with _lock:
                _state["last_error"] = f"{_label(job)}: {err}"
                if path:
                    _state["done_paths"][path] = time.time()
            print(f"[parts_pricer] job failed: {_label(job)}: {err}")
            traceback.print_exc()
            if isinstance(e, sx.ChallengeError):
                # don't hammer the site while it's challenging us
                time.sleep(20)
        finally:
            with _lock:
                _state["running"] = None
                # forget completions older than 10 minutes
                old = time.time() - 600
                _state["done_paths"] = {k: v for k, v in _state["done_paths"].items()
                                        if v > old}
            _q.task_done()
        if job[0] not in ("family", "diag"):
            sx.polite_sleep()


def _scheduler(app_dir):
    """Hourly: inside the night window, refresh stale cached models; refresh
    the model list weekly."""
    while True:
        time.sleep(3600)
        try:
            s = store.kv_get(app_dir, "crawl", {}) or {}
            if not s.get("auto", True):
                continue
            hour = time.localtime().tm_hour
            start = int(s.get("night_start", 2))
            end = int(s.get("night_end", 6))
            in_window = (start <= hour < end) if start < end else (hour >= start or hour < end)
            if not in_window:
                continue
            days = float(s.get("stale_days", 3))
            refresh_stale(app_dir, days)
            st = store.stats(app_dir)
            if not st["index_fetched_at"] or time.time() - st["index_fetched_at"] > 7 * 86400:
                enqueue_index(app_dir)
        except Exception as e:
            print(f"[parts_pricer] scheduler: {e}")


def ensure_threads(app_dir):
    global _threads_started
    with _lock:
        if _threads_started:
            return
        _threads_started = True
    threading.Thread(target=_worker, name="parts_pricer-worker",
                     daemon=True).start()
    threading.Thread(target=_scheduler, args=(app_dir,),
                     name="parts_pricer-sched", daemon=True).start()


def run_now(app_dir, path, name=""):
    """Synchronous fetch for callers that can block (the Tk app's thread)."""
    return do_model(app_dir, path, name)
