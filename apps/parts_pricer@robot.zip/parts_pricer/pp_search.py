#!/usr/bin/env python3
"""
pp_search.py — turn "iphone 13 pro max screen" into (model, part filter).

Pure functions, no I/O. The dashboard hands us the cached model index and a
model's cached parts; we hand back ranked matches.

How a query is read:
  1. tokenize: lowercase, split letters from digits ("iphone13" -> iphone 13),
     expand a few shop shorthands (ip -> iphone, sam -> samsung, promax ->
     pro max, s23u -> s23 ultra).
  2. MODEL: a model matches when every *significant* token of its name is in
     the query (site names like "Galaxy S23 Ultra" ignore filler words such
     as galaxy/apple/samsung). More matched tokens = more specific = ranks
     first, so "iphone 13 pro max screen" prefers "iPhone 13 Pro Max" over
     "iPhone 13". Ties broken by shorter model name.
  3. PART: the query tokens the model did not use become the part filter.
     Each part word is expanded to synonyms (screen -> lcd/oled/display/
     assembly …) and a part matches when every filter word (or a synonym)
     appears in its name.
"""

from __future__ import annotations

import re

STOP = {"galaxy", "apple", "samsung", "for", "the", "a", "and", "parts", "part",
        "series", "with", "5g", "4g", "lte", "wifi", "cellular", "compatible",
        "replacement", "phone", "model", "gen", "generation"}

SHORTHAND = {
    "ip": "iphone", "iph": "iphone", "sam": "samsung", "sammy": "samsung",
    "promax": "pro max", "pm": "pro max", "plus": "plus", "+": "plus",
    "ps5": "playstation 5", "ps4": "playstation 4", "ps3": "playstation 3",
    "xsx": "xbox series x", "xss": "xbox series s", "xb1": "xbox one",
    "nsw": "switch", "gen": "gen", "u": "ultra", "fe": "fe",
    "screen": "screen", "bat": "battery", "batt": "battery",
    "cp": "charging port", "chargeport": "charging port",
    "backglass": "back glass", "lcd": "lcd", "oled": "oled",
}

# part word -> alternatives that count as the same thing in a product name
SYNONYMS = {
    "screen": ["screen", "lcd", "oled", "display", "assembly", "digitizer"],
    "display": ["screen", "lcd", "oled", "display", "assembly"],
    "lcd": ["lcd", "assembly", "display"],
    "oled": ["oled", "assembly", "display"],
    "battery": ["battery"],
    "charging": ["charging", "charge", "dock", "usb-c", "lightning"],
    "charge": ["charging", "charge", "dock", "usb-c", "lightning"],
    "port": ["port", "connector", "dock", "flex"],
    "dock": ["dock", "charging"],
    "back": ["back", "rear"],
    "rear": ["rear", "back"],
    "glass": ["glass", "cover", "housing"],
    "housing": ["housing", "frame", "chassis", "back"],
    "frame": ["frame", "housing", "chassis"],
    "camera": ["camera"],
    "front": ["front", "selfie"],
    "speaker": ["speaker", "loudspeaker", "buzzer", "loud"],
    "earpiece": ["earpiece", "ear", "receiver"],
    "ear": ["earpiece", "ear", "receiver"],
    "mic": ["mic", "microphone"],
    "microphone": ["mic", "microphone"],
    "power": ["power", "on/off", "on-off", "sleep"],
    "volume": ["volume"],
    "button": ["button", "flex", "key"],
    "flex": ["flex", "cable", "ribbon"],
    "cable": ["flex", "cable", "ribbon"],
    "vibrator": ["vibrator", "taptic", "vibration", "motor"],
    "taptic": ["taptic", "vibrator", "vibration"],
    "sim": ["sim", "tray"],
    "tray": ["tray", "sim"],
    "wireless": ["wireless", "nfc", "qi", "magsafe"],
    "nfc": ["nfc", "wireless"],
    "hdmi": ["hdmi"],
    "fan": ["fan", "cooling"],
    "drive": ["drive", "disc", "disk", "blu-ray", "bluray", "optical"],
    "controller": ["controller", "dualsense", "dualshock", "joycon", "joy-con"],
    "stick": ["stick", "joystick", "thumbstick", "analog"],
    "joystick": ["stick", "joystick", "thumbstick", "analog"],
    "lens": ["lens", "glass"],
    "adhesive": ["adhesive", "tape", "seal"],
    "keyboard": ["keyboard", "topcase", "top case"],
    "trackpad": ["trackpad", "touchpad"],
    "logic": ["logic", "board", "motherboard", "mainboard"],
    "board": ["board", "logic", "motherboard", "mainboard"],
    "ssd": ["ssd", "storage"],
    "genuine": ["genuine", "oem", "service pack", "original"],
    "oem": ["genuine", "oem", "service pack", "original"],
    "aftermarket": ["aftermarket"],
    "incell": ["incell", "in-cell"],
    "soft": ["soft"],
    "hard": ["hard"],
    "refurb": ["refurb", "refurbished"],
    "pull": ["pull", "pulled", "used"],
}

def tokenize(text):
    """Lowercase word list with shorthands expanded. A word glued to a
    number is split only when the word part is 3+ letters ("iphone13" ->
    "iphone 13", "13promax" -> "13 pro max") so codes like s23 / a15 /
    a2991 / 5g stay whole."""
    text = (text or "").lower().replace("-", " ").replace("/", " ")
    text = re.sub(r'(\d)\s*(?:"|”|\'\'|inch\b)', r"\1", text)   # 13" -> 13
    text = text.replace("+", " plus ")
    text = re.sub(r"[^\w\s.]", " ", text)
    text = re.sub(r"([a-z]{3,})(\d)", r"\1 \2", text)
    text = re.sub(r"(\d)([a-z]{3,})", r"\1 \2", text)
    out = []
    for w in text.split():
        w = w.strip(".")
        if not w:
            continue
        m = re.match(r"^([a-z]{1,2})(\d+)$", w)      # ip13 -> iphone 13
        if m and m.group(1) in _GLUED:
            w = _GLUED[m.group(1)] + " " + m.group(2)
        w = SHORTHAND.get(w, w)
        out.extend(w.split())
    return out


_GLUED = {"ip": "iphone"}   # only prefixes that are never a model code


_CODE_RE = re.compile(r"^(a\d{4}|sm\w{3,}|m[1-5]|[12]\d{3}|\d+(\.\d+)?in)$")


def is_code(tok):
    """Model codes / years / chip names — helpful when typed, never required."""
    return bool(_CODE_RE.match(tok))


def _model_tokens(name):
    """Significant tokens of a site model name -> (required, optional).
    Everything from the first parenthesis on — "(A2338)", "(2023) M3 Pro /
    M3 Max" — plus A-numbers, chip names and years anywhere are optional: a
    tech rarely types them, but when they do they pin the model down."""
    name = (name or "").lower()
    cut = name.find("(")
    head, tail = (name, "") if cut < 0 else (name[:cut], name[cut:])
    sig, opt = [], []
    for t in tokenize(head):
        if t in STOP:
            continue
        (opt if is_code(t) else sig).append(t)
    for t in tokenize(tail):
        if t not in STOP and t not in sig and t not in opt:
            opt.append(t)
    return sig, opt


_STRONG_RE = re.compile(r"^(a\d{4}|sm\w{3,}|[a-z]{1,2}\d{3,4})$")


def _strong_codes(sig, opt):
    """Optional tokens that identify a model on their own: A-numbers
    (a2991), SM- codes, Samsung short codes in the tail (a156, s918)."""
    return {t for t in opt if _STRONG_RE.match(t) and t not in sig}


def match_models(query, models, limit=6):
    """Rank the model index for a query. Returns a list of
    (model_dict, score, used_tokens) — best first. Empty if nothing fits."""
    q = tokenize(query)
    qset = set(q)
    if not qset:
        return []
    ranked = []
    for m in models:
        sig, opt = _model_tokens(m.get("name", ""))
        if not sig and not opt:
            continue
        hit = [t for t in sig if t in qset]
        opt_hit = [t for t in opt if t in qset]
        strong = _strong_codes(sig, opt)
        strong_code = [t for t in opt_hit if t in strong]
        if sig and len(hit) == len(sig):
            # model fully named in the query; codes only sharpen the score
            score = len(hit) * 10 + len(opt_hit) * 3
        elif strong_code:
            # "a2991 screen" — an A-number / SM- code pins the model on its own
            score = 8 + len(strong_code) * 12 + len(hit) * 4
        else:
            continue
        ranked.append((m, score, set(hit) | set(opt_hit)))
    if not ranked:
        # loose fallback: at least two significant tokens (or one if that's
        # all the model has) matched — for typos like "iphone 13 promax"
        for m in models:
            sig, opt = _model_tokens(m.get("name", ""))
            if not sig:
                continue
            hit = [t for t in sig if t in qset]
            if len(hit) >= max(1, min(2, len(sig))) and len(hit) >= len(sig) - 1 \
                    and any(t.isdigit() or any(ch.isdigit() for ch in t) for t in hit):
                ranked.append((m, len(hit) * 4 - (len(sig) - len(hit)), set(hit)))
    ranked.sort(key=lambda r: (-r[1], len(r[0].get("name", "")), r[0].get("depth", 9)))
    return ranked[:limit]


def part_filter(query, used_tokens):
    """Query tokens left after the model took its share."""
    return [t for t in tokenize(query) if t not in used_tokens and t not in STOP]


def _expand(word):
    alts = SYNONYMS.get(word)
    return alts if alts else [word]


def match_parts(filter_words, products, limit=60):
    """Filter + rank a model's products. Returns list of (product, score)."""
    words = [w for w in (filter_words or []) if w]
    scored = []
    for p in products:
        name = (p.get("name") or "").lower()
        ntoks = set(tokenize(name))
        ok = True
        score = 0
        for w in words:
            alts = _expand(w)
            found = False
            for a in alts:
                if " " in a:
                    if a in name:
                        found = True
                        score += 2 if a == w else 1
                        break
                elif a in ntoks or a in name:
                    found = True
                    score += 3 if a == w else 1
                    break
            if not found:
                ok = False
                break
        if not ok:
            continue
        # gentle preferences: in stock first, then what a repair shop usually
        # means (an assembly, not a protection mesh)
        if p.get("in_stock"):
            score += 5
        if "assembly" in ntoks:
            score += 2
        if any(k in name for k in ("protector", "protection", "mesh", "stencil",
                                    "film", "pack)", "tempered", "sticker")):
            score -= 4
        scored.append((p, score))
    scored.sort(key=lambda r: (-r[1], r[0].get("price") if r[0].get("price") is not None else 1e9,
                               r[0].get("name", "")))
    return scored[:limit]


def match_sheet(query, rows, limit=5):
    """Match the shop's own price sheet rows ({device, repair, price}).
    A row matches when all its device words AND repair words (via synonyms)
    appear in the query. Returns [(row, score)]."""
    q = tokenize(query)
    qset = set(q)
    out = []
    for r in rows:
        dev = [t for t in tokenize(r.get("device", "")) if t not in STOP]
        rep = [t for t in tokenize(r.get("repair", "")) if t not in STOP]
        if not dev and not rep:
            continue
        if any(t not in qset for t in dev):
            continue
        rep_ok = True
        for w in rep:
            if not any(a in qset or (" " in a and a in " ".join(q)) for a in _expand(w)):
                rep_ok = False
                break
        if not rep_ok:
            continue
        out.append((r, len(dev) * 10 + len(rep) * 5, set(dev)))
    # "iPhone 13 Pro" beats "iPhone 13" when both fit: drop rows whose device
    # words are a strict subset of another hit's
    devsets = [d for _r, _s, d in out]
    keep = [(r, s) for r, s, d in out
            if not any(d < other for other in devsets)]
    keep.sort(key=lambda x: -x[1])
    return keep[:limit]
