#!/usr/bin/env python3
"""
Parts Pricer — bench touchscreen face.

The real work happens on the Hero Dashboard page (web.py): search a model +
part, see MobileSentrix cost next to the customer price, log the quote.
This screen is for the tech standing at the bench:

  • a QR code + URL for the dashboard page (scan with the counter phone)
  • cache health at a glance (models known / cached, quotes today)
  • QUICK LOOKUP — on-screen keyboard -> top matches with prices, right here
  • REFRESH LIST — reload the MobileSentrix model list

Follows the BenchTool app contract: own Tk root, ui_theme when on the bench,
big X top-right -> sys.exit(0), never crashes on a network failure.
"""

import os
import sys
import threading
import tkinter as tk
from tkinter import font

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import pp_pricing as pricing
import pp_search as search
import pp_sentrix as sx
import pp_store as store
import pp_worker as worker

try:
    import ui_theme as _ui
    ON_BENCH = True
except ImportError:
    _ui = None
    ON_BENCH = False

try:
    import bench_keyboard
except ImportError:
    bench_keyboard = None

BG = "#0d0d0f"
CARD = "#1b1b21"
FG = "#e8e8f0"
DIM = "#aab0bf"
MUT = "#7a7a8c"
ACC = "#40c4ff"
OK = "#00c853"
WARN = "#ff6666"
MONEY = "#69f0ae"

DASH_PORT = 8377


def _lan_ip():
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"


class App(tk.Tk):
    TITLE = "PARTS PRICER"

    def __init__(self):
        super().__init__()
        if ON_BENCH and hasattr(_ui, "apply_root"):
            _ui.apply_root(self)
        else:
            self.geometry("800x480")
            self.title(self.TITLE + " (dev)")
        self.configure(bg=BG)
        self.f_title = font.Font(family="DejaVu Sans", size=26, weight="bold")
        self.f_btn = font.Font(family="DejaVu Sans", size=18, weight="bold")
        self.f_body = font.Font(family="DejaVu Sans", size=14)
        self.f_small = font.Font(family="DejaVu Sans", size=11)
        self.f_money = font.Font(family="DejaVu Sans", size=20, weight="bold")
        self.f_exit = font.Font(family="DejaVu Sans", size=24, weight="bold")
        self.url = f"http://{_lan_ip()}:{DASH_PORT}/x/{os.path.basename(HERE)}/"
        self._qr_img = None
        self._build()
        self.after(150, self.refresh_stats)

    # ---- layout -------------------------------------------------------- #
    def _build(self):
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill=tk.X, padx=10, pady=(8, 2))
        tk.Label(bar, text="💲 " + self.TITLE, font=self.f_title, bg=BG,
                 fg=ACC).pack(side=tk.LEFT, padx=6)
        tk.Button(bar, text="X", font=self.f_exit, bg="#3a1a1a", fg=WARN,
                  activebackground="#5a2a2a", activeforeground=WARN, bd=3,
                  relief="raised", width=3, command=self.close).pack(side=tk.RIGHT, padx=6)

        self.body = tk.Frame(self, bg=BG)
        self.body.pack(fill=tk.BOTH, expand=True, padx=12, pady=4)
        self._home()

    def _clear(self):
        for w in self.body.winfo_children():
            w.destroy()

    def _home(self):
        self._clear()
        left = tk.Frame(self.body, bg=BG)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        right = tk.Frame(self.body, bg=CARD, bd=0)
        right.pack(side=tk.RIGHT, fill=tk.Y, padx=(10, 0))

        tk.Label(left, text="Quote repairs from the Hero Dashboard:",
                 font=self.f_body, bg=BG, fg=DIM, anchor="w").pack(fill=tk.X)
        tk.Label(left, text=self.url, font=self.f_body, bg=BG, fg=ACC,
                 anchor="w", wraplength=440, justify="left").pack(fill=tk.X, pady=(0, 6))
        self.stats_lbl = tk.Label(left, text="…", font=self.f_small, bg=BG, fg=MUT,
                                  anchor="w", justify="left", wraplength=440)
        self.stats_lbl.pack(fill=tk.X)
        self.status = tk.Label(left, text="", font=self.f_small, bg=BG, fg=DIM,
                               anchor="w", justify="left", wraplength=440)
        self.status.pack(fill=tk.X, pady=(2, 6))

        tk.Button(left, text="🔎  QUICK LOOKUP", font=self.f_btn, bg="#123a4d", fg="#eaf6ff",
                  activebackground="#1a4f68", activeforeground="#fff", bd=0, height=2,
                  command=self.quick_lookup).pack(fill=tk.X, pady=4)
        tk.Button(left, text="↻  REFRESH MODEL LIST", font=self.f_btn, bg=CARD, fg=DIM,
                  activebackground="#2a2a32", activeforeground=FG, bd=0, height=2,
                  command=self.refresh_index).pack(fill=tk.X, pady=4)

        # QR code of the dashboard URL (optional libs, guarded)
        tk.Label(right, text="scan for the\ndashboard page", font=self.f_small,
                 bg=CARD, fg=MUT, justify="center").pack(padx=10, pady=(8, 2))
        qr = self._make_qr(self.url)
        if qr is not None:
            self._qr_img = qr
            tk.Label(right, image=qr, bg=CARD).pack(padx=10, pady=(0, 10))
        else:
            tk.Label(right, text="(QR unavailable)", font=self.f_small, bg=CARD,
                     fg=MUT).pack(padx=10, pady=10)

    def _make_qr(self, text):
        try:
            import qrcode
            from PIL import ImageTk
            img = qrcode.make(text, box_size=5, border=2).convert("RGB")
            img = img.resize((220, 220))
            return ImageTk.PhotoImage(img)
        except Exception as e:      # missing lib, no display, etc.
            print(f"qr unavailable: {e}")
            return None

    # ---- actions ------------------------------------------------------- #
    def refresh_stats(self):
        try:
            st = store.stats(HERE)
            self.stats_lbl.config(
                text=(f"{st['models']} models known · {st['cached']} cached "
                      f"({st['products']} parts) · {st['sheet']} sheet rows · "
                      f"{st['quotes_today']} quotes today"))
        except Exception as e:
            self.stats_lbl.config(text=f"stats unavailable: {e}", fg=WARN)

    def set_status(self, msg, color=DIM):
        try:
            self.status.config(text=msg, fg=color)
            self.update_idletasks()
        except tk.TclError:
            pass

    def refresh_index(self):
        self.set_status("Loading the MobileSentrix model list…", ACC)

        def run():
            try:
                msg = worker.do_index(HERE)
                self.after(0, lambda: (self.set_status(msg, OK), self.refresh_stats()))
            except Exception as e:
                err = f"Failed: {e}"
                self.after(0, lambda: self.set_status(err, WARN))
        threading.Thread(target=run, daemon=True).start()

    def quick_lookup(self):
        if bench_keyboard:
            q = bench_keyboard.ask_text(self, "MODEL + PART")
        else:
            q = _dev_ask(self, "Model + part (dev keyboard):")
        if not q:
            return
        q = q.strip()
        if not q:
            return
        self._results_screen(q)

    def _results_screen(self, q):
        self._clear()
        top = tk.Frame(self.body, bg=BG)
        top.pack(fill=tk.X)
        tk.Button(top, text="◀ BACK", font=self.f_body, bg=CARD, fg=DIM, bd=0,
                  activebackground="#2a2a32", command=self._home).pack(side=tk.LEFT)
        tk.Label(top, text=q, font=self.f_body, bg=BG, fg=FG, anchor="w").pack(
            side=tk.LEFT, padx=10)
        self.res_status = tk.Label(self.body, text="Searching…", font=self.f_small,
                                   bg=BG, fg=ACC, anchor="w")
        self.res_status.pack(fill=tk.X, pady=(4, 2))
        self.res_frame = tk.Frame(self.body, bg=BG)
        self.res_frame.pack(fill=tk.BOTH, expand=True)
        threading.Thread(target=self._lookup_worker, args=(q,), daemon=True).start()

    def _lookup_worker(self, q):
        try:
            models = store.all_models(HERE)
            if not models:
                self.after(0, lambda: self._res_msg("Loading the model list first…"))
                worker.do_index(HERE)
                models = store.all_models(HERE)
            ranked = search.match_models(q, models)
            if not ranked:
                self.after(0, lambda: self._res_msg("No model matched. Try e.g. "
                                                    "'iphone 13 pro max screen'.", WARN))
                return
            best, _s, used = ranked[0]
            words = search.part_filter(q, used)
            m = store.get_model(HERE, best["path"]) or best
            if not m.get("fetched_at"):
                self.after(0, lambda: self._res_msg(
                    f"Fetching every {best['name']} part from MobileSentrix…"))
                worker.do_model(HERE, best["path"], best["name"])
            products = store.products_for(HERE, best["path"])
            hits = search.match_parts(words, products, limit=6)
            settings = pricing.clean_settings(store.kv_get(HERE, "settings", {}))
            rows = []
            for p, _sc in hits:
                bd = pricing.quote(p.get("price") or 0, settings, p["name"])
                rows.append((p, bd))
            self.after(0, lambda: self._show_rows(best["name"], len(products), rows))
        except Exception as e:
            print(f"lookup failed: {e}")
            err = f"Lookup failed: {e}"
            self.after(0, lambda: self._res_msg(err, WARN))

    def _res_msg(self, msg, color=ACC):
        try:
            self.res_status.config(text=msg, fg=color)
        except tk.TclError:
            pass

    def _show_rows(self, model_name, total, rows):
        try:
            self.res_status.config(
                text=f"{model_name} · {total} parts cached · top {len(rows)} shown"
                     " · full list + quoting on the dashboard", fg=DIM)
            for w in self.res_frame.winfo_children():
                w.destroy()
            if not rows:
                tk.Label(self.res_frame, text="No part matched those words.",
                         font=self.f_body, bg=BG, fg=WARN).pack(anchor="w")
                return
            for p, bd in rows:
                row = tk.Frame(self.res_frame, bg=CARD)
                row.pack(fill=tk.X, pady=2)
                name = p["name"] if len(p["name"]) <= 58 else p["name"][:56] + "…"
                stock = "" if p.get("in_stock") else "  (out of stock)"
                tk.Label(row, text=name + stock, font=self.f_small, bg=CARD,
                         fg=FG if p.get("in_stock") else MUT, anchor="w").pack(
                    side=tk.LEFT, fill=tk.X, expand=True, padx=8, pady=6)
                tk.Label(row, text=f"cost {pricing.money(p.get('price'))}", font=self.f_small,
                         bg=CARD, fg=DIM).pack(side=tk.LEFT, padx=6)
                tk.Label(row, text=pricing.money(bd["price"]), font=self.f_money,
                         bg=CARD, fg=MONEY).pack(side=tk.RIGHT, padx=10)
        except tk.TclError:
            pass

    def close(self):
        self.destroy()
        sys.exit(0)


def _dev_ask(root, prompt):
    """Dev-PC only: a tiny modal with a real keyboard (never on the bench)."""
    win = tk.Toplevel(root)
    win.configure(bg=BG)
    win.title(prompt)
    var = tk.StringVar()
    tk.Label(win, text=prompt, bg=BG, fg=FG).pack(padx=10, pady=6)
    e = tk.Entry(win, textvariable=var, width=40)
    e.pack(padx=10, pady=6)
    e.focus_set()
    out = {"v": None}

    def done(*_):
        out["v"] = var.get()
        win.destroy()
    e.bind("<Return>", done)
    tk.Button(win, text="OK", command=done).pack(pady=6)
    win.grab_set()
    root.wait_window(win)
    return out["v"]


if __name__ == "__main__":
    App().mainloop()
