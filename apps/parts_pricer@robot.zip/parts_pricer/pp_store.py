#!/usr/bin/env python3
"""
pp_store.py — one SQLite file, shared by the dashboard (web.py) and the
touchscreen (main.py). Lives in the app's own data/ folder.

Tables
  models    every model page MobileSentrix lists (path, name, brand, family)
            + when its parts were last cached and how that went
  products  the parts of every cached model (price, stock, quality)
  sheet     the shop's own price sheet (device, repair, price, note)
  quotes    every price the tech quoted from the search page
  kv        settings + small state (JSON values)

Every public function opens its own short connection, so the dashboard's
worker thread and request threads never share a cursor.
"""

from __future__ import annotations

import csv
import io
import json
import os
import sqlite3
import time

DB_NAME = "parts_pricer.db"


def data_dir(app_dir):
    d = os.path.join(app_dir, "data")
    os.makedirs(d, exist_ok=True)
    return d


def db_path(app_dir):
    return os.path.join(data_dir(app_dir), DB_NAME)


def _conn(app_dir):
    c = sqlite3.connect(db_path(app_dir), timeout=15)
    c.row_factory = sqlite3.Row
    try:
        c.execute("PRAGMA journal_mode=WAL")
    except sqlite3.DatabaseError:
        pass
    _ensure(c)
    return c


_SCHEMA = """
CREATE TABLE IF NOT EXISTS models(
  path TEXT PRIMARY KEY, name TEXT NOT NULL, brand TEXT, family TEXT,
  depth INTEGER, fetched_at REAL, product_count INTEGER DEFAULT 0,
  status TEXT DEFAULT '', error TEXT DEFAULT '', pinned INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS products(
  pid TEXT PRIMARY KEY, model_path TEXT NOT NULL, name TEXT NOT NULL,
  path TEXT, price REAL, in_stock INTEGER, qty INTEGER, quality TEXT,
  all_colors INTEGER, seen_at REAL, sku TEXT DEFAULT '');
CREATE INDEX IF NOT EXISTS ix_products_model ON products(model_path);
CREATE TABLE IF NOT EXISTS sheet(
  id INTEGER PRIMARY KEY AUTOINCREMENT, device TEXT NOT NULL,
  repair TEXT NOT NULL, price REAL NOT NULL, note TEXT DEFAULT '',
  source TEXT DEFAULT '', added_at REAL);
CREATE TABLE IF NOT EXISTS quotes(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, model TEXT, part TEXT,
  pid TEXT, cost REAL, price REAL, breakdown TEXT, note TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT);
"""


def _ensure(c):
    c.executescript(_SCHEMA)


# --------------------------------------------------------------------------- #
#  kv / settings
# --------------------------------------------------------------------------- #
def kv_get(app_dir, key, default=None):
    with _conn(app_dir) as c:
        r = c.execute("SELECT v FROM kv WHERE k=?", (key,)).fetchone()
    if not r:
        return default
    try:
        return json.loads(r["v"])
    except ValueError:
        return default


def kv_set(app_dir, key, value):
    with _conn(app_dir) as c:
        c.execute("INSERT OR REPLACE INTO kv(k,v) VALUES(?,?)",
                  (key, json.dumps(value)))


# --------------------------------------------------------------------------- #
#  models
# --------------------------------------------------------------------------- #
def replace_model_index(app_dir, models):
    """Upsert the model list; keeps fetched_at/status of models we already
    know. Returns (total, new)."""
    new = 0
    with _conn(app_dir) as c:
        known = {r["path"] for r in c.execute("SELECT path FROM models")}
        for m in models:
            if m["path"] in known:
                c.execute("UPDATE models SET name=?, brand=?, family=?, depth=? "
                          "WHERE path=?",
                          (m["name"], m.get("brand", ""), m.get("family", ""),
                           m.get("depth", 0), m["path"]))
            else:
                new += 1
                c.execute("INSERT INTO models(path,name,brand,family,depth) "
                          "VALUES(?,?,?,?,?)",
                          (m["path"], m["name"], m.get("brand", ""),
                           m.get("family", ""), m.get("depth", 0)))
        c.execute("INSERT OR REPLACE INTO kv(k,v) VALUES('index_fetched_at',?)",
                  (json.dumps(time.time()),))
    return len(models), new


def all_models(app_dir):
    with _conn(app_dir) as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM models ORDER BY brand, family, name")]


def get_model(app_dir, path):
    with _conn(app_dir) as c:
        r = c.execute("SELECT * FROM models WHERE path=?", (path,)).fetchone()
    return dict(r) if r else None


def set_model_status(app_dir, path, status, error=""):
    with _conn(app_dir) as c:
        c.execute("UPDATE models SET status=?, error=? WHERE path=?",
                  (status, error[:400], path))


def cached_models(app_dir):
    with _conn(app_dir) as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM models WHERE fetched_at IS NOT NULL "
            "ORDER BY fetched_at DESC")]


def families(app_dir):
    """[(brand, family, n_models, n_cached)] for the crawl-set picker."""
    with _conn(app_dir) as c:
        rows = c.execute(
            "SELECT brand, family, COUNT(*) n, "
            "SUM(CASE WHEN fetched_at IS NULL THEN 0 ELSE 1 END) cached "
            "FROM models GROUP BY brand, family ORDER BY brand, family").fetchall()
    return [(r["brand"], r["family"], r["n"], r["cached"]) for r in rows]


def models_in_family(app_dir, brand, family):
    with _conn(app_dir) as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM models WHERE brand=? AND family=? ORDER BY name",
            (brand, family))]


def stale_models(app_dir, older_than_days):
    cutoff = time.time() - older_than_days * 86400
    with _conn(app_dir) as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM models WHERE fetched_at IS NOT NULL AND fetched_at<? "
            "AND brand<>'search' ORDER BY fetched_at", (cutoff,))]


def ensure_model(app_dir, path, name, brand="search", family="search"):
    """Create a (pseudo) model row if it doesn't exist; returns the row."""
    with _conn(app_dir) as c:
        c.execute("INSERT OR IGNORE INTO models(path,name,brand,family,depth) "
                  "VALUES(?,?,?,?,0)", (path, name, brand, family))
    return get_model(app_dir, path)


def forget_model(app_dir, path):
    with _conn(app_dir) as c:
        c.execute("DELETE FROM products WHERE model_path=?", (path,))
        c.execute("UPDATE models SET fetched_at=NULL, product_count=0, "
                  "status='', error='' WHERE path=?", (path,))


# --------------------------------------------------------------------------- #
#  products
# --------------------------------------------------------------------------- #
def replace_products(app_dir, model_path, products):
    now = time.time()
    with _conn(app_dir) as c:
        c.execute("DELETE FROM products WHERE model_path=?", (model_path,))
        for p in products:
            c.execute(
                "INSERT OR REPLACE INTO products(pid,model_path,name,path,price,"
                "in_stock,qty,quality,all_colors,seen_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (str(p["pid"]), model_path, p["name"], p.get("path", ""),
                 p.get("price"), 1 if p.get("in_stock") else 0, p.get("qty"),
                 p.get("quality", ""), 1 if p.get("all_colors") else 0, now))
        c.execute("UPDATE models SET fetched_at=?, product_count=?, status='ok', "
                  "error='' WHERE path=?", (now, len(products), model_path))


def products_for(app_dir, model_path):
    with _conn(app_dir) as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM products WHERE model_path=? ORDER BY name", (model_path,))]


def get_product(app_dir, pid):
    with _conn(app_dir) as c:
        r = c.execute("SELECT * FROM products WHERE pid=?", (str(pid),)).fetchone()
    return dict(r) if r else None


def update_product_live(app_dir, pid, price, in_stock, sku=""):
    with _conn(app_dir) as c:
        c.execute("UPDATE products SET price=?, in_stock=?, seen_at=?, sku=? "
                  "WHERE pid=?", (price, 1 if in_stock else 0, time.time(),
                                  sku or "", str(pid)))


def stats(app_dir):
    with _conn(app_dir) as c:
        n_models = c.execute("SELECT COUNT(*) FROM models WHERE brand<>'search'").fetchone()[0]
        n_cached = c.execute(
            "SELECT COUNT(*) FROM models WHERE fetched_at IS NOT NULL AND brand<>'search'").fetchone()[0]
        n_products = c.execute("SELECT COUNT(*) FROM products").fetchone()[0]
        n_sheet = c.execute("SELECT COUNT(*) FROM sheet").fetchone()[0]
        n_quotes = c.execute("SELECT COUNT(*) FROM quotes").fetchone()[0]
        day = time.time() - 86400
        n_quotes_today = c.execute(
            "SELECT COUNT(*) FROM quotes WHERE ts>?", (day,)).fetchone()[0]
        r = c.execute("SELECT v FROM kv WHERE k='index_fetched_at'").fetchone()
    idx = None
    if r:
        try:
            idx = float(json.loads(r["v"]))
        except (ValueError, TypeError):
            idx = None
    return {"models": n_models, "cached": n_cached, "products": n_products,
            "sheet": n_sheet, "quotes": n_quotes, "quotes_today": n_quotes_today,
            "index_fetched_at": idx}


# --------------------------------------------------------------------------- #
#  price sheet
# --------------------------------------------------------------------------- #
_DEV_KEYS = ("device", "model", "phone", "item")
_REP_KEYS = ("repair", "service", "part", "job", "description", "type")
_PRICE_KEYS = ("price", "cost", "customer price", "retail", "total", "quote")
_NOTE_KEYS = ("note", "notes", "comment", "comments", "remarks")


def _pick(cols, keys):
    low = {c.strip().lower(): c for c in cols}
    for k in keys:
        for name, orig in low.items():
            if name == k or name.startswith(k):
                return orig
    return None


def import_sheet_csv(app_dir, text, source="csv", replace=False):
    """Import a CSV/TSV price sheet. Columns are matched by name (device /
    model, repair / service, price; note optional). With no header we take
    the first three columns. Returns (imported, skipped, message)."""
    text = (text or "").lstrip("﻿")
    if not text.strip():
        return 0, 0, "The file is empty."
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    rows = list(csv.reader(io.StringIO(text), dialect))
    rows = [r for r in rows if any(cell.strip() for cell in r)]
    if not rows:
        return 0, 0, "No rows found."
    header = rows[0]
    dev_c = _pick(header, _DEV_KEYS)
    rep_c = _pick(header, _REP_KEYS)
    pr_c = _pick(header, _PRICE_KEYS)
    note_c = _pick(header, _NOTE_KEYS)
    body = rows[1:]
    if dev_c and rep_c and pr_c:
        di, ri, pi = header.index(dev_c), header.index(rep_c), header.index(pr_c)
        ni = header.index(note_c) if note_c else None
    else:
        # headerless: device, repair, price[, note]
        di, ri, pi, ni = 0, 1, 2, 3
        body = rows
    imported = skipped = 0
    with _conn(app_dir) as c:
        if replace:
            c.execute("DELETE FROM sheet")
        for r in body:
            try:
                dev = r[di].strip()
                rep = r[ri].strip()
                price = float(str(r[pi]).replace("$", "").replace(",", "").strip())
                note = r[ni].strip() if ni is not None and ni < len(r) else ""
            except (IndexError, ValueError):
                skipped += 1
                continue
            if not dev or not rep:
                skipped += 1
                continue
            c.execute("INSERT INTO sheet(device,repair,price,note,source,added_at) "
                      "VALUES(?,?,?,?,?,?)", (dev, rep, price, note, source, time.time()))
            imported += 1
    return imported, skipped, f"Imported {imported} row(s), skipped {skipped}."


def sheet_rows(app_dir):
    with _conn(app_dir) as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM sheet ORDER BY device, repair")]


def sheet_add(app_dir, device, repair, price, note="", source="manual"):
    with _conn(app_dir) as c:
        c.execute("INSERT INTO sheet(device,repair,price,note,source,added_at) "
                  "VALUES(?,?,?,?,?,?)",
                  (device.strip(), repair.strip(), float(price), note.strip(),
                   source, time.time()))


def sheet_delete(app_dir, row_id):
    with _conn(app_dir) as c:
        c.execute("DELETE FROM sheet WHERE id=?", (int(row_id),))


def sheet_clear(app_dir):
    with _conn(app_dir) as c:
        c.execute("DELETE FROM sheet")


def sheet_csv(app_dir):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["device", "repair", "price", "note"])
    for r in sheet_rows(app_dir):
        w.writerow([r["device"], r["repair"], f"{r['price']:.2f}", r.get("note", "")])
    return buf.getvalue()


# --------------------------------------------------------------------------- #
#  quotes
# --------------------------------------------------------------------------- #
def add_quote(app_dir, model, part, pid, cost, price, breakdown, note=""):
    with _conn(app_dir) as c:
        cur = c.execute(
            "INSERT INTO quotes(ts,model,part,pid,cost,price,breakdown,note) "
            "VALUES(?,?,?,?,?,?,?,?)",
            (time.time(), model, part, str(pid or ""), cost, price,
             json.dumps(breakdown or {}), note))
        return cur.lastrowid


def quotes(app_dir, limit=200):
    with _conn(app_dir) as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM quotes ORDER BY ts DESC LIMIT ?", (int(limit),))]


def get_quote(app_dir, qid):
    with _conn(app_dir) as c:
        r = c.execute("SELECT * FROM quotes WHERE id=?", (int(qid),)).fetchone()
    return dict(r) if r else None


def delete_quote(app_dir, qid):
    with _conn(app_dir) as c:
        c.execute("DELETE FROM quotes WHERE id=?", (int(qid),))


def quotes_csv(app_dir):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["when", "model", "part", "cost", "price", "note"])
    for q in quotes(app_dir, limit=100000):
        w.writerow([time.strftime("%Y-%m-%d %H:%M", time.localtime(q["ts"])),
                    q["model"], q["part"], f"{q['cost']:.2f}", f"{q['price']:.2f}",
                    q.get("note", "")])
    return buf.getvalue()
