#!/usr/bin/env python3
"""
web.py — the Hero Dashboard face of Parts Pricer.

    http://<bench-ip>:8377/x/parts_pricer/

Type a model and a part ("iphone 13 pro max screen", "s23 ultra battery",
"ps5 hdmi port"), and in a second or two you get MobileSentrix's cost for
every matching part next to the price the customer pays — your price sheet
first, MobileSentrix for everything that isn't on it.

Sub-pages (all under /x/parts_pricer/):
    ""         search + results (the page the counter uses)
    frag       results fragment for the search box (HTML, polled by the page)
    api/…      small JSON actions: quote, live, fetch, status
    settings   markup / labor / rounding
    sheet      the shop's own price sheet: import CSV, add rows, export
    quotes     everything quoted from this page, export CSV, add to sheet
    crawl      MobileSentrix cache: model list, cached models, night refresh

Contract: one handle(ctx) — see the app SDK README. All network work goes
through pp_worker's thread; a request never waits on MobileSentrix except
the explicit "Live check" button.
"""

from __future__ import annotations

import html as _h
import os
import sys
import time
from urllib.parse import quote as _urlquote

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pp_pricing as pricing
import pp_search as search
import pp_sentrix as sx
import pp_store as store
import pp_worker as worker

APP_TITLE = "Parts Pricer"


def _esc(s):
    return _h.escape("" if s is None else str(s), quote=True)


def _age(ts):
    if not ts:
        return "never"
    d = max(0, time.time() - float(ts))
    if d < 90:
        return "just now"
    if d < 3600:
        return f"{int(d // 60)} min ago"
    if d < 86400 * 2:
        return f"{d / 3600:.0f} h ago"
    return f"{d / 86400:.0f} days ago"


def _money(x):
    return pricing.money(x)


# --------------------------------------------------------------------------- #
#  CSS (scoped under .pp so the dashboard shell is untouched)
# --------------------------------------------------------------------------- #
PAGE_CSS = """
<style>
.pp{--acc:#40c4ff;--ok:#00c853;--warn:#ffab00;--err:#ff5252;--card:#1b1b21;
  --bg2:#101014;--line:#2a2a32;--dim:#aab0bf;--mut:#7a7a8c;--fg:#e8e8f0;
  --money:#69f0ae}
.pp h1{font-size:20px;color:var(--acc);margin:0 0 2px;letter-spacing:.3px}
.pp .sub{color:var(--mut);font-size:13px;margin:0 0 10px}
.pp .nav{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 12px}
.pp .nav a{background:#14141a;border:1px solid var(--line);border-radius:99px;
  padding:7px 13px;font-size:13px;color:var(--dim);text-decoration:none}
.pp .nav a.on{background:#123a4d;border-color:var(--acc);color:var(--acc)}
.pp .meters{display:flex;gap:8px;margin:0 0 12px;flex-wrap:wrap}
.pp .meter{flex:1;min-width:88px;background:var(--card);border:1px solid var(--line);
  border-radius:10px;padding:8px 10px}
.pp .meter b{display:block;font-size:20px;color:var(--acc);line-height:1.1}
.pp .meter small{color:var(--mut);font-size:11px;text-transform:uppercase;letter-spacing:.5px}
.pp .card{background:var(--card);border:1px solid var(--line);border-radius:12px;
  padding:14px;margin:12px 0}
.pp .card h2{font-size:13px;color:var(--dim);text-transform:uppercase;letter-spacing:.6px;margin:0 0 10px}
.pp label{display:block;color:var(--dim);font-size:12px;margin:12px 0 4px}
.pp input[type=text],.pp input[type=number],.pp input[type=search],.pp textarea,.pp select{
  width:100%;background:var(--bg2);color:var(--fg);border:1px solid var(--line);
  border-radius:8px;padding:11px;font-size:15px;box-sizing:border-box}
.pp input[type=file]{color:var(--dim);font-size:13px}
.pp .q input{font-size:22px;padding:16px 18px;border-radius:14px;border:2px solid #23485a;
  background:#0b1216;color:#fff}
.pp .q input:focus{outline:none;border-color:var(--acc);box-shadow:0 0 14px rgba(64,196,255,.3)}
.pp .row{display:flex;gap:8px;flex-wrap:wrap}
.pp .row>div{flex:1;min-width:120px}
.pp button,.pp .btn{background:#123a4d;color:#eaf6ff;border:0;border-radius:10px;
  padding:12px 16px;font-size:14px;font-weight:700;cursor:pointer;text-align:center;
  display:inline-block;text-decoration:none;margin-top:10px}
.pp button.ghost,.pp .btn.ghost{background:#14141a;border:1px solid var(--line);color:var(--dim)}
.pp button.go,.pp .btn.go{background:linear-gradient(90deg,#0d6b2f,#00c853);color:#04120a}
.pp button.danger{background:#3a0d0d;color:#ff8a8a}
.pp button.done{background:#0d3318;color:#69f0ae;border:1px solid #135c2c}
.pp .mini{padding:8px 12px;font-size:13px;margin-top:0}
.pp .flash{border-radius:8px;padding:10px 12px;margin:0 0 12px;font-size:14px}
.pp .flash.ok{background:#0d3318;color:#69f0ae;border:1px solid #135c2c}
.pp .flash.err{background:#3a0d0d;color:#ff9a9a;border:1px solid #5c1313}
.pp .flash.warn{background:#3a2a05;color:#ffd27a;border:1px solid #5c4413}
.pp .hint{color:var(--mut);font-size:12px;margin-top:8px;line-height:1.5}
.pp .chip{display:inline-block;border-radius:99px;padding:2px 9px;font-size:11px;
  border:1px solid var(--line);color:var(--dim);background:#14141a;margin-left:6px;vertical-align:middle}
.pp .chip.ok{color:#69f0ae;border-color:#135c2c}
.pp .chip.bad{color:#ff9a9a;border-color:#5c1313}
.pp .chip.q{color:#9fd0ff;border-color:#23485a}
.pp .chips{display:flex;gap:6px;flex-wrap:wrap;margin:6px 0 10px}
.pp .chips a{background:#14141a;border:1px solid var(--line);border-radius:99px;
  padding:7px 12px;font-size:13px;color:var(--fg);text-decoration:none}
.pp .chips a.on{background:#123a4d;border-color:var(--acc);color:var(--acc)}
.pp .part{background:var(--bg2);border:1px solid var(--line);border-left:3px solid #23485a;
  border-radius:10px;padding:10px 12px;margin:8px 0}
.pp .part.oos{opacity:.75;border-left-color:#5c1313}
.pp .part .pn{font-size:15px;color:#eaf1f8;line-height:1.35}
.pp .part .pr{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap;margin:6px 0 2px}
.pp .part .cost{color:var(--dim);font-size:14px}
.pp .part .price{color:var(--money);font-size:26px;font-weight:800;letter-spacing:.3px}
.pp .part .price small{font-size:12px;color:var(--mut);font-weight:400;margin-left:4px}
.pp .part .labwrap{display:inline-flex;align-items:center;gap:6px;color:var(--mut);font-size:12px;margin-left:auto}
.pp .part select.labor{width:auto;max-width:320px;padding:6px 8px;font-size:13px}
.pp .part input.customlabor{padding:6px 8px;font-size:13px}
.pp .part .acts{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px;align-items:center}
.pp .part details{margin:4px 0 0}
.pp .part summary{cursor:pointer;color:var(--mut);font-size:12px}
.pp .part .bd{font-family:ui-monospace,Menlo,monospace;font-size:12px;color:#cfd6de;
  background:#0b0b0e;border:1px solid var(--line);border-radius:6px;padding:8px;margin-top:6px}
.pp .sheethit{border-left-color:var(--ok);background:#0d1f14}
.pp .sheethit .price{color:#fff}
.pp table{width:100%;border-collapse:collapse;font-size:13px}
.pp th,.pp td{padding:8px 6px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
.pp th{color:var(--mut);font-weight:600;text-transform:uppercase;font-size:11px;letter-spacing:.5px}
.pp td form{display:inline;margin:0}
.pp .spin{display:inline-block;width:14px;height:14px;border:2px solid #23485a;
  border-top-color:var(--acc);border-radius:50%;animation:ppspin .8s linear infinite;vertical-align:middle;margin-right:8px}
@keyframes ppspin{to{transform:rotate(360deg)}}
.pp code{background:#14141a;border:1px solid var(--line);border-radius:5px;padding:1px 5px;font-size:12px;color:#9fd0ff}
.pp .stat{color:var(--mut);font-size:12px;margin:4px 0 8px}
.pp .rightlink{float:right;font-size:12px;color:var(--acc);text-decoration:none}
</style>
"""

_NAV = [("", "🔎 Search"), ("sheet", "📋 Price sheet"), ("quotes", "🧾 Quotes"),
        ("crawl", "☁ Cache"), ("settings", "⚙ Pricing rules")]


def _nav(url, active):
    parts = []
    for sub, label in _NAV:
        cls = " class='on'" if sub == active else ""
        parts.append(f"<a{cls} href='{_esc(url(sub))}'>{label}</a>")
    return "<div class='nav'>" + "".join(parts) + "</div>"


def _flash(ok="", err="", warn=""):
    if err:
        return f"<div class='flash err'>⚠ {_esc(err)}</div>"
    if warn:
        return f"<div class='flash warn'>{_esc(warn)}</div>"
    if ok:
        return f"<div class='flash ok'>✓ {_esc(ok)}</div>"
    return ""


def _head(url, active, title, sub=""):
    return (PAGE_CSS + "<div class='pp'>"
            f"<h1>💲 {APP_TITLE} — {_esc(title)}</h1>"
            + (f"<p class='sub'>{sub}</p>" if sub else "")
            + _nav(url, active))


# --------------------------------------------------------------------------- #
#  Search page
# --------------------------------------------------------------------------- #
def render_search(app_dir, url, q=""):
    st = store.stats(app_dir)
    settings = pricing.clean_settings(store.kv_get(app_dir, "settings", {}))
    H = [_head(url, "", "quote a repair in seconds",
               "Type the <b>model</b> and the <b>part</b>. Your price sheet answers "
               "first; anything not on it is priced from MobileSentrix cost + "
               f"<b>{settings['markup_pct']:g}%</b> + labor ("
               f"{len(settings['labor_rates'])} rate{'s' if len(settings['labor_rates']) != 1 else ''}, "
               f"default {_money(settings['labor'])}).")]
    H.append("<div class='meters'>")
    H.append(f"<div class='meter'><b>{st['models']}</b><small>models known</small></div>")
    H.append(f"<div class='meter'><b>{st['cached']}</b><small>models cached</small></div>")
    H.append(f"<div class='meter'><b>{st['sheet']}</b><small>sheet rows</small></div>")
    H.append(f"<div class='meter'><b>{st['quotes_today']}</b><small>quotes today</small></div>")
    H.append("</div>")
    if not st["models"]:
        H.append("<div class='flash warn'>First run: the MobileSentrix model list "
                 "isn't loaded yet. It loads itself the first time you search "
                 "(about 10 s), or load it now on the "
                 f"<a href='{_esc(url('crawl'))}' style='color:#ffd27a'>Cache</a> page.</div>")
    H.append("<form class='q' method='get' action='" + _esc(url("")) + "' "
             "onsubmit='return false' autocomplete='off'>")
    H.append(f"<input type='search' id='ppq' name='q' value='{_esc(q)}' "
             "placeholder='iphone 13 pro max screen · s23 ultra battery · ps5 hdmi' "
             "autofocus></form>")
    H.append("<div id='ppres'>")
    if q:
        frag, _poll = render_results(app_dir, url, q)
        H.append(frag)
    H.append("</div>")
    H.append(_SEARCH_JS.replace("__FRAG__", _esc(url("frag")))
             .replace("__API__", _esc(url("api"))))
    H.append("</div>")
    return "".join(H)


_SEARCH_JS = """
<script>(function(){
 var inp=document.getElementById('ppq'), res=document.getElementById('ppres');
 if(!inp||!res) return;
 var FRAG='__FRAG__', API='__API__', t=null, pollT=null, seq=0;
 function money(x){return '$'+(Math.round(x*100)/100).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});}
 function roundPrice(x,rt){ if(x<=0) return 0; if(rt==0||rt==1) return Math.round(x*100)/100;
   if(rt==9){ var n=Math.ceil(x); while(n%10!=9) n++; return n; } return Math.ceil(x/rt)*rt; }
 function laborOf(row){ var sel=row.querySelector('select.labor'); if(!sel) return null;
   if(sel.value==='custom'){ var c=row.querySelector('input.customlabor'); return {amt:parseFloat(c&&c.value||'0')||0, name:'custom'}; }
   var o=sel.options[sel.selectedIndex]; return {amt:parseFloat(o.getAttribute('data-labor'))||0, name:o.getAttribute('data-name')||o.textContent}; }
 function recompute(row){
   var cost=parseFloat(row.getAttribute('data-cost')); if(isNaN(cost)) return;
   var mk=parseFloat(row.getAttribute('data-markup'))||0, rt=parseInt(row.getAttribute('data-round'))||0, mn=parseFloat(row.getAttribute('data-min'))||0;
   var lab=laborOf(row); if(!lab) return;
   var mkAmt=Math.round(cost*mk)/100, sub=cost+mkAmt+lab.amt, price=roundPrice(sub,rt); if(mn&&price<mn) price=roundPrice(mn,rt);
   var p=row.querySelector('.price'); if(p) p.firstChild.nodeValue=money(price);
   var q=row.querySelector('[data-act=quote]'); if(q&&!q.classList.contains('done')) q.textContent='Quote '+money(price);
   var bd=row.querySelector('.bd'); if(bd) bd.textContent='cost '+money(cost)+' + '+mk+'% markup ('+money(mkAmt)+') + labor '+money(lab.amt)+' ['+lab.name+'] = '+money(sub)+' → '+money(price)+'   (margin '+money(price-cost)+')';
   var c=row.querySelector('.cost'); if(c) c.textContent='cost '+money(cost);
 }
 function load(){
   var q=inp.value.trim(); var my=++seq;
   try{history.replaceState(null,'',q?('?q='+encodeURIComponent(q)):location.pathname);}catch(e){}
   if(!q){res.innerHTML='';return;}
   fetch(FRAG+'?q='+encodeURIComponent(q),{credentials:'same-origin'})
    .then(function(r){return r.text();})
    .then(function(h){ if(my!==seq) return; res.innerHTML=h;
      clearTimeout(pollT);
      if(res.querySelector('[data-poll]')){ pollT=setTimeout(load,1500); } })
    .catch(function(){});
 }
 inp.addEventListener('input',function(){clearTimeout(t);t=setTimeout(load,350);});
 inp.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();clearTimeout(t);load();}});
 res.addEventListener('change',function(e){
   var row=e.target.closest('.part'); if(!row) return;
   if(e.target.matches('select.labor')){ var c=row.querySelector('input.customlabor'); if(c) c.style.display=(e.target.value==='custom')?'':'none'; }
   recompute(row);
 });
 res.addEventListener('input',function(e){ if(e.target.matches('input.customlabor')) recompute(e.target.closest('.part')); });
 res.addEventListener('click',function(e){
   var chip=e.target.closest('[data-q]');
   if(chip){e.preventDefault();inp.value=chip.getAttribute('data-q');load();inp.focus();return;}
   var b=e.target.closest('[data-act]'); if(!b) return; e.preventDefault();
   var act=b.getAttribute('data-act'), pid=b.getAttribute('data-pid')||'', path=b.getAttribute('data-path')||'';
   var row=b.closest('.part'), lab=row?laborOf(row):null;
   b.disabled=true; var old=b.textContent; b.textContent='…';
   fetch(API+'/'+act,{method:'POST',credentials:'same-origin',
     headers:{'Content-Type':'application/x-www-form-urlencoded'},
     body:new URLSearchParams({pid:pid,path:path,q:inp.value,labor:lab?lab.amt:'',labor_name:lab?lab.name:''})})
   .then(function(r){return r.json();}).then(function(j){
     if(j.error){b.textContent=old;b.disabled=false;alert(j.error);return;}
     if(act==='quote'){b.textContent='✓ quoted '+j.price_fmt;b.classList.add('done');}
     else if(act==='live'){
       if(row){ row.setAttribute('data-cost', j.cost); var s=row.querySelector('.stock');
         if(s){ s.textContent=j.in_stock?'in stock':'out of stock'; s.className='chip stock '+(j.in_stock?'ok':'bad'); }
         recompute(row); }
       b.textContent='✓ live '+new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});b.classList.add('done');b.disabled=false;
     } else { load(); }
   }).catch(function(){b.textContent=old;b.disabled=false;});
 });
 if(inp.value.trim() && res.querySelector('[data-poll]')){ pollT=setTimeout(load,1500); }
})();</script>
"""


def _breakdown_txt(bd):
    s = (f"cost {_money(bd['cost'])} + {bd['markup_pct']:g}% markup "
         f"({_money(bd['markup_amt'])}) + labor {_money(bd['labor'])}")
    if bd.get("labor_name"):
        s += f" [{bd['labor_name']}]"
    s += f" = {_money(bd['subtotal'])}"
    if bd["round_to"] in (5, 10):
        s += f" → up to ${bd['round_to']} = {_money(bd['price'])}"
    elif bd["round_to"] == 9:
        s += f" → ends in 9 = {_money(bd['price'])}"
    else:
        s += f" → {_money(bd['price'])}"
    s += f"   (margin {_money(bd['margin'])})"
    return s


def _labor_select(settings, bd):
    """The per-result labor dropdown: every named rate + default + custom."""
    opts = []
    chosen = bd.get("rate_id") or ""
    for r in settings.get("labor_rates") or []:
        sel = " selected" if r["id"] == chosen else ""
        hint = " · ".join(x for x in (r.get("model", ""), r.get("part", "")) if x)
        opts.append(f"<option value='{_esc(r['id'])}' data-labor='{r['labor']:g}' "
                    f"data-name='{_esc(r['name'])}'{sel}>{_esc(r['name'])} — "
                    f"{_money(r['labor'])}{(' (' + _esc(hint) + ')') if hint else ''}</option>")
    sel = " selected" if not chosen else ""
    opts.append(f"<option value='default' data-labor='{settings['labor']:g}' data-name='default'{sel}>"
                f"Default labor — {_money(settings['labor'])}</option>")
    opts.append("<option value='custom' data-labor='0' data-name='custom'>Custom…</option>")
    return ("<label class='labwrap'>labor <select class='labor'>" + "".join(opts) + "</select>"
            "<input type='number' class='customlabor' step='1' min='0' placeholder='$' "
            "style='display:none;width:90px'></label>")


def _part_row(p, settings, model_name):
    bd = pricing.quote(p.get("price") or 0, settings, p.get("name", ""), model_name)
    oos = not p.get("in_stock")
    qty = p.get("qty")
    stock = ("in stock" + (f" · {qty}" if qty else "")) if not oos else "out of stock"
    quality = p.get("quality") or ""
    H = [f"<div class='part{' oos' if oos else ''}' data-row='{_esc(p['pid'])}' "
         f"data-cost='{'' if p.get('price') is None else p['price']}' "
         f"data-markup='{settings['markup_pct']:g}' data-round='{settings['round_to']}' "
         f"data-min='{settings['min_price']:g}'>"]
    H.append(f"<div class='pn'>{_esc(p['name'])}"
             + (f"<span class='chip q'>{_esc(quality)}</span>" if quality else "")
             + f"<span class='chip stock {'bad' if oos else 'ok'}'>{_esc(stock)}</span>"
             + ("<span class='chip'>all colors</span>" if p.get("all_colors") else "")
             + "</div>")
    if p.get("price") is None:
        H.append("<div class='pr'><span class='cost'>no price shown on the site</span></div>")
    else:
        H.append(f"<div class='pr'><span class='cost'>cost {_money(p['price'])}</span>"
                 f"<span style='color:#556'>→</span>"
                 f"<span class='price'>{_money(bd['price'])}"
                 + (f"<small>{_esc(bd['tax_note'])}</small>" if bd.get("tax_note") else "")
                 + "</span>" + _labor_select(settings, bd) + "</div>")
        H.append("<details><summary>how that's worked out</summary>"
                 f"<div class='bd'>{_esc(_breakdown_txt(bd))}</div></details>")
    H.append("<div class='acts'>")
    if p.get("price") is not None:
        H.append(f"<button class='mini go' data-act='quote' data-pid='{_esc(p['pid'])}'>"
                 f"Quote {_money(bd['price'])}</button>")
    H.append(f"<button class='mini ghost' data-act='live' data-pid='{_esc(p['pid'])}'>"
             "Live check</button>")
    if p.get("path"):
        H.append(f"<a class='btn mini ghost' target='_blank' rel='noopener' "
                 f"href='{_esc(sx.product_url(p['path']))}'>↗ MobileSentrix</a>")
    H.append(f"<span class='hint' style='margin:0 0 0 auto'>cached {_age(p.get('seen_at'))}</span>")
    H.append("</div></div>")
    return "".join(H)


def render_results(app_dir, url, q):
    """The results fragment. Returns (html, needs_poll)."""
    q = (q or "").strip()
    if not q:
        return "", False
    settings = pricing.clean_settings(store.kv_get(app_dir, "settings", {}))
    H, poll = [], False

    # 1. the shop's own sheet
    sheet_hits = search.match_sheet(q, store.sheet_rows(app_dir))
    if sheet_hits:
        H.append("<div class='card'><h2>On your price sheet</h2>")
        for r, _s in sheet_hits:
            H.append(f"<div class='part sheethit'><div class='pn'>{_esc(r['device'])} — "
                     f"{_esc(r['repair'])}"
                     + (f"<span class='chip'>{_esc(r['note'])}</span>" if r.get("note") else "")
                     + "</div>"
                     f"<div class='pr'><span class='price'>{_money(r['price'])}</span>"
                     f"<span class='cost'>your sheet price</span></div></div>")
        H.append("</div>")

    # 2. the model
    models = store.all_models(app_dir)
    ws = worker.status()
    if not models:
        if not ws["running"] and not ws["queued"]:
            worker.enqueue_index(app_dir)
        H.append("<div class='card' data-poll='1'><span class='spin'></span>"
                 "Loading the MobileSentrix model list for the first time… "
                 "(about 10 s)"
                 + (f"<div class='flash err' style='margin-top:10px'>{_esc(ws['last_error'])}</div>"
                    if ws.get("last_error") else "")
                 + "</div>")
        return "".join(H), True

    real_models = [m for m in models if m.get("brand") != "search"]
    force_site = q.lower().startswith(("site:", "?"))
    ranked = [] if force_site else search.match_models(q, real_models)

    if not ranked:
        # No model name in the query ("x218 lcd", "sm-a536 battery"): fall back
        # to MobileSentrix's own search, which knows the model codes.
        site_q = q.split(":", 1)[1].strip() if q.lower().startswith("site:") else q.lstrip("?").strip()
        if not site_q:
            return "".join(H), False
        row = store.ensure_model(app_dir, sx.search_path(site_q), f"Site search: {site_q}")
        H.append("<div class='card'><h2>MobileSentrix site search"
                 f"<a class='rightlink' target='_blank' rel='noopener' "
                 f"href='{_esc(sx.search_url(site_q))}'>open on the site ↗</a></h2>")
        H.append(f"<p class='hint' style='margin:0 0 8px'>No model in the list is called that, so this "
                 f"is what MobileSentrix's own search returns for <b>{_esc(site_q)}</b>. "
                 "Model codes (X218, SM-A536…) work here.</p>")
        near = _near_models(site_q, real_models, limit=6)
        block, poll = _model_block(app_dir, url, row, [], settings, ws,
                                   label=f"results for “{site_q}”", suggest_from=real_models)
        H.append(block)
        if near:
            H.append("<p class='hint'>Or pick a model from the list:</p><div class='chips'>" + "".join(
                f"<a href='#' data-q='{_esc(m['name'])}'>{_esc(m['name'])}</a>" for m in near)
                + "</div>")
        H.append("</div>")
        return "".join(H), poll

    best, _score, used = ranked[0]
    words = search.part_filter(q, used)
    part_txt = " ".join(words)
    H.append("<div class='card'><h2>MobileSentrix"
             f"<a class='rightlink' target='_blank' rel='noopener' "
             f"href='{_esc(sx.BASE + '/' + best['path'])}'>open model page ↗</a></h2>")
    # model chips (the best one + alternates) + a way to force the site search
    H.append("<div class='chips'>")
    for m, _s, _u in ranked[:6]:
        on = " class='on'" if m["path"] == best["path"] else ""
        H.append(f"<a href='#'{on} data-q='{_esc((m['name'] + ' ' + part_txt).strip())}'>"
                 f"{_esc(m['name'])}</a>")
    H.append(f"<a href='#' data-q='site: {_esc(q)}' title='search the whole site instead'>"
             f"🔍 site search</a>")
    H.append("</div>")
    fresh = store.get_model(app_dir, best["path"]) or best
    block, poll = _model_block(app_dir, url, fresh, words, settings, ws)
    H.append(block)
    H.append("</div>")
    return "".join(H), poll


def _model_block(app_dir, url, model, words, settings, ws, label="", suggest_from=None):
    """Fetch-on-demand / poll / parts list for one (pseudo) model row.
    Returns (html, needs_poll)."""
    H, poll = [], False
    name = model["name"]
    what = label or f"every <b>{_esc(name)}</b> part"
    if not model.get("fetched_at"):
        pending = worker.is_pending(model["path"])
        if not pending and model.get("status") == "error":
            # a failed fetch is never retried on its own — the tech taps Try
            # again, so a blocked bench can't hammer the site every poll
            H.append(f"<div class='flash err'>Couldn't fetch <b>{_esc(name)}</b>: "
                     f"{_esc(model.get('error') or 'unknown error')}</div>")
            H.append(f"<button class='mini' data-act='fetch' data-path='{_esc(model['path'])}'>"
                     "Try again</button>")
        else:
            if not pending:
                worker.enqueue_model(app_dir, model["path"], name)
            queued_ahead = len(ws["queued"])
            H.append(f"<div data-poll='1'><span class='spin'></span>Fetching {what} "
                     "from MobileSentrix… "
                     + (f"({queued_ahead} job(s) ahead in the queue)" if queued_ahead > 1 else "a few seconds")
                     + "</div>")
            poll = True
        return "".join(H), poll

    products = store.products_for(app_dir, model["path"])
    hits = search.match_parts(words, products)
    part_txt = " ".join(words)
    H.append(f"<div class='stat'>{len(hits)} of {len(products)} parts"
             + (f" match <b>{_esc(part_txt)}</b>" if words else "")
             + f" · cached {_age(model['fetched_at'])} · "
             f"<a href='#' data-act='fetch' data-path='{_esc(model['path'])}' "
             f"style='color:var(--acc)'>refresh</a></div>")
    if worker.is_pending(model["path"]):
        H.append("<div class='stat' data-poll='1'><span class='spin'></span>refreshing…</div>")
        poll = True
    if suggest_from and products:
        # which real models do these results belong to? (chips to jump there)
        counts = {}
        for p in products[:60]:
            for m, _s, _u in search.match_models(p["name"], suggest_from, limit=2)[:1]:
                counts[m["path"]] = counts.get(m["path"], 0) + 1
        if counts:
            by = {m["path"]: m for m in suggest_from}
            top = sorted(counts.items(), key=lambda kv: -kv[1])[:4]
            H.append("<div class='chips'><span class='hint' style='margin:auto 0'>looks like:</span>" + "".join(
                f"<a href='#' data-q='{_esc(by[pth]['name'] + (' ' + part_txt if part_txt else ''))}'>"
                f"{_esc(by[pth]['name'])} <small style='color:var(--mut)'>{n}</small></a>"
                for pth, n in top if pth in by) + "</div>")
    if not hits:
        if products:
            H.append("<p class='hint'>No part here matches those words. Try "
                     "<code>screen</code>, <code>battery</code>, <code>charging port</code>, "
                     "<code>back glass</code>, <code>camera</code>, or leave the part off to see "
                     "everything.</p>")
        else:
            H.append("<p class='hint'>MobileSentrix returned nothing for that. Try fewer "
                     "words, or the model name.</p>")
    for p, _s in hits:
        H.append(_part_row(p, settings, name))
    if len(products) > len(hits) and not words:
        H.append(f"<p class='hint'>Showing the first {len(hits)} — add a part word to narrow it.</p>")
    return "".join(H), poll


def _near_models(q, models, limit=10):
    toks = [t for t in search.tokenize(q) if t not in search.STOP]
    if not toks:
        return []
    out = []
    for m in models:
        low = m["name"].lower()
        if any(t in low for t in toks if len(t) > 1):
            out.append(m)
    out.sort(key=lambda m: (-sum(1 for t in toks if t in m["name"].lower()), len(m["name"])))
    return out[:limit]


# --------------------------------------------------------------------------- #
#  JSON actions
# --------------------------------------------------------------------------- #
def api_quote(app_dir, form):
    pid = form.get("pid", "")
    p = store.get_product(app_dir, pid)
    if not p:
        return {"error": "That part is no longer in the cache — search again."}
    if p.get("price") is None:
        return {"error": "No price for that part."}
    settings = pricing.clean_settings(store.kv_get(app_dir, "settings", {}))
    model = store.get_model(app_dir, p["model_path"]) or {}
    labor = form.get("labor", "")
    labor = None if labor in ("", None) else labor
    bd = pricing.quote(p["price"], settings, p["name"], model.get("name", ""),
                       labor=labor, labor_name=form.get("labor_name", "") or None)
    qid = store.add_quote(app_dir, model.get("name", p["model_path"]), p["name"], pid,
                          bd["cost"], bd["price"], bd, note=form.get("q", "")[:120])
    return {"ok": True, "id": qid, "price": bd["price"], "price_fmt": _money(bd["price"])}


def api_live(app_dir, form):
    pid = form.get("pid", "")
    p = store.get_product(app_dir, pid)
    if not p or not p.get("path"):
        return {"error": "That part is no longer in the cache — search again."}
    try:
        html = sx.fetch(sx.product_url(p["path"]))
    except sx.FetchError as e:
        return {"error": str(e)}
    info = sx.parse_product(html)
    if not info or info.get("price") is None:
        return {"error": "Loaded the product page but couldn't read a price from it."}
    store.update_product_live(app_dir, pid, info["price"], info["in_stock"], info.get("sku", ""))
    settings = pricing.clean_settings(store.kv_get(app_dir, "settings", {}))
    model = store.get_model(app_dir, p["model_path"]) or {}
    bd = pricing.quote(info["price"], settings, p["name"], model.get("name", ""))
    return {"ok": True, "cost": info["price"], "cost_fmt": _money(info["price"]),
            "in_stock": bool(info["in_stock"]), "price": bd["price"],
            "price_fmt": _money(bd["price"]), "sku": info.get("sku", ""),
            "breakdown_txt": _breakdown_txt(bd)}


def api_fetch(app_dir, form):
    path = form.get("path", "").strip("/")
    m = store.get_model(app_dir, path)
    if not m:
        return {"error": "Unknown model."}
    worker.enqueue_model(app_dir, path, m["name"])
    return {"ok": True}


def api_status(app_dir):
    s = worker.status()
    s["stats"] = store.stats(app_dir)
    return s


# --------------------------------------------------------------------------- #
#  Settings page
# --------------------------------------------------------------------------- #
def render_settings(app_dir, url, ok="", err=""):
    s = pricing.clean_settings(store.kv_get(app_dir, "settings", {}))
    ex = pricing.quote(16.74, s, "LCD Assembly For iPhone 13", "iPhone 13")
    H = [_head(url, "settings", "pricing rules",
               "customer price = part cost + markup % + labor, then rounded. "
               "Labor comes from the first rate below that fits the job; otherwise the default.")]
    H.append(_flash(ok, err))
    H.append(f"<div class='card'><h2>Markup, default labor, rounding</h2>"
             f"<form method='post' action='{_esc(url('settings'))}?a=save'>")
    H.append("<div class='row'>")
    H.append(f"<div><label>Markup on the part (%)</label><input type='number' step='1' min='0' "
             f"name='markup_pct' value='{s['markup_pct']:g}'></div>")
    H.append(f"<div><label>Default labor ($) — when no rate below fits</label><input type='number' step='1' min='0' "
             f"name='labor' value='{s['labor']:g}'></div>")
    H.append("</div><div class='row'>")
    opts = [(0, "no rounding"), (5, "up to the next $5"), (10, "up to the next $10"),
            (9, "end in 9 ($49, $59…)")]
    H.append("<div><label>Rounding</label><select name='round_to'>" + "".join(
        f"<option value='{v}'{' selected' if s['round_to'] == v else ''}>{t}</option>"
        for v, t in opts) + "</select></div>")
    H.append(f"<div><label>Minimum price ($)</label><input type='number' step='1' min='0' "
             f"name='min_price' value='{s['min_price']:g}'></div>")
    H.append("</div>")
    H.append(f"<label>Note shown under the price (e.g. “+ tax”)</label>"
             f"<input type='text' name='tax_note' maxlength='40' value='{_esc(s['tax_note'])}'>")
    H.append("<button class='go' type='submit'>Save</button></form>")
    H.append(f"<p class='hint'>Example: {_esc(_breakdown_txt(ex))}</p>")
    H.append("</div>")

    # ---- labor rates ----
    rates = s["labor_rates"]
    H.append(f"<div class='card'><h2>Labor rates ({len(rates)})</h2>")
    H.append("<p class='hint'>Each rate names <b>what it's for</b>. Leave <i>Model</i> empty for a "
             "rate that applies to that part on any device (<code>screen</code>, "
             "<code>battery</code>, <code>back glass</code>, <code>charging port</code>…). Fill in "
             "<i>Model</i> for a special rate — <code>ipad</code> + <code>screen</code>, "
             "<code>iphone 14 pro max</code> + <code>back glass</code>, <code>ps5</code> + "
             "<code>hdmi</code>, or a model alone (<code>galaxy fold</code>) for everything on it. "
             "Model + part beats part-only beats model-only; the tech can still pick any rate "
             "from the dropdown on a result.</p>")
    if rates:
        H.append("<table><tr><th>Name</th><th>Model</th><th>Part</th><th>Labor</th><th></th></tr>")
        any_ = "<span style='color:var(--mut)'>any</span>"
        for r in rates:
            H.append(f"<tr><td>{_esc(r['name'])}</td><td>{_esc(r['model']) or any_}</td>"
                     f"<td>{_esc(r['part']) or any_}</td>"
                     f"<td><b style='color:var(--money)'>{_money(r['labor'])}</b></td>"
                     f"<td><form method='post' action='{_esc(url('settings'))}?a=del_rate'>"
                     f"<input type='hidden' name='id' value='{_esc(r['id'])}'>"
                     "<button class='mini danger' type='submit'>✕</button></form></td></tr>")
        H.append("</table>")
    H.append(f"<form method='post' action='{_esc(url('settings'))}?a=add_rate'><div class='row'>"
             "<div><label>Name</label><input type='text' name='name' maxlength='40' placeholder='iPad screen'></div>"
             "<div><label>Model (optional)</label><input type='text' name='model' maxlength='60' placeholder='ipad'></div>"
             "<div><label>Part (optional)</label><input type='text' name='part' maxlength='60' placeholder='screen'></div>"
             "<div><label>Labor ($)</label><input type='number' step='1' min='0' name='labor' placeholder='80'></div>"
             "</div><button class='mini' type='submit'>＋ Add rate</button></form>")
    if not rates:
        H.append(f"<form method='post' action='{_esc(url('settings'))}?a=starter_rates' style='margin-top:8px'>"
                 "<button class='mini ghost' type='submit'>Load a starter set (screen / battery / "
                 "charging port / back glass / camera / speaker / board-level) to edit</button></form>")
    H.append("</div></div>")
    return "".join(H)


_STARTER_RATES = [
    ("Screen", "", "screen", 60), ("Battery", "", "battery", 40),
    ("Charging port", "", "charging port", 70), ("Back glass", "", "back glass", 90),
    ("Camera", "", "camera", 50), ("Speaker / earpiece", "", "speaker", 50),
    ("Board-level", "", "board", 150), ("iPad screen", "ipad", "screen", 100),
    ("Console HDMI", "playstation", "hdmi", 120),
]


def settings_action(app_dir, action, form):
    raw = store.kv_get(app_dir, "settings", {}) or {}
    s = pricing.clean_settings(raw)
    if action == "save":
        for k in ("markup_pct", "labor", "round_to", "min_price", "tax_note"):
            if form.get(k) is not None:
                s[k] = form.get(k)
        s = pricing.clean_settings(s)
        store.kv_set(app_dir, "settings", s)
        return "Pricing rules saved.", ""
    if action == "add_rate":
        r = pricing.clean_rate({"name": form.get("name", ""), "model": form.get("model", ""),
                                "part": form.get("part", ""), "labor": form.get("labor", "")})
        if not r:
            return "", "A rate needs a labor amount and at least a name, model or part."
        s["labor_rates"].append(r)
        store.kv_set(app_dir, "settings", s)
        return f"Added rate “{r['name']}” at {_money(r['labor'])}.", ""
    if action == "del_rate":
        rid = form.get("id", "")
        s["labor_rates"] = [r for r in s["labor_rates"] if r["id"] != rid]
        store.kv_set(app_dir, "settings", s)
        return "Rate removed.", ""
    if action == "starter_rates":
        have = {(r["model"], r["part"]) for r in s["labor_rates"]}
        n = 0
        for name, model, part, labor in _STARTER_RATES:
            if (model, part) not in have:
                s["labor_rates"].append(pricing.clean_rate(
                    {"name": name, "model": model, "part": part, "labor": labor}))
                n += 1
        store.kv_set(app_dir, "settings", s)
        return f"Loaded {n} starter rate(s) — edit the amounts to match the shop.", ""
    return "", f"Unknown action: {action}"


def save_settings(app_dir, form):
    return settings_action(app_dir, "save", form)[0]


# --------------------------------------------------------------------------- #
#  Price sheet page
# --------------------------------------------------------------------------- #
def render_sheet(app_dir, url, ok="", err=""):
    rows = store.sheet_rows(app_dir)
    H = [_head(url, "sheet", "your price sheet",
               "Repairs you already price. These answer first on the search page. "
               "Import a CSV (columns like <code>device, repair, price</code>), or add rows by hand.")]
    H.append(_flash(ok, err))
    H.append("<div class='row'>")
    H.append(f"<div class='card'><h2>Import CSV</h2>"
             f"<form method='post' enctype='multipart/form-data' action='{_esc(url('sheet'))}?a=upload'>"
             "<input type='file' name='csv' accept='.csv,.tsv,.txt,text/csv'>"
             "<div class='chips' style='margin-top:10px'><input type='checkbox' id='rep' name='replace' value='1'>"
             "<label for='rep' style='display:inline;margin:0 0 0 6px'>replace the whole sheet</label></div>"
             "<button class='mini' type='submit'>Import</button></form>"
             "<p class='hint'>Header names are matched loosely: device/model, repair/service/part, "
             "price/cost/retail, note. No header? Columns are taken as device, repair, price, note.</p></div>")
    H.append(f"<div class='card'><h2>Add a row</h2>"
             f"<form method='post' action='{_esc(url('sheet'))}?a=add'>"
             "<label>Device</label><input type='text' name='device' placeholder='iPhone 13'>"
             "<label>Repair</label><input type='text' name='repair' placeholder='Screen'>"
             "<label>Price ($)</label><input type='number' step='0.01' name='price'>"
             "<label>Note</label><input type='text' name='note' placeholder='aftermarket / OEM…'>"
             "<button class='mini go' type='submit'>Add</button></form></div>")
    H.append("</div>")
    H.append(f"<div class='card'><h2>{len(rows)} rows"
             f"<a class='rightlink' href='{_esc(url('sheet'))}?a=export'>⬇ export CSV</a></h2>")
    if rows:
        H.append("<table><tr><th>Device</th><th>Repair</th><th>Price</th><th>Note</th><th></th></tr>")
        for r in rows:
            H.append(f"<tr><td>{_esc(r['device'])}</td><td>{_esc(r['repair'])}</td>"
                     f"<td>{_money(r['price'])}</td><td>{_esc(r.get('note',''))}</td>"
                     f"<td><form method='post' action='{_esc(url('sheet'))}?a=del'>"
                     f"<input type='hidden' name='id' value='{r['id']}'>"
                     "<button class='mini danger' type='submit'>✕</button></form></td></tr>")
        H.append("</table>")
        H.append(f"<form method='post' action='{_esc(url('sheet'))}?a=clear' "
                 "onsubmit='return confirm(\"Delete every row of the price sheet?\")'>"
                 "<button class='mini danger' type='submit'>Clear the sheet</button></form>")
    else:
        H.append("<p class='hint'>Empty. Import your sheet above, or quote from the search "
                 "page and use <b>add to sheet</b> on the Quotes page.</p>")
    H.append("</div></div>")
    return "".join(H)


def sheet_action(app_dir, action, req):
    if action == "upload":
        f = req.files.get("csv") if hasattr(req, "files") else None
        if not f or not getattr(f, "filename", ""):
            return "", "Choose a CSV file first."
        raw = f.read()
        for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        else:
            return "", "Couldn't read that file as text."
        n, skipped, msg = store.import_sheet_csv(
            app_dir, text, source=f.filename, replace=req.form.get("replace") == "1")
        return (msg, "") if n else ("", msg)
    if action == "add":
        try:
            store.sheet_add(app_dir, req.form.get("device", ""), req.form.get("repair", ""),
                            req.form.get("price", ""), req.form.get("note", ""))
        except ValueError:
            return "", "Price must be a number."
        if not req.form.get("device", "").strip() or not req.form.get("repair", "").strip():
            return "", "Device and repair are required."
        return "Row added.", ""
    if action == "del":
        store.sheet_delete(app_dir, req.form.get("id", 0))
        return "Row removed.", ""
    if action == "clear":
        store.sheet_clear(app_dir)
        return "Sheet cleared.", ""
    return "", f"Unknown action: {action}"


# --------------------------------------------------------------------------- #
#  Quotes page
# --------------------------------------------------------------------------- #
def render_quotes(app_dir, url, ok="", err=""):
    qs = store.quotes(app_dir, 300)
    H = [_head(url, "quotes", "quotes given",
               "Every price quoted from the search page. Add the ones you'll repeat to the sheet.")]
    H.append(_flash(ok, err))
    H.append(f"<div class='card'><h2>{len(qs)} recent"
             f"<a class='rightlink' href='{_esc(url('quotes'))}?a=export'>⬇ export CSV</a></h2>")
    if not qs:
        H.append("<p class='hint'>Nothing yet. Tap <b>Quote</b> on a search result.</p>")
    else:
        H.append("<table><tr><th>When</th><th>Model</th><th>Part</th><th>Cost</th>"
                 "<th>Quoted</th><th></th></tr>")
        for qd in qs:
            when = time.strftime("%b %d %H:%M", time.localtime(qd["ts"]))
            H.append(f"<tr><td>{when}</td><td>{_esc(qd['model'])}</td><td>{_esc(qd['part'])}</td>"
                     f"<td>{_money(qd['cost'])}</td><td><b style='color:var(--money)'>"
                     f"{_money(qd['price'])}</b></td><td>"
                     f"<form method='post' action='{_esc(url('quotes'))}?a=tosheet'>"
                     f"<input type='hidden' name='id' value='{qd['id']}'>"
                     "<button class='mini ghost' type='submit'>+ sheet</button></form> "
                     f"<form method='post' action='{_esc(url('quotes'))}?a=del'>"
                     f"<input type='hidden' name='id' value='{qd['id']}'>"
                     "<button class='mini danger' type='submit'>✕</button></form></td></tr>")
        H.append("</table>")
    H.append("</div></div>")
    return "".join(H)


def _repair_word(part_name):
    """A short repair label from a MobileSentrix part name, for the sheet."""
    low = part_name.lower()
    for kw, label in (("battery", "Battery"), ("lcd", "Screen"), ("oled", "Screen"),
                      ("screen", "Screen"), ("charging port", "Charging port"),
                      ("charge port", "Charging port"), ("dock", "Charging port"),
                      ("back glass", "Back glass"), ("back cover", "Back glass"),
                      ("rear camera", "Rear camera"), ("front camera", "Front camera"),
                      ("camera", "Camera"), ("earpiece", "Earpiece"),
                      ("loud speaker", "Loudspeaker"), ("loudspeaker", "Loudspeaker"),
                      ("speaker", "Speaker"), ("hdmi", "HDMI port"),
                      ("housing", "Housing"), ("frame", "Frame"), ("fan", "Fan"),
                      ("power button", "Power button"), ("volume", "Volume flex")):
        if kw in low:
            return label
    return part_name[:40]


def quotes_action(app_dir, action, form):
    if action == "del":
        store.delete_quote(app_dir, form.get("id", 0))
        return "Quote removed.", ""
    if action == "tosheet":
        qd = store.get_quote(app_dir, form.get("id", 0))
        if not qd:
            return "", "That quote is gone."
        store.sheet_add(app_dir, qd["model"], _repair_word(qd["part"]), qd["price"],
                        note=qd["part"][:80], source="quote")
        return f"Added {qd['model']} — {_repair_word(qd['part'])} at {_money(qd['price'])} to the sheet.", ""
    return "", f"Unknown action: {action}"


# --------------------------------------------------------------------------- #
#  Cache / crawl page
# --------------------------------------------------------------------------- #
_FAMILY_LABELS = {
    "iphone-parts": "iPhone", "ipad-parts": "iPad", "iwatch": "Apple Watch",
    "macbook-pro": "MacBook Pro", "macbook-air": "MacBook Air", "macbook": "MacBook",
    "imac": "iMac", "airpods": "AirPods", "ipod-parts": "iPod",
    "genuine-apple-parts": "Genuine Apple Parts", "galaxy-s-series": "Galaxy S",
    "galaxy-note-series": "Galaxy Note", "galaxy-a-series": "Galaxy A",
    "galaxy-j-series": "Galaxy J", "tab-series": "Galaxy Tab", "xcover-series": "XCover",
}


_BRAND_LABELS = {"sony": "PlayStation", "microsoft": "Xbox", "nintendo": "Nintendo",
                 "oculus": "Meta Quest", "google-pixel": "Google Pixel",
                 "others-brands-parts": "Other brands", "search": "Site searches"}


def _fam_label(brand, family):
    if family in _FAMILY_LABELS:
        return _FAMILY_LABELS[family]
    if family == brand and brand in _BRAND_LABELS:
        return _BRAND_LABELS[brand]
    return (family or brand).replace("-", " ").title()


def render_crawl(app_dir, url, ok="", err=""):
    st = store.stats(app_dir)
    ws = worker.status()
    crawl = store.kv_get(app_dir, "crawl", {}) or {}
    H = [_head(url, "crawl", "MobileSentrix cache",
               "The bench keeps its own copy of the parts it has looked up. A model is "
               "fetched the first time you search it, then refreshed overnight.")]
    H.append(_flash(ok, err))
    if ws.get("last_error"):
        H.append(f"<div class='flash err'>Last problem: {_esc(ws['last_error'])}</div>")
    H.append("<div class='meters'>")
    H.append(f"<div class='meter'><b>{st['models']}</b><small>models · list {_age(st['index_fetched_at'])}</small></div>")
    H.append(f"<div class='meter'><b>{st['cached']}</b><small>models cached</small></div>")
    H.append(f"<div class='meter'><b>{st['products']}</b><small>parts cached</small></div>")
    H.append("</div>")

    # worker status
    H.append("<div class='card'><h2>Fetcher</h2>")
    if ws["running"]:
        H.append(f"<div data-poll='1'><span class='spin'></span>Working on <b>{_esc(ws['running']['label'])}</b>"
                 f" · {len(ws['queued'])} queued</div>")
    elif ws["queued"]:
        H.append(f"<div><span class='spin'></span>{len(ws['queued'])} job(s) queued</div>")
    else:
        H.append("<div class='hint'>Idle." + (f" Last: {_esc(ws['last_done'])} ({_age(ws['last_done_at'])})"
                                             if ws.get("last_done") else "") + "</div>")
    H.append(f"<form method='post' action='{_esc(url('crawl'))}?a=index' style='display:inline'>"
             "<button class='mini' type='submit'>↻ Refresh the model list</button></form> ")
    H.append(f"<form method='post' action='{_esc(url('crawl'))}?a=stale' style='display:inline'>"
             "<button class='mini ghost' type='submit'>↻ Refresh stale models now</button></form> ")
    H.append(f"<form method='post' action='{_esc(url('crawl'))}?a=diag' style='display:inline'>"
             "<button class='mini ghost' type='submit'>🩺 Connection test</button></form>")
    diag = store.kv_get(app_dir, "last_diag", None)
    if diag:
        H.append(_render_diag(diag))
    H.append("</div>")

    # night refresh settings
    H.append(f"<div class='card'><h2>Overnight refresh</h2>"
             f"<form method='post' action='{_esc(url('crawl'))}?a=auto'><div class='row'>")
    H.append("<div><label>Automatic</label><select name='auto'>"
             f"<option value='1'{' selected' if crawl.get('auto', True) else ''}>on</option>"
             f"<option value='0'{'' if crawl.get('auto', True) else ' selected'}>off</option></select></div>")
    H.append(f"<div><label>Refresh models older than (days)</label><input type='number' min='1' max='60' "
             f"name='stale_days' value='{crawl.get('stale_days', 3)}'></div>")
    H.append(f"<div><label>Window start (hour, 0–23)</label><input type='number' min='0' max='23' "
             f"name='night_start' value='{crawl.get('night_start', 2)}'></div>")
    H.append(f"<div><label>Window end</label><input type='number' min='0' max='23' "
             f"name='night_end' value='{crawl.get('night_end', 6)}'></div>")
    H.append("</div><button class='mini' type='submit'>Save</button></form>"
             "<p class='hint'>Each model is one request (2–3 MB). Refreshing 40 cached models "
             "takes a couple of minutes, spaced out politely.</p></div>")

    # families to pre-cache
    fams = store.families(app_dir)
    if fams:
        H.append(f"<div class='card'><h2>Pre-cache a whole family</h2>"
                 f"<form method='post' action='{_esc(url('crawl'))}?a=family'>")
        H.append("<div class='chips'>")
        for brand, family, n, cached in fams:
            key = f"{brand}|{family}"
            H.append(f"<input type='checkbox' id='f_{_esc(key)}' name='fam' value='{_esc(key)}' style='display:none'>"
                     f"<label for='f_{_esc(key)}' style='display:inline;margin:0'>"
                     f"<a href='#' onclick=\"var c=document.getElementById('f_{_esc(key)}');c.checked=!c.checked;this.classList.toggle('on');return false\">"
                     f"{_esc(_fam_label(brand, family))} <small style='color:var(--mut)'>{cached}/{n}</small></a></label>")
        H.append("</div><button class='mini' type='submit'>Fetch the ticked families</button></form>"
                 "<p class='hint'>Optional — searching a model fetches it on the spot anyway. "
                 "Pre-caching makes the very first search of every model in a family instant.</p></div>")

    # cached models list
    cm = store.cached_models(app_dir)
    H.append(f"<div class='card'><h2>{len(cm)} cached models</h2>")
    if cm:
        H.append("<table><tr><th>Model</th><th>Parts</th><th>Fetched</th><th></th></tr>")
        for m in cm[:400]:
            H.append(f"<tr><td>{_esc(m['name'])}<br><small style='color:var(--mut)'>{_esc(m['path'])}</small></td>"
                     f"<td>{m['product_count']}</td><td>{_age(m['fetched_at'])}"
                     + (f"<br><small style='color:#ff9a9a'>{_esc(m['error'])}</small>" if m.get("error") else "")
                     + f"</td><td><form method='post' action='{_esc(url('crawl'))}?a=refetch'>"
                     f"<input type='hidden' name='path' value='{_esc(m['path'])}'>"
                     "<button class='mini ghost' type='submit'>↻</button></form> "
                     f"<form method='post' action='{_esc(url('crawl'))}?a=forget'>"
                     f"<input type='hidden' name='path' value='{_esc(m['path'])}'>"
                     "<button class='mini danger' type='submit'>✕</button></form></td></tr>")
        H.append("</table>")
    else:
        H.append("<p class='hint'>Nothing cached yet — search a model on the Search page.</p>")
    H.append("</div>")
    H.append(_POLL_JS)
    H.append("</div>")
    return "".join(H)


def _render_diag(d):
    def line(label, r):
        if not r:
            return f"<li>{label}: not tried</li>"
        if r.get("error"):
            return f"<li>{label}: <span style='color:#ff9a9a'>{_esc(r['error'])}</span></li>"
        state = ("Cloudflare challenge" if r.get("challenge")
                 else f"{r.get('model_links', 0)} models found")
        extra = f" · HTTP {r['status']}" if r.get("status") else ""
        extra += f" · {r['seconds']} s" if r.get("seconds") else ""
        extra += f" · {_esc(r['binary'])}" if r.get("binary") else ""
        color = "#69f0ae" if r.get("model_links", 0) > 50 else "#ffd27a"
        return f"<li>{label}: <span style='color:{color}'>{state}</span>{extra}</li>"
    return ("<div class='hint' style='margin-top:10px'>Connection test "
            f"({_age(d.get('at'))}):<ul style='margin:4px 0 0 18px;padding:0'>"
            + line("Plain request", d.get("requests"))
            + line("Bench Chromium", d.get("chromium")) + "</ul></div>")


_POLL_JS = """<script>(function(){if(document.querySelector('[data-poll]')){setTimeout(function(){location.reload();},4000);}})();</script>"""


def crawl_action(app_dir, action, form):
    if action == "index":
        worker.enqueue_index(app_dir)
        return "Refreshing the model list in the background.", ""
    if action == "diag":
        worker.enqueue_diag(app_dir)
        return "Connection test running — this page refreshes itself; results show under the Fetcher box in ~10–60 s.", ""
    if action == "stale":
        crawl = store.kv_get(app_dir, "crawl", {}) or {}
        n = worker.refresh_stale(app_dir, float(crawl.get("stale_days", 3)))
        return f"Queued {n} stale model(s).", ""
    if action == "auto":
        crawl = store.kv_get(app_dir, "crawl", {}) or {}
        crawl["auto"] = form.get("auto", "1") == "1"
        for k, d in (("stale_days", 3), ("night_start", 2), ("night_end", 6)):
            try:
                crawl[k] = int(form.get(k, d))
            except (TypeError, ValueError):
                crawl[k] = d
        store.kv_set(app_dir, "crawl", crawl)
        return "Overnight refresh settings saved.", ""
    if action == "family":
        keys = form.getlist("fam") if hasattr(form, "getlist") else [form.get("fam", "")]
        n = 0
        for key in keys:
            if "|" in key:
                brand, family = key.split("|", 1)
                worker.enqueue_family(app_dir, brand, family)
                n += 1
        return (f"Queued {n} family(ies) — watch the Fetcher box.", "") if n else ("", "Tick a family first.")
    if action == "refetch":
        m = store.get_model(app_dir, form.get("path", ""))
        if not m:
            return "", "Unknown model."
        worker.enqueue_model(app_dir, m["path"], m["name"])
        return f"Refetching {m['name']}.", ""
    if action == "forget":
        store.forget_model(app_dir, form.get("path", ""))
        return "Forgotten — it will be fetched again on the next search.", ""
    return "", f"Unknown action: {action}"


# --------------------------------------------------------------------------- #
#  Entry point
# --------------------------------------------------------------------------- #
def _redirect(ctx, sub, ok="", err=""):
    from flask import redirect
    q = ""
    if ok:
        q = "?ok=" + _urlquote(ok[:200])
    elif err:
        q = "?err=" + _urlquote(err[:200])
    return redirect(ctx.url(sub) + q)


def _csv_response(text, filename):
    from flask import Response
    return Response(text, mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={filename}"})


def handle(ctx):
    path = (ctx.path or "").strip("/")
    req = ctx.request
    app_dir = ctx.app_dir
    url = ctx.url
    worker.ensure_threads(app_dir)

    if path == "frag":
        from flask import Response
        frag, _poll = render_results(app_dir, url, req.args.get("q", ""))
        return Response(frag, mimetype="text/html")

    if path.startswith("api"):
        sub = path[3:].strip("/")
        if sub == "status":
            return api_status(app_dir)
        if req.method != "POST":
            return {"error": "POST only"}
        if sub == "quote":
            return api_quote(app_dir, req.form)
        if sub == "live":
            return api_live(app_dir, req.form)
        if sub == "fetch":
            return api_fetch(app_dir, req.form)
        return {"error": f"unknown api: {sub}"}

    ok = req.args.get("ok", "")
    err = req.args.get("err", "")

    if path == "settings":
        if req.method == "POST":
            o, e = settings_action(app_dir, req.args.get("a", "save"), req.form)
            return _redirect(ctx, "settings", ok=o, err=e)
        return render_settings(app_dir, url, ok, err)

    if path == "sheet":
        if req.args.get("a") == "export":
            return _csv_response(store.sheet_csv(app_dir), "price_sheet.csv")
        if req.method == "POST":
            o, e = sheet_action(app_dir, req.args.get("a", ""), req)
            return _redirect(ctx, "sheet", ok=o, err=e)
        return render_sheet(app_dir, url, ok, err)

    if path == "quotes":
        if req.args.get("a") == "export":
            return _csv_response(store.quotes_csv(app_dir), "quotes.csv")
        if req.method == "POST":
            o, e = quotes_action(app_dir, req.args.get("a", ""), req.form)
            return _redirect(ctx, "quotes", ok=o, err=e)
        return render_quotes(app_dir, url, ok, err)

    if path == "crawl":
        if req.method == "POST":
            o, e = crawl_action(app_dir, req.args.get("a", ""), req.form)
            return _redirect(ctx, "crawl", ok=o, err=e)
        return render_crawl(app_dir, url, ok, err)

    return render_search(app_dir, url, req.args.get("q", ""))
