#!/usr/bin/env python3
"""
pp_pricing.py — the shop's pricing rule, as pure functions.

    customer price = round( part cost + part cost × markup% + labor )

Settings (all editable on the dashboard):
  markup_pct   flat percentage added to the part cost           (default 60)
  labor        the DEFAULT labor charge in dollars               (default 45)
  round_to     0 = no rounding, 5 / 10 = round UP to nearest,   (default 5)
               9 = make it end in 9 (…49, …59)
  min_price    never quote below this                           (default 0)
  tax_note     free text shown under the price ("+ tax")        (default "")
  labor_rates  a list of named labor rates that beat the default when they
               fit the job. Each: {"id", "name", "model", "part", "labor"}
                 name   what the tech sees in the dropdown ("Back glass")
                 model  optional model words ("iphone 14 pro max", "ipad",
                        "ps5") — matched against the model name
                 part   optional part words ("back glass", "screen") —
                        matched against the part name, with the same
                        synonyms the search box uses
                 labor  dollars
               The most specific fitting rate wins (model+part beats part
               only beats model only); the default labor is the fallback.
               The tech can still pick any rate from the dropdown on a
               result before quoting.
"""

from __future__ import annotations

import math
import uuid

DEFAULTS = {
    "markup_pct": 60.0,
    "labor": 45.0,
    "round_to": 5,
    "min_price": 0.0,
    "tax_note": "",
    "labor_rates": [],
}


def _num(v, default=0.0):
    try:
        return max(0.0, float(str(v).replace("$", "").replace(",", "").strip()))
    except (TypeError, ValueError):
        return default


def clean_rate(raw):
    """One labor rate from a form/JSON -> clean dict, or None if useless."""
    if not isinstance(raw, dict):
        return None
    name = str(raw.get("name", "") or "").strip()[:40]
    model = str(raw.get("model", "") or "").strip().lower()[:60]
    part = str(raw.get("part", "") or "").strip().lower()[:60]
    labor = _num(raw.get("labor"), None)
    if labor is None or not (name or model or part):
        return None
    if not name:
        name = " ".join(x for x in (model, part) if x).title()
    rid = str(raw.get("id") or "").strip()[:16] or uuid.uuid4().hex[:8]
    return {"id": rid, "name": name, "model": model, "part": part, "labor": labor}


def clean_settings(raw):
    """Coerce a settings dict (from a form or JSON) into safe values."""
    s = dict(DEFAULTS)
    s["labor_rates"] = []
    if not isinstance(raw, dict):
        return s
    for k in ("markup_pct", "labor", "min_price"):
        s[k] = _num(raw.get(k, s[k]), s[k])
    try:
        rt = int(float(raw.get("round_to", s["round_to"])))
        s["round_to"] = rt if rt in (0, 1, 5, 9, 10) else s["round_to"]
    except (TypeError, ValueError):
        pass
    s["tax_note"] = str(raw.get("tax_note", "") or "")[:40]
    rates = raw.get("labor_rates") or []
    if isinstance(rates, list):
        for r in rates:
            c = clean_rate(r)
            if c:
                s["labor_rates"].append(c)
    # v1.0 stored {"back glass": 70} — carry those forward as part-only rates
    lo = raw.get("labor_overrides") or {}
    if isinstance(lo, dict):
        for kw, dollars in lo.items():
            c = clean_rate({"name": str(kw).title(), "part": kw, "labor": dollars})
            if c and not any(x["part"] == c["part"] and not x["model"] for x in s["labor_rates"]):
                s["labor_rates"].append(c)
    return s


# --------------------------------------------------------------------------- #
#  Picking a labor rate for a job
# --------------------------------------------------------------------------- #
def _tokens(text):
    from pp_search import STOP, tokenize
    return [t for t in tokenize(text) if t not in STOP]


def _part_words_fit(words, part_name):
    from pp_search import SYNONYMS, tokenize
    name = (part_name or "").lower()
    ntoks = set(tokenize(name))
    for w in words:
        alts = SYNONYMS.get(w, [w])
        if not any((a in name) if " " in a else (a in ntoks or a in name) for a in alts):
            return False
    return True


def rate_fits(rate, part_name, model_name=""):
    """Score how well a rate fits (0 = doesn't). model+part > part > model."""
    mwords = _tokens(rate.get("model", ""))
    pwords = _tokens(rate.get("part", ""))
    if not mwords and not pwords:
        return 0
    score = 0
    if mwords:
        have = set(_tokens(model_name)) | set(_tokens(part_name))
        if not all(w in have for w in mwords):
            return 0
        score += 100 + len(mwords) * 10
    if pwords:
        if not _part_words_fit(pwords, part_name):
            return 0
        score += 50 + len(pwords) * 5
    return score


def pick_labor(part_name, settings, model_name=""):
    """-> (labor_dollars, rate_dict_or_None) for this job."""
    best, best_score = None, 0
    for r in settings.get("labor_rates") or []:
        sc = rate_fits(r, part_name, model_name)
        if sc > best_score:
            best, best_score = r, sc
    if best:
        return float(best["labor"]), best
    return float(settings.get("labor", 0.0)), None


def round_price(x, round_to):
    if x <= 0:
        return 0.0
    if round_to in (0, 1, None):
        return round(x, 2)
    if round_to == 9:
        n = math.ceil(x)
        while n % 10 != 9:
            n += 1
        return float(n)
    step = int(round_to)
    return float(math.ceil(x / step) * step)


def quote(cost, settings, part_name="", model_name="", labor=None, labor_name=None):
    """Customer price for a part cost. `labor` overrides the auto-picked
    rate (the dropdown on a result). Returns a breakdown dict."""
    s = clean_settings(settings)
    cost = _num(cost, 0.0)
    markup_amt = round(cost * s["markup_pct"] / 100.0, 2)
    if labor is None:
        labor_amt, rate = pick_labor(part_name, s, model_name)
        labor_label = rate["name"] if rate else "default"
        rate_id = rate["id"] if rate else ""
    else:
        labor_amt = _num(labor, 0.0)
        labor_label = str(labor_name or "custom")[:40]
        rate_id = ""
    subtotal = cost + markup_amt + labor_amt
    price = round_price(subtotal, s["round_to"])
    if s["min_price"] and price < s["min_price"]:
        price = round_price(s["min_price"], s["round_to"])
    return {
        "cost": round(cost, 2),
        "markup_pct": s["markup_pct"],
        "markup_amt": markup_amt,
        "labor": labor_amt,
        "labor_name": labor_label,
        "rate_id": rate_id,
        "subtotal": round(subtotal, 2),
        "price": round(price, 2),
        "round_to": s["round_to"],
        "min_price": s["min_price"],
        "margin": round(price - cost, 2),
        "tax_note": s["tax_note"],
    }


def money(x):
    try:
        return f"${float(x):,.2f}"
    except (TypeError, ValueError):
        return "—"


# kept for older callers / tests
def parse_overrides(text):
    out = {}
    for line in str(text or "").splitlines():
        line = line.strip()
        for sep in ("=", ":"):
            if sep in line:
                k, v = line.split(sep, 1)
                try:
                    out[k.strip().lower()] = max(0.0, float(v.strip().lstrip("$")))
                except ValueError:
                    pass
                break
    return out


def format_overrides(d):
    return "\n".join(f"{k} = {v:g}" for k, v in sorted((d or {}).items()))


def labor_for(part_name, settings):
    labor, rate = pick_labor(part_name, clean_settings(settings))
    return labor, (rate["part"] if rate else "")

