# Thermal Cam P3 — BenchTool app

Live radiometric view from a **Thermal Master P3** (256×192, 25 Hz) or **P1**
(160×120) USB-C thermal camera on the bench touchscreen. Built for finding
shorted / hot components on a PCB.

## What's on screen

* Live image at 2× (512×384) with **hot** (red ring) and **cold** (blue ring)
  markers and a centre reticle.
* **Tap anywhere** on the image to place a spot meter; tap the spot again to
  clear it. Works while frozen too.
* Readout strip: MAX · MIN · CTR (centre) · SPOT.
* Buttons: palette (Ironbow / White hot / Black hot / Rainbow / Inferno /
  CAM AGC = the camera's own enhanced picture), GAIN HIGH (−20…150 °C, most
  sensitive — default for boards) / LOW (0…550 °C), SHUTTER/NUC (flat-field
  re-calibration; the camera also does this itself every ~90 s), SNAPSHOT,
  FREEZE, °C/°F, emissivity ε (0.95 solder-mask default → 0.90 → 0.80 →
  0.60 → 1.00).
* SNAPSHOT writes `snapshots/thermal_<stamp>.png` (image with markers) and
  `thermal_<stamp>.csv` (the full 192×256 °C matrix) inside the app folder.

## Install

```bash
python3 validate_app.py thermal_cam          # from the SDK
scp -r thermal_cam <user>@<bench>:~/benchtool-apps/
```
…or zip the folder and upload it on Hero Dashboard ▸ 🧩 My Apps. It appears
under Utilities ▸ My Apps. No extra pip packages: pyusb, numpy and Pillow are
already in the bench venv.

### USB permission (one time per bench)

libusb needs a udev rule for VID `3474`. The app detects "access denied" and
shows a **FIX USB PERMISSION** button that installs
`99-bench-thermal.rules` via `sudo -n`. If sudo needs a password on that
bench, do it over SSH once:

```bash
sudo cp ~/benchtool-apps/thermal_cam/99-bench-thermal.rules /etc/udev/rules.d/
sudo udevadm control --reload-rules && sudo udevadm trigger
```

then unplug/replug the camera. The same rule is also in the main repo's
`udev/` folder, so benches provisioned with `benchtool-apply-setup` get it
automatically.

## Dev machine

`THERMAL_SIM=1 python3 main.py` runs the whole UI on synthetic frames
(moving hot spot) without a camera. With a camera attached on a Linux
laptop, install the udev rule and run `python3 main.py`.

## Protocol credits

The USB handshake, command bytes and frame layout come from the community
reverse-engineering work in
[jvdillon/p3-ir-camera](https://github.com/jvdillon/p3-ir-camera)
(Apache-2.0, USB analysis by @aeternium) and
[Phalphy/OpenP3](https://github.com/Phalphy/OpenP3) (MIT). `p3cam.py` is a
compact re-implementation of that protocol for the bench.
