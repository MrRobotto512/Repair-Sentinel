#!/usr/bin/env python3
"""Thermal Cam P3 — BenchTool user app for the Thermal Master P3 / P1.

Live radiometric view of a board on the 800x480 touchscreen: hot/cold
markers, tap-to-place spot meter, palettes, gain, manual shutter (NUC),
°C/°F, emissivity, freeze and PNG+CSV snapshots.

Follows the BenchTool app contract: standalone Tk root, ui_theme when on
the bench, big X top-right → close() → sys.exit(0), never crashes on
missing hardware (everything is reported in the status line).

Driver: p3cam.py (beside this file).  THERMAL_SIM=1 runs without hardware.
"""

import os
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import font

import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageTk

APP_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP_DIR)
import p3cam  # noqa: E402

try:
    import ui_theme as _ui          # bench only
    ON_BENCH = True
except ImportError:
    _ui = None
    ON_BENCH = False

# BenchTool design tokens
BG_NORMAL = "#0d0d0f"
BG_CARD = "#1b1b21"
BG_CODE = "#101014"
BG_CHIP = "#22222a"
BORDER_DIM = "#2a2a32"
FG_MAIN = "#e8e8f0"
FG_DIM = "#aab0bf"
FG_MUTED = "#7a7a8c"
ACCENT_OK = "#00c853"
ACCENT_HOT = "#ff5252"
ACCENT_COLD = "#40c4ff"
ACCENT_WARN = "#ffab40"

RULE_FILE = os.path.join(APP_DIR, "99-bench-thermal.rules")
SNAP_DIR = os.path.join(APP_DIR, "snapshots")

# ---------------------------------------------------------------------------
# palettes: 256x3 uint8 LUTs from colour control points
# ---------------------------------------------------------------------------

def _lut(points):
    pts = np.array(points, dtype=np.float32)
    xs = np.linspace(0, 1, len(pts))
    idx = np.linspace(0, 1, 256)
    return np.stack([np.interp(idx, xs, pts[:, c]) for c in range(3)],
                    axis=1).astype(np.uint8)


PALETTES = [
    ("IRONBOW", _lut([(0, 0, 0), (25, 0, 70), (110, 0, 130), (190, 30, 100),
                      (235, 100, 30), (255, 180, 10), (255, 240, 150),
                      (255, 255, 255)])),
    ("WHITE HOT", _lut([(0, 0, 0), (255, 255, 255)])),
    ("BLACK HOT", _lut([(255, 255, 255), (0, 0, 0)])),
    ("RAINBOW", _lut([(10, 0, 60), (0, 0, 255), (0, 200, 255), (0, 255, 80),
                      (255, 255, 0), (255, 80, 0), (255, 255, 255)])),
    ("INFERNO", _lut([(0, 0, 4), (40, 11, 84), (101, 21, 110), (159, 42, 99),
                      (212, 72, 66), (245, 125, 21), (250, 193, 39),
                      (252, 255, 164)])),
    ("CAM AGC", None),      # camera's own hardware-enhanced picture
]
EMISSIVITY = [0.95, 0.90, 0.80, 0.60, 1.00]


# ---------------------------------------------------------------------------

class App(tk.Tk):
    TITLE = "THERMAL CAM"

    def __init__(self):
        super().__init__()
        if ON_BENCH and hasattr(_ui, "apply_root"):
            _ui.apply_root(self, self.TITLE)
        else:
            self.geometry("800x480")
            self.title(self.TITLE + " (dev)")
        self.configure(bg=BG_NORMAL)

        self.f_title = font.Font(family="DejaVu Sans", size=24, weight="bold")
        self.f_btn = font.Font(family="DejaVu Sans", size=15, weight="bold")
        self.f_body = font.Font(family="DejaVu Sans", size=14)
        self.f_read = font.Font(family="DejaVu Sans", size=17, weight="bold")
        self.f_small = font.Font(family="DejaVu Sans", size=11)
        self.f_exit = font.Font(family="DejaVu Sans", size=24, weight="bold")

        # state
        self.cam = None
        self.latest = None            # (ir, thermal) from worker
        self.lock = threading.Lock()
        self.cmds = queue.Queue()
        self.alive = True
        self.pal_idx = 0
        self.gain_high = True
        self.use_f = False
        self.emis_idx = 0
        self.frozen = False
        self.spot = None              # (x, y) in sensor coords
        self.scale = 2
        self.photo = None
        self.conn_msg = "Looking for camera…"
        self.conn_color = FG_DIM
        self.perm_denied = False
        self.fps_n = 0
        self.fps_t = time.time()
        self.fps = 0.0
        self.last_frame = None        # last rendered (thermal_c, rgb) for snapshot

        self._build_header()
        self._build_body()
        self.protocol("WM_DELETE_WINDOW", self.close)

        threading.Thread(target=self._worker, daemon=True).start()
        self.after(80, self._tick)

    # ---- chrome --------------------------------------------------------
    def _build_header(self):
        bar = tk.Frame(self, bg=BG_NORMAL, height=52)
        bar.pack(fill=tk.X, padx=8, pady=(4, 0))
        bar.pack_propagate(False)
        tk.Label(bar, text=self.TITLE, font=self.f_title, bg=BG_NORMAL,
                 fg=FG_MAIN).pack(side=tk.LEFT, padx=4)
        tk.Button(bar, text="X", font=self.f_exit, bg="#3a1a1a", fg=ACCENT_HOT,
                  activebackground="#5a2a2a", activeforeground=ACCENT_HOT,
                  bd=3, relief="raised", width=3,
                  command=self.close).pack(side=tk.RIGHT, padx=4)
        self.status = tk.Label(bar, text="starting…", font=self.f_body,
                               bg=BG_NORMAL, fg=FG_DIM, anchor="w")
        self.status.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=12)

    def _build_body(self):
        body = tk.Frame(self, bg=BG_NORMAL)
        body.pack(fill=tk.BOTH, expand=True, padx=8, pady=(4, 4))

        # left: image
        left = tk.Frame(body, bg=BG_NORMAL)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.canvas = tk.Canvas(left, bg=BG_CODE, highlightthickness=1,
                                highlightbackground=BORDER_DIM, cursor="crosshair")
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.canvas.bind("<ButtonRelease-1>", self._on_tap)
        self.img_item = self.canvas.create_image(0, 0, anchor="nw")
        self.hint = self.canvas.create_text(260, 180, text="", fill=FG_DIM, width=480,
                                            justify="center", font=self.f_read)
        self.overlay = []

        # readout strip under image
        strip = tk.Frame(left, bg=BG_CARD, height=44)
        strip.pack(fill=tk.X, pady=(4, 0))
        strip.pack_propagate(False)
        self.read_max = self._readout(strip, "MAX", ACCENT_HOT)
        self.read_min = self._readout(strip, "MIN", ACCENT_COLD)
        self.read_ctr = self._readout(strip, "CTR", FG_MAIN)
        self.read_spot = self._readout(strip, "SPOT", ACCENT_WARN)

        # right: buttons
        right = tk.Frame(body, bg=BG_NORMAL, width=250)
        right.pack(side=tk.RIGHT, fill=tk.Y, padx=(8, 0))
        right.pack_propagate(False)

        self.b_pal = self._button(right, "IRONBOW", self._cycle_palette)
        self.b_gain = self._button(right, "GAIN: HIGH  (-20…150°)", self._toggle_gain)
        self.b_shut = self._button(right, "⟳ SHUTTER / NUC", self._shutter)
        self.b_snap = self._button(right, "📷 SNAPSHOT", self._snapshot, fg=ACCENT_OK)
        self.b_freeze = self._button(right, "❚❚ FREEZE", self._toggle_freeze)
        row = tk.Frame(right, bg=BG_NORMAL)
        row.pack(fill=tk.X, pady=2)
        self.b_unit = tk.Button(row, text="°C", font=self.f_btn, bg=BG_CARD, fg=FG_MAIN,
                                activebackground=BG_CHIP, activeforeground=FG_MAIN,
                                bd=2, relief="raised", height=2, command=self._toggle_unit)
        self.b_unit.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 2))
        self.b_emis = tk.Button(row, text="ε 0.95", font=self.f_btn, bg=BG_CARD, fg=FG_MAIN,
                                activebackground=BG_CHIP, activeforeground=FG_MAIN,
                                bd=2, relief="raised", height=2, command=self._cycle_emis)
        self.b_emis.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(2, 0))

        # only shown when libusb says EACCES
        self.b_fix = tk.Button(right, text="🔧 FIX USB PERMISSION", font=self.f_btn,
                               bg="#3a2a10", fg=ACCENT_WARN, activebackground="#5a4020",
                               activeforeground=ACCENT_WARN, bd=2, relief="raised",
                               height=2, wraplength=230, command=self._fix_permission)

    def _button(self, parent, text, cmd, fg=FG_MAIN):
        b = tk.Button(parent, text=text, font=self.f_btn, bg=BG_CARD, fg=fg,
                      activebackground=BG_CHIP, activeforeground=fg, bd=2,
                      relief="raised", height=2, wraplength=230, command=cmd)
        b.pack(fill=tk.X, pady=2)
        return b

    def _readout(self, parent, label, color):
        f = tk.Frame(parent, bg=BG_CARD)
        f.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tk.Label(f, text=label, font=self.f_small, bg=BG_CARD, fg=FG_MUTED).pack()
        v = tk.Label(f, text="—", font=self.f_read, bg=BG_CARD, fg=color)
        v.pack()
        return v

    def set_status(self, msg, color=FG_DIM):
        self.status.config(text=msg, fg=color)

    # ---- worker thread: owns the USB device -----------------------------
    def _worker(self):
        while self.alive:
            cam = p3cam.make_camera()
            try:
                if not isinstance(cam, p3cam.SimCamera) and not p3cam.P3Camera.find():
                    self._set_conn("No camera — plug the Thermal Master P3 into a USB port (USB-C cable)", FG_DIM)
                    time.sleep(1.5)
                    continue
                self._set_conn("Camera found — initialising…", ACCENT_WARN)
                cam.open()
                cam.start_stream()
                self.cam = cam
                self.perm_denied = False
                name = cam.info.get("read_name", cam.model)
                self._set_conn(f"{name} · fw {cam.info.get('read_version', '?')} · live", ACCENT_OK)
                bad = 0
                while self.alive:
                    self._drain_cmds(cam)
                    fr = cam.read_frame()
                    if fr is None:
                        bad += 1
                        if bad > 50:
                            raise p3cam.CameraError("lost frame sync")
                        continue
                    bad = 0
                    with self.lock:
                        self.latest = fr
            except p3cam.PermissionDenied as e:
                print(f"permission denied: {e}")
                self.perm_denied = True
                self._set_conn("USB permission denied — tap FIX USB PERMISSION, then replug", ACCENT_HOT)
                time.sleep(3)
            except Exception as e:      # noqa: BLE001
                print(f"camera loop error: {e}")
                self._set_conn(f"Camera disconnected: {e}", ACCENT_HOT)
                time.sleep(2)
            finally:
                try:
                    cam.close()
                except Exception:
                    pass
                self.cam = None

    def _drain_cmds(self, cam):
        while True:
            try:
                fn = self.cmds.get_nowait()
            except queue.Empty:
                return
            try:
                fn(cam)
            except Exception as e:      # noqa: BLE001
                print(f"command failed: {e}")
                self._set_conn(f"Command failed: {e}", ACCENT_WARN)

    def _set_conn(self, msg, color):
        self.conn_msg, self.conn_color = msg, color

    # ---- UI loop ----------------------------------------------------------
    def _tick(self):
        if not self.alive:
            return
        try:
            self._render()
        except Exception as e:          # noqa: BLE001  — never a black screen
            print(f"render error: {e}")
            self.set_status(f"Display error: {e}", ACCENT_HOT)
        self.after(70, self._tick)

    def _render(self):
        # status line + permission button
        st = self.conn_msg
        if self.frozen:
            st += " · FROZEN"
        self.set_status(st, self.conn_color)
        if self.last_frame is None:
            cw = max(self.canvas.winfo_width(), 10)
            ch = max(self.canvas.winfo_height(), 10)
            self.canvas.coords(self.hint, cw // 2, ch // 2)
            self.canvas.itemconfig(self.hint, text=self.conn_msg, fill=self.conn_color,
                                   width=cw - 40)
        if self.perm_denied and not self.b_fix.winfo_ismapped():
            self.b_fix.pack(fill=tk.X, pady=2)
        elif not self.perm_denied and self.b_fix.winfo_ismapped():
            self.b_fix.pack_forget()

        if self.frozen:
            return
        with self.lock:
            fr = self.latest
            self.latest = None
        if fr is None:
            return
        ir, thermal = fr
        h, w = thermal.shape

        # fps
        self.fps_n += 1
        now = time.time()
        if now - self.fps_t >= 1.0:
            self.fps = self.fps_n / (now - self.fps_t)
            self.fps_n, self.fps_t = 0, now

        # fit image into the canvas, keeping aspect ratio
        cw = max(self.canvas.winfo_width(), 10)
        ch = max(self.canvas.winfo_height(), 10)
        self.scale = max(0.5, min((cw - 4) / w, (ch - 4) / h))
        s = self.scale
        dw, dh = int(w * s), int(h * s)

        temp_c = p3cam.raw_to_c(thermal)
        temp_c = self._apply_emissivity(temp_c)
        name, lut = PALETTES[self.pal_idx]
        if lut is None:
            rgb = np.repeat(ir[:, :, None], 3, axis=2)
        else:
            lo, hi = np.percentile(temp_c, (0.5, 99.5))
            if hi - lo < 0.5:
                hi = lo + 0.5
            idx = np.clip((temp_c - lo) / (hi - lo) * 255, 0, 255).astype(np.uint8)
            rgb = lut[idx]
        img = Image.fromarray(rgb, "RGB").resize((dw, dh), Image.BILINEAR)
        self.photo = ImageTk.PhotoImage(img)
        ox = (cw - dw) // 2
        oy = (ch - dh) // 2
        self.canvas.coords(self.img_item, ox, oy)
        self.canvas.itemconfig(self.img_item, image=self.photo)
        self.canvas.itemconfig(self.hint, text="")
        self.img_origin = (ox, oy)
        self.last_frame = (temp_c, rgb)

        # overlays
        for it in self.overlay:
            self.canvas.delete(it)
        self.overlay = []
        imax = int(np.argmax(temp_c))
        imin = int(np.argmin(temp_c))
        my, mx = divmod(imax, w)
        ny, nx = divmod(imin, w)
        self._marker(ox + (mx + 0.5) * s, oy + (my + 0.5) * s, ACCENT_HOT)
        self._marker(ox + (nx + 0.5) * s, oy + (ny + 0.5) * s, ACCENT_COLD)
        cx, cy = ox + (w / 2) * s, oy + (h / 2) * s
        self._cross(cx, cy, FG_DIM, 8)
        if self.spot:
            sx, sy = self.spot
            px, py = ox + (sx + 0.5) * s, oy + (sy + 0.5) * s
            self._cross(px, py, ACCENT_WARN, 14)
            self.overlay.append(self.canvas.create_text(
                px + 16, py - 14, text=self._fmt(temp_c[sy, sx]), anchor="w",
                fill=ACCENT_WARN, font=self.f_read))
        self.overlay.append(self.canvas.create_text(
            ox + 6, oy + dh - 6, text=f"{name} · {self.fps:.0f} fps", anchor="sw",
            fill=FG_DIM, font=self.f_small))

        # readouts
        self.read_max.config(text=self._fmt(temp_c[my, mx]))
        self.read_min.config(text=self._fmt(temp_c[ny, nx]))
        self.read_ctr.config(text=self._fmt(temp_c[h // 2, w // 2]))
        self.read_spot.config(text=self._fmt(temp_c[self.spot[1], self.spot[0]])
                              if self.spot else "tap")

    def _marker(self, x, y, color):
        r = 7
        self.overlay.append(self.canvas.create_oval(x - r, y - r, x + r, y + r,
                                                    outline=color, width=3))

    def _cross(self, x, y, color, r):
        self.overlay.append(self.canvas.create_line(x - r, y, x + r, y, fill=color, width=2))
        self.overlay.append(self.canvas.create_line(x, y - r, x, y + r, fill=color, width=2))

    def _apply_emissivity(self, temp_c):
        e = EMISSIVITY[self.emis_idx]
        if e >= 1.0:
            return temp_c
        # Stefan-Boltzmann correction with reflected ambient 25 °C
        tk4 = (temp_c + 273.15) ** 4
        tr4 = np.float32((25.0 + 273.15) ** 4)
        return np.maximum((tk4 - (1 - e) * tr4) / e, 0) ** 0.25 - 273.15

    def _fmt(self, c):
        c = float(c)
        return f"{c * 9 / 5 + 32:.1f}°F" if self.use_f else f"{c:.1f}°C"

    # ---- touch actions ---------------------------------------------------
    def _on_tap(self, ev):
        if self.last_frame is None:
            return
        ox, oy = getattr(self, "img_origin", (0, 0))
        s = self.scale
        h, w = self.last_frame[0].shape
        sx, sy = int((ev.x - ox) / s), int((ev.y - oy) / s)
        if not (0 <= sx < w and 0 <= sy < h):
            return
        if self.spot and abs(self.spot[0] - sx) <= 6 and abs(self.spot[1] - sy) <= 6:
            self.spot = None              # tap the spot again to clear it
        else:
            self.spot = (int(sx), int(sy))
        if self.frozen:
            self.frozen = False
            self._render()
            self.frozen = True
            self.b_freeze.config(text="▶ LIVE", fg=ACCENT_WARN)

    def _cycle_palette(self):
        self.pal_idx = (self.pal_idx + 1) % len(PALETTES)
        self.b_pal.config(text=PALETTES[self.pal_idx][0])

    def _toggle_gain(self):
        self.gain_high = not self.gain_high
        self.b_gain.config(text="GAIN: HIGH  (-20…150°)" if self.gain_high
                           else "GAIN: LOW  (0…550°)")
        hi = self.gain_high
        self.cmds.put(lambda cam: cam.set_gain(hi))

    def _shutter(self):
        self.cmds.put(lambda cam: cam.shutter())
        self.set_status("Shutter / NUC requested…", ACCENT_WARN)

    def _toggle_unit(self):
        self.use_f = not self.use_f
        self.b_unit.config(text="°F" if self.use_f else "°C")

    def _cycle_emis(self):
        self.emis_idx = (self.emis_idx + 1) % len(EMISSIVITY)
        self.b_emis.config(text=f"ε {EMISSIVITY[self.emis_idx]:.2f}")

    def _toggle_freeze(self):
        self.frozen = not self.frozen
        self.b_freeze.config(text="▶ LIVE" if self.frozen else "❚❚ FREEZE",
                             fg=ACCENT_WARN if self.frozen else FG_MAIN)

    def _snapshot(self):
        if self.last_frame is None:
            self.set_status("No frame to save yet", ACCENT_WARN)
            return
        try:
            os.makedirs(SNAP_DIR, exist_ok=True)
            temp_c, rgb = self.last_frame
            h, w = temp_c.shape
            stamp = time.strftime("%Y%m%d_%H%M%S")
            base = os.path.join(SNAP_DIR, f"thermal_{stamp}")
            img = Image.fromarray(rgb, "RGB").resize((w * 3, h * 3), Image.BILINEAR)
            d = ImageDraw.Draw(img)
            try:
                fnt = ImageFont.truetype("DejaVuSans-Bold.ttf", 18)
            except Exception:
                fnt = ImageFont.load_default()
            imax, imin = int(np.argmax(temp_c)), int(np.argmin(temp_c))
            for i, col in ((imax, (255, 82, 82)), (imin, (64, 196, 255))):
                y, x = divmod(i, w)
                d.ellipse((x * 3 - 8, y * 3 - 8, x * 3 + 8, y * 3 + 8), outline=col, width=3)
                d.text((x * 3 + 12, y * 3 - 10), self._fmt(temp_c[y, x]), fill=col, font=fnt)
            if self.spot:
                sx, sy = self.spot
                d.text((sx * 3 + 12, sy * 3 - 10), self._fmt(temp_c[sy, sx]), fill=(255, 171, 64), font=fnt)
                d.line((sx * 3 - 12, sy * 3, sx * 3 + 12, sy * 3), fill=(255, 171, 64), width=2)
                d.line((sx * 3, sy * 3 - 12, sx * 3, sy * 3 + 12), fill=(255, 171, 64), width=2)
            d.text((6, h * 3 - 26), f"{stamp}  max {self._fmt(temp_c.max())}  "
                   f"min {self._fmt(temp_c.min())}  e={EMISSIVITY[self.emis_idx]:.2f}",
                   fill=(232, 232, 240), font=fnt)
            img.save(base + ".png")
            np.savetxt(base + ".csv", temp_c, fmt="%.2f", delimiter=",")
            print(f"snapshot saved: {base}.png / .csv")
            self.set_status(f"Saved {os.path.basename(base)}.png + .csv", ACCENT_OK)
            if ON_BENCH and hasattr(_ui, "toast"):
                _ui.toast(self, "Snapshot saved")
        except Exception as e:          # noqa: BLE001
            print(f"snapshot failed: {e}")
            self.set_status(f"Snapshot failed: {e}", ACCENT_HOT)

    def _fix_permission(self):
        """Install the udev rule so the bench user can open the camera."""
        try:
            cmd = (f"install -m 644 '{RULE_FILE}' /etc/udev/rules.d/99-bench-thermal.rules"
                   " && udevadm control --reload-rules && udevadm trigger")
            r = subprocess.run(["sudo", "-n", "sh", "-c", cmd], capture_output=True,
                               text=True, timeout=20)
            if r.returncode == 0:
                self.perm_denied = False
                self.set_status("USB rule installed — unplug and replug the camera", ACCENT_OK)
            else:
                print(f"udev install failed: {r.stderr}")
                self.set_status("Needs sudo. Over SSH: sudo cp "
                                "~/benchtool-apps/thermal_cam/99-bench-thermal.rules "
                                "/etc/udev/rules.d/ && sudo udevadm trigger", ACCENT_WARN)
        except Exception as e:          # noqa: BLE001
            self.set_status(f"Could not install rule: {e}", ACCENT_HOT)

    # ---- exit ------------------------------------------------------------
    def close(self):
        self.alive = False
        try:
            if self.cam is not None:
                self.cam.close()
        except Exception:
            pass
        try:
            self.destroy()
        finally:
            sys.exit(0)


if __name__ == "__main__":
    App().mainloop()
