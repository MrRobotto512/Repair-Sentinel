#!/usr/bin/env python3
"""Thermal Master P3 / P1 USB driver (pure Python, pyusb).

The P3 is NOT a plain UVC camera: it needs a vendor handshake on interface 0
before the bulk video interface (1, alt 1) produces frames. Every frame is
386 rows x 256 px of little-endian uint16:

    rows   0..191  AGC'd IR picture (low byte = 8-bit brightness)
    rows 192..193  metadata
    rows 194..385  radiometric data, raw/64 = Kelvin

Protocol per the community reverse-engineering effort:
  https://github.com/jvdillon/p3-ir-camera  (Apache-2.0, USB analysis by
  @aeternium) and https://github.com/Phalphy/OpenP3 (MIT).  Command bytes
  and the frame layout below are taken from that work.

Set THERMAL_SIM=1 to run without hardware (synthetic frames) — used for
developing the UI on a laptop.
"""

import array
import os
import struct
import threading
import time

import numpy as np

try:
    import usb.core
    import usb.util
    HAVE_USB = True
except Exception:          # pyusb / libusb missing → simulator only
    usb = None
    HAVE_USB = False

VID = 0x3474
MODELS = {                 # PID: (name, width, height)
    0x45A2: ("P3", 256, 192),
    0x45C2: ("P1", 160, 120),
}
MARKER = 12                # 12-byte start/end frame markers on the bulk pipe
CHUNK = 16384
KELVIN = 273.15

# 18-byte vendor commands (CRC16 pre-computed; camera doesn't check it).
CMD = {
    "read_name":    bytes.fromhex("0101810001000000000000001e0000004f90"),
    "read_version": bytes.fromhex("0101810002000000000000000c0000001f63"),
    "read_serial":  bytes.fromhex("01018100070000000000000040000000104c"),
    "status":       bytes.fromhex("1021810000000000000000000200000095d1"),
    "start_stream": bytes.fromhex("012f81000000000000000000010000004930"),
    "gain_low":     bytes.fromhex("012f41000000000000000000000000003c3a"),
    "gain_high":    bytes.fromhex("012f41000100000000000000000000004939"),
    "shutter":      bytes.fromhex("01364300000000000000000000000000cd0b"),
}


def raw_to_c(raw):
    """uint16 raw (1/64 K) → °C (works on scalars and numpy arrays)."""
    return np.asarray(raw, dtype=np.float32) / 64.0 - KELVIN


class CameraError(Exception):
    pass


class PermissionDenied(CameraError):
    """libusb EACCES — the bench user can't open the device (udev rule)."""


class P3Camera:
    """Blocking driver. Use from ONE worker thread; UI reads .latest."""

    def __init__(self):
        self.dev = None
        self.model = "?"
        self.w, self.h = 256, 192
        self.info = {}
        self.streaming = False
        self._lock = threading.Lock()     # serialises control transfers
        self._buf = None
        self._chunk = None

    # ---- discovery -------------------------------------------------------
    @staticmethod
    def find():
        """Return (pid, name) of the first attached P-series camera, or None."""
        if not HAVE_USB:
            return None
        for pid, (name, _w, _h) in MODELS.items():
            try:
                if usb.core.find(idVendor=VID, idProduct=pid) is not None:
                    return pid, name
            except Exception as e:      # noqa: BLE001  (no backend etc.)
                print(f"usb find failed: {e}")
                return None
        return None

    # ---- lifecycle -------------------------------------------------------
    def open(self):
        found = self.find()
        if not found:
            raise CameraError("camera not found")
        pid, name = found
        self.model, self.w, self.h = MODELS[pid]
        self.dev = usb.core.find(idVendor=VID, idProduct=pid)
        try:
            for cfg in self.dev:
                for intf in cfg:
                    try:
                        if self.dev.is_kernel_driver_active(intf.bInterfaceNumber):
                            self.dev.detach_kernel_driver(intf.bInterfaceNumber)
                    except Exception:
                        pass
            self.dev.set_configuration()
            usb.util.claim_interface(self.dev, 0)
            usb.util.claim_interface(self.dev, 1)
        except usb.core.USBError as e:
            if e.errno == 13 or "Access denied" in str(e) or "EACCES" in str(e):
                raise PermissionDenied(str(e)) from e
            raise CameraError(f"usb open failed: {e}") from e

        rows = 2 * self.h + 2
        self.frame_bytes = rows * self.w * 2
        self.read_size = self.frame_bytes + 2 * MARKER
        self._buf = array.array("B", bytes(self.read_size + 64 * 1024))
        self._chunk = array.array("B", bytes(CHUNK))

        # identify (best effort — some units answer slowly right after plug-in)
        for key, n in (("read_name", 30), ("read_version", 12), ("read_serial", 64)):
            try:
                self.info[key] = self._read_register(key, n)
            except Exception as e:
                print(f"register {key} failed: {e}")
        print(f"[p3cam] {self.model} {self.info}")

    def close(self):
        try:
            self.stop_stream()
        except Exception:
            pass
        try:
            if self.dev is not None:
                usb.util.dispose_resources(self.dev)
        except Exception:
            pass
        self.dev = None

    # ---- control plane ---------------------------------------------------
    def _cmd(self, key):
        self.dev.ctrl_transfer(0x41, 0x20, 0, 0, CMD[key], 1000)

    def _resp(self, n):
        return bytes(self.dev.ctrl_transfer(0xC1, 0x21, 0, 0, n, 1000))

    def _status(self):
        return self.dev.ctrl_transfer(0xC1, 0x22, 0, 0, 1, 1000)[0]

    def _read_register(self, key, n):
        with self._lock:
            self._cmd(key)
            self._status()
            data = self._resp(n)
            self._status()
        return data.rstrip(b"\x00").decode(errors="replace")

    def start_stream(self):
        """Handshake observed from the official Windows tool."""
        with self._lock:
            self._cmd("start_stream")
            self._status()
            self._resp(1)
            self._status()
            time.sleep(1.0)
            self.dev.set_interface_altsetting(interface=1, alternate_setting=1)
            self.dev.ctrl_transfer(0x40, 0xEE, 0, 1, None, 1000)
            time.sleep(2.0)
            try:
                self.dev.read(0x81, self.frame_bytes, 100)
            except Exception:
                pass
            self._cmd("start_stream")
            self._status()
            self._resp(1)
            self._status()
        self.streaming = True

    def stop_stream(self):
        if self.streaming and self.dev is not None:
            with self._lock:
                self.dev.set_interface_altsetting(interface=1, alternate_setting=0)
        self.streaming = False

    def set_gain(self, high):
        with self._lock:
            self._cmd("gain_high" if high else "gain_low")
            self._status()

    def shutter(self):
        """Manual NUC / flat-field.  The camera does one itself ~every 90 s."""
        with self._lock:
            self._cmd("shutter")
            self._status()
        self._resync = True

    # ---- data plane ------------------------------------------------------
    _resync = False

    def read_frame(self):
        """Return (ir_uint8[h,w], thermal_uint16[h,w]) or None on a bad frame.

        The camera sends each frame as bulk data terminated by a 12-byte end
        marker, so we accumulate 16 KiB reads until exactly read_size bytes
        ending in a 12-byte transfer have arrived.
        """
        buf = memoryview(self._buf)
        chunk = self._chunk
        pos = 0
        want = self.read_size
        deadline = time.time() + 3.0
        while pos < want:
            if time.time() > deadline:
                raise CameraError("frame timeout")
            n = self.dev.read(0x81, chunk, 2000)
            nxt = pos + n
            if (n == MARKER and nxt < want) or (nxt >= want and n != MARKER):
                pos = 0            # out of sync (e.g. right after shutter)
                continue
            if nxt > len(buf):
                pos = 0
                continue
            buf[pos:nxt] = memoryview(chunk)[:n]
            pos = nxt

        s_cnt = struct.unpack_from("<I", buf, 2)[0]
        e_cnt = struct.unpack_from("<I", buf, want - MARKER + 2)[0]
        if s_cnt != e_cnt:
            return None
        px = np.frombuffer(buf[MARKER:MARKER + self.frame_bytes], dtype="<u2")
        full = px.reshape((2 * self.h + 2, self.w))
        ir = (full[: self.h] & 0xFF).astype(np.uint8)
        thermal = full[self.h + 2:].copy()
        return ir, thermal


class SimCamera:
    """Synthetic frames for development without hardware."""

    def __init__(self):
        self.model, self.w, self.h = "SIM", 256, 192
        self.info = {"read_name": "P3 (simulated)", "read_version": "0.0"}
        self.streaming = False
        self.t0 = time.time()
        yy, xx = np.mgrid[0:self.h, 0:self.w].astype(np.float32)
        self._xx, self._yy = xx, yy

    def open(self):
        pass

    def close(self):
        pass

    def start_stream(self):
        self.streaming = True

    def stop_stream(self):
        self.streaming = False

    def set_gain(self, high):
        pass

    def shutter(self):
        pass

    def read_frame(self):
        time.sleep(1 / 25)
        t = time.time() - self.t0
        xx, yy = self._xx, self._yy
        base = 24.0 + 3.0 * np.sin(xx / 60.0) + 1.5 * np.cos(yy / 40.0)
        hot = 95.0 * np.exp(-(((xx - 150 + 20 * np.sin(t)) ** 2 + (yy - 80) ** 2) / 300.0))
        warm = 20.0 * np.exp(-(((xx - 60) ** 2 + (yy - 130 + 10 * np.cos(t)) ** 2) / 900.0))
        cold = -8.0 * np.exp(-(((xx - 210) ** 2 + (yy - 150) ** 2) / 500.0))
        c = base + hot + warm + cold + np.random.normal(0, 0.15, xx.shape)
        thermal = ((c + KELVIN) * 64.0).astype(np.uint16)
        span = c.max() - c.min() or 1
        ir = ((c - c.min()) / span * 255).astype(np.uint8)
        return ir, thermal


def make_camera():
    if os.environ.get("THERMAL_SIM") == "1":
        return SimCamera()
    return P3Camera()
