import tkinter as tk
from PIL import Image, ImageTk, ImageEnhance
import random
import os

# Get absolute path for assets relative to this script so it runs correctly anywhere on the portable hardware
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

INVENTORS = [
    {
        "name": "Nikola Tesla",
        "quote": "\"The present is theirs; the future, for which I really worked, is mine.\"",
        "image": os.path.join(BASE_DIR, "assets", "tesla_bg.jpg")
    },
    {
        "name": "Ada Lovelace",
        "quote": "\"That brain of mine is something more than merely mortal; as time will show.\"",
        "image": os.path.join(BASE_DIR, "assets", "lovelace_bg.jpg")
    },
    {
        "name": "Thomas Edison",
        "quote": "\"I have not failed. I've just found 10,000 ways that won't work.\"",
        "image": os.path.join(BASE_DIR, "assets", "edison_bg.jpg")
    }
]

class InventorScreensaver(tk.Tk):
    def __init__(self, rotation_time_ms=8000):
        super().__init__()
        
        self.rotation_time = rotation_time_ms
        self.attributes("-fullscreen", True)
        self.configure(bg="black")
        self.config(cursor="none")
        
        self.bind("<Any-KeyPress>", self.exit_saver)
        self.bind("<Any-Button>", self.exit_saver)
        self.bind("<Motion>", self.exit_saver)
        
        self.canvas = tk.Canvas(self, highlightthickness=0, bg="black")
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        self.update_idletasks()
        self.screen_width = self.winfo_screenwidth()
        self.screen_height = self.winfo_screenheight()
        
        self.current_image = None
        self.after(100, self.update_screensaver)

    def update_screensaver(self):
        self.canvas.delete("all")
        item = random.choice(INVENTORS)
        
        try:
            img = Image.open(item["image"])
            img = img.resize((self.screen_width, self.screen_height), Image.Resampling.LANCZOS)
            
            # Darken image for better text contrast
            enhancer = ImageEnhance.Brightness(img)
            img = enhancer.enhance(0.35)
            
            self.current_image = ImageTk.PhotoImage(img)
            self.canvas.create_image(0, 0, image=self.current_image, anchor="nw")
        except Exception as e:
            print(f"Failed to load {item['image']}: {e}")
            
        self.canvas.create_text(
            self.screen_width // 2, 
            self.screen_height // 2 - 40, 
            text=item["quote"], 
            fill="white", 
            font=("Helvetica", 28, "italic"), 
            justify="center",
            width=self.screen_width * 0.75
        )
        
        self.canvas.create_text(
            self.screen_width // 2, 
            self.screen_height // 2 + 60, 
            text=f"- {item['name']}", 
            fill="#cccccc", 
            font=("Helvetica", 20, "bold")
        )
        
        self.after(self.rotation_time, self.update_screensaver)

    def exit_saver(self, event=None):
        self.destroy()

if __name__ == "__main__":
    app = InventorScreensaver()
    app.mainloop()
