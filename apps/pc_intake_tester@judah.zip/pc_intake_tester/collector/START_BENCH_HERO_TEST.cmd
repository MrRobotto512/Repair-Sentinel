@echo off
setlocal
cd /d "%~dp0"
PowerShell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BenchHero-PC-Collector.ps1"
echo.
echo Press any key to close.
pause >nul
