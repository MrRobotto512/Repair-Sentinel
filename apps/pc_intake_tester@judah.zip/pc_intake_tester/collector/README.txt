Bench Hero PC Intake Collector

1. Open START_BENCH_HERO_TEST.cmd on the Windows 10/11 computer.
2. Enter the customer or ticket name and a short PC label.
3. Approve the administrator prompt when available.
4. The collector saves a JSON copy to BENCH_HERO\PC_RESULTS on this USB.
5. It also sends the result wirelessly to the Bench Hero PC Intake Tester on the shop network.

The collector gathers technical hardware and Windows health information only. It does not copy customer documents, passwords, browser data, or personal files.

If wireless return fails, bring the USB back to Bench Hero and use IMPORT RESULT.
