# Bench Hero PC Collector 1.0 - Windows PowerShell 5.1 compatible
$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'
$CollectorVersion = '1.1.0'
$SchemaVersion = 1
$Root = Split-Path -Parent $PSScriptRoot
$OutDir = Join-Path $Root 'PC_RESULTS'
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$OutFile = Join-Path $OutDir ("PC_INTAKE_{0}.json" -f $Stamp)
$Errors = New-Object System.Collections.Generic.List[string]
$ReceiverFile = Join-Path $PSScriptRoot 'bench_receiver.txt'
$DefaultReceiver = 'http://192.168.1.141:8378/api/pc-intake'
if(Test-Path $ReceiverFile){
  $ConfiguredReceiver = (Get-Content -LiteralPath $ReceiverFile -Raw).Trim()
  if($ConfiguredReceiver){$DefaultReceiver=$ConfiguredReceiver}
}
Write-Host ''
Write-Host 'IDENTIFY THIS COMPUTER' -ForegroundColor Cyan
$CustomerName = Read-Host 'Customer name or ticket name'
$SuggestedPCName = $env:COMPUTERNAME
$PCName = Read-Host "PC name / label [$SuggestedPCName]"
if([string]::IsNullOrWhiteSpace($PCName)){$PCName=$SuggestedPCName}
$ReceiverInput = Read-Host "Bench receiver [$DefaultReceiver]"
if([string]::IsNullOrWhiteSpace($ReceiverInput)){$ReceiverUrl=$DefaultReceiver}else{$ReceiverUrl=$ReceiverInput.Trim()}
function Try-Value([scriptblock]$Block, $Default=$null, [string]$Name='') {
  try { & $Block } catch { if($Name){$Errors.Add("$Name`: $($_.Exception.Message)")}; $Default }
}
function Safe-Percent($Full,$Design) {
  if($Design -and $Design -gt 0 -and $Full -ne $null){ return [math]::Round(($Full/$Design)*100,0) }
  return $null
}
function Verdict($state,$title,$detail,$recommendation='') {
  [ordered]@{ state=$state; title=$title; detail=$detail; recommendation=$recommendation }
}
Write-Host 'Bench Hero PC Collector'
Write-Host 'Collecting system information...'
$cs = Try-Value { Get-CimInstance Win32_ComputerSystem } $null 'computer system'
$bios = Try-Value { Get-CimInstance Win32_BIOS } $null 'bios'
$os = Try-Value { Get-CimInstance Win32_OperatingSystem } $null 'operating system'
$cpu = Try-Value { Get-CimInstance Win32_Processor | Select-Object -First 1 } $null 'processor'
$base = Try-Value { Get-CimInstance Win32_BaseBoard | Select-Object -First 1 } $null 'baseboard'
$secureBoot = Try-Value { Confirm-SecureBootUEFI } $null
$tpm = Try-Value { Get-Tpm } $null
$activation = Try-Value { (Get-CimInstance SoftwareLicensingProduct -Filter "Name like 'Windows%' and PartialProductKey is not null" | Select-Object -First 1).LicenseStatus } $null
$activationText = switch($activation){1{'Licensed'} 2{'Initial grace'} 3{'Additional grace'} 4{'Non-genuine grace'} 5{'Notification'} 6{'Extended grace'} default{'Unknown'}}
$pendingRestart = $false
$pendingRestart = $pendingRestart -or (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')
$pendingRestart = $pendingRestart -or (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\PendingFileRenameOperations')
$bitlocker = Try-Value { Get-BitLockerVolume | ForEach-Object { [ordered]@{mount_point=$_.MountPoint; volume_status="$($_.VolumeStatus)"; protection_status="$($_.ProtectionStatus)"; encryption_method="$($_.EncryptionMethod)"} } } @()
$memory = Try-Value { Get-CimInstance Win32_PhysicalMemory | ForEach-Object { [ordered]@{bank=$_.BankLabel; slot=$_.DeviceLocator; manufacturer=$_.Manufacturer; part_number=($_.PartNumber -as [string]).Trim(); capacity_bytes=[int64]$_.Capacity; speed_mhz=$_.Speed; configured_speed_mhz=$_.ConfiguredClockSpeed} } } @() 'memory'
$gpus = Try-Value { Get-CimInstance Win32_VideoController | ForEach-Object { [ordered]@{name=$_.Name; driver_version=$_.DriverVersion; status=$_.Status; resolution=if($_.CurrentHorizontalResolution){"$($_.CurrentHorizontalResolution)x$($_.CurrentVerticalResolution)"}else{$null}; adapter_ram_bytes=[int64]$_.AdapterRAM} } } @() 'graphics'
Write-Host 'Checking storage...'
$physical = Try-Value { Get-PhysicalDisk } @()
$storage = @()
foreach($pd in $physical){
  $rel = Try-Value { $pd | Get-StorageReliabilityCounter } $null
  $mediaType = "$($pd.MediaType)"
  $health = "$($pd.HealthStatus)"
  $state='PASS'; $reasons=@()
  if($health -and $health -notin @('Healthy','Unknown')){$state='FAIL';$reasons += "Health status: $health"}
  if($rel){
    if($rel.ReadErrorsUncorrected -gt 0 -or $rel.WriteErrorsUncorrected -gt 0){$state='FAIL';$reasons += 'Uncorrected media errors'}
    if($rel.Temperature -ge 65 -and $state -eq 'PASS'){$state='WARN';$reasons += "High temperature: $($rel.Temperature) C"}
    if($rel.Wear -ne $null -and $rel.Wear -ge 80 -and $state -eq 'PASS'){$state='WARN';$reasons += "Wear used: $($rel.Wear)%"}
  }
  $storage += [ordered]@{
    friendly_name=$pd.FriendlyName; serial_number=$pd.SerialNumber; media_type=$mediaType; bus_type="$($pd.BusType)";
    size_bytes=[int64]$pd.Size; health_status=$health; operational_status=($pd.OperationalStatus -join ', ');
    temperature_c=if($rel){$rel.Temperature}else{$null}; wear_percent_used=if($rel){$rel.Wear}else{$null};
    power_on_hours=if($rel){$rel.PowerOnHours}else{$null}; read_errors_uncorrected=if($rel){$rel.ReadErrorsUncorrected}else{$null};
    write_errors_uncorrected=if($rel){$rel.WriteErrorsUncorrected}else{$null}; verdict=$state; reasons=$reasons
  }
}
if(-not $storage){
  $storage = Try-Value { Get-CimInstance Win32_DiskDrive | ForEach-Object {[ordered]@{friendly_name=$_.Model;serial_number=$_.SerialNumber;media_type=$_.MediaType;bus_type=$_.InterfaceType;size_bytes=[int64]$_.Size;health_status=$_.Status;verdict=if($_.Status -eq 'OK'){'UNKNOWN'}else{'WARN'};reasons=@('Detailed SMART data unavailable')}} } @() 'disk drives'
}
$volumes = Try-Value { Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object { [ordered]@{drive=$_.DeviceID; filesystem=$_.FileSystem; size_bytes=[int64]$_.Size; free_bytes=[int64]$_.FreeSpace} } } @()
Write-Host 'Checking battery and devices...'
$batteries = @()
$bats = Try-Value { Get-CimInstance Win32_Battery } @()
foreach($b in $bats){
  $design = $null; $full = $null; $cycles = $null
  $static = Try-Value { Get-CimInstance -Namespace root\wmi BatteryStaticData | Select-Object -First 1 } $null
  $fullObj = Try-Value { Get-CimInstance -Namespace root\wmi BatteryFullChargedCapacity | Select-Object -First 1 } $null
  $cycleObj = Try-Value { Get-CimInstance -Namespace root\wmi BatteryCycleCount | Select-Object -First 1 } $null
  if($static){$design=$static.DesignedCapacity}; if($fullObj){$full=$fullObj.FullChargedCapacity}; if($cycleObj){$cycles=$cycleObj.CycleCount}
  $health=Safe-Percent $full $design
  $verdict=if($health -eq $null){'UNKNOWN'}elseif($health -ge 80){'PASS'}elseif($health -ge 60){'WARN'}else{'FAIL'}
  $batteries += [ordered]@{name=$b.Name; manufacturer=$b.Manufacturer; chemistry=$b.Chemistry; design_capacity_mwh=$design; full_charge_capacity_mwh=$full; health_percent=$health; cycle_count=$cycles; estimated_charge_remaining=$b.EstimatedChargeRemaining; status=$b.Status; verdict=$verdict}
}
$pnpErrors = Try-Value { Get-PnpDevice -PresentOnly | Where-Object {$_.Status -ne 'OK'} | ForEach-Object {[ordered]@{class=$_.Class;friendly_name=$_.FriendlyName;status="$($_.Status)";instance_id=$_.InstanceId}} } @() 'device manager'
$netAdapters = Try-Value { Get-NetAdapter | ForEach-Object {[ordered]@{name=$_.Name;description=$_.InterfaceDescription;status="$($_.Status)";link_speed="$($_.LinkSpeed)";mac=$_.MacAddress}} } @()
$ipConfig = Try-Value { Get-NetIPConfiguration | ForEach-Object {[ordered]@{interface=$_.InterfaceAlias;ipv4=($_.IPv4Address.IPAddress -join ',');gateway=($_.IPv4DefaultGateway.NextHop -join ',');dns=($_.DNSServer.ServerAddresses -join ',')}} } @()
$internet = Try-Value { Test-NetConnection -ComputerName 1.1.1.1 -InformationLevel Quiet } $false
$dnsOk = Try-Value { [bool](Resolve-DnsName microsoft.com -ErrorAction Stop) } $false
Write-Host 'Reading recent errors...'
$since=(Get-Date).AddDays(-30)
$events = Try-Value { Get-WinEvent -FilterHashtable @{LogName='System';StartTime=$since;Level=1,2} -MaxEvents 150 | Where-Object {$_.ProviderName -match 'WHEA|Disk|Ntfs|stor|Kernel-Power|volmgr|Display'} | ForEach-Object {[ordered]@{time=$_.TimeCreated.ToUniversalTime().ToString('o');provider=$_.ProviderName;event_id=$_.Id;level=$_.LevelDisplayName;message=(($_.Message -replace '\s+',' ').Trim())}} } @() 'event logs'
$findings = New-Object System.Collections.Generic.List[object]
foreach($d in $storage){ if($d.verdict -in @('WARN','FAIL')){$findings.Add((Verdict $d.verdict $d.friendly_name (($d.reasons -join '; ')) $(if($d.verdict -eq 'FAIL'){'Clone before further work'}else{'Review drive health'}))) } }
foreach($b in $batteries){ if($b.verdict -in @('WARN','FAIL')){$findings.Add((Verdict $b.verdict 'Battery' ("Health: {0}%" -f $b.health_percent) 'Consider battery replacement'))} }
if($pnpErrors.Count -gt 0){$findings.Add((Verdict 'WARN' 'Device Manager' ("{0} device problem(s)" -f $pnpErrors.Count) 'Install or repair affected drivers'))}
$wheaCount=@($events | Where-Object {$_.provider -match 'WHEA'}).Count
if($wheaCount -gt 0){$findings.Add((Verdict 'FAIL' 'Hardware errors' ("{0} WHEA event(s) in 30 days" -f $wheaCount) 'Run hardware diagnostics'))}
$diskEventCount=@($events | Where-Object {$_.provider -match 'Disk|Ntfs|stor'}).Count
if($diskEventCount -gt 0){$findings.Add((Verdict 'WARN' 'Storage events' ("{0} disk/storage event(s) in 30 days" -f $diskEventCount) 'Review event timeline and drive health'))}
if($pendingRestart){$findings.Add((Verdict 'WARN' 'Pending restart' 'Windows reports a restart is required' 'Restart after intake'))}
if(-not $internet){$findings.Add((Verdict 'WARN' 'Internet test' 'Could not reach test endpoint' 'Verify connection'))}
$passCount=0;$warnCount=0;$failCount=0
foreach($f in $findings){if($f.state -eq 'FAIL'){$failCount++}elseif($f.state -eq 'WARN'){$warnCount++}}
$checkedCategories=9
$passCount=[math]::Max(0,$checkedCategories-$warnCount-$failCount)
$overall=if($failCount -gt 0){'FAIL'}elseif($warnCount -gt 0){'WARN'}else{'PASS'}
$recommendation=if($failCount -gt 0){($findings | Where-Object {$_.state -eq 'FAIL'} | Select-Object -First 1).recommendation}elseif($warnCount -gt 0){($findings | Where-Object {$_.state -eq 'WARN'} | Select-Object -First 1).recommendation}else{'No immediate issue found in automated intake checks'}
$result=[ordered]@{
 schema_version=$SchemaVersion; collector_version=$CollectorVersion; created_utc=(Get-Date).ToUniversalTime().ToString('o');
 intake_meta=[ordered]@{customer_name=$CustomerName;pc_name=$PCName;windows_computer_name=$env:COMPUTERNAME;receiver_url=$ReceiverUrl};
 identity=[ordered]@{manufacturer=$cs.Manufacturer;model=$cs.Model;serial_number=$bios.SerialNumber;system_type=$cs.PCSystemType;system_sku=$cs.SystemSKUNumber;baseboard="$($base.Manufacturer) $($base.Product)";bios_version=($bios.SMBIOSBIOSVersion -join ', ');bios_date=$bios.ReleaseDate;secure_boot=$secureBoot;tpm_present=if($tpm){$tpm.TpmPresent}else{$null};tpm_ready=if($tpm){$tpm.TpmReady}else{$null}};
 windows=[ordered]@{caption=$os.Caption;version=$os.Version;build=$os.BuildNumber;architecture=$os.OSArchitecture;install_date=$os.InstallDate;last_boot=$os.LastBootUpTime;activation=$activationText;pending_restart=$pendingRestart;bitlocker=$bitlocker};
 cpu=[ordered]@{name=$cpu.Name;cores=$cpu.NumberOfCores;logical_processors=$cpu.NumberOfLogicalProcessors;max_clock_mhz=$cpu.MaxClockSpeed;current_clock_mhz=$cpu.CurrentClockSpeed};
 memory=[ordered]@{total_bytes=[int64]$cs.TotalPhysicalMemory;modules=$memory}; graphics=$gpus; storage=[ordered]@{physical=$storage;volumes=$volumes}; battery=$batteries;
 devices=[ordered]@{problems=$pnpErrors}; network=[ordered]@{adapters=$netAdapters;ip_configuration=$ipConfig;internet_reachable=$internet;dns_working=$dnsOk}; recent_problems=$events;
 summary=[ordered]@{verdict=$overall;passed=$passCount;warnings=$warnCount;failed=$failCount;manufacturer=$cs.Manufacturer;model=$cs.Model;top_findings=@($findings | Select-Object -First 5);recommendation=$recommendation};
 collection_errors=@($Errors)
}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $OutFile -Encoding UTF8
if(Test-Path $OutFile){
  Write-Host ''
  Write-Host 'COLLECTOR COMPLETE' -ForegroundColor Green
  Write-Host "Saved locally: $OutFile"
  Write-Host ''
  Write-Host "Sending to Bench Hero: $ReceiverUrl"
  try {
    $Body = Get-Content -LiteralPath $OutFile -Raw -Encoding UTF8
    $Response = Invoke-RestMethod -Uri $ReceiverUrl -Method Post -ContentType 'application/json; charset=utf-8' -Body $Body -TimeoutSec 20
    if($Response.ok){
      Write-Host 'WIRELESS RETURN COMPLETE' -ForegroundColor Green
      Write-Host "Received by Bench Hero as: $($Response.saved_as)"
    }else{
      Write-Host 'Bench Hero did not confirm receipt. The USB copy is still available.' -ForegroundColor Yellow
    }
  } catch {
    Write-Host 'Wireless return failed. The result is still safely stored on this USB.' -ForegroundColor Yellow
    Write-Host $_.Exception.Message
  }
}else{
  Write-Host 'COLLECTOR FAILED TO WRITE RESULTS' -ForegroundColor Red
  exit 1
}
Write-Host ''
Read-Host 'Press Enter to close'
