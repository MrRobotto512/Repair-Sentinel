#!/usr/bin/env python3
import os, sys, json, queue, shutil, subprocess, threading, datetime, hashlib, zipfile, socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import tkinter as tk
from tkinter import font
try:
    import ui_theme as _ui
except ImportError:
    _ui = None
try:
    import bench_keyboard
except ImportError:
    bench_keyboard = None

BG_NORMAL='#0d0d0f'; BG_CARD='#1b1b21'; BG_CODE='#101014'; BG_CHIP='#22222a'; BORDER_DIM='#2a2a32'
FG_MAIN='#e8e8f0'; FG_DIM='#aab0bf'; FG_MUTED='#7a7a8c'; OK='#00c853'; WARN='#ffc107'; FAIL='#ff5c5c'; BLUE='#5aa9ff'
APP_DIR=os.path.dirname(os.path.abspath(__file__))
IMPORT_DIRS=('BENCH_HERO/PC_RESULTS','BENCH_HERO/IMPORTS','BENCH_HERO/PC_COLLECTOR/RESULTS')
RECEIVER_PORT=8378
RECEIVER_PATH='/api/pc-intake'

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        if _ui and hasattr(_ui,'apply_root'): _ui.apply_root(self)
        else: self.geometry('800x480'); self.title('PC Intake Tester (dev)')
        self.configure(bg=BG_NORMAL); self.protocol('WM_DELETE_WINDOW',self.close)
        self.f_title=font.Font(family='DejaVu Sans',size=25,weight='bold')
        self.f_btn=font.Font(family='DejaVu Sans',size=17,weight='bold')
        self.f_body=font.Font(family='DejaVu Sans',size=14)
        self.f_small=font.Font(family='DejaVu Sans',size=11)
        self.q=queue.Queue(); self.pages={}; self.history=[]; self.usbs=[]; self.selected=None; self.results=None; self.current=None
        self.manual={name:{'status':'NOT TESTED','note':''} for name in ManualPage.TESTS}
        self.receiver=None
        self._build_chrome()
        for cls in (HomePage,UsbPage,ImportPage,SummaryPage,DetailsPage,ManualPage,BusyPage):
            p=cls(self.body); self.pages[cls.__name__]=p; p.place(x=0,y=0,relwidth=1,relheight=1)
        self.show('HomePage',push=False); self.after(150,self._poll); self.after(300,self.refresh_usb); self.after(600,self._start_receiver)

    def _build_chrome(self):
        head=tk.Frame(self,bg=BG_CARD); head.place(x=0,y=0,width=800,height=64)
        tk.Label(head,text='PC Intake Tester',font=self.f_title,bg=BG_CARD,fg=FG_MAIN).place(x=16,y=7)
        tk.Label(head,text='standardized Windows intake',font=self.f_small,bg=BG_CARD,fg=FG_DIM).place(x=19,y=41)
        tk.Button(head,text='X',font=self.f_btn,bg='#3a1a1a',fg=FG_MAIN,activebackground='#5a2a2a',bd=2,command=self.close).place(x=722,y=6,width=66,height=52)
        self.body=tk.Frame(self,bg=BG_NORMAL); self.body.place(x=8,y=70,width=784,height=354)
        foot=tk.Frame(self,bg=BG_NORMAL); foot.place(x=0,y=424,width=800,height=56)
        tk.Button(foot,text='BACK',font=self.f_body,bg=BG_CARD,fg=FG_MAIN,command=self.back).place(x=10,y=6,width=105,height=44)
        self.status=tk.StringVar(value='Ready')
        tk.Label(foot,textvariable=self.status,font=self.f_small,bg=BG_NORMAL,fg=FG_DIM,anchor='w',wraplength=520).place(x=128,y=4,width=530,height=48)
        tk.Button(foot,text='HOME',font=self.f_body,bg=BG_CARD,fg=FG_MAIN,command=lambda:self.show('HomePage')).place(x=675,y=6,width=115,height=44)

    def set_status(self,msg,color=None):
        print('[PC INTAKE]',msg); self.status.set(str(msg))
    def show(self,name,push=True,**ctx):
        current=self.current
        if push and current and current!=name: self.history.append(current)
        for p in self.pages.values(): p.place_forget()
        p=self.pages[name]; p.place(x=0,y=0,relwidth=1,relheight=1); p.tkraise(); self.current=name; p.on_show(**ctx)
    def back(self):
        if self.history: self.show(self.history.pop(),push=False)
        else: self.show('HomePage',push=False)
    def run_bg(self,func,*args):
        threading.Thread(target=self._worker,args=(func,args),daemon=True).start()
    def _worker(self,func,args):
        try: self.q.put(('done',func(*args)))
        except Exception as e: self.q.put(('error',str(e)))
    def _poll(self):
        try:
            while True:
                kind,payload=self.q.get_nowait()
                if kind=='usb': self.usbs=payload; self.pages['UsbPage'].render(payload)
                elif kind=='progress': self.pages['BusyPage'].progress(*payload)
                elif kind=='imported': self.results=payload; self.set_status('Result imported'); self.show('SummaryPage')
                elif kind=='received': self.results=payload; self.set_status('Result received from Windows PC'); self.show('SummaryPage')
                elif kind=='message': self.set_status(payload)
                elif kind=='error': self.set_status('Error: '+payload)
                elif kind=='done' and isinstance(payload,str): self.set_status(payload)
        except queue.Empty: pass
        self.after(120,self._poll)

    def _start_receiver(self):
        app=self
        class Handler(BaseHTTPRequestHandler):
            def _reply(self,code,obj):
                body=json.dumps(obj).encode('utf-8')
                self.send_response(code); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
            def do_GET(self):
                if self.path in ('/','/health',RECEIVER_PATH+'/health'):
                    self._reply(200,{'ok':True,'service':'Bench Hero PC Intake Receiver','port':RECEIVER_PORT})
                else:self._reply(404,{'ok':False,'error':'not found'})
            def do_POST(self):
                if self.path.rstrip('/')!=RECEIVER_PATH:self._reply(404,{'ok':False,'error':'not found'});return
                try:
                    length=int(self.headers.get('Content-Length','0'))
                    if length<=0 or length>8*1024*1024: raise ValueError('invalid payload size')
                    data=json.loads(self.rfile.read(length).decode('utf-8-sig'))
                    if not isinstance(data,dict) or not data.get('identity') or not data.get('summary'): raise ValueError('invalid PC Intake result')
                    inbox=os.path.join(APP_DIR,'inbox'); os.makedirs(inbox,exist_ok=True)
                    meta=data.get('intake_meta') or {}; safe='-'.join(str(meta.get('pc_name') or data.get('identity',{}).get('model') or 'PC').split())[:40]
                    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                    path=os.path.join(inbox,f'PC_INTAKE_{safe}_{stamp}.json')
                    tmp=path+'.tmp'
                    with open(tmp,'w',encoding='utf-8') as f: json.dump(data,f,indent=2,ensure_ascii=False);f.flush();os.fsync(f.fileno())
                    os.replace(tmp,path)
                    app.q.put(('received',data)); self._reply(200,{'ok':True,'saved_as':os.path.basename(path)})
                except Exception as e:self._reply(400,{'ok':False,'error':str(e)})
            def log_message(self,fmt,*args): pass
        try:
            self.receiver=ThreadingHTTPServer(('0.0.0.0',RECEIVER_PORT),Handler)
            threading.Thread(target=self.receiver.serve_forever,daemon=True).start()
            ip=self._local_ip(); self.set_status(f'Ready · wireless return: http://{ip}:{RECEIVER_PORT}')
        except Exception as e:self.set_status('Wireless receiver unavailable: '+str(e))
    def _local_ip(self):
        try:
            sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);sock.connect(('8.8.8.8',80));ip=sock.getsockname()[0];sock.close();return ip
        except Exception:return '192.168.1.141'

    def refresh_usb(self): self.run_bg(self._discover_usb_bg)
    def _discover_usb_bg(self):
        rows=self._discover_usb_sync()
        self.q.put(('usb',rows))
        return ''
    def _discover_usb_sync(self):
        fields='NAME,KNAME,PATH,TYPE,TRAN,RM,HOTPLUG,RO,FSTYPE,LABEL,UUID,SIZE,MODEL,VENDOR,SERIAL,MOUNTPOINTS,PKNAME'
        p=subprocess.run(['lsblk','-J','-b','-o',fields],capture_output=True,text=True,timeout=8)
        if p.returncode: raise RuntimeError(p.stderr.strip() or 'lsblk failed')
        roots=json.loads(p.stdout).get('blockdevices',[])
        root_source=subprocess.run(['findmnt','-n','-o','SOURCE','/'],capture_output=True,text=True).stdout.strip()
        root_parent=''
        if root_source.startswith('/dev/'):
            root_parent=subprocess.run(['lsblk','-no','PKNAME',root_source],capture_output=True,text=True).stdout.strip()
        rows=[]
        def walk(node,parent=None):
            inherited={k:(node.get(k) if node.get(k) not in (None,'') else (parent or {}).get(k)) for k in ('tran','model','vendor','serial')}
            name=node.get('name',''); typ=node.get('type',''); fs=(node.get('fstype') or '').lower()
            mounts=node.get('mountpoints') or []
            if isinstance(mounts,str): mounts=[mounts]
            mounts=[m for m in mounts if m]
            is_usb=inherited.get('tran')=='usb'
            bad=name.startswith(('zram','loop')) or typ in ('loop','rom') or fs in ('swap','squashfs')
            system=(name==root_parent or node.get('kname')==root_parent or root_source==node.get('path'))
            if is_usb and not bad and not system and typ in ('part','disk') and fs and fs!='swap':
                mp=mounts[0] if mounts else None
                free=None; writable=False
                if mp and os.path.isdir(mp):
                    try: free=shutil.disk_usage(mp).free; writable=os.access(mp,os.W_OK) and not bool(node.get('ro'))
                    except OSError: pass
                rows.append({'name':name,'path':node.get('path'),'type':typ,'tran':'usb','ro':bool(node.get('ro')),
                  'fstype':fs,'label':node.get('label') or 'USB Drive','uuid':node.get('uuid') or '',
                  'size':int(node.get('size') or 0),'model':(inherited.get('model') or '').strip(),'vendor':(inherited.get('vendor') or '').strip(),
                  'serial':(inherited.get('serial') or '').strip(),'mountpoint':mp,'free':free,'writable':writable})
            for ch in node.get('children') or []: walk(ch,{**node,**inherited})
        for r in roots: walk(r)
        return rows

    def identify(self,d): return (d.get('uuid'),d.get('serial'),d.get('model'),d.get('size'))
    def resolve_selected(self,need_write=False):
        target=self.identify(self.selected or {})
        latest=self._discover_usb_sync()
        for d in latest:
            if self.identify(d)==target:
                if not d.get('mountpoint'): d=self._mount_usb(d)
                if need_write and not d.get('writable'): raise RuntimeError('Selected USB is not writable')
                return d
        raise RuntimeError('Selected USB was removed or changed')
    def _mount_usb(self,d):
        p=subprocess.run(['udisksctl','mount','-b',d['path']],capture_output=True,text=True,timeout=20)
        if p.returncode: raise RuntimeError(p.stderr.strip() or 'Could not mount USB')
        for x in self._discover_usb_sync():
            if self.identify(x)==self.identify(d): return x
        raise RuntimeError('USB mounted but could not be rediscovered')

    def create_collector(self):
        self.show('UsbPage',mode='collector')
    def write_collector(self):
        self.show('BusyPage',title='Creating Collector'); self.run_bg(self._write_collector)
    def _write_collector(self):
        d=self.resolve_selected(True); mp=d['mountpoint']; dest=os.path.join(mp,'BENCH_HERO','PC_COLLECTOR'); os.makedirs(dest,exist_ok=True)
        src=os.path.join(APP_DIR,'collector'); files=('START_BENCH_HERO_TEST.cmd','BenchHero-PC-Collector.ps1','README.txt')
        for i,name in enumerate(files,1):
            self.q.put(('progress',(f'Writing {name}',int(i/len(files)*78))))
            s=os.path.join(src,name); out=os.path.join(dest,name); tmp=out+'.tmp'
            shutil.copyfile(s,tmp)
            with open(tmp,'rb') as f: os.fsync(f.fileno())
            os.replace(tmp,out)
            if hashlib.sha256(open(s,'rb').read()).digest()!=hashlib.sha256(open(out,'rb').read()).digest(): raise RuntimeError('Verification failed: '+name)
        self.q.put(('progress',('Writing wireless return address',88)))
        receiver=f'http://{self._local_ip()}:{RECEIVER_PORT}{RECEIVER_PATH}\n'.encode('utf-8')
        self._atomic(os.path.join(dest,'bench_receiver.txt'),receiver)
        subprocess.run(['sync'],timeout=15); self.q.put(('progress',('Collector verified — safe to remove',100)))
        return 'Collector created and verified on '+(d.get('label') or d.get('model') or d['path'])

    def find_packages(self,d):
        d=self.resolve_selected(False); found=[]
        for rel in IMPORT_DIRS:
            base=os.path.join(d['mountpoint'],*rel.split('/'))
            if not os.path.isdir(base): continue
            for name in sorted(os.listdir(base),reverse=True):
                if name.lower().endswith(('.json','.bhpkg','.zip')):
                    path=os.path.join(base,name)
                    found.append({'path':path,'name':name,'size':os.path.getsize(path)})
        return found
    def import_package(self,path):
        self.show('BusyPage',title='Importing Result'); self.run_bg(self._import_package,path)
    def _import_package(self,path):
        self.q.put(('progress',('Validating package',25)))
        if path.lower().endswith(('.zip','.bhpkg')):
            with zipfile.ZipFile(path) as z:
                names=[n for n in z.namelist() if n.lower().endswith('.json')]
                if not names: raise RuntimeError('Package contains no JSON result')
                data=json.loads(z.read(names[0]).decode('utf-8-sig'))
        else:
            with open(path,'r',encoding='utf-8-sig') as f: data=json.load(f)
        if not isinstance(data,dict) or not data.get('summary') or not data.get('identity'): raise RuntimeError('Not a valid PC Intake result')
        self.q.put(('progress',('Result validated',100))); self.q.put(('imported',data)); return ''

    def export_results(self):
        if not self.results: self.set_status('No result to export'); return
        self.show('UsbPage',mode='export')
    def write_report(self):
        self.show('BusyPage',title='Exporting Report'); self.run_bg(self._write_report)
    def _write_report(self):
        d=self.resolve_selected(True); outdir=os.path.join(d['mountpoint'],'BENCH_HERO','REPORTS'); os.makedirs(outdir,exist_ok=True)
        ident=self.results.get('identity',{}); model='-'.join(str(ident.get('model') or 'PC').split())[:36]
        stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S'); stem=f'PC_INTAKE_{model}_{stamp}'
        js=os.path.join(outdir,stem+'.json'); txt=os.path.join(outdir,stem+'.txt')
        self.q.put(('progress',('Writing JSON',35))); self._atomic(js,json.dumps(self.results,indent=2,ensure_ascii=False).encode())
        self.q.put(('progress',('Writing technician report',70))); self._atomic(txt,self.ticket_summary().encode())
        subprocess.run(['sync'],timeout=15)
        if not os.path.getsize(js) or not os.path.getsize(txt): raise RuntimeError('Report verification failed')
        self.q.put(('progress',('Export verified — safe to remove',100))); return 'Exported '+os.path.basename(txt)
    def _atomic(self,path,data):
        tmp=path+'.tmp'
        with open(tmp,'wb') as f: f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
    def ticket_summary(self):
        if not self.results: return 'No PC intake result.'
        s=self.results.get('summary',{}); i=self.results.get('identity',{}); lines=[
          'PC Intake completed.',f"{i.get('manufacturer','')} {i.get('model','')}".strip(),
          f"Passed: {s.get('passed',0)}  Warnings: {s.get('warnings',0)}  Failed: {s.get('failed',0)}",'']
        findings=s.get('top_findings') or []
        if findings:
            lines.append('Findings:')
            for f in findings: lines.append(f"- [{f.get('state','UNKNOWN')}] {f.get('title','')}: {f.get('detail','')}")
        lines += ['', 'Recommended next step:',str(s.get('recommendation') or 'Review full report.')]
        completed=[f"- {k}: {v['status']}"+(f" — {v['note']}" if v['note'] else '') for k,v in self.manual.items() if v['status']!='NOT TESTED' or v['note']]
        if completed: lines += ['','Manual tests:']+completed
        return '\n'.join(lines)
    def close(self):
        try:
            if self.receiver:self.receiver.shutdown();self.receiver.server_close()
        except Exception:pass
        self.destroy(); sys.exit(0)

class Page(tk.Frame):
    def __init__(self,parent): super().__init__(parent,bg=BG_NORMAL); self.app=parent.master
    def on_show(self,**ctx): pass
    def button(self,parent,text,cmd,bg=BG_CARD): return tk.Button(parent,text=text,font=self.app.f_btn,bg=bg,fg=FG_MAIN,activebackground=BG_CHIP,bd=2,command=cmd)

class HomePage(Page):
    def __init__(self,p):
        super().__init__(p); grid=tk.Frame(self,bg=BG_NORMAL); grid.pack(fill='both',expand=True,padx=4,pady=4)
        items=[('CREATE\nCOLLECTOR USB',self.app.create_collector),('IMPORT\nRESULT',lambda:self.app.show('UsbPage',mode='import')),
               ('WAIT FOR\nWIRELESS RESULT',self.waiting),('VIEW LAST\nRESULT',self.last)]
        for n,(text,cmd) in enumerate(items):
            b=self.button(grid,text,cmd); b.grid(row=n//2,column=n%2,sticky='nsew',padx=7,pady=7)
        for x in (0,1): grid.columnconfigure(x,weight=1)
        for y in (0,1): grid.rowconfigure(y,weight=1)
    def waiting(self):
        self.app.set_status(f'Waiting for collector at http://{self.app._local_ip()}:{RECEIVER_PORT}')
    def last(self):
        if self.app.results:self.app.show('SummaryPage')
        else:self.app.set_status('No imported result yet')

class UsbPage(Page):
    def __init__(self,p):
        super().__init__(p); self.mode='import'; self.title=tk.StringVar()
        tk.Label(self,textvariable=self.title,font=self.app.f_btn,bg=BG_NORMAL,fg=FG_MAIN).pack(anchor='w',padx=6,pady=(2,3))
        wrap=tk.Frame(self,bg=BG_NORMAL); wrap.pack(fill='both',expand=True)
        self.canvas=tk.Canvas(wrap,bg=BG_NORMAL,highlightthickness=0); self.inner=tk.Frame(self.canvas,bg=BG_NORMAL)
        self.canvas.create_window((0,0),window=self.inner,anchor='nw'); self.inner.bind('<Configure>',lambda e:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.pack(side='left',fill='both',expand=True); sb=tk.Scrollbar(wrap,command=self.canvas.yview,width=10); sb.pack(side='right',fill='y'); self.canvas.configure(yscrollcommand=sb.set)
        bottom=tk.Frame(self,bg=BG_NORMAL); bottom.pack(fill='x')
        self.button(bottom,'REFRESH',self.app.refresh_usb).pack(side='left',padx=6,pady=4)
        self.go=self.button(bottom,'CONTINUE',self.continue_); self.go.pack(side='right',padx=6,pady=4)
        self._bind_scroll(self.canvas); self._bind_scroll(self.inner)
    def _bind_scroll(self,w):
        w.bind('<ButtonPress-1>',lambda e:self.canvas.scan_mark(e.x,e.y)); w.bind('<B1-Motion>',lambda e:self.canvas.scan_dragto(e.x,e.y,gain=1))
    def on_show(self,mode='import'):
        self.mode=mode; self.app.selected=None
        self.title.set({'collector':'SELECT USB FOR COLLECTOR','import':'SELECT USB TO IMPORT','export':'SELECT USB FOR EXPORT'}.get(mode,'SELECT USB'))
        self.render(self.app.usbs); self.app.refresh_usb()
    def render(self,rows):
        for w in self.inner.winfo_children(): w.destroy()
        if not rows:
            tk.Label(self.inner,text='NO USB DRIVE DETECTED\nConnect a USB drive. The list refreshes automatically.',font=self.app.f_body,bg=BG_NORMAL,fg=FG_DIM,justify='center').pack(pady=70,padx=80)
            return
        for d in rows:
            card=tk.Frame(self.inner,bg=BG_CARD,highlightbackground=BORDER_DIM,highlightthickness=1); card.pack(fill='x',padx=5,pady=4)
            name=(d.get('label') or d.get('model') or d.get('name'))
            info=f"{fmt(d.get('size'))} · {d.get('fstype','?').upper()} · {fmt(d.get('free'))} free\n{d.get('mountpoint') or 'Not mounted'} · {'Writable' if d.get('writable') else 'Read-only / unmounted'}"
            tk.Label(card,text=name,font=self.app.f_body,bg=BG_CARD,fg=FG_MAIN,anchor='w').pack(side='left',fill='x',expand=True,padx=8,pady=8)
            tk.Label(card,text=info,font=self.app.f_small,bg=BG_CARD,fg=FG_DIM,justify='left').pack(side='left',padx=4)
            self.button(card,'SELECT',lambda x=d:self.select(x),BG_CHIP).pack(side='right',padx=8,pady=7)
            for w in card.winfo_children()+[card]: self._bind_scroll(w)
        if len(rows)==1:self.select(rows[0])
    def select(self,d): self.app.selected=d; self.app.set_status('Selected '+(d.get('label') or d.get('path')))
    def continue_(self):
        if not self.app.selected:self.app.set_status('Select a USB drive first');return
        if self.mode=='collector':self.app.write_collector()
        elif self.mode=='export':self.app.write_report()
        else:
            try: found=self.app.find_packages(self.app.selected)
            except Exception as e:self.app.set_status(str(e));return
            self.app.show('ImportPage',packages=found)

class ImportPage(Page):
    def __init__(self,p):
        super().__init__(p); tk.Label(self,text='SELECT RESULT PACKAGE',font=self.app.f_btn,bg=BG_NORMAL,fg=FG_MAIN).pack(anchor='w',padx=6)
        self.list=tk.Frame(self,bg=BG_NORMAL); self.list.pack(fill='both',expand=True,pady=5)
    def on_show(self,packages=None):
        for w in self.list.winfo_children():w.destroy()
        if not packages: tk.Label(self.list,text='No compatible PC Intake result packages found.',font=self.app.f_body,bg=BG_NORMAL,fg=FG_DIM).pack(pady=80); return
        for item in packages[:4]:
            b=self.button(self.list,f"{item['name']}\n{fmt(item['size'])}",lambda p=item['path']:self.app.import_package(p)); b.pack(fill='x',padx=10,pady=5)

class SummaryPage(Page):
    def __init__(self,p):
        super().__init__(p); self.head=tk.Label(self,font=self.app.f_btn,bg=BG_NORMAL,fg=FG_MAIN,justify='left'); self.head.pack(anchor='w',padx=8,pady=4)
        self.find=tk.Label(self,font=self.app.f_body,bg=BG_CARD,fg=FG_DIM,justify='left',anchor='nw',wraplength=750); self.find.pack(fill='both',expand=True,padx=8,pady=4)
        row=tk.Frame(self,bg=BG_NORMAL); row.pack(fill='x')
        for text,cmd in [('DETAILS',lambda:self.app.show('DetailsPage')),('MANUAL',lambda:self.app.show('ManualPage')),('EXPORT',self.app.export_results)]: self.button(row,text,cmd).pack(side='left',expand=True,fill='x',padx=4,pady=3)
    def on_show(self,**x):
        r=self.app.results
        if not r:self.head.config(text='NO SCAN DATA');self.find.config(text='Create a collector USB, run it on the Windows PC, then import the result.');return
        s=r.get('summary',{});i=r.get('identity',{});m=r.get('intake_meta') or {};v=s.get('verdict','UNKNOWN'); color={'PASS':OK,'WARN':WARN,'FAIL':FAIL}.get(v,FG_MAIN)
        label=' · '.join(x for x in (m.get('customer_name'),m.get('pc_name')) if x)
        prefix=(label+'\n') if label else ''
        self.head.config(text=prefix+f"{v}  ·  {i.get('manufacturer','')} {i.get('model','')}\nPassed {s.get('passed',0)}   Warnings {s.get('warnings',0)}   Failed {s.get('failed',0)}",fg=color)
        lines=[]
        for f in (s.get('top_findings') or [])[:4]:lines.append(f"[{f.get('state')}] {f.get('title')}: {f.get('detail')}")
        lines+=['', 'NEXT: '+str(s.get('recommendation') or 'Review details')]
        self.find.config(text='\n'.join(lines) if lines else 'No immediate automated findings.')

class DetailsPage(Page):
    CATS=('identity','windows','cpu','memory','graphics','storage','battery','devices','network','recent_problems')
    def __init__(self,p):
        super().__init__(p); self.cat='identity'; top=tk.Frame(self,bg=BG_NORMAL);top.pack(fill='x')
        for n,c in enumerate(self.CATS): tk.Button(top,text=c.upper().replace('_',' '),font=self.app.f_small,bg=BG_CARD,fg=FG_MAIN,command=lambda x=c:self.draw(x)).grid(row=n//5,column=n%5,sticky='nsew',padx=2,pady=2)
        for i in range(5):top.columnconfigure(i,weight=1)
        wrap=tk.Frame(self,bg=BG_NORMAL);wrap.pack(fill='both',expand=True,pady=3)
        self.text=tk.Text(wrap,font=self.app.f_small,bg=BG_CODE,fg=FG_MAIN,insertbackground=FG_MAIN,wrap='word',bd=0)
        self.text.pack(side='left',fill='both',expand=True); rail=tk.Frame(wrap,bg=BG_NORMAL);rail.pack(side='right',fill='y')
        tk.Button(rail,text='▲',font=self.app.f_btn,bg=BG_CARD,fg=FG_MAIN,repeatdelay=350,repeatinterval=110,command=lambda:self.text.yview_scroll(-4,'units')).pack(fill='both',expand=True)
        tk.Button(rail,text='▼',font=self.app.f_btn,bg=BG_CARD,fg=FG_MAIN,repeatdelay=350,repeatinterval=110,command=lambda:self.text.yview_scroll(4,'units')).pack(fill='both',expand=True)
        if _ui and hasattr(_ui,'bind_text_drag'):_ui.bind_text_drag(self.text)
    def on_show(self,**x):self.draw(self.cat)
    def draw(self,c):
        self.cat=c; self.text.config(state='normal');self.text.delete('1.0','end')
        data=(self.app.results or {}).get(c,{})
        self.text.insert('1.0',format_category(c,data) if data not in ({},[],None) else 'No data for this category.');self.text.config(state='disabled')


def nice_key(key): return str(key).replace('_',' ').strip().title()
def yesno(value):
    if value is True:return 'Yes'
    if value is False:return 'No'
    if value in (None,''):return 'Unknown'
    return str(value)
def human_value(key,value):
    if value in (None,''):return 'Unknown'
    if key.endswith('_bytes') or key in ('total_bytes','size_bytes','free_bytes','adapter_ram_bytes'):return fmt(value)
    if key.endswith('_percent') or key in ('health_percent','wear_percent_used'):return f'{value}%'
    if key.endswith('_c'):return f'{value} °C'
    if isinstance(value,bool):return yesno(value)
    return str(value)
def section(title,lines):
    return title.upper()+'\n'+('─'*min(44,len(title)+12))+'\n'+'\n'.join(lines)
def flat_lines(obj,skip=()):
    lines=[]
    if isinstance(obj,dict):
        for k,v in obj.items():
            if k in skip:continue
            if isinstance(v,(dict,list)):continue
            lines.append(f'{nice_key(k)}: {human_value(k,v)}')
    return lines

def format_category(cat,data):
    if cat=='identity': return section('Computer',flat_lines(data))
    if cat=='windows':
        lines=flat_lines(data,('bitlocker',)); bl=data.get('bitlocker') or []
        if bl:
            lines+=['','BITLOCKER']+[f"{x.get('mount_point','Drive')}: {x.get('protection_status','Unknown')} · {x.get('encryption_method','Unknown')}" for x in bl]
        return section('Windows',lines)
    if cat=='cpu': return section('Processor',flat_lines(data))
    if cat=='memory':
        lines=[f"Installed Memory: {fmt(data.get('total_bytes'))}"]
        for idx,m in enumerate(data.get('modules') or [],1):
            lines+=['',f'MODULE {idx}',f"Slot: {m.get('slot') or m.get('bank') or 'Unknown'}",f"Capacity: {fmt(m.get('capacity_bytes'))}",f"Manufacturer: {m.get('manufacturer') or 'Unknown'}",f"Part: {m.get('part_number') or 'Unknown'}",f"Speed: {m.get('configured_speed_mhz') or m.get('speed_mhz') or 'Unknown'} MHz"]
        return section('Memory',lines)
    if cat=='graphics':
        items=data if isinstance(data,list) else [data]; lines=[]
        for idx,g in enumerate(items,1):
            lines += [f'GPU {idx}: {g.get("name") or "Unknown"}',f'Driver: {g.get("driver_version") or "Unknown"}',f'Status: {g.get("status") or "Unknown"}',f'Resolution: {g.get("resolution") or "Unknown"}',f'Video Memory: {fmt(g.get("adapter_ram_bytes"))}','']
        return section('Graphics',lines)
    if cat=='storage':
        lines=[]
        for idx,d in enumerate(data.get('physical') or [],1):
            verdict=d.get('verdict','UNKNOWN'); lines += [f'{verdict} · DRIVE {idx}',d.get('friendly_name') or 'Unknown drive',f"Capacity: {fmt(d.get('size_bytes'))}",f"Type: {d.get('media_type') or 'Unknown'} · {d.get('bus_type') or 'Unknown'}",f"Health: {d.get('health_status') or 'Unknown'}",f"Temperature: {human_value('temperature_c',d.get('temperature_c'))}",f"Power-on Hours: {d.get('power_on_hours') if d.get('power_on_hours') is not None else 'Unknown'}",f"Wear Used: {human_value('wear_percent_used',d.get('wear_percent_used'))}"]
            reasons=d.get('reasons') or []
            if reasons: lines += ['Reason: '+'; '.join(map(str,reasons))]
            lines+=['']
        vols=data.get('volumes') or []
        if vols:
            lines += ['VOLUMES']
            for v in vols: lines.append(f"{v.get('drive','?')} · {v.get('filesystem') or 'Unknown'} · {fmt(v.get('free_bytes'))} free of {fmt(v.get('size_bytes'))}")
        return section('Storage',lines)
    if cat=='battery':
        items=data if isinstance(data,list) else [data]; lines=[]
        if not items or items==[None]:return 'No battery detected. This is normal for a desktop.'
        for idx,b in enumerate(items,1):
            health=human_value('health_percent',b.get('health_percent'))
            charge=human_value('estimated_charge_remaining',b.get('estimated_charge_remaining'))
            lines += [f"{b.get('verdict','UNKNOWN')} · BATTERY {idx}",f"Health: {health}",f"Charge: {charge}%",f"Cycles: {b.get('cycle_count') if b.get('cycle_count') is not None else 'Unknown'}",f"Design Capacity: {b.get('design_capacity_mwh') or 'Unknown'} mWh",f"Full Charge Capacity: {b.get('full_charge_capacity_mwh') or 'Unknown'} mWh",f"Status: {b.get('status') or 'Unknown'}",'']
        return section('Battery',lines)
    if cat=='devices':
        probs=data.get('problems') if isinstance(data,dict) else data
        if not probs:return 'PASS\nNo Device Manager problems were reported.'
        return section('Device Problems',[f"{x.get('friendly_name') or 'Unknown device'}\n  Class: {x.get('class') or 'Unknown'} · Status: {x.get('status') or 'Unknown'}" for x in probs])
    if cat=='network':
        lines=[f"Internet Reachable: {yesno(data.get('internet_reachable'))}",f"DNS Working: {yesno(data.get('dns_working'))}",'']
        for a in data.get('adapters') or []:lines += [a.get('name') or 'Adapter',f"  {a.get('description') or ''}",f"  Status: {a.get('status') or 'Unknown'} · Link: {a.get('link_speed') or 'Unknown'}",'']
        return section('Network',lines)
    if cat=='recent_problems':
        if not data:return 'PASS\nNo matching critical hardware or storage events were found in the collection window.'
        lines=[]
        for e in data[:50]: lines += [f"{e.get('time','')} · {e.get('provider','')} · Event {e.get('event_id','')}",'  '+str(e.get('message') or '')[:360],'']
        return section('Recent Problems',lines)
    return json.dumps(data,indent=2,ensure_ascii=False,default=str)

class ManualPage(Page):
    TESTS=('Keyboard','Trackpad','Touchscreen','Display','Backlight','Webcam','Microphone','Speakers','USB Ports','USB-C Ports','HDMI','SD Reader','Ethernet','Wi-Fi','Bluetooth','Battery Charging','Sleep / Wake','Hinges','Physical Damage')
    def __init__(self,p):
        super().__init__(p); self.index=0
        self.name=tk.Label(self,font=self.app.f_title,bg=BG_NORMAL,fg=FG_MAIN);self.name.pack(pady=8)
        self.value=tk.Label(self,font=self.app.f_btn,bg=BG_CARD,fg=FG_DIM);self.value.pack(fill='x',padx=90,pady=6,ipady=10)
        grid=tk.Frame(self,bg=BG_NORMAL);grid.pack(fill='both',expand=True,padx=30,pady=6)
        for n,s in enumerate(('PASS','FAIL','NOT TESTED','N/A')):
            self.button(grid,s,lambda x=s:self.setval(x)).grid(row=n//2,column=n%2,sticky='nsew',padx=5,pady=5)
        for i in range(2):grid.columnconfigure(i,weight=1);grid.rowconfigure(i,weight=1)
        nav=tk.Frame(self,bg=BG_NORMAL);nav.pack(fill='x')
        self.button(nav,'◀ PREV',self.prev).pack(side='left',padx=8);self.button(nav,'ADD NOTE',self.note).pack(side='left',expand=True);self.button(nav,'NEXT ▶',self.next).pack(side='right',padx=8)
    def on_show(self,**x):self.draw()
    def draw(self):
        n=self.TESTS[self.index];v=self.app.manual[n];self.name.config(text=f'{self.index+1}/{len(self.TESTS)}  {n}');self.value.config(text=v['status']+((' · '+v['note']) if v['note'] else ''))
    def setval(self,v):self.app.manual[self.TESTS[self.index]]['status']=v;self.draw()
    def prev(self):self.index=(self.index-1)%len(self.TESTS);self.draw()
    def next(self):self.index=(self.index+1)%len(self.TESTS);self.draw()
    def note(self):
        n=self.TESTS[self.index]
        if bench_keyboard: val=bench_keyboard.ask_text(self.app,'NOTE: '+n)
        else: val=''
        if val is not None:self.app.manual[n]['note']=val;self.draw()

class BusyPage(Page):
    def __init__(self,p):
        super().__init__(p);self.title=tk.StringVar();self.stage=tk.StringVar(value='Starting...');self.percent=0
        tk.Label(self,textvariable=self.title,font=self.app.f_title,bg=BG_NORMAL,fg=FG_MAIN).pack(pady=30)
        tk.Label(self,textvariable=self.stage,font=self.app.f_body,bg=BG_NORMAL,fg=FG_DIM,wraplength=720).pack(pady=10)
        self.bar=tk.Canvas(self,height=40,bg=BG_CODE,highlightthickness=1,highlightbackground=BORDER_DIM);self.bar.pack(fill='x',padx=50,pady=20)
    def on_show(self,title='Working',**x):self.title.set(title);self.progress('Starting...',5)
    def progress(self,msg,pct):
        self.stage.set(msg);self.percent=pct;self.bar.delete('all');w=max(1,self.bar.winfo_width());self.bar.create_rectangle(0,0,w*pct/100,40,fill=OK,outline='');self.bar.create_text(w/2,20,text=f'{pct}%',fill=FG_MAIN,font=self.app.f_body)

def fmt(n):
    if n in (None,''):return 'unknown'
    try:n=float(n)
    except:return str(n)
    for u in ('B','KB','MB','GB','TB'):
        if n<1024:return f'{n:.0f}{u}'
        n/=1024
    return f'{n:.0f}PB'

if __name__=='__main__': App().mainloop()
